/*TMCI18N BEGIN HEADER*/
/*TMCI18N END HEADER*/

/* AUDIT_TRAIL_MSGKEY_UPDATE
-- PROJECT : MSGKEY
-- MODULE  : SIS
-- SOURCE  : enUS
-- TARGET  : I18N
-- DATE    : Mon Aug 30 07:34:29 2010
-- MSGSIGN : #0000000000000000
END AUDIT_TRAIL_MSGKEY_UPDATE */
/* sis.h - definitions, macros and typdefs for
sissql.olb */
/* 15-FEB-94 EBERTS     created.                          */
/* CK 04/15/95 rem this line - creates problem in ALPHA VMS machines */
/* force initialization of SQLCA memory
#define SQLCA_INIT 1 */
/*
AUDIT TRAIL: 8.0
1.  I18N conversions and obsolete unused functions               PNN 12/10/2007
    Note - if a function is needed in the future use the
    tm equivalent instead of redefining it here.
    These redefinition are here for compatibility only.
AUDIT TRAIL: 8.9
PNN 08/30/2010
1.  Run rekey.
AUDIT TRAIL: 8.2.1.1
PKR 12/1/2011
1.  Adding audit trail 8.2.1.1 for General 8.5 variant work. No change to the code.
AUDIT TRAIL END
*/

/* macros to force typecasting on alpha for string functions */
#define sql_strcat(a,b)    tmstrcat((TMCHAR *)(a),(TMCHAR *)(b))
#define sql_strcmp(a,b)    tmstrcmp((TMCHAR *)(a),(TMCHAR *)(b))
#define sql_strcpy(a,b)    tmstrcpy((TMCHAR *)(a),(TMCHAR *)(b))
#define sql_strlen(a)      tmstrlen((TMCHAR *)(a))

/*
  NOTE - These functions are NOT used by Banner or there are no tm equivalent

#define sql_strncat(a,b,c) strncat((char *)(a),(char *)(b),(c))
#define sql_strchr(a,b)    strchr((char *)(a),(b))
#define sql_strrchr(a,b)   strrchr((char *)(a),(b))
#define sql_strncmp(a,b,c) strncmp((char *)(a),(char *)(b),(c))
#define sql_strncpy(a,b,c) strncpy((char *)(a),(char *)(b),(c))
#define sql_strcspn(a,b)   strcspn((char *)(a),(char *)(b))
#define sql_strspn(a,b)    strspn(char *)(a),(char *)(b))
#define sql_strpbrk(a,b)   strpbrk((char *)(a),(char *)(b))
#define sql_strtod(a,b)    strtod((const char *)(a),(char **)(b))
#define sql_atof(a)        atof((const char *)(a))
#define sql_strtok(a,b)    strtok((char *)(a),(const char *)(b))
#define sql_strtol(a,b,c)  strtol((const char *)(a),(char **)(b),c)
#define sql_atol(a)        atol((const char *)(a))
#define sql_atoi(a)        atoi((const char *)(a))
#define sql_strtoul(a,b,c) strtoul((const char *)(a),(char **)(b),c)

#define sql_capstr(str_struct) \
    str_struct.arr[str_struct.len] = '\0'

#define sql_text() \
   { \
    if (sqlstm.stmt != 0) \
      printf("[SQL TEXT:%s]", sqlstm.stmt); \
    else \
      printf("[NO SQL TEXT AVAILABLE.]\n"); \
   }
*/
