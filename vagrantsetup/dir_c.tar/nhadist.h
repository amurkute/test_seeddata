/*UnicodeSedFixed*/
/*TMCI18N BEGIN HEADER*/
#if !defined( _TMBNHADIST_H_EXISTS )
/* No Initialisation Required */                                               
#include "tmcilib.h"
static struct TMBundle _TMBNHADIST_H = {"nhadist.h",NULL,NULL,NULL,NULL};
#define _TMBNHADIST_H_EXISTS
#endif
/*TMCI18N END HEADER*/

/* AUDIT_TRAIL_TM63
-- TranMan 6.3 
-- PROJECT : PVV_TEST
-- MODULE  : NHADIST
-- SOURCE  : enUS
-- TARGET  : I18N
-- DATE    : Tue Nov 06 06:42:57 2007
END AUDIT_TRAIL_TM63 */
/* Copyright 2008 Sungard Higher Education. All rights reserved.           */
/* nhadist.h - Include Header File for Salary Distribution Reports         */


/*  AUDIT TRAIL:  2.0.10                                                    */
/*                                                                          */
/*  1. Initial Coding                                     KM   11-11-94     */
/*  ---------------------------------------------------  ----  --------     */
/* AUDIT TRAIL: 2.1.5 Supplemental                            CFIX  09/09/95  */
/* 1. Program modified by cfix.c to remedy mostly Pro*C related problems:     */
/*    split SQL concatenations joined, colons added to FETCH targets,         */
/*    file extensions added to SQL INCLUDEs, 'static' modifier removed from   */
/*    indicator variables, new logic to hadle CLOSE_CURSOR was added to SQL   */
/*    function wrappers, and object owner references were removed as part of  */
/*    BANNER2.1.  (Not all changes necessarily apply.)                        */
/*
    AUDIT TRAIL: 6.1
    1. Defect# 85295                         MT 02/04/2004
      Problem : Report abort with the Oracle error message
      Functional Impact : Parameters are now validated for a valid combination
           and if they are wrong, the process aborts with an error message.
      Technical Fix : Included couple of declarations
              invalid_parm_format variable and validate_parm_format function
              are declared.
    AUDIT TRAIL: 7.0
    1. Changes Migrated to Release 7.0           MT 03/15/2004
       Defect# 85295  Release 6.1
    AUDIT TRAIL: 8.0
    1. Enhancement to Grants Management Multi Year Encumbrance  LA 09/20/2007
       Added the following parameters:
          par_grnt_opetion
          par_grnt_form
          par_grnt_to
          par_grnt
       Added the following functions declaration:
          ins_par_grnt_code(void)
          ins_grnt_option(void)
          ins_grnt_range(void)
          ins_grnt_code(void)
          ins_grnt_s(void)
*/
/* AUDIT TRAIL END */


EXEC SQL BEGIN DECLARE SECTION;

  static BANNUMSTR(par_one_up_no)={0}/*TMCI18N CHANGED FROM ""*/;
  static TMCHAR   par_one_up_no_from[8]={0}/*TMCI18N CHANGED FROM ""*/;
  static TMCHAR  temp[31]={0}/*TMCI18N CHANGED FROM ""*/;
  static TMCHAR  one_up_no_msg[31]={0}/*TMCI18N CHANGED FROM ""*/;
  static TMCHAR   valid_ind[2]={0}/*TMCI18N CHANGED FROM ""*/;
  static BANNUMSTR(par_line_count)={0}/*TMCI18N CHANGED FROM ""*/;
  static TMCHAR   par_line_count_from[8]={0}/*TMCI18N CHANGED FROM ""*/;
  static TMCHAR   parm_ind[2]={0}/*TMCI18N CHANGED FROM ""*/;
  static TMCHAR   are_parameters_valid[4]={0}/*TMCI18N CHANGED FROM ""*/; /*  all parms valid flag */
  static TMCHAR   reenter_parm[2]={0}/*TMCI18N CHANGED FROM ""*/;        /*  re-enter parameters flag */
  static TMCHAR  parameter_msg[100]={0}/*TMCI18N CHANGED FROM ""*/;       /*  parameter error msg */
  static TMCHAR  parm[31]={0}/*TMCI18N CHANGED FROM ""*/;                /*  parameter value */
  static TMCHAR  parm_msg[66]={0}/*TMCI18N CHANGED FROM ""*/;            /*  parameter message */
  static TMCHAR  parm_name[31]={0}/*TMCI18N CHANGED FROM ""*/;           /*  parameter name */
  static TMCHAR   parm_no[3]={0}/*TMCI18N CHANGED FROM ""*/;             /*  parameter number */
  static TMCHAR   parm_source[8]={0}/*TMCI18N CHANGED FROM ""*/;         /*  parameter source */
  static TMCHAR  par_from[132]={0}/*TMCI18N CHANGED FROM ""*/;
  static TMCHAR   par_report_type[2]={0}/*TMCI18N CHANGED FROM ""*/;
  static TMCHAR   par_sort_option[2]={0}/*TMCI18N CHANGED FROM ""*/;
  static TMCHAR  par_example_date[12]={0}/*TMCI18N CHANGED FROM ""*/;
  static TMCHAR  par_begin_date[12]={0}/*TMCI18N CHANGED FROM ""*/;
  static TMCHAR  begin_date_msg[65]={0}/*TMCI18N CHANGED FROM ""*/;
  static TMCHAR  par_end_date[12]={0}/*TMCI18N CHANGED FROM ""*/;
  static TMCHAR  end_date_msg[65]={0}/*TMCI18N CHANGED FROM ""*/;
  static TMCHAR   par_pict[3]={0}/*TMCI18N CHANGED FROM ""*/;
  static TMCHAR   all_pict[2]={0}/*TMCI18N CHANGED FROM ""*/;
  static TMCHAR   par_hier[2]={0}/*TMCI18N CHANGED FROM ""*/;
  static TMCHAR   par_fund_level[2]={0}/*TMCI18N CHANGED FROM ""*/;
  static TMCHAR   par_orgn_level[2]={0}/*TMCI18N CHANGED FROM ""*/;
  static TMCHAR   par_acct_level[2]={0}/*TMCI18N CHANGED FROM ""*/;
  static TMCHAR   par_prog_level[2]={0}/*TMCI18N CHANGED FROM ""*/;
  static TMCHAR   par_coas[2]={0}/*TMCI18N CHANGED FROM ""*/;
  static TMCHAR   par_home_coas[2]={0}/*TMCI18N CHANGED FROM ""*/;
  static TMCHAR   par_home_coas_no[3]={0}/*TMCI18N CHANGED FROM ""*/;
  static TMCHAR   home_coas[2]={0}/*TMCI18N CHANGED FROM ""*/;
  static TMCHAR   par_home_orgn_option[2]={0}/*TMCI18N CHANGED FROM ""*/;
  static TMCHAR   par_home_orgn_from[7]={0}/*TMCI18N CHANGED FROM ""*/;
  static TMCHAR   par_home_orgn_to[7]={0}/*TMCI18N CHANGED FROM ""*/;
  static TMCHAR   par_home_orgn[7]={0}/*TMCI18N CHANGED FROM ""*/;
  static TMCHAR   par_fund_option[2]={0}/*TMCI18N CHANGED FROM ""*/;
  static TMCHAR   par_fund_from[7]={0}/*TMCI18N CHANGED FROM ""*/;
  static TMCHAR   par_fund_to[7]={0}/*TMCI18N CHANGED FROM ""*/;
  static TMCHAR   par_fund[7]={0}/*TMCI18N CHANGED FROM ""*/;
  static TMCHAR   par_grnt_option[2]={0}/*TMCI18N CHANGED FROM ""*/;
  static TMCHAR  par_grnt_from[10]={0}/*TMCI18N CHANGED FROM ""*/;
  static TMCHAR  par_grnt_to[10]={0}/*TMCI18N CHANGED FROM ""*/;
  static TMCHAR  par_grnt[10]={0}/*TMCI18N CHANGED FROM ""*/;
  static TMCHAR   par_orgn_option[2]={0}/*TMCI18N CHANGED FROM ""*/;
  static TMCHAR   par_orgn_from[7]={0}/*TMCI18N CHANGED FROM ""*/;
  static TMCHAR   par_orgn_to[7]={0}/*TMCI18N CHANGED FROM ""*/;
  static TMCHAR   par_orgn[7]={0}/*TMCI18N CHANGED FROM ""*/;
  static TMCHAR   par_acct_option[2]={0}/*TMCI18N CHANGED FROM ""*/;
  static TMCHAR   par_acct_from[7]={0}/*TMCI18N CHANGED FROM ""*/;
  static TMCHAR   par_acct_to[7]={0}/*TMCI18N CHANGED FROM ""*/;
  static TMCHAR   par_acct[7]={0}/*TMCI18N CHANGED FROM ""*/;
  static TMCHAR   par_prog_option[2]={0}/*TMCI18N CHANGED FROM ""*/;
  static TMCHAR   par_prog_from[7]={0}/*TMCI18N CHANGED FROM ""*/;
  static TMCHAR   par_prog_to[7]={0}/*TMCI18N CHANGED FROM ""*/;
  static TMCHAR   par_prog[7]={0}/*TMCI18N CHANGED FROM ""*/;
  static TMCHAR   par_ecls[3]={0}/*TMCI18N CHANGED FROM ""*/;
  static TMCHAR   all_ecls[2]={0}/*TMCI18N CHANGED FROM ""*/;
  static TMCHAR  par_empl_id[10]={0}/*TMCI18N CHANGED FROM ""*/;
  static TMCHAR   all_empl[2]={0}/*TMCI18N CHANGED FROM ""*/;
  
  static TMCHAR   par_report_type_no[3]={0}/*TMCI18N CHANGED FROM ""*/;
  static TMCHAR   par_sort_option_no[3]={0}/*TMCI18N CHANGED FROM ""*/;
  static TMCHAR   par_begin_date_no[3]={0}/*TMCI18N CHANGED FROM ""*/;
  static TMCHAR   par_end_date_no[3]={0}/*TMCI18N CHANGED FROM ""*/;
  static TMCHAR   par_pict_no[3]={0}/*TMCI18N CHANGED FROM ""*/;
  static TMCHAR   par_hier_no[3]={0}/*TMCI18N CHANGED FROM ""*/;
  static TMCHAR   par_fund_level_no[3]={0}/*TMCI18N CHANGED FROM ""*/;
  static TMCHAR   par_orgn_level_no[3]={0}/*TMCI18N CHANGED FROM ""*/;
  static TMCHAR   par_acct_level_no[3]={0}/*TMCI18N CHANGED FROM ""*/;
  static TMCHAR   par_prog_level_no[3]={0}/*TMCI18N CHANGED FROM ""*/;
  static TMCHAR   par_coas_no[3]={0}/*TMCI18N CHANGED FROM ""*/;
  static TMCHAR   par_home_orgn_option_no[3]={0}/*TMCI18N CHANGED FROM ""*/;
  static TMCHAR   par_home_orgn_from_no[3]={0}/*TMCI18N CHANGED FROM ""*/;
  static TMCHAR   par_home_orgn_to_no[3]={0}/*TMCI18N CHANGED FROM ""*/;
  static TMCHAR   par_home_orgn_no[3]={0}/*TMCI18N CHANGED FROM ""*/;
  static TMCHAR   par_fund_option_no[3]={0}/*TMCI18N CHANGED FROM ""*/;
  static TMCHAR   par_fund_from_no[3]={0}/*TMCI18N CHANGED FROM ""*/;
  static TMCHAR   par_fund_to_no[3]={0}/*TMCI18N CHANGED FROM ""*/;
  static TMCHAR   par_fund_no[3]={0}/*TMCI18N CHANGED FROM ""*/;
  static TMCHAR   par_grnt_option_no[3]={0}/*TMCI18N CHANGED FROM ""*/;
  static TMCHAR   par_grnt_from_no[3]={0}/*TMCI18N CHANGED FROM ""*/;
  static TMCHAR   par_grnt_to_no[3]={0}/*TMCI18N CHANGED FROM ""*/;
  static TMCHAR   par_grnt_no[3]={0}/*TMCI18N CHANGED FROM ""*/;
  static TMCHAR   par_orgn_option_no[3]={0}/*TMCI18N CHANGED FROM ""*/;
  static TMCHAR   par_orgn_from_no[3]={0}/*TMCI18N CHANGED FROM ""*/;
  static TMCHAR   par_orgn_to_no[3]={0}/*TMCI18N CHANGED FROM ""*/;
  static TMCHAR   par_orgn_no[3]={0}/*TMCI18N CHANGED FROM ""*/;
  static TMCHAR   par_acct_option_no[3]={0}/*TMCI18N CHANGED FROM ""*/;
  static TMCHAR   par_acct_from_no[3]={0}/*TMCI18N CHANGED FROM ""*/;
  static TMCHAR   par_acct_to_no[3]={0}/*TMCI18N CHANGED FROM ""*/;
  static TMCHAR   par_acct_no[3]={0}/*TMCI18N CHANGED FROM ""*/;
  static TMCHAR   par_prog_option_no[3]={0}/*TMCI18N CHANGED FROM ""*/;
  static TMCHAR   par_prog_from_no[3]={0}/*TMCI18N CHANGED FROM ""*/;
  static TMCHAR   par_prog_to_no[3]={0}/*TMCI18N CHANGED FROM ""*/;
  static TMCHAR   par_prog_no[3]={0}/*TMCI18N CHANGED FROM ""*/;
  static TMCHAR   par_ecls_no[3]={0}/*TMCI18N CHANGED FROM ""*/;
  static TMCHAR   par_empl_id_no[3]={0}/*TMCI18N CHANGED FROM ""*/;
  static int     invalid_parm_format=0;  

/* Standard variables */

  static TMCHAR  institution[31]={0}/*TMCI18N CHANGED FROM ""*/;         /*  institution name */
  static TMCHAR   finance_installed[2]={0}/*TMCI18N CHANGED FROM ""*/;
  static TMCHAR   hr_installed[2]={0}/*TMCI18N CHANGED FROM ""*/;
  static int     linelimit=55;           /*  lines on a page */
  static int  lineno=0;              /*  current line number */
  static BANNUMSTR(one)={0}/*TMCI18N CHANGED FROM ""*/;                 /*  value of 1 */
  static BANNUMSTR(pageno)={0}/*TMCI18N CHANGED FROM ""*/;              /*  current page number */
  static BANNUMSTR(rec_count)={0}/*TMCI18N CHANGED FROM ""*/;           /*  used to count things */
  static TMCHAR  rptname[31]={0}/*TMCI18N CHANGED FROM ""*/;             /*  report name */
  static TMCHAR  run_date[12]={0}/*TMCI18N CHANGED FROM ""*/;            /*  system date */
  static TMCHAR   run_time[9]={0}/*TMCI18N CHANGED FROM ""*/;            /*  system time */
  static TMCHAR  title_var[31]={0}/*TMCI18N CHANGED FROM ""*/;           /*  title of report */

  static TMCHAR   rpt_fund_code[7]={0}/*TMCI18N CHANGED FROM ""*/;
  static TMCHAR   rpt_fund_level[2]={0}/*TMCI18N CHANGED FROM ""*/;
  static TMCHAR   save_fund_level_1[7]={0}/*TMCI18N CHANGED FROM ""*/;
  static TMCHAR   save_fund_level_2[7]={0}/*TMCI18N CHANGED FROM ""*/;
  static TMCHAR   save_fund_level_3[7]={0}/*TMCI18N CHANGED FROM ""*/;
  static TMCHAR   save_fund_level_4[7]={0}/*TMCI18N CHANGED FROM ""*/;
  static TMCHAR   save_fund_level_5[7]={0}/*TMCI18N CHANGED FROM ""*/;
  static TMCHAR   rpt_prog_code[7]={0}/*TMCI18N CHANGED FROM ""*/;
  static TMCHAR   rpt_prog_level[2]={0}/*TMCI18N CHANGED FROM ""*/;
  static TMCHAR   save_prog_level_1[7]={0}/*TMCI18N CHANGED FROM ""*/;
  static TMCHAR   save_prog_level_2[7]={0}/*TMCI18N CHANGED FROM ""*/;
  static TMCHAR   save_prog_level_3[7]={0}/*TMCI18N CHANGED FROM ""*/;
  static TMCHAR   save_prog_level_4[7]={0}/*TMCI18N CHANGED FROM ""*/;
  static TMCHAR   save_prog_level_5[7]={0}/*TMCI18N CHANGED FROM ""*/;
  static TMCHAR   rpt_acct_code[7]={0}/*TMCI18N CHANGED FROM ""*/;
  static TMCHAR   rpt_acct_level[2]={0}/*TMCI18N CHANGED FROM ""*/;
  static TMCHAR   save_acct_level_1[7]={0}/*TMCI18N CHANGED FROM ""*/;
  static TMCHAR   save_acct_level_2[7]={0}/*TMCI18N CHANGED FROM ""*/;
  static TMCHAR   save_acct_level_3[7]={0}/*TMCI18N CHANGED FROM ""*/;
  static TMCHAR   save_acct_level_4[7]={0}/*TMCI18N CHANGED FROM ""*/;
  static TMCHAR   rpt_orgn_code[7]={0}/*TMCI18N CHANGED FROM ""*/;
  static TMCHAR   rpt_orgn_level[2]={0}/*TMCI18N CHANGED FROM ""*/;
  static TMCHAR  rpt_orgn_title[36]={0}/*TMCI18N CHANGED FROM ""*/;
  static TMCHAR   save_orgn_level_1[7]={0}/*TMCI18N CHANGED FROM ""*/;
  static TMCHAR   save_orgn_level_2[7]={0}/*TMCI18N CHANGED FROM ""*/;
  static TMCHAR   save_orgn_level_3[7]={0}/*TMCI18N CHANGED FROM ""*/;
  static TMCHAR   save_orgn_level_4[7]={0}/*TMCI18N CHANGED FROM ""*/;
  static TMCHAR   save_orgn_level_5[7]={0}/*TMCI18N CHANGED FROM ""*/;
  static TMCHAR   save_orgn_level_6[7]={0}/*TMCI18N CHANGED FROM ""*/;
  static TMCHAR   save_orgn_level_7[7]={0}/*TMCI18N CHANGED FROM ""*/;
  static TMCHAR   save_orgn_level_8[7]={0}/*TMCI18N CHANGED FROM ""*/;






         short   Ind_01;
         short   Ind_02;
         short   Ind_03;
         short   Ind_04;
         short   Ind_05;
         short   Ind_06;
         short   Ind_07;
         short   Ind_08;
         short   Ind_09;
         short   Ind_10;

EXEC SQL END DECLARE SECTION;

/* Function Prototypes */

static int gen_one_up_no(int mode);
static int validate_one_up_no(int mode);
static void del_parm(void);
static void get_parameters(void);
static int add_19(int mode);
static int add_20(int mode);
static void retrieve_parms(void);
static void retr_coas_parms_body(void);
static int sel_gjbprun_par(int mode,TMCHAR par_no[4], TMCHAR par_value[35]);
static int sel_coas_gjbprun_par(int mode,TMCHAR coas[2],TMCHAR par_no[4], TMCHAR par_value[35]) ;
static void ins_coas_parm(TMCHAR parm_no[4], TMCHAR parm_value[35]);
static void ins_par_pict(void);
static void ins_par_ecls_code(void);
static void ins_par_empl_id(void);
static void ins_par_coas_code(void);
static void ins_par_home_orgn(void);
static void ins_par_home_orgn_s(void);
static void ins_par_fund_code(void);
static void ins_par_grnt_code(void);
static void ins_par_orgn_s(void);
static void ins_par_acct_s(void);
static void ins_par_prog_s(void);
static void ins_par_fund_s(void);
static void ins_par_grnt_s(void);
static void ins_par_orgn_code(void);
static void ins_par_acct_code(void);
static void ins_par_prog_code(void);
static void ins_pict_code(void);
static void ins_ecls_code(void);
static void ins_empl_id(void);
static void ins_coas_code(void);
static void ins_fund_option(void);
static void ins_fund_range(void);
static void ins_fund_code(void);
static void ins_fund_s(void);
static void ins_grnt_option(void);
static void ins_grnt_range(void);
static void ins_grnt_code(void);
static void ins_grnt_s(void);
static void ins_orgn_s(void);
static void ins_acct_s(void);
static void ins_prog_s(void);
static void ins_orgn_option(void);
static void ins_orgn_range(void);
static void ins_orgn_code(void);
static void ins_acct_option(void);
static void ins_acct_range(void);
static void ins_acct_code(void);
static void ins_prog_option(void);
static void ins_prog_range(void);
static void ins_prog_code(void);
static void ins_home_orgn(void);
static void ins_home_orgn_s(void);
static void ins_home_orgn_range(void);
static void ins_home_orgn_option(void);
static int sel_home_orgn_option (int mode);
static void get_home_orgn (void);
static void validate_dates(void);
static void missing_parm(void);
static void control_home_info(void);
static void retr_home_parms(void);
static int parm_sel(int mode,TMCHAR parm_no[4],TMCHAR parm_value[32]);
static int coas_parm_sel(int mode,TMCHAR parm_no[4], TMCHAR parm_value[32], TMCHAR parm_source[32]);
static int home_parm_sel(int mode,TMCHAR parm_no[4], TMCHAR parm_value[32], TMCHAR parm_source[32]);
static void page_heading(void);
static void del_colr(void);
static void del_hier(void);
static int sel_coas(int mode);     
static void coas_parm_body(void);
static void control_info(void);
static void parm_body(TMCHAR parm_name[32],TMCHAR parm_no[4],TMCHAR parm_dest[32]);
static void home_parm_body(TMCHAR parm_name[32],TMCHAR parm_no[4],TMCHAR parm_dest[32]);
static void parm_sel_body(TMCHAR parm_name[32],TMCHAR parm_no[4]);
static void fund_hier(void);
static void fund_body1(void);
static void fund_body2(void);
static void fund_body3(void);
static void fund_body4(void);
static void fund_body5(void);
static void spec_fund_hier(void);
static void level_fund_hier_1(void);
static void level_fund_hier_2(void);
static void level_fund_hier_3(void);
static void level_fund_hier_4(void);
static void level_fund_hier_5(void);
static int sel_spec_fundhier(int mode);
static int sel_all_fundhier(int mode);
static void ins_fgrfdhc(void);
static void ins_fund_exists(void);
static void prog_hier(void);
static void prog_body1(void);
static void prog_body2(void);
static void prog_body3(void);
static void prog_body4(void);
static void prog_body5(void);
static void spec_prog_hier(void);
static void level_prog_hier_1(void);
static void level_prog_hier_2(void);
static void level_prog_hier_3(void);
static void level_prog_hier_4(void);
static void level_prog_hier_5(void);
static void prog_hier(void);
static int sel_spec_proghier(int mode);
static int sel_all_proghier(int mode);
static void ins_fgrpghc(void);
static void ins_prog_exists(void);
static void acct_hier(void);
static void acct_body1(void);
static void acct_body2(void);
static void acct_body3(void);
static void acct_body4(void);
static void spec_acct_hier(void);
static void level_acct_hier_1(void);
static void level_acct_hier_2(void);
static void level_acct_hier_3(void);
static void level_acct_hier_4(void);
static void acct_hier(void);
static int sel_spec_accthier(int mode);
static int sel_all_accthier(int mode);
static void ins_fgrathc(void);
static void ins_acct_exists(void);
static void orgn_hier(void);
static void orgn_body1(void);
static void orgn_body2(void);
static void orgn_body3(void);
static void orgn_body4(void);
static void orgn_body5(void);
static void orgn_body6(void);
static void orgn_body7(void);
static void orgn_body8(void);

static void spec_orgn_hier(void);
static void level_orgn_hier_1(void);
static void level_orgn_hier_2(void);
static void level_orgn_hier_3(void);
static void level_orgn_hier_4(void);
static void level_orgn_hier_5(void);
static void level_orgn_hier_6(void);
static void level_orgn_hier_7(void);
static void level_orgn_hier_8(void);

static void orgn_hier(void);
static int sel_spec_orgnhier(int mode);
static int sel_all_orgnhier(int mode);
static void ins_fgrorhc(void);
static void ins_orgn_exists(void);
static void validate_parm_format(TMCHAR parm_no[3], TMCHAR in_value[10]);