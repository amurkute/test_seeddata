/******************************************************************************/
/* UOQADDR.C  Copyright (c) SCT Corporation 1995.  All rights reserved.       */
/******************************************************************************/

/***************************************************/
/*                                                 */
/*       CONFIDENTIAL BUSINESS INFORMATION         */
/*                                                 */
/*      **********************************         */
/*                                                 */
/*  THIS PROGRAM IS PROPRIETARY INFORMATION OF     */
/* SYSTEMS AND COMPUTER TECHNOLOGY CORPORATION     */
/* AND IS NOT TO BE COPIED, REPRODUCED, LENT OR    */
/* DISPOSED OF, NOR USED FOR ANY PURPOSE OTHER     */
/* THAN THAT FOR WHICH IT IS SPECIFICALLY PROVIDED */
/* WITHOUT THE WRITTEN PERMISSION OF SAID COMPANY  */
/*                                                 */
/***************************************************/

/*------------------------------------------------------------------------*/
/* UOQADDR.C                                                              */
/* Get Mailing Address Subroutine                                         */
/*                                                                        */
/* AUDIT TRAIL                                        INIT    DATE        */
/* -------------------------------------------------  ----  --------      */
/* Release: 2.1.7.X                                                       */
/* 1. Ran CFIX on UOQADDR because of Bug #9923,       WW    25-NOV-1997   */
/*    see Audit Trail for Release 2.0.3.X.1.                              */
/*                                                                        */
/* AUDIT TRAIL                                        INIT    DATE        */
/* -------------------------------------------------  ----  --------      */
/* Release: 2.0.3.X                                                       */
/* 1. Bug # 9923 (Same as Char. Bug #9922) -          WW    25-NOV-1997   */
/*    Added one parameter in GetMailAddress                               */
/*    function to receive the address selection                           */
/*    date from the calling programs.                                     */
/*    This allows the function to make comparison  			  */
/*    between UCRADDR_FROM_DATE/UCRADDR_TO_DATE and 			  */
/*    Address selection date instead of to compare                        */
/*    with the SYSDATE.                 				  */	
/*									  */	
/* AUDIT TRAIL                                        INIT    DATE        */
/* -------------------------------------------------  ----  --------      */
/* Release: 2.0.3.4                                                       */
/* 1.  Bug 8532 - Added if condition to case          JBJ   25-FEB-1997   */
/*     statement in GetMailAddress function.  This                        */
/*     allows the function to go to next step in                          */
/*     the address hierarchy if no rows are found.                        */
/*                                                                        */
/* AUDIT TRAIL                                        INIT    DATE        */
/* -------------------------------------------------  ----  --------      */
/* Release: 2.0.3                                                         */
/*                                                                        */
/* 1.  Initial Version                                RMM   30-JAN-1995   */
/* 2.  When no account could be found the indicator   RMM   24-MAY-1995   */
/*     variables where not being set to -1                                */
/*                                                                        */
/* ********************************************************************** */
/* AUDIT TRAIL: 8.0 */
/* AUDIT TRAIL END */
/*                                                                        */
/*    This subroutine is used to get the proper mailing address.          */
/*                                                                        */
/* Parameters:                                                            */
/*             N/A                                                        */
/*                                                                        */
/* Tables:                                                                */
/*             UCBCUST - customer table                           */
/*             UCBPREM - premises table                           */
/*             UCRADDR - address table                            */
/*                                                                        */
/*             SPRCOLR  - collector table                          */
/*                                                                        */
/* Views:                                                                 */
/*             UCVADDS - address view                             */
/*                                                                        */
/*------------------------------------------------------------------------*/

/* Column Definitions for Table: ucvadds                                  */
/* NOTE: If these are defined in the calling program, they will need to   */
/*       be commented out.                                                */

EXEC SQL BEGIN DECLARE SECTION;
  static CHAR21  ucvadds_city           = "";
  static CHAR61  ucvadds_last_name      = "";
  static CHAR61  ucvadds_print_name     = "";
  static CHAR51  ucvadds_street_address = "";
  static CHAR31  ucvadds_street_line1   = "";
  static CHAR31  ucvadds_street_line2   = "";
  static CHAR31  ucvadds_street_line3   = "";
  static CHAR7   ucvadds_street_number  = "";
  static CHAR3   ucvadds_pdir_code_pre  = "";
  static CHAR31  ucvadds_street_name    = "";
  static CHAR7   ucvadds_ssfx_code      = "";
  static CHAR3   ucvadds_pdir_code_post = "";
  static CHAR7   ucvadds_utyp_code      = "";
  static CHAR7   ucvadds_unit           = "";
  static CHAR4   ucvadds_stat_code      = "";
  static CHAR11  ucvadds_zip            = "";
  static CHAR3   ucvadds_delivery_point = "";
  static CHAR5   ucvadds_car_rt         = "";
  static CHAR6   ucvadds_natn_code      = "";
  static CHAR29  ucvadds_nation         = "";

  short   sInd_01 = 0;
  short   sInd_02 = 0;
  short   sInd_03 = 0;
  short   sInd_04 = 0;
  short   sInd_05 = 0;
  short   sInd_06 = 0;
  short   sInd_07 = 0;
  short   sInd_08 = 0;
  short   sInd_09 = 0;
  short   sInd_10 = 0;
  short   sInd_11 = 0;
  short   sInd_12 = 0;
  short   sInd_13 = 0;
  short   sInd_14 = 0;
  short   sInd_15 = 0;
  short   sInd_16 = 0;
  short   sInd_17 = 0;
  short   sInd_18 = 0;
  short   sInd_19 = 0;
  short   sInd_20 = 0;
EXEC SQL END DECLARE SECTION;

int GetMailAddress (long, char *, char *);

static short ReadPremisesTable (long, char *);
static short ReadAddrTable     (long, char *, char *);
static short ReadAddsView      (long);

/******************************************************************************
*                                                                             *
*   GetMailAddress()                                                          *
*                                                                             *
*   Description.....: This procedure will get all the mailing address         *
*                     information for the given customer.  This procedure     *
*                     attempts to get the address in the following way:       *
*                                                                             *
*                 1)  If UCRACCT_PREM_CODE_BILL_ADDR exists it uses it and    *
*                     gets the address from the premises table                *
*                                                                             *
*                 2)  If UCRACCT_ADDR_ATYP_CODE exists it uses it and gets    *
*                     the address from the UCRADDR table                      *
*                                                                             *
*                 3)  If a row exists in UCVADDS for the given customer code  *
*                     it gets the address from there                          *
*                                                                             *
*                 4)  If all else fails it gets the address from the premises *
*                     table                                                   *
*                                                                             *
*                     Inorder to get a row from UCVADDS, SPRCOLR must  *
*                     have been loaded with the current session ID, address   *
*                     type code(s), and address selection date(s).            *
*                                                                             *
*   Parameters:                                                               *
*                                                                             *
*        Type             Name                     Description                *
*       ------------   --------------    --------------------------------     *
*        long           lCustCode         Customer Code On The Account Record *
*        char *         pszPremCode       Premises Code On The Account Record *
*        char *         pszAddrDate       Address Selection Date From GJBPRUN *
*                                                                             *
*   Return Values:                                                            *
*                                                                             *
*        Type       Value     #define              Description                *
*       --------    -----   ----------------   --------------------------     *
*        int         1       TRUE               Completed successfully        *
*                    0       FALSE              An error occurred             *
*                                                                             *
******************************************************************************/
int GetMailAddress(long lCustCode,
                   char *pszPremCode, 
                   char *pszAddrDate)
     {
     EXEC SQL BEGIN DECLARE SECTION;
        CHAR8   szLocalPremCode        = "";
        CHAR8   szPremCodeBillAddr     = "";
        CHAR3   szAddrAtypCode         = "";
        long    lLocalCustCode         = lCustCode;
        short   sAddsCount             = 0;
     EXEC SQL END   DECLARE SECTION;
     short    sAtyp          = 0;
     short    sNoRowsFound   = FALSE;

     /*----------------------------------------------------------------------*/
     /* Make a local copy of the premises code.                              */
     /*----------------------------------------------------------------------*/
     strcpy(szLocalPremCode, pszPremCode);

     /*----------------------------------------------------------------------*/
     /* Use the supplied cust code and prem code to see if the account       */
     /* record has an alternate premises code or an address type code.       */
     /*----------------------------------------------------------------------*/
     EXEC SQL
          SELECT ucracct_prem_code_bill_addr,
                 ucracct_addr_atyp_code
            INTO :szPremCodeBillAddr     :sInd_01,
                 :szAddrAtypCode         :sInd_02
            FROM ucracct
           WHERE ucracct_cust_code = :lLocalCustCode
             AND ucracct_prem_code = :szLocalPremCode;
     POSTORA;

     /*----------------------------------------------------------------------*/
     /* If no account can be found then force the indicators to -1 so the    */
     /* algorythm will fall through to trying to use UCVADDS                 */
     /*----------------------------------------------------------------------*/
     if (NO_ROWS_FOUND)
          {
          sInd_01 = -1;
          sInd_02 = -1;
          }

     /*----------------------------------------------------------------------*/
     /* Set a switch to tell which cursor will be used to get the address    */
     /*----------------------------------------------------------------------*/
     if (sInd_01 != -1)                  /* Use Alternate Premises Address   */
          sAtyp = 1;
     else if (sInd_02 != -1)             /* Use Address Type Code On Account */
          sAtyp = 2;
     else                                /* Try The UCVADDS View             */
          {
          /*-----------------------------------------------------------------*/
          /* Check to see if a row exists in the view                        */
          /*-----------------------------------------------------------------*/
          EXEC SQL
               SELECT COUNT(*)
                 INTO :sAddsCount   :sInd_01
                 FROM ucvadds
                WHERE ucvadds_cust_code = :lLocalCustCode;

          /*-----------------------------------------------------------------*/
          /* If a row exists in the view use it, otherwise use the premises  */
          /*-----------------------------------------------------------------*/
          if (sInd_01 != -1 && sAddsCount)
               sAtyp = 3;                /* Use UCVADDS Address Row          */
          else
               sAtyp = 4;                /* Default To The Premises Address  */
          }

     /*----------------------------------------------------------------------*/
     /* Using the address type switch, read the appropriate table            */
     /*----------------------------------------------------------------------*/
     switch (sAtyp)
          {
          case 1:
               sNoRowsFound = ReadPremisesTable(lCustCode, szPremCodeBillAddr);
               break;

          case 2:
	       /*-----------------------------------------------------*/ 
	       /* Bug #9923 -- Add one more parameter -- pszAddrDate  */     
	       /* to pass the address selection date.      WW         */
	       /*---------------------------------------------------- */
               sNoRowsFound = ReadAddrTable(lCustCode, szAddrAtypCode, 
                                            pszAddrDate);
               /* Bug 8532 Added if condition.  Allows case statement to
                * fall through to the next case if no rows are found. */
               if (!sNoRowsFound) 
	 	  break;
          case 3:
               sNoRowsFound = ReadAddsView(lCustCode);
               /* Bug 8532 Added if condition.  Allows case statement to
                * fall through to the next case if no rows are found. */
               if (!sNoRowsFound) break;

          case 4:
               sNoRowsFound = ReadPremisesTable(lCustCode, pszPremCode);
               break;

          default:
               sNoRowsFound = TRUE;
               break;
          }

     /*----------------------------------------------------------------------*/
     /* If nothing was found then null out the host variables and return a   */
     /* failure indicator.                                                   */
     /*----------------------------------------------------------------------*/
     if ( sNoRowsFound )
          {
          *ucvadds_last_name        = '\0';
          *ucvadds_print_name       = '\0';
          *ucvadds_street_address   = '\0';
          *ucvadds_city             = '\0';
          *ucvadds_street_number    = '\0';
          *ucvadds_pdir_code_pre    = '\0';
          *ucvadds_street_name      = '\0';
          *ucvadds_ssfx_code        = '\0';
          *ucvadds_pdir_code_post   = '\0';
          *ucvadds_stat_code        = '\0';
          *ucvadds_zip              = '\0';
          *ucvadds_delivery_point   = '\0';
          *ucvadds_car_rt           = '\0';
          *ucvadds_unit             = '\0';
          *ucvadds_utyp_code        = '\0';
          *ucvadds_street_line1     = '\0';
          *ucvadds_street_line2     = '\0';
          *ucvadds_street_line3     = '\0';
          *ucvadds_natn_code        = '\0';
          *ucvadds_nation           = '\0';
          return FALSE;
          }

     /*----------------------------------------------------------------------*/
     /* Return success                                                       */
     /*----------------------------------------------------------------------*/
     return TRUE;
     }                                                 /* end GetMailAddress */

/******************************************************************************
*                                                                             *
*   ReadPremisesTable()                                                       *
*                                                                             *
*   Description.....: Get the address information from the premises table     *
*                                                                             *
*   Parameters:                                                               *
*                                                                             *
*        Type             Name                     Description                *
*       ------------   --------------    --------------------------------     *
*        long           lCustCode         Customer Code                       *
*        char *         pszPremCode       Premises Code                       *
*                                                                             *
*   Return Values:                                                            *
*                                                                             *
*        Type       Value     #define              Description                *
*       --------    -----   ----------------   --------------------------     *
*        short       1       TRUE               Rows were found               *
*                    0       FALSE              Rows were not found           *
*                                                                             *
******************************************************************************/
static short ReadPremisesTable(long lCustCode, char *pszPremCode)
     {
     EXEC SQL BEGIN DECLARE SECTION;
        CHAR8   szLocalPremCode     = "";
        long    lLocalCustCode      = lCustCode;
     EXEC SQL END   DECLARE SECTION;
     short  sNoRowsFound = FALSE;

     /*----------------------------------------------------------------------*/
     /* Make a local copy of the premises code.                              */
     /*----------------------------------------------------------------------*/
     strcpy(szLocalPremCode, pszPremCode);

     /*----------------------------------------------------------------------*/
     /* Declare a cursor to get the premises address information.            */
     /*----------------------------------------------------------------------*/
     EXEC SQL DECLARE padr_cursor CURSOR FOR
      SELECT       ucbcust_last_name,
                   DECODE(ucbcust_first_name, '', '',
                          ucbcust_first_name || ' ')
                     || DECODE(ucbcust_middle_name, '', '',
                               SUBSTR(ucbcust_middle_name, 1, 1) || '. ')
                     || ucbcust_last_name,
                   DECODE(ucbprem_street_number, '', '',
                          ucbprem_street_number || ' ')
                     || DECODE(ucbprem_pdir_code_pre, '', '',
                               ucbprem_pdir_code_pre || ' ')
                     || ucbprem_street_name
                     || DECODE(ucbprem_ssfx_code, '', '',
                               ' ' || ucbprem_ssfx_code)
                     || DECODE(ucbprem_pdir_code_post, '', '',
                               ' ' || ucbprem_pdir_code_post),
                   ucbprem_city,
                   ucbprem_street_number,
                   ucbprem_pdir_code_pre,
                   ucbprem_street_name,
                   ucbprem_ssfx_code,
                   ucbprem_pdir_code_post,
                   ucbprem_stat_code_addr,
                   ucbprem_zipc_code,
                   ucbprem_delivery_point,
                   ucbprem_car_rt,
                   ucbprem_unit,
                   ucbprem_utyp_code,
                   NULL,
                   NULL,
                   NULL,
                   ucbprem_natn_code,
                   stvnatn_nation
      FROM         ucbcust,
                   ucbprem,
                   stvnatn
      WHERE        ucbcust_cust_code = :lLocalCustCode
        AND        ucbprem_code      = :szLocalPremCode
        AND        stvnatn_code(+)   = ucbprem_natn_code;

     /*----------------------------------------------------------------------*/
     /* Open the cursor                                                      */
     /*----------------------------------------------------------------------*/
     EXEC SQL OPEN padr_cursor;
     POSTORA;

     /*----------------------------------------------------------------------*/
     /* Fetch the data                                                       */
     /*----------------------------------------------------------------------*/
     EXEC SQL FETCH padr_cursor INTO
          :ucvadds_last_name              :sInd_01,
          :ucvadds_print_name             :sInd_02,
          :ucvadds_street_address         :sInd_03,
          :ucvadds_city                   :sInd_04,
          :ucvadds_street_number          :sInd_05,
          :ucvadds_pdir_code_pre          :sInd_06,
          :ucvadds_street_name            :sInd_07,
          :ucvadds_ssfx_code              :sInd_08,
          :ucvadds_pdir_code_post         :sInd_09,
          :ucvadds_stat_code              :sInd_10,
          :ucvadds_zip                    :sInd_11,
          :ucvadds_delivery_point         :sInd_12,
          :ucvadds_car_rt                 :sInd_13,
          :ucvadds_unit                   :sInd_14,
          :ucvadds_utyp_code              :sInd_15,
          :ucvadds_street_line1           :sInd_16,
          :ucvadds_street_line2           :sInd_17,
          :ucvadds_street_line3           :sInd_18,
          :ucvadds_natn_code              :sInd_19,
          :ucvadds_nation                 :sInd_20;
     POSTORA;

     /*----------------------------------------------------------------------*/
     /* Set an indicator of whether rows were found                          */
     /*----------------------------------------------------------------------*/
     sNoRowsFound = NO_ROWS_FOUND;

     /*----------------------------------------------------------------------*/
     /* Close the cursor                                                     */
     /*----------------------------------------------------------------------*/
     EXEC SQL CLOSE padr_cursor;

     return sNoRowsFound;
     }                                              /* end ReadPremisesTable */

/******************************************************************************
*                                                                             *
*   ReadAddrTable()                                                           *
*                                                                             *
*   Description.....: Get the address information from the UCRADDR table      *
*                                                                             *
*   Parameters:                                                               *
*                                                                             *
*        Type             Name                     Description                *
*       ------------   --------------      --------------------------------   *
*        long           lCustCode           Customer Code                     *
*        char *         pszAtypCode         Address Type Code                 *
*        char *         pszAddrDate         Address Select Date               *
*                                                                             *
*   Return Values:                                                            *
*                                                                             *
*        Type       Value     #define              Description                *
*       --------    -----   ----------------   --------------------------     *
*        short       1       TRUE               Rows were found               *
*                    0       FALSE              Rows were not found           *
*                                                                             *
******************************************************************************/
static short ReadAddrTable(long lCustCode, char *pszAtypCode,
                          char *pszAddrDate)
     {
     EXEC SQL BEGIN DECLARE SECTION;
        CHAR3   szLocalAddrAtypCode    = "";
        long    lLocalCustCode         = lCustCode;
        CHAR12  szLocalAddrDate        = "";
     EXEC SQL END   DECLARE SECTION;
     short  sNoRowsFound = FALSE;

     /*----------------------------------------------------------------------*/
     /* Make a local copy of the address type code.                          */
     /*----------------------------------------------------------------------*/
     strcpy(szLocalAddrAtypCode, pszAtypCode);
     strcpy(szLocalAddrDate,     pszAddrDate);
     /*----------------------------------------------------------------------*/
     /* Declare a cursor to get the address informatioin from UCRADDR        */
     /*----------------------------------------------------------------------*/
     EXEC SQL DECLARE addr_cursor CURSOR FOR
          select ucbcust_last_name,
                    decode(ucbcust_first_name, '', '',
                        ucbcust_first_name || ' ')
                            || decode(ucbcust_middle_name, '', '',
                                         substr(ucbcust_middle_name, 1, 1) || '. ')
                            || ucbcust_last_name,
                    decode(ucraddr_street_number, '', '',
                        ucraddr_street_number || ' ')
                            || decode(ucraddr_pdir_code_pre, '', '',
                                         ucraddr_pdir_code_pre || ' ')
                            || ucraddr_street_name
                            || decode(ucraddr_ssfx_code, '', '',
                                ' ' || ucraddr_ssfx_code)
                            || decode(ucraddr_pdir_code_post, '', '',
                                         ' ' || ucraddr_pdir_code_post),
                    ucraddr_city,
                    ucraddr_street_number,
                    ucraddr_pdir_code_pre,
                    ucraddr_street_name,
                    ucraddr_ssfx_code,
                    ucraddr_pdir_code_post,
                    ucraddr_stat_code,
                    ucraddr_zip,
                    ucraddr_delivery_point,
                    ucraddr_car_rt,
                    ucraddr_unit,
                    ucraddr_utyp_code,
                    ucraddr_street_line1,
                    ucraddr_street_line2,
                    ucraddr_street_line3,
                    ucraddr_natn_code,
                    stvnatn_nation
            from stvnatn,
                    ucraddr,
                 ucbcust
           where ucbcust_cust_code = :lLocalCustCode
             and ucraddr_cust_code = ucbcust_cust_code
             and ucraddr_atyp_code = :szLocalAddrAtypCode
             and ucraddr_seqno between -99 and 99
             and ucraddr_status_ind = 'A'
             and nvl(ucraddr_from_date,to_date('17000101','YYYYMMDD'))
                 <= to_date(UPPER(:szLocalAddrDate),'DD-MON-YYYY')
             /*    <= SYSDATE                */
             and nvl(ucraddr_to_date, to_date('20991231', 'YYYYMMDD'))
                 >= to_date(UPPER(:szLocalAddrDate),'DD-MON-YYYY')
             /*    >= SYSDATE                */
             and stvnatn_code(+) = ucraddr_natn_code;

     /*----------------------------------------------------------------------*/
     /* Bug #9923          WW   23-OCT-1997                                  */
     /* Make comparison between UCRADDR_FROM_DATE /UCRADDR_TO_DATE and       */
     /* Address selection date instead of to compare with the SYSDATE.       */
     /*----------------------------------------------------------------------*/
     /*----------------------------------------------------------------------*/
     /* Open the cursor                                                      */
     /*----------------------------------------------------------------------*/
     EXEC SQL OPEN addr_cursor;
     POSTORA;

     /*----------------------------------------------------------------------*/
     /* Fetch the data                                                       */
     /*----------------------------------------------------------------------*/
     EXEC SQL FETCH addr_cursor INTO
          :ucvadds_last_name              :sInd_01,
          :ucvadds_print_name             :sInd_02,
          :ucvadds_street_address         :sInd_03,
          :ucvadds_city                   :sInd_04,
          :ucvadds_street_number          :sInd_05,
          :ucvadds_pdir_code_pre          :sInd_06,
          :ucvadds_street_name            :sInd_07,
          :ucvadds_ssfx_code              :sInd_08,
          :ucvadds_pdir_code_post         :sInd_09,
          :ucvadds_stat_code              :sInd_10,
          :ucvadds_zip                    :sInd_11,
          :ucvadds_delivery_point         :sInd_12,
          :ucvadds_car_rt                 :sInd_13,
          :ucvadds_unit                   :sInd_14,
          :ucvadds_utyp_code              :sInd_15,
          :ucvadds_street_line1           :sInd_16,
          :ucvadds_street_line2           :sInd_17,
          :ucvadds_street_line3           :sInd_18,
          :ucvadds_natn_code              :sInd_19,
          :ucvadds_nation                 :sInd_20;
     POSTORA;

     /*----------------------------------------------------------------------*/
     /* Set an indicator of whether rows were found                          */
     /*----------------------------------------------------------------------*/
     sNoRowsFound = NO_ROWS_FOUND;

     /*----------------------------------------------------------------------*/
     /* Close the cursor                                                     */
     /*----------------------------------------------------------------------*/
     EXEC SQL CLOSE addr_cursor;

     return sNoRowsFound;
     }                                                  /* end ReadAddrTable */

/******************************************************************************
*                                                                             *
*   ReadAddsView()                                                            *
*                                                                             *
*   Description.....: Get the address information from the UCVADDS view       *
*                                                                             *
*   Parameters:                                                               *
*                                                                             *
*        Type             Name                     Description                *
*       ------------   --------------    --------------------------------     *
*        long           lCustCode         Customer Code                       *
*                                                                             *
*   Return Values:                                                            *
*                                                                             *
*        Type       Value     #define              Description                *
*       --------    -----   ----------------   --------------------------     *
*        short       1       TRUE               Rows were found               *
*                    0       FALSE              Rows were not found           *
*                                                                             *
******************************************************************************/
static short ReadAddsView(long lCustCode)
     {
     EXEC SQL BEGIN DECLARE SECTION;
        long    lLocalCustCode      = lCustCode;
     EXEC SQL END   DECLARE SECTION;
     short  sNoRowsFound = FALSE;

     /*----------------------------------------------------------------------*/
     /* Declare a cursor to read the UCVADDS view based on cust code.        */
     /* NOTE: UCVADDS uses the collector table SPRCOLR which should have     */
     /* already been loaded by the calling routine with the address          */
     /* hierarchy and address selection date.                                */
     /*----------------------------------------------------------------------*/
     EXEC SQL DECLARE adds_cursor CURSOR FOR
      SELECT       ucvadds_last_name,
                   ucvadds_print_name,
                   ucvadds_street_address,
                   ucvadds_city,
                   ucvadds_street_number,
                   ucvadds_pdir_code_pre,
                   ucvadds_street_name,
                   ucvadds_ssfx_code,
                   ucvadds_pdir_code_post,
                   ucvadds_stat_code,
                   ucvadds_zip,
                   ucvadds_delivery_point,
                   ucvadds_car_rt,
                   ucvadds_unit,
                   ucvadds_utyp_code,
                   ucvadds_street_line1,
                   ucvadds_street_line2,
                   ucvadds_street_line3,
                   ucvadds_natn_code,
                   ucvadds_nation
      FROM         ucvadds
      WHERE        ucvadds_cust_code = :lLocalCustCode;

     /*----------------------------------------------------------------------*/
     /* Open the cursor                                                      */
     /*----------------------------------------------------------------------*/
     EXEC SQL OPEN adds_cursor;
     POSTORA;

     /*----------------------------------------------------------------------*/
     /* Fetch the data                                                       */
     /*----------------------------------------------------------------------*/
     EXEC SQL FETCH adds_cursor INTO
          :ucvadds_last_name              :sInd_01,
          :ucvadds_print_name             :sInd_02,
          :ucvadds_street_address         :sInd_03,
          :ucvadds_city                   :sInd_04,
          :ucvadds_street_number          :sInd_05,
          :ucvadds_pdir_code_pre          :sInd_06,
          :ucvadds_street_name            :sInd_07,
          :ucvadds_ssfx_code              :sInd_08,
          :ucvadds_pdir_code_post         :sInd_09,
          :ucvadds_stat_code              :sInd_10,
          :ucvadds_zip                    :sInd_11,
          :ucvadds_delivery_point         :sInd_12,
          :ucvadds_car_rt                 :sInd_13,
          :ucvadds_unit                   :sInd_14,
          :ucvadds_utyp_code              :sInd_15,
          :ucvadds_street_line1           :sInd_16,
          :ucvadds_street_line2           :sInd_17,
          :ucvadds_street_line3           :sInd_18,
          :ucvadds_natn_code              :sInd_19,
          :ucvadds_nation                 :sInd_20;
     POSTORA;

     /*----------------------------------------------------------------------*/
     /* Set an indicator of whether rows were found                          */
     /*----------------------------------------------------------------------*/
     sNoRowsFound = NO_ROWS_FOUND;

     /*----------------------------------------------------------------------*/
     /* Close the cursor                                                     */
     /*----------------------------------------------------------------------*/
     EXEC SQL CLOSE adds_cursor;

     return sNoRowsFound;
     }                                                   /* end ReadAddsView */

