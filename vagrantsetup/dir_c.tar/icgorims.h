/*****************************************************************************/
/* ICGORIMS.H Copyright (c) SCT Corporation 2001-2002.                       */
/* All rights reserved.                                                      */
/*****************************************************************************/

/*****************************************************************************/
/*                                                                           */
/*       CONFIDENTIAL BUSINESS INFORMATION                                   */
/*                                                                           */
/*      **********************************                                   */
/*                                                                           */
/* THIS PROGRAM IS PROPRIETARY INFORMATION OF                                */
/* SYSTEMS AND COMPUTER TECHNOLOGY CORPORATION                               */
/* AND IS NOT TO BE COPIED, REPRODUCED, LENT OR                              */
/* DISPOSED OF, NOR USED FOR ANY PURPOSE OTHER                               */
/* THAN THAT FOR WHICH IT IS SPECIFICALLY PROVIDED                           */
/* WITHOUT THE WRITTEN PERMISSION OF SAID COMPANY                            */
/*                                                                           */
/*****************************************************************************/
/* ICGORIMS.H                                                                */
/* Program ICGORIMS.PC Header File.                                          */
/*                                                                           */
/* AUDIT TRAIL:5.1                                      INIT    DATE         */
/*                                                       ZYB   28 MAR 2001   */
/* The output process was created to provide the ability to output           */
/* IMS standard XML out to a file.                                           */
/*                                                       ZYB   22 JUN 2001   */
/* 2. Change char size of *role[MAXSIZE_256] to char                         */
/*     role[MAXSIZE_2] to enable compile on the VMS system.                  */
/*                                                                           */
/* AUDIT TRAIL: 5.2                                     INIT    DATE         */
/*                                                       ZYB   28Feb2002     */
/* 1. Added structures and procedure to handle the LOCATION                  */
/*     extension in the GROUP object                                         */
/* 2. Increased variable sizes to manage the ascii translation.              */
/*                                                                           */
/* AUDIT TRAIL: 6.0.0.1                                                      */
/* 1. SC 07/10/2003                                                          */
/*    DEFECT: 86841                                                          */
/*    ISSUE: Data in the SOURCE and ID fields is getting corrupted when      */
/*    ICSORIMS process is run.                                               */
/*    FIX: Modified the printMemebershipBeginning function so that it        */
/*    now sends correct data to the XML output file.                         */ 
/*    Added two new global variables sch_name and global_groupID to the      */
/*    header file.                                                           */
/*                                                                           */
/* AUDIT TRAIL : 8.0 (I18N) *//* AUDIT TRAIL END                            */
/*****************************************************************************/
#include <stdio.h>
#include <stdlib.h>
#ifndef _ICGORIMS_C_
#define STORE_CLASS extern
#else
#define STORE_CLASS /* */
#endif

#define MAXSIZE_2    3
#define MAXSIZE_10   11
#define MAXSIZE_20   21
#define MAXSIZE_25   26
#define MAXSIZE_30   31
#define MAXSIZE_33   34
#define MAXSIZE_60   61
#define MAXSIZE_65   66
#define MAXSIZE_100  101
#define MAXSIZE_129  130
#define MAXSIZE_257  257
#define MAXSIZE_1025 1026
#define MAXSIZE_2000 2001
#define MAXSIZE_2049 2049

EXEC SQL BEGIN DECLARE SECTION;
   STORE_CLASS short  	Ind_01;
   STORE_CLASS short  	Ind_02;
   STORE_CLASS short  	Ind_03;
   STORE_CLASS short  	Ind_04;
   STORE_CLASS short  	Ind_05;
   STORE_CLASS short  	Ind_06;
   STORE_CLASS short  	Ind_07;
   STORE_CLASS short  	Ind_08;
   STORE_CLASS short  	Ind_09;
   STORE_CLASS short  	Ind_10;
   STORE_CLASS short  	Ind_11;
   STORE_CLASS short  	Ind_12;
   STORE_CLASS short  	Ind_13;
   STORE_CLASS short  	Ind_14;
   STORE_CLASS short  	Ind_15;
   STORE_CLASS short  	Ind_16;
   STORE_CLASS short  	Ind_17;
   STORE_CLASS short  	Ind_18;
   STORE_CLASS short  	Ind_19;
   STORE_CLASS short  	Ind_20;
   STORE_CLASS short  	Ind_21;
   STORE_CLASS short  	Ind_22;
   STORE_CLASS short  	Ind_23;
   STORE_CLASS short  	Ind_24;
   STORE_CLASS short  	Ind_25;
   STORE_CLASS short  	Ind_26;
   STORE_CLASS short  	Ind_27;
   STORE_CLASS short  	Ind_28;

   STORE_CLASS CHAR200 sch_name; 
   STORE_CLASS CHAR70  global_groupID; 
EXEC SQL END DECLARE SECTION;
/************************************************************************/
/*  Variable declaration section                                        */
/************************************************************************/
   STORE_CLASS FILE    *myfp;
   STORE_CLASS FNSTRUC outfile;  
   STORE_CLASS char    orgid[MAXSIZE_257];  
   STORE_CLASS char    target[MAXSIZE_100];
   STORE_CLASS char    filename[MAXSIZE_20];  
   STORE_CLASS char    orgname[MAXSIZE_100]; 
   STORE_CLASS char    datasource[MAXSIZE_257];
   STORE_CLASS char    sched_type[MAXSIZE_100][MAXSIZE_60];
typedef struct gstruct
{
  struct gstruct *next;
} GNODE;

typedef struct sourcedid{
               char     source[MAXSIZE_33];
               char     id[MAXSIZE_257];
} SOURCE;
/************************************************************************/
/*  structure declaration section for IMSPropertiesObject structure     */
/************************************************************************/  
typedef struct proptarget{
               struct proptarget *next;
               char  targetsystem[MAXSIZE_257];
} TARGET;

typedef struct propextension{
               struct propextension *next;
               char   extension[MAXSIZE_257];
} PROPEXTEN;

typedef struct imspropertiesobject{
               char      datasource[MAXSIZE_257];
               char      type[MAXSIZE_33];
               char      datetime[MAXSIZE_30];
               TARGET    *targets;
               PROPEXTEN *extensions;
} PROPERTIES;


/************************************************************************/
/*  structure declaration section for IMSPersonObject structure         */
/************************************************************************/ 
typedef struct othername{
               struct   othername *next;
               char     othern[MAXSIZE_33];
} OTHER;

typedef struct telephone{
               struct   telephone *next;
               char     teltype[MAXSIZE_10];
               char     telephon[MAXSIZE_33];
} TEL;

typedef struct streetaddr{
               struct   streetaddr *next;
               char     street[MAXSIZE_129];
} STREET;

typedef struct personrole{
               struct personrole *next;
               char   role[MAXSIZE_10];
} USERROLE;

typedef struct presonextension{
               char     webcredentials[MAXSIZE_257];
               USERROLE *userroles;
} PERSONEXTEN;

typedef struct imspersonobject{
               long     pidm;
               char     title[MAXSIZE_257];
               char     transaction[MAXSIZE_10];
               SOURCE   sourceid;
               char     userid[MAXSIZE_257];
               char     fn[MAXSIZE_257];
               char     sort[MAXSIZE_257];
               char     nickname[MAXSIZE_257];
               char     family[MAXSIZE_257];
               char     given[MAXSIZE_257];
               OTHER    *othern;
               char     prefix[MAXSIZE_33];
               char     suffix[MAXSIZE_33];
               char     gender[MAXSIZE_10];
               char     bday[MAXSIZE_30];
               char     email[MAXSIZE_257];
               char     imgtype[MAXSIZE_10];
               char     extrefattr[MAXSIZE_10];
               char     extref[MAXSIZE_1025];
               char     datasource[MAXSIZE_257];
               PERSONEXTEN *extens;
} PERSON;

/************************************************************************/
/*  structure declaration section for IMSGroupObject structure          */
/************************************************************************/  
typedef struct typevalue{
               struct   typevalue *next;
               char     level[MAXSIZE_10];
               char     typevalue[MAXSIZE_257];
} TYPVALUE;

typedef struct grouptype{
               struct    grouptype *next;
               char       scheme[MAXSIZE_33];
               TYPVALUE   *type;
} GTYPE;

typedef struct longdescription{
               struct     longdescription *next;
               char       longd[MAXSIZE_257];
} LONGDESC;

typedef struct fulldescription{
               struct     fulldescription *next;
               char       full[MAXSIZE_2049];
} FULLDESC;
   
typedef struct description{
               struct     description *next;
               char       shortd[MAXSIZE_60];
               LONGDESC   *longd;
               FULLDESC   *fulld;
} DESC;

typedef struct organizationunit{
               struct     organizationunit *next;
               char       orgunit[MAXSIZE_257];
} ORGNUNIT;
   
typedef struct organization{
               char     orgnam[MAXSIZE_257];
               ORGNUNIT   *orgunits;
               char       type[MAXSIZE_33];
               char       id[MAXSIZE_257];
} ORG;

typedef struct relationship{
               struct    relationship *next;
               char      relation[MAXSIZE_10];
               SOURCE    rel_source;
               char      label[MAXSIZE_257];
} RELATION;

typedef struct delivery{
               struct    delivery *next;
               char      deliverytype[MAXSIZE_33];
} DEL;

typedef struct schedtype{
               struct    schedtype *next;
               char      deliverymode[MAXSIZE_33];
} SCHTYPE;  

typedef struct campuscode{
               struct    campuscode *next;
               char      campusdesc[MAXSIZE_33];
} CAMPUS; 
 
typedef struct grpextension{
               DEL              *deltype;
               SCHTYPE   *delmode;
               CAMPUS    *campdesc;               
} GRPEXTEN;

typedef struct timeframe{
               char      begin_restrict[MAXSIZE_10];
               char      begindate[MAXSIZE_30];
               char      end_restrict[MAXSIZE_10];
               char      enddate[MAXSIZE_30];
               char      adminperiod[MAXSIZE_33];
} TIMEFR;

typedef struct imsgroupobject{
               char      grouptitle[MAXSIZE_100];
               char      transaction[MAXSIZE_10];
               SOURCE    sourceid;
               GTYPE     *grptype;
               DESC      *descript;
               ORG       organiz;
               TIMEFR    timefram;
               char      enrollaccept[MAXSIZE_10];
               char      enrollallowed[MAXSIZE_10];
               char      email[MAXSIZE_257];
               char      urlvalue[MAXSIZE_10];
               char      url[MAXSIZE_257];
               RELATION  *relations;
               char      datasource[MAXSIZE_257];
               GRPEXTEN	 extensions;
} GROUP;


/************************************************************************/
/*  structure declaration section for IMSMembershipObject structure     */
/************************************************************************/
typedef struct valuelist{
               struct    valuelist *next;
               char      list[MAXSIZE_33];
} VLIST;

typedef struct finalresult{
               char      mode[MAXSIZE_65];
               char      value[MAXSIZE_10];
               VLIST     *list;
               char      min[MAXSIZE_33];
               char      max[MAXSIZE_33];
               char      result[MAXSIZE_33];
               char      comments[MAXSIZE_2049];
} FRESULT;

typedef struct memextension{
               char     mode[MAXSIZE_65];
               char     gradable[MAXSIZE_10];
} MEMEXTEN;

typedef struct memberrole{
               struct    memberrole *next;
               char      transaction[MAXSIZE_10];
               char      roletype[MAXSIZE_10];
               char      subrole[MAXSIZE_65];
               char      status[MAXSIZE_10];
               char      userid[MAXSIZE_257];
               char      comments[MAXSIZE_2049];
               TIMEFR    timef;
               char      email[MAXSIZE_257];
               FRESULT   finresults;
               MEMEXTEN  exten;
               char      datasource[MAXSIZE_257];
} MEMROLE;

typedef struct imsmemberobject{
               struct    imsmemberobject *next;
               SOURCE    sourceid;
               char      idtype[MAXSIZE_10];
               MEMROLE   *role;
} MEMBER;

typedef struct memberheader{
               char      membershiptitle[MAXSIZE_100];
               SOURCE    sourceid;
               MEMBER    *members;
} MEMHEADER;  

   STORE_CLASS PROPERTIES prop;
   STORE_CLASS PERSON persn;   
   STORE_CLASS GROUP grp;    
   STORE_CLASS MEMHEADER memhead;
   STORE_CLASS MEMBER mem;    
/************************************************************************/
/*  procedure declaration section                                       */
/************************************************************************/ 
   STORE_CLASS long trim(char string[]);
   STORE_CLASS void *getmemory(int size);
   STORE_CLASS void *genericAddNode(int size,GNODE **head,GNODE **tail);
   STORE_CLASS void genericClearAll(GNODE **head);
   

/************************************************************************/
/*  macro declaration section for generic procedures                    */
/************************************************************************/ 
   STORE_CLASS CAMPUS          *campus_head;
   STORE_CLASS CAMPUS          *campus_tail;
   STORE_CLASS DEL                   *del_head;
   STORE_CLASS DEL                   *del_tail;
   STORE_CLASS DESC               *desc_head;
   STORE_CLASS DESC               *desc_tail;
   STORE_CLASS FULLDESC     *fdesc_head;
   STORE_CLASS FULLDESC     *fdesc_tail;
   STORE_CLASS GTYPE              *gtype_head;
   STORE_CLASS GTYPE              *gtype_tail;
   STORE_CLASS LONGDESC    *ldesc_head;
   STORE_CLASS LONGDESC    *ldesc_tail;
   STORE_CLASS MEMBER          *member_head;
   STORE_CLASS MEMBER          *member_tail;
   STORE_CLASS MEMEXTEN     *memext_head;
   STORE_CLASS MEMEXTEN     *memext_tail;
   STORE_CLASS MEMROLE       *memrole_head;
   STORE_CLASS MEMROLE       *memrole_tail;
   STORE_CLASS PROPEXTEN  *prext_head;
   STORE_CLASS PROPEXTEN  *prext_tail;
   STORE_CLASS ORGNUNIT      *orgu_head;
   STORE_CLASS ORGNUNIT      *orgu_tail;
   STORE_CLASS OTHER            *oth_head;
   STORE_CLASS OTHER            *oth_tail;
   STORE_CLASS RELATION      *rel_head;
   STORE_CLASS RELATION      *rel_tail;
   STORE_CLASS SCHTYPE       *schtype_head;
   STORE_CLASS SCHTYPE       *schtype_tail;
   STORE_CLASS STREET          *str_head;
   STORE_CLASS STREET          *str_tail;
   STORE_CLASS TARGET          *trg_head;
   STORE_CLASS TARGET          *trg_tail;
   STORE_CLASS TEL                   *tel_head;
   STORE_CLASS TEL                   *tel_tail;
   STORE_CLASS TYPVALUE      *typv_head;
   STORE_CLASS TYPVALUE      *typv_tail;
   STORE_CLASS USERROLE     *prole_head;
   STORE_CLASS USERROLE     *prole_tail;
   STORE_CLASS VLIST                *vlist_head;
   STORE_CLASS VLIST                 *vlist_tail;

#define ADD_CAMPUS_NODE(p) \
  p=(CAMPUS *)genericAddNode(sizeof(CAMPUS), \
                                   (GNODE **)&campus_head, \
                                   (GNODE **)&campus_tail)

#define ADD_DEL_NODE(p) \
  p=(DEL *)genericAddNode(sizeof(DEL), \
                                   (GNODE **)&del_head, \
                                   (GNODE **)&del_tail)

#define ADD_DESC_NODE(p) \
  p=(DESC *)genericAddNode(sizeof(DESC), \
                                   (GNODE **)&desc_head, \
                                   (GNODE **)&desc_tail)

#define ADD_FULLDESC_NODE(p) \
  p=(FULLDESC *)genericAddNode(sizeof(FULLDESC), \
                                   (GNODE **)&fdesc_head, \
                                   (GNODE **)&fdesc_tail)

#define ADD_GTYPE_NODE(p) \
  p=(GTYPE *)genericAddNode(sizeof(GTYPE), \
                                   (GNODE **)&gtype_head, \
                                   (GNODE **)&gtype_tail)

#define ADD_LONGDESC_NODE(p) \
  p=(LONGDESC *)genericAddNode(sizeof(LONGDESC), \
                                   (GNODE **)&ldesc_head, \
                                   (GNODE **)&ldesc_tail)

#define ADD_MEMBER_NODE(p) \
  p=(MEMBER *)genericAddNode(sizeof(MEMROLE), \
                                   (GNODE **)&member_head, \
                                   (GNODE **)&member_tail)

#define ADD_MEMEXTEN_NODE(p) \
  p=(MEMEXTEN *)genericAddNode(sizeof(MEMEXTEN), \
                                   (GNODE **)&memext_head, \
                                   (GNODE **)&memext_tail)

#define ADD_MEMROLE_NODE(p) \
  p=(MEMROLE *)genericAddNode(sizeof(MEMROLE), \
                                   (GNODE **)&memrole_head, \
                                   (GNODE **)&memrole_tail)

#define ADD_ORGNUNIT_NODE(p) \
  p=(ORGNUNIT *)genericAddNode(sizeof(ORGNUNIT), \
                                   (GNODE **)&orgu_head, \
                                   (GNODE **)&orgu_tail)

#define ADD_OTHER_NODE(p) \
  p=(OTHER *)genericAddNode(sizeof(OTHER), \
                                   (GNODE **)&oth_head, \
                                   (GNODE **)&oth_tail)

#define ADD_PROPEXTEN_NODE(p) \
  p=(PROPEXTEN *)genericAddNode(sizeof(PROPEXTEN), \
                                   (GNODE **)&prext_head, \
                                   (GNODE **)&prext_tail)

#define ADD_RELATION_NODE(p) \
  p=(RELATION *)genericAddNode(sizeof(RELATION), \
                                   (GNODE **)&rel_head, \
                                   (GNODE **)&rel_tail)

#define ADD_SCHTYPE_NODE(p) \
  p=(SCHTYPE *)genericAddNode(sizeof(SCHTYPE), \
                                   (GNODE **)&schtype_head, \
                                   (GNODE **)&schtype_tail)

#define ADD_STREET_NODE(p) \
  p=(STREET *)genericAddNode(sizeof(STREET), \
                                   (GNODE **)&str_head, \
                                   (GNODE **)&str_tail)

#define ADD_TARGET_NODE(p) \
  p=(TARGET *)genericAddNode(sizeof(TARGET), \
                                   (GNODE **)&trg_head, \
                                   (GNODE **)&trg_tail)

#define ADD_TEL_NODE(p) \
  p=(TEL *)genericAddNode(sizeof(TEL), \
                                   (GNODE **)&tel_head, \
                                   (GNODE **)&tel_tail)

#define ADD_TYPVALUE_NODE(p) \
  p=(TYPVALUE *)genericAddNode(sizeof(TYPVALUE), \
                                   (GNODE **)&typv_head, \
                                   (GNODE **)&typv_tail)

#define ADD_USERROLE_NODE(p) \
  p=(USERROLE *)genericAddNode(sizeof(USERROLE), \
                                   (GNODE **)&prole_head, \
                                   (GNODE **)&prole_tail)

#define ADD_VLIST_NODE(p) \
  p=(VLIST *)genericAddNode(sizeof(VLIST), \
                                   (GNODE **)&vlist_head, \
                                   (GNODE **)&vlist_tail)

#define CLEAR_ALL_CAMPUS(p) \
   genericClearAll((GNODE **)&campus_head)

#define CLEAR_ALL_DEL(p) \
   genericClearAll((GNODE **)&del_head)

#define CLEAR_ALL_DESC(p) \
   genericClearAll((GNODE **)&desc_head)

#define CLEAR_ALL_FULLDESC(p) \
   genericClearAll((GNODE **)&fdesc_head)

#define CLEAR_ALL_GTYPE(p) \
   genericClearAll((GNODE **)&gtype_head)

#define CLEAR_ALL_LONGDESC(p) \
   genericClearAll((GNODE **)&ldesc_head)

#define CLEAR_ALL_MEMBER(p) \
   genericClearAll((GNODE **)&member_head)

#define CLEAR_ALL_MEMEXTEN(p) \
   genericClearAll((GNODE **)&memext_head)

#define CLEAR_ALL_MEMROLE(p) \
   genericClearAll((GNODE **)&memrole_head)

#define CLEAR_ALL_ORGNUNIT(p) \
   genericClearAll((GNODE **)&orgu_head)

#define CLEAR_ALL_OTHER(p) \
   genericClearAll((GNODE **)&oth_head)

#define CLEAR_ALL_PROPEXTEN(p) \
   genericClearAll((GNODE **)&pext_head)

#define CLEAR_ALL_RELATION(p) \
   genericClearAll((GNODE **)&rel_head)

#define CLEAR_ALL_SCHTYPE(p) \
   genericClearAll((GNODE **)&schtype_head)

#define CLEAR_ALL_STREET(p) \
   genericClearAll((GNODE **)&str_head)

#define CLEAR_ALL_TARGET(p) \
   genericClearAll((GNODE **)&trg_head)

#define CLEAR_ALL_TEL(p) \
   genericClearAll((GNODE **)&tel_head)

#define CLEAR_ALL_TYPVALUE(p) \
   genericClearAll((GNODE **)&typv_head)

#define CLEAR_ALL_USERROLE(p) \
   genericClearAll((GNODE **)&prole_head)

#define CLEAR_ALL_VLIST(p) \
   genericClearAll((GNODE **)&vlist_head)

/************************************************************************/
/*  IMS Enterprise Model Object Output prototypes                       */
/************************************************************************/

   STORE_CLASS void printEnterpriseEnding(void);
   STORE_CLASS void printEnterpriseHeader(void);
   STORE_CLASS void printGroupObject(void);
   STORE_CLASS void printMember(void);
   STORE_CLASS void printMembershipBegining(void);
   STORE_CLASS void printMembershipEnding(void);
   STORE_CLASS void printPersonObject(void);
   STORE_CLASS void printPropertiesObject(void);
   
