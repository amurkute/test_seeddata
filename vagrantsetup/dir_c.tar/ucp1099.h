/* AUDIT TRAIL: 8.0 */
/* AUDIT TRAIL END */
/*  Include file for contants, macros, etc. specific to UCP1099.PC  */

#ifndef UCP1099_H
#define UCP1099_H

#define INCL_JOB_SUBMISSION

#define EXEC_NAME         "UCP1099"               /* the name of this program */
#define RELEASE_NUMBER    "2.0.2"
#define PAGE_WIDTH        131
#define DEFAULT_TITLE     "1099 Process"
#define MAX_PARMS         50
#define NUM_PARMS         13  /* should be 1 more than # to include page size */

#define NUM_BREAK_LEVELS  4       /*  Customer, Tax ID, & grand total breaks  */
#define INIT_TOTALS       { 0, 0, 0, 0 }  /*  Change this w/NUM_BREAK_LEVELS  */
#define GRAND_TOT_LEVEL   0
#define TAXID_TOT_LEVEL   1
#define CUST_TOT_LEVEL    2
#define DPST_TOT_LEVEL    3
#define FORM_FEED         TRUE
#define NO_FORM_FEED      FALSE
#define COL_HEAD          TRUE
#define NO_COL_HEAD       FALSE

#define INIT_PARM_DEFAULTS { szJSSysDate+7,\
                             "N",\
                             "N",\
                             "N",\
                             "%",\
                             "",\
                             "10",\
                             "",\
                             "",\
                             "",\
                             "N",\
                             "BI",\
                             "60" }

/*  Column Heading definitions  */

typedef struct stPrintFieldStruct {
   short  sAbsRow;
   short  sAbsCol;
   short  sRelRow;
   short  sRelCol;
   char   szPrintFormat[9];
   char   szText[133];
} PRINT_FIELD;

#define NUM_COL_HEADS     26
#define INIT_COL_HEADS {\
   {   0,   0,   2,   0, "", "Recipient" },\
   {   0,  56,   0,   0, "", "Deposit" },\
   {   0,  69,   0,   0, "", "Interest" },\
   {   0,  83,   0,   0, "", "Interest" },\
   {   0,  97,   0,   0, "", "Interest" },\
   {   0, 111,   0,   0, "", "Interest" },\
   {   0, 120,   0,   0, "", "Exception" },\
   {   0,   0,   1,   0, "", "Tax ID" },\
   {   0,  13,   0,   0, "", "Recipient Name" },\
   {   0,  44,   0,   0, "", "Cust Code" },\
   {   0,  57,   0,   0, "", "Number" },\
   {   0,  69,   0,   0, "", "Refunded" },\
   {   0,  84,   0,   0, "", "Applied" },\
   {   0,  97,   0,   0, "", "Eligible" },\
   {   0, 111,   0,   0, "", "Reported" },\
   {   0, 120,   0,   0, "", "Codes" },\
   {   0,   0,   1,   0, "", "------------" },\
   {   0,  13,   0,   0, "", "------------------------------" },\
   {   0,  44,   0,   0, "", "---------" },\
   {   0,  54,   0,   0, "", "---------" },\
   {   0,  64,   0,   0, "", "-------------" },\
   {   0,  78,   0,   0, "", "-------------" },\
   {   0,  92,   0,   0, "", "-------------" },\
   {   0, 106,   0,   0, "", "-------------" },\
   {   0, 120,   0,   0, "", "------------" },\
   {   0,   0,   0,   0, "", "" } }
                         
/*  Form 1099-INT (regular & test pattern) definitions  */
                                    
#define NUM_1099INT_FIELDS 23
#define INIT_1099INT_FIELDS {\
   {   2,  24,   0,   0, "",        "x" },\
   {   2,  32,   0,   0, "",        "x" },\
   {   4,   5,   0,   0, "%-0.33s", "xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx" },\
   {   4,  39,   0,   0, "",        "xxxxxxxxxxxxx" },\
   {   5,   5,   0,   0, "%-0.33s", "xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx" },\
   {   6,   5,   0,   0, "%-0.33s", "xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx" },\
   {   7,   5,   0,   0, "%-0.33s", "xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx" },\
   {   8,   5,   0,   0, "%-0.33s", "xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx" },\
   {  10,   5,   0,   0, "",        "xxxxxxxxxxxxxxxx" },\
   {  10,  23,   0,   0, "",        "xxxxxxxxxxxxxxxx" },\
   {  10,  40,   0,   0, "%12.12s", "xxxxxxxxxxxx" },\
   {  12,   5,   0,   0, "%-0.33s", "xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx" },\
   {  13,   5,   0,   0, "%-0.33s", "xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx" },\
   {  13,  40,   0,   0, "%12.12s", "xxxxxxxxxxxx" },\
   {  13,  54,   0,   0, "%12.12s", "xxxxxxxxxxxx" },\
   {  15,   5,   0,   0, "%-0.33s", "xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx" },\
   {  15,  40,   0,   0, "%12.12s", "xxxxxxxxxxxx" },\
   {  17,   5,   0,   0, "%-0.33s", "xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx" },\
   {  19,   5,   0,   0, "",        "xxxxxxxxxxxxxxxxxxxxxxxxxxx" },\
   {  19,  35,   0,   0, "",        "x" },\
   {  19,  40,   0,   0, "%12.12s", "xxxxxxxxxxxx" },\
   {  19,  54,   0,   0, "",        "xxxxxxxxxxxx" },\
   {   0,   0,   0,   0, "",        "" } }
                         
/*  Report Exception Legend definitions  */
                                    
#define NUM_LEGEND_LINES  7
#define NUM_LEGEND_FIELDS 5
#define INIT_LEGEND_FIELDS {\
   { 0, 0, 3, 0, "", "EXCEPTION CODE LEGEND:" },\
   { 0, 0, 2, 0, "", "Code  Description" },\
   { 0, 0, 1, 0, "", "----  --------------------------------------------" },\
   { 0, 0, 1, 0, "", "   1  Interest for Tax ID did not meet IRS minimum" },\
   { 0, 0, 0, 0, "", "" } }

/* 
 *  define IRS electronic filing record types and the appropriate 
 *  default initialization for these types.
 */

/*  IRS record type "A" (payer/transmitter record) (420 bytes)  */

typedef struct {
   int    iRecordCount;
   char   szPrintFormat[256];
   char   cRecordType;
   char   szPaymentYear[3];
   char   szReelSequenceNumber[4];
   char   szPayerFedEmpID[10];
   char   szPayerNameCtrl[5];
   char   cLastFilingIndicator;
   char   cCombinedFedStateInd;
   char   cTypeOfReturn;
   char   szAmountCodes[10];
   char   cTestIndicator;
   char   cServiceBureauInd;
   char   szBlank1[9];
   char   szMagTapeFilerInd[3];
   char   szTransmitterCtrlCode[6];
   char   cForeignEntityInd;       
   char   szFirstPayerNameLine[41];
   char   szSecondPayerNameLine[41];
   char   cTransferAgentInd;       
   char   szPayerShipAddress[41];  
   char   szPayerCityStateZip[41]; 
   char   szTransmitterName[81];   
   char   szTransmitterMailAddress[41];
   char   szTransmitterCityStateZip[41];
   char   szBlank2[49];            
} IRS_REC_TYPE_A;

/*  Default initialization for IRS record type "A"  */

#define INIT_IRS_REC_TYPE_A {\
   0,\
   "%c%-2.2s%-3.3s%-9.9s%-4.4s%c%c%c%-9.9s%c%c%-8.8s%-2.2s%-5.5s%c%-40.40s\
%-40.40s%c%-40.40s%-40.40s%-80.80s%-40.40s%-40.40s%-48.48s\n",\
   'A',\
   "",\
   "",\
   "",\
   "",\
   ' ',\
   ' ',\
   ' ',\
   "",\
   ' ',\
   ' ',\
   "",\
   "LS",\
   "",\
   ' ',\
   "",\
   "",\
   '0',     /*  0 indicates the next field is not the transfer agent  */\
   "",\
   "",\
   "",\
   "",\
   "",\
   "" }

/*  IRS record type "B" (payee record) (420 bytes)  */

typedef struct {
   int    iRecordCount;
   char   szPrintFormat[256];
   char   cRecordType;                   
   char   szPaymentYear[3];              
   char   szDocSpecificDistCode[3];      
   char   szSecondTINNotice[2];              
   char   szCorrectedReturnInd[2];           
   char   szNameControl[5];              
   char   cDirectSalesInd;               
   char   cBlank1;                       
   char   cTypeOfTIN;                    
   char   szTIN[10];                     
   char   szPayersAcctNoForPayee[21];    
   char   c1099RIRASEPInd;               
   char   sz1099RPctOfTotalDist[3];      
   char   c1099RTotalDistInd;            
   char   c1099RTxblAmtNotDtrmndInd;     
   char   szBlank2[3];                   
   double dPaymentAmount1;               
   double dPaymentAmount2;               
   double dPaymentAmount3;               
   double dPaymentAmount4;               
   double dPaymentAmount5;               
   double dPaymentAmount6;               
   double dPaymentAmount7;               
   double dPaymentAmount8;               
   double dPaymentAmount9;               
   char   szBlank3[21];                  
   char   cForeignCountryInd;            
   char   szFirstPayeeNameLine[41];      
   char   szSecondPayeeNameLine[41];     
   char   szPayeeMailAddress[41];        
   char   szPayeeCity[30];               
   char   szPayeeState[3];               
   char   szPayeeZIPCode[10];            
   char   cBlank4;                       
   char   szSpecialDataEntries[68];      
   char   szCombinedFedStateCode[3];     
} IRS_REC_TYPE_B;

/*  Default initialization for IRS record type "B"  */

#define INIT_IRS_REC_TYPE_B {\
   0,\
   "%c%-2.2s%-2.2s%-1.1s%-1.1s%-4.4s%c%c%c%-9.9s%-20.20s%c%-2.2s%c%c%-2.2s\
%010.0lf%010.0lf%010.0lf%010.0lf%010.0lf%010.0lf%010.0lf%010.0lf%010.0lf\
%-20.20s%c%-40.40s%-40.40s%-40.40s%-29.29s%-2.2s%-9.9s%c%-67.67s%-2.2s\n",\
   'B',\
   "",\
   "",\
   "",\
   "",\
   "",\
   ' ',\
   ' ',\
   ' ',\
   "",\
   "",\
   ' ',\
   "",\
   ' ',\
   ' ',\
   "",\
   0,\
   0,\
   0,\
   0,\
   0,\
   0,\
   0,\
   0,\
   0,\
   "",\
   ' ',\
   "",\
   "",\
   "",\
   "",\
   "",\
   "",\
   ' ',\
   "",\
   "" }


/*  IRS record type "C" (end of payer record) (420 bytes)  */

typedef struct {
   int    iRecordCount;
   char   szPrintFormat[256];
   char   cRecordType;
   int    iNumPayees;  
   char   szBlank1[4]; 
   double dCtrlTotal1; 
   double dCtrlTotal2; 
   double dCtrlTotal3; 
   double dCtrlTotal4; 
   double dCtrlTotal5; 
   double dCtrlTotal6; 
   double dCtrlTotal7; 
   double dCtrlTotal8; 
   double dCtrlTotal9; 
   char   szBlank2[274];
} IRS_REC_TYPE_C;

/*  Default initialization for IRS record type "C"  */

#define INIT_IRS_REC_TYPE_C {\
   0,\
   "%c%06d%-3.3s%015.0lf%015.0lf%015.0lf%015.0lf%015.0lf%015.0lf%015.0lf\
%015.0lf%015.0lf%-273.273s\n",\
   'C',\
   0,\
   "",\
   0,\
   0,\
   0,\
   0,\
   0,\
   0,\
   0,\
   0,\
   0,\
   "" }

/*  IRS record type "F" (end of transmission record) (420 bytes)  */

typedef struct {
   int    iRecordCount;
   char   szPrintFormat[256];
   char   cRecordType; 
   int    sNumARecs;   
   long   lZeros;      
   char   szBlank1[389];
} IRS_REC_TYPE_F;

/*  Default initialization for IRS record type "F"  */

#define INIT_IRS_REC_TYPE_F {\
   0,\
   "%c%04d%025ld%-388.388s\n",\
   'F',\
   0,\
   0,\
   "" }

#endif

/*  End of UCP1099.H C header file  */
