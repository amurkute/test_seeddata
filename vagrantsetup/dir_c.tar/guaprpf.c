/*TMCI18N BEGIN HEADER*/
#if !defined( tmBundle_EXISTS )
/* No Initialisation Required */                                               
#include "tmcilib.h"
static struct TMBundle tmBundle = {"guaprpf.c",NULL,NULL,NULL,NULL};
#define tmBundle_EXISTS
#endif
/*TMCI18N END HEADER*/

/* AUDIT_TRAIL_MSGKEY_UPDATE
-- PROJECT : MSGKEY
-- MODULE  : GUAPRPF
-- SOURCE  : enUS
-- TARGET  : I18N
-- DATE    : Mon Feb 15 10:13:33 2010
-- MSGSIGN : #72b0a2133a5839e0
END AUDIT_TRAIL_MSGKEY_UPDATE */

/* AUDIT_TRAIL_TM63
-- TranMan 6.3 
-- PROJECT : PVV_TEST
-- MODULE  : GUAPRPF
-- SOURCE  : enUS
-- TARGET  : I18N
-- DATE    : Mon Dec 17 07:14:07 2007
END AUDIT_TRAIL_TM63 */
/* Object: guaprpf.h
   Author: John Morgan
 Mod Date: 08/18/95
  Release: General 2.1.5
*/

/*==========================================================================*/
/* guaprpf.c Copyright 1995 - 2010 SunGard.  All rights reserved.           */
/****************************************************************************/
/*                                                                          */
/* Copyright 1995 - 2010 SunGard.  All rights reserved.                     */
/*                                                                          */
/* SunGard or its subsidiaries in the U.S. and other countries is the owner */
/* of numerous marks, including "SunGard," the SunGard logo, "Banner,"      */
/* "PowerCAMPUS," "Advance," "Luminis," "UDC," and "Unified Digital Campus."*/
/* Other names and marks used in this material are owned by third parties.  */
/*                                                                          */
/* This [site/software] contains confidential and proprietary information   */
/* of SunGard and its subsidiaries. Use of this [site/software] is limited  */
/* to SunGard Higher Education licensees, and is subject to the terms and   */
/* conditions of one or more written license agreements between SunGard     */
/* Higher Education and the licensee in question.                           */
/*                                                                          */
/****************************************************************************/

/***************************************************/
/*                                                 */
/*       CONFIDENTIAL BUSINESS INFORMATION         */
/*                                                 */
/*      **********************************         */
/*                                                 */
/*  THIS PROGRAM IS PROPRIETARY INFORMATION OF     */
/* SYSTEMS AND COMPUTER TECHNOLOGY CORPORATION     */
/* AND IS NOT TO BE COPIED, REPRODUCED, LENT OR    */
/* DISPOSED OF, NOR USED FOR ANY PURPOSE OTHER     */
/* THAN THAT FOR WHICH IT IS SPECIFICALLY PROVIDED */
/* WITHOUT THE WRITTEN PERMISSION OF SAID COMPANY  */
/*                                                 */
/***************************************************/

/* AUDIT TRAIL: 2.1.5                              INIT      DATE           */
/*                                                                          */
/* 1. New object; stand-alone RPF emulation.        JWM    08/18/95         */
/*                                                                          */
/* AUDIT TRAIL: 2.1.11                              INIT      DATE          */
/*                                                                          */
/* 1. Fix for core dump with long text strings.     JWM    02/03/97         */
/*                                                                          */
/* AUDIT TRAIL: 3.1                                 INIT      DATE          */
/*                                                                          */
/* 1. Increased input buffer to 2000 characters.    JWM    02/18/98         */
/*                                                                          */
/* AUDIT TRAIL : 8.0 (I18N) *//* AUDIT TRAIL END                            */
/*                                                                          */
/* AUDIT TRAIL: 8.3.0.2                              INIT      DATE         */
/* 1. Defect # 1-5MDW69                                                     */
/*    Removed TM_NLS_Get from untranslatable codes.   EM    02/15/2010      */
/*                                                                          */
/* AUDIT TRAIL END                                                          */

/* guaprpf (Process RPF File) is a stand-alone replacement for the ORACLE RPF
   facility, intended to be used with processes such as letter generation 
   which require the ability to process RPF files.  This program originated
   as part of the SCTCCONV code, and has been modified to fit into the 
   standard General C support code.  Usage info may be displayed by executing
   with no arguments.
*/

/* includes - guarpfk.h included twice to create table and enumeration */

#include "guarpfe.h"
#include "guarpfk.h"
#include "guarpfk.h"

/* prototypes */

static int find_rpfkey(TMCHAR *s);
static void untab(TMCHAR *buffer);
static int rpf_getword(void);
static int rpf_getline(void);
static int rpf_getnum(void);
static void rpferror(void);
static void cmdhelp(void);
static void translate_rpf(void);
static void translate_rpf_cmd(int cmd);
static void translate_rpf_1_num_arg(int cmd);
static void translate_rpf_table_define(void);
static void translate_rpf_page(void);
static void translate_rpf_pgnum(void);
static void translate_rpf_title(void);

/* global variables */

static UFILE *ifile;
static FNSTRUC infile,outfile;
static TMCHAR read_buffer[2001],*rpf_buffer={0}/*TMCI18N CHANGED FROM ""*/,rpf_strbuf[512],rpf_word[256];
static long rpf_lineno;
static short int rpf_literal=FALSE;

int main(int argc,TMCHAR *argv[])
{
  int cnt,i,next_arg;
  TMCHAR *default_ext=_TMC("lis"),*ofile_name=NULL;

  /* parse the command-line */

  if ( argc==1 )
    cmdhelp();
      
  for ( cnt=1 ; cnt < argc ; cnt++ )
    if ( *argv[cnt] != '-' )
      break;    
    else if ( ! argv[cnt][1] )
      cmdhelp();
    else
      for ( i=1,next_arg=FALSE ; argv[cnt][i] && !next_arg ; i++ )
        switch(argv[cnt][i])
          {
            case 'f' : setcflag(CL_FF,TRUE);
                       break;
            case 'i' : setcflag(CL_EJECT,TRUE);
                       break;
            case 'u' : setcflag(CL_UC,TRUE);
                       break;
            case 'v' : setcflag(CL_REV,TRUE);
                       break;
            case 'o' : if ( argv[cnt][i+1] )
                         cmdhelp();
                       ofile_name=argv[++cnt];
                       next_arg=TRUE;
                       break;
            default  : cmdhelp();
          }

  if ( cnt!=argc-1 )
    cmdhelp();

  /* setup the filenames for input and output; if no output specified then
     defaults to name of rpf input file with .lis extension
  */

  tmstrcpy(exefile.name,_TMC("guaprpf"));

  tmstrcpy(infile.fname,argv[cnt]);
  parsfn(&infile);
  if ( !*infile.ext )
    {
      tmstrcpy(infile.ext,_TMC("rpf"));
      makefn(&infile);
    }

  initfn(&outfile);
  if ( ofile_name )
    {
      tmstrcpy(outfile.fname,ofile_name);
      parsfn(&outfile);
      if ( !*outfile.ext )
        tmstrcpy(outfile.ext,default_ext);
    }
  else
    {
      tmstrcpy(outfile.name,infile.name);
      tmstrcpy(outfile.ext,default_ext);
    }

  /* open the input file */

  if ( !(ifile=tmfopen(&tmBundle, infile.fname,_TMC("r"))) )
    prtmsg(IOERROR,infile.fname);

  /* setup the output file name in the emulator */

  setfile(outfile.dir,outfile.name,outfile.ext,outfile.vers);

  /* now do the real work */

  rptinit();          /* initialize the emulator */
  regexit(rptclose);  /* register the rptclose function */
  translate_rpf();    /* process the input file */

  /* cleanup and done */

  tmfclose(ifile);
  exit2os(EXIT_SUCCESS);
  return EXIT_SUCCESS;
}

/* cmdhelp is called if an unrecognized command-line argument is received; 
   no arguments, and exits with EXIT_FAILURE on completion.
*/

static void cmdhelp(void)
{
  TMCHAR *msg[]={
       TM_NLS_Get("0000","guaprpf [-fiuv] [-o output_file] input_file"),
       TM_NLS_Get("0001","         -f Form Feed for page eject"),
       TM_NLS_Get("0002","         -i Initial page eject"),
       TM_NLS_Get("0003","         -u Upper case output"),
       TM_NLS_Get("0004","         -v ReVerse order of underlines (default underline first)"),
       TM_NLS_Get("0005","         -o Specify Output file"),
       NULL};
  int i;

  for ( i=0 ; msg[i] ; tmputs(msg[i++]) );

  exit2os(EXIT_FAILURE);
}

/* find_rpfkey takes a char pointer argument word and returns the integer
   offset in the rpfkey keyword table of word if it is found, or -1 otherwise.
*/

static int find_rpfkey(TMCHAR *word)
{
  int i;
  TMCHAR ucword[256];

  /* '.' and '#' are interchangable to RPF */

  if ( ! ( *word == '.' || *word == '#' ) )
    return -1;

  str2uc(tmstrcpy(ucword,&word[1]));
  for ( i=0 ; rpfkey[i] ; i++ )
    if ( ! tmstrcmp(ucword,_TMV(rpfkey[i])) )
      return i;

  return -1;
}

/* rpf_getline gets the next line from the input file, and returns FALSE if
   the input line is exhausted, TRUE otherwise.  The line is processed (tabs
   and newlines eliminated) and rpf_buffer is set to point to the processed
   line.
*/

static int rpf_getline(void)
{
  static int eof=FALSE;
  int len;

  if (eof)
    return FALSE;

  if ( !tmfgets(read_buffer,2000,ifile) )
    {
      if ( tmferror(ifile) )
        tmperror(infile.fname);
      eof=TRUE;
      return FALSE;
    }
  else
    {
      len = tmstrlen(read_buffer);
      if ( len )
        if (read_buffer[len-1] == '\n')
          read_buffer[len-1]='\0';

      rpf_lineno++;
      untab(read_buffer);
      rpf_buffer=read_buffer;
    }

  return TRUE;
}

/* rpf_getword retrieves the next RPF style word from rpf_buffer into
   rpf_word; if rpf_buffer is NULL or empty, then it calls rpt_getline
   to attempt to populate it.  TRUE is returned on success, FALSE if
   there are no more words to retrieve.
*/

static int rpf_getword(void)
{
  TMCHAR *p;

  /* buffer is empty - try to fill it */

  if (!rpf_buffer || (rpf_buffer && !*rpf_buffer))
    if (!rpf_getline())
      return FALSE;

  *rpf_word='\0';

  /* if literal mode is on, then entire buffer goes into rpf_word */

  if ( rpf_literal )
    {
      tmstrcpy(rpf_word,rpf_buffer);
      if ( !*rpf_word )
        tmstrcpy(rpf_word,_TMC(" "));  /* minimally a blank */

      /* if a # or . followed by optional blanks and end of line, then
         make rpf_word "#" since it is a literal termination
      */

      if ( *rpf_buffer=='#' || *rpf_buffer=='.' )
        {
          for ( rpf_buffer++ ; *rpf_buffer==' ' ; rpf_buffer++ );
          if ( !*rpf_buffer )
            tmstrcpy(rpf_word,_TMC("#"));
        }
      rpf_buffer=NULL;  /* done with current token */
    }
  else
    {
      /* skip blank lines */

      for ( ; ; )
        {
          for ( ; *rpf_buffer==' ' ; rpf_buffer++ );   /* ltrim blanks */
          if (*rpf_buffer)
            if ( tmstrcmp(rpf_buffer,_TMC("\\")) )
              break;
          if (!rpf_getline())
            return FALSE;
        }

      /* build a blank-delimited word */

      for ( p=rpf_word ; *rpf_buffer && *rpf_buffer != ' ' ; )
        {
          *p++ = *rpf_buffer++;

          /* include whatever character is escaped */

          if ( *(p-1) == '\\' )
            if ( *rpf_buffer )
              *p++ = *rpf_buffer++;
            else
              p--;
        }

      /* null terminate the word */

      *p='\0';

      /* make life easier elsewhere, since '.' and '#' are equivalent
         as an RPF command
      */

      if ( !tmstrcmp(rpf_word,_TMC(".")) )
        *rpf_word='#';
    }

  return TRUE;
}

/* translate_rpf is the driving function for converting lines of input
   containing text and RPF commands into calls to RPF emulation functions
*/

static void translate_rpf(void)
{
  int cmd;

  *rpf_strbuf='\0'; /* no text pending */
  rpf_lineno=0;     /* just starting */

  /* continue until EOF */

  while(rpf_getword())
    {
      if ( rpf_literal )
        {
          /* literal mode terminated */

          if ( !tmstrcmp(rpf_word,_TMC("#")) )
            {
              rpf_literal=FALSE;
              setmode(M_NORMAL);
            }

          /* otherwise, print the entire line */

          else
            prtstr(rpf_word);
        }
      else
        {
          /* if word is an RPF command translate it */

          if ( (cmd=find_rpfkey(rpf_word)) >= 0 )
            translate_rpf_cmd(cmd);

          /* if not a close character, add word to string buffer */

          else if ( tmstrcmp(rpf_word,_TMC("#")) )
            {
              if ( *rpf_strbuf )
                tmstrcat(rpf_strbuf,_TMC(" "));
              tmstrcat(rpf_strbuf,rpf_word);
              if ( tmstrlen(rpf_strbuf) > 256 )
                {
                  prtstr(rpf_strbuf);
                  *rpf_strbuf = '\0';
                }
            }

          /* close character; print out and reset mode */

          /* A note about the # character; in RPF, # can either terminate
             certain commands or be literal text.  Since the rules for when
             it acts as one and not the other are very difficult to analyze,
             and even impossible considering that program flow could cause
             it to act as one for a particular set of data and as the other
             for a different set of data, guaprpf takes the easy way out.
             Singleton # characters are always treated as an attempt to
             change the current mode (turn off underlining, centering, etc.)
             If it is truly text, then use the escape character (i.e., \#).
          */

          else
            {
              if (*rpf_strbuf)
                {
                  prtstr(rpf_strbuf);
                  *rpf_strbuf='\0';
                }
              setmode(M_NORMAL);
            }
        }
    }
  
  /* print anything held in buffer */

  if (*rpf_strbuf)
    prtstr(rpf_strbuf);
}

/* translate_rpf_cmd is a driver for the remainder of the translate_rpf_
   functions; it accepts an int argument which is an offset into the
   rpfkey table, and calls the appropriate function to continue the
   translation.  Each of these functions makes calls to various
   functions defined in guarpfe.h to emulate the behavior of the original
   RPF code.  Those functions which translate more than one RPF command
   take an int argument indicating the current command.
*/

static void translate_rpf_cmd(int cmd)
{
  /* purge the string buffer */

  if (*rpf_strbuf)
    {
      prtstr(rpf_strbuf);
      *rpf_strbuf='\0';
    }

  switch(cmd)
    {
      case RPF_B      : skipline(1);
                        break;
      case RPF_CL     : 
      case RPF_L      : rpf_literal=TRUE;
                        rpf_buffer=NULL;
                        (cmd==RPF_L) ? setmode(M_LITER) : setmode(M_COLLIT);
                        break;
      case RPF_CEN    : setmode(M_CENTER);
                        break;
      case RPF_CUL    : setmode(M_CENUND);
                        break;
      case RPF_UL     : setmode(M_UNDER);
                        break;
      case RPF_CONCAT : concat();
                        break;
      case RPF_N      : newline();
                        break;
      case RPF_NC     : newcol();
                        break;
      case RPF_NP     : newpage();
                        break;
      case RPF_P      : pgraph();
                        break;
      case RPF_CS     :
      case RPF_I      :
      case RPF_S      :
      case RPF_T      : translate_rpf_1_num_arg(cmd);
                        break;
      case RPF_DT     : translate_rpf_table_define();
                        break;
      case RPF_FR     : justify(J_FULL);
                        break;
      case RPF_R      : justify(J_RIGHT);
                        break;
      case RPF_RR     : justify(J_LEFT);
                        break;
      case RPF_PAGE   : translate_rpf_page();
                        break;
      case RPF_SPN    : translate_rpf_pgnum();
                        break;
      case RPF_TE     : table(T_END);
                        break;
      case RPF_TTL    : translate_rpf_title();
                        break;

      /* non-implemented commands get to here */

      default         : prtmsg(RPFNIMP,rpf_lineno,_TMV(rpfkey[cmd]));
    }
}

/* translate_rpf_1_num_arg translates RPF commands which accept a single
   integer argument; #CS #I #S #T
*/

static void translate_rpf_1_num_arg(int cmd)
{
  int num;

  /* get the integer argument */

  if ( !rpf_getword() )
    prtmsg(MISSARG,rpf_lineno,_TMV(rpfkey[cmd]));

  /* translate it to a number */

  num=rpf_getnum();

  /* now perform the proper command */

  switch(cmd)
    {
      case RPF_CS : colskip(num);
                    break;
      case RPF_I  : indent(num);
                    break;
      case RPF_S  : skipline(num);
                    break;
      case RPF_T  : table(T_BEGIN,num);
                    break;
    }
}

/* translate_rpf_table_define translates the RPF command #DT into a call
   to the function table with an initial argument of T_DEFINE2.  table may
   be actually called in two ways to define a table, with T_DEFINE and
   and a variable argument list consisting of column definitions, or with
   T_DEFINE2 and a pointer to an array containing the column definitions.
*/

static void translate_rpf_table_define(void)
{
  int cols[129];     /* big enough for 64 columns */
  int i=0,num;

  /* get the table number */

  if ( !rpf_getword() )
    prtmsg(MISSARG,rpf_lineno,"DT");
  num=rpf_getnum();

  /* get a column starting position */

  if (!rpf_getword())
    prtmsg(MISSARG,rpf_lineno,"DT");

  /* gotta have at least one */

  if (!tmstrcmp(rpf_word,_TMC("#")))
    prtmsg(MISSARG,rpf_lineno,"DT");

  /* keep going until end of command reached */

  while ( tmstrcmp(rpf_word,_TMC("#")) )
    {
      cols[i++]=rpf_getnum();

      /* get a column ending position */

      if ( !rpf_getword() )
        prtmsg(MISSARG,rpf_lineno,"DT");
      cols[i++]=rpf_getnum();

      /* get the next column start (or # to end command) */

      if (!rpf_getword())
        prtmsg(MISSARG,rpf_lineno,"DT");
    }

  cols[i]=0; /* terminate the column list in the array */

  table(T_DEFINE2,num,cols);

  *rpf_word='\0';   /* otherwise # causes problems */
}

/* translate_rpf_page translates the RPF command #PAGE into a call to
   the function pgformat.
*/

static void translate_rpf_page(void)
{
  int top,bottom;

  /* get the top margin */

  if (!rpf_getword())
    prtmsg(MISSARG,rpf_lineno,"PAGE");
  top=rpf_getnum();

  /* get the bottom margin */

  if (!rpf_getword())
    prtmsg(MISSARG,rpf_lineno,"PAGE");
  bottom=rpf_getnum();

  pgformat(top,bottom);
}

/* translate_rpf_pgnum translates the RPF command #SPN into a call to
   the function pgnum.
*/

static void translate_rpf_pgnum(void)
{
  int type,pos,line,start,sect;

  /* get the page numbering type */

  if(!rpf_getword())
    prtmsg(MISSARG,rpf_lineno,"SPN");
  type=rpf_getnum();

  /* get the position for the page number */

  if(!rpf_getword())
    prtmsg(MISSARG,rpf_lineno,"SPN");
  pos=rpf_getnum();

  /* get the lines to skip after the page number */

  if(!rpf_getword())
    prtmsg(MISSARG,rpf_lineno,"SPN");
  line=rpf_getnum();

  /* get the starting page number */

  if(!rpf_getword())
    prtmsg(MISSARG,rpf_lineno,"SPN");
  start=rpf_getnum();

  /* get the optional section number (really only valid for type==1, but
     get it anyway.
  */

  if(!rpf_getword())
    prtmsg(MISTERM,rpf_lineno,"SPN");
  if ( !tmstrcmp(rpf_word,_TMC("#")) )
    sect=0;
  else
    {
      sect=rpf_getnum();
      if(!rpf_getword())
        prtmsg(MISTERM,rpf_lineno,"SPN");
      if ( tmstrcmp(rpf_word,_TMC("#")) )
        prtmsg(MISTERM,rpf_lineno,"SPN");
    }
  pgnum(type,pos,line,start,sect);

  *rpf_word='\0';  /* otherwise the # causes problems */
}

/* translate_rpf_title translates the RPF command #TTL into a call to the
   title function.  When parsing the text strings making up the lines of
   the title, it is necessary to grab the lines an RPF word at a time
   in order to correctly emulate RPF behavior with respect to spacing
   and periods.
*/

static void translate_rpf_title(void)
{
  TMCHAR str1[256],str2[256];
  int width;

  /* get the title width */

  if (!rpf_getword())
    prtmsg(MISSARG,rpf_lineno,"TTL");
  width=rpf_getnum();

  /* get the first line of the title (a word at a time) */

  if (!rpf_getword())
    prtmsg(MISSARG,rpf_lineno,"TTL");
  tmstrcpy(str1,rpf_word);

  if (!rpf_getword())
    prtmsg(MISTERM,rpf_lineno,"TTL");
  while ( tmstrcmp(rpf_word,_TMC("#")) && tmstrcmp(rpf_word,_TMC("|")) )
    {
      tmstrcat(str1,_TMC(" "));
      tmstrcat(str1,rpf_word);
      if (!rpf_getword())
        prtmsg(MISTERM,rpf_lineno,"TTL");
    }

  /* get the optional second line of the title (a word at a time) */

  *str2='\0';
  if ( !tmstrcmp(rpf_word,_TMC("|")) )
    {
      if( !rpf_getword())
        prtmsg(MISTERM,rpf_lineno,"TTL");
      if ( tmstrcmp(rpf_word,_TMC("#")) )
        {
          tmstrcpy(str2,rpf_word);
          if ( !rpf_getword())
            prtmsg(MISTERM,rpf_lineno,"TTL");
          while ( tmstrcmp(rpf_word,_TMC("#")) )
            {
              tmstrcat(str2,_TMC(" "));
              tmstrcat(str2,rpf_word);
              if ( !rpf_getword())
                prtmsg(MISTERM,rpf_lineno,"TTL");
            }
        }
    }

  /* look for the terminator */

  if ( tmstrcmp(rpf_word,_TMC("#")) )
    prtmsg(MISTERM,rpf_lineno,"TTL");

  /* make the appropriate call depending on whether there is a second line */

  if ( *str2 )
    title(width,str1,str2);
  else
    title(width,str1,NULL);

  *rpf_word='\0';    /* otherwise # causes problems */
}

/* rpf_getnum translates the current value of rpf_word into an integer
   and returns its value; an invalid number generates an error message
   and causes 0 to be returned.
*/

static int rpf_getnum(void)
{
  TMCHAR *p;

  for ( p=rpf_word ; isdigit(*p) ; p++ );
  if ( *p )
    prtmsg(NONPOSI,rpf_lineno,rpf_word);

  return tmatoi(rpf_word);
}

/* untab replaces tab characters in buffer by the appropriate number of
   spaces, depending on the location of the tab.
*/

void untab(TMCHAR *buffer)
{
  TMCHAR temp[256];
  int pos;
  TMCHAR *p;
  TMCHAR *blanks[]={_TMC("        "),
                         _TMC("       "),
                         _TMC("      "),
                         _TMC("     "),
                         _TMC("    "),
                         _TMC("   "),
                         _TMC("  "),
                         _TMC(" ")};

  while( (p=tmstrchr(buffer,'\t')) != NULL )
    {
      pos=p-buffer;
      tmstrcpy(temp,&buffer[pos+1]);
      buffer[pos]='\0';
      tmstrcat(buffer,blanks[pos%8]);
      tmstrcat(buffer,temp);
    }
}
