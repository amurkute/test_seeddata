/*TMCI18N BEGIN HEADER*/
#if !defined( _TMBGUASTDF_H_EXISTS )
/* No Initialisation Required */                                               
#include "tmcilib.h"
static struct TMBundle _TMBGUASTDF_H = {"guastdf.h",NULL,NULL,NULL,NULL};
#define _TMBGUASTDF_H_EXISTS
#endif
/*TMCI18N END HEADER*/

/* AUDIT_TRAIL_MSGKEY_UPDATE
-- PROJECT : MSGKEY
-- MODULE  : GUASTDF
-- SOURCE  : enUS
-- TARGET  : I18N
-- DATE    : Fri Oct 22 14:33:32 2010
-- MSGSIGN : #0000000000000000
END AUDIT_TRAIL_MSGKEY_UPDATE */

/* AUDIT_TRAIL_SCB
-- Solution Centre Baseline 
-- PROJECT : BAN74c
-- MODULE  : GUASTDF
-- SOURCE  : enUS
-- TARGET  : I18N
-- DATE    : Mon Mar 19 13:00:03 2007
END AUDIT_TRAIL_SCB */
/* Object: guastdf.h
   Author: John Morgan
 Mod Date: 05/02/95
  Release: General 2.1.1
*/

/****************************************************************************/
/*                                                                          */
/* Copyright 1993 - 2010 SunGard.  All rights reserved.                     */
/*                                                                          */
/* SunGard or its subsidiaries in the U.S. and other countries is the owner */
/* of numerous marks, including "SunGard," the SunGard logo, "Banner,"      */
/* "PowerCAMPUS," "Advance," "Luminis," "DegreeWorks," "fsaATLAS,"          */
/* "Course Signals," and "Open Digital Campus." Other names and marks used  */
/* in this material are owned by third parties.                             */
/*                                                                          */
/* This [site/software] contains confidential and proprietary information   */
/* of SunGard and its subsidiaries. Use of this [site/software] is limited  */
/* to SunGard Higher Education licensees, and is subject to the terms and   */
/* conditions of one or more written license agreements between SunGard     */
/* Higher Education and the licensee in question.                           */
/*                                                                          */
/****************************************************************************/

/* AUDIT TRAIL: 2.0                                INIT      DATE           */
/*                                                                          */
/* 1. Moved GETMEM macro from guarpfe.c to here,    GL     09/15/93         */
/*    to be available to all Pro*C programs, both                           */
/*    converted and native.                                                 */
/* 2. Added macro definition for FREEMEM.           GL     09/22/93         */
/*    Currently just "free(p)", but macro will                              */
/*    allow for any future changes to how memory                            */
/*    is freed across mulitple platforms, systems.                          */
/*                                                                          */
/* AUDIT TRAIL: 2.1                                INIT      DATE           */
/*                                                                          */
/* 1. Restored COLLISION_CHECK logic.              JWM     04/25/94         */
/* 2. Added function prototypes and macros for     JWM     04/26/94         */
/*    ORACLE support routines (originally in                                */
/*    guaorac.c).                                                           */
/* 3. Added prototypes for functions in            JWM     04/25/94         */
/*    guaorac2.pc.                                                          */
/* 4. Explicitly prototype sqlglm to prevent       JWM     11/21/94         */
/*    compile warning when in ANSI mode.                                    */
/* 5. Changed OS logic to eliminate use of         JWM     11/21/94         */
/*    defined keyword; Pro*C 2.0 doesn't recognize.                         */
/* 6. Include signal.h for VMS so that sleep       JWM     11/21/94         */
/*    will be prototyped.                                                   */
/* 7. Added CLOSE_CURSOR macro for programs not    JWM     12/16/94         */
/*    including guarpfe.h.                                                  */
/* 8. Added include of unistd.h for UNIX platforms JWM     12/16/94         */
/*    to get prototype for sleep().                                         */
/*                                                                          */
/* AUDIT TRAIL: 2.1.1                              INIT      DATE           */
/*                                                                          */
/* 1. Moved all cursor management macros from      JWM     05/02/95         */
/*    guarpfe.h to here.                                                    */
/*                                                                          */
/* AUDIT TRAIL: 2.1.5                              INIT      DATE           */
/*                                                                          */
/* 1. Security mods - getxnam function added.      JWM     08/15/95         */
/* 2. Mods to dberror - see guaorac2.pc.            JWM    08/16/95         */
/* 3. Removed obsolete OS and platform macros.     JWM     08/16/95         */
/*                                                                          */
/* AUDIT TRAIL: 2.1.11                             INIT      DATE           */
/*                                                                          */
/* 1. Made sure that A_OSF is defined for           JWM    09/08/96         */
/*    Digital UNIX platform, and modified                                   */
/*    prototype of sqlglm for 64-bit platforms.                             */
/* 2. Added prototypes for setglob and dateconv     JWM    09/19/96         */
/*    for handling century pivoting.                                        */
/*                                                                          */
/*                                                                          */
/* AUDIT TRAIL: 3.1                                      INIT      DATE     */
/*                                                                          */
/* 1. Add DEFAULT_DATE_FORMAT and sysdate function.       RLH    02/25/98   */
/*    This function was originally in guastdf.c.  The                       */
/*    version in guastdf.c was renamed to lsysdate.                         */
/*                                                                          */
/* AUDIT TRAIL: 3.1.0.1                                  INIT      DATE     */
/*                                                                          */
/* 1. NT Specific change for sleep routine.               RRM    07/27/9    */
/*                                                                          */
/*                                                                          */
/* AUDIT TRAIL: 4.0                                                         */
/* 1. TAM 12/15/1998                                                        */
/*    Added include for guaprod.h. This header file is generated by the     */
/*    new install process based on the subdirectories of $BANNER_HOME. It   */
/*    is also generated by the General 4.0 upgrade.                         */
/*                                                                          */
/* AUDIT TRAIL: 5.1                                                         */
/* 1. JWM 02/28/2001                                                        */
/*    Defect 57457 - Oracle8i version 8.1.6 does not properly set STRING    */
/*    variables to an empty string when a NULL or '' (Oracle empty string)  */
/*    are explicitly selected or returned by a decode. The macro NULLFIX    */
/*    has been added to expedite applying a work-around to effected code.   */
/* 2. JWM 03/16/2001                                                        */
/*    Defect 59690 - The DEC C 6.4 compiler is C99 compliant, and has       */
/*    introduced round as a reserved word; replace round with _round and    */
/*    use a macro to translate.                                             */
/*                                                                          */
/* AUDIT TRAIL: 6.1.2.1                                                     */
/* 1. JWM 02/06/2004                                                        */
/*    Added OS_LINUX support, and conditional inclusion of errno.h to       */
/*    resolve gurjobs.pc compilation problem on Linux. Defect 92535.        */
/*                                                                          */
/* AUDIT TRAIL: 7.0                                                         */
/* 1. Added POSTORA_API macro and API error message          JWM   03/19/04 */
/*    globals; also prototypes for p_commit and                             */
/*    p_rollback.                                                           */
/*                                                                          */
/* AUDIT TRAIL: 8.0                                                         */
/* TAM 10/08/2007                                                           */
/* 1. Internationalization unicode conversion                               */
/*                                                                          */
/* AUDIT TRAIL: 8.4                                                         */
/* 1. TGKinderman 10/19/2010                                                */
/*    Defect 1-2IHOFH                                                       */
/*    HPUX conditional compile directives to use hp_round() instead of      */
/*    _round() such that calls to round() work properly.                    */
/*                                                                          */
/* AUDIT TRAIL END                                                          */
/*                                                                          */
/* guastdf.h should be included in any compilation unit which needs to
   access the functions in guastdf.c or guaorac2.pc.
*/

#ifndef _GUASTDF_H_

/* Most of the code doesn't care what hardware/OS, but this logic will
   define macros and initialize variables for those that do.  When this
   code is done, the macros OPSYS and PLATFORM will contain values with,
   at least, a best guess.
*/

/* Supported Operating Systems */

#define OS_VMS      0
#define OS_VM       1
#define OS_UNIX     2
#define OS_MPE      3
#define OS_MSDOS    4  /* no, DOS is not supported, but support code was */
                       /* developed using Turbo C++ */
#define OS_OS2      5
#define OS_WINNT    6  /* Just getting ready; not quite there yet */
#define OS_LINUX    7

/* Supported Hardware Platforms */

#define PL_VAX      0
#define PL_SEQUENT  1
#define PL_IBM370   2
#define PL_ATT      3
#define PL_RS6000   4
#define PL_HP       5
#define PL_AVIION   6
#define PL_NCR      7
#define PL_SUN      8
#define PL_80X86    9
#define PL_UNISYS  10
#define PL_ALPHA   11
#define PL_UNKNOWN 12

/* Considering the number of possibilities and the changes in compilers, it
   is a hard problem to figure out where you are based on compiler-provided
   macros, so force the user to specify at least OS during compile.  Should
   be safe at this point to default to UNIX.
*/

#ifdef OPSYS_VMS
#define OPSYS OS_VMS
#endif
#ifdef OPSYS_VM
#define OPSYS OS_VM
#endif
#ifdef OPSYS_UNIX
#define OPSYS OS_UNIX
#endif
#ifdef OPSYS_MPE
#define OPSYS OS_MPE
#endif
#ifdef OPSYS_MSDOS
#define OPSYS OS_MSDOS
#endif
#ifdef OPSYS_OS2
#define OPSYS OS_OS2
#endif
#ifdef OPSYS_WINNT
#define OPSYS OS_WINNT
#endif
#ifdef OPSYS_LINUX
#define OPSYS OS_UNIX
#define OPSYS2 OS_LINUX
#endif
#ifndef OPSYS
#define OPSYS OS_UNIX
#endif

/* Similar logic for platform; first, check for user provided PLAT_
   definition; if that yields nothing, make a guess based on setting of
   OPSYS; finally default to UNKNOWN
*/

#ifdef PLAT_VAX
#define PLATFORM PL_VAX
#endif
#ifdef PLAT_SEQUENT
#define PLATFORM PL_SEQUENT
#endif
#ifdef PLAT_IBM370
#define PLATFORM PL_IBM3270
#endif
#ifdef PLAT_ATT
#define PLATFORM PL_ATT
#endif
#ifdef PLAT_RS6000
#define PLATFORM PL_RS6000
#endif
#ifdef PLAT_HP
#define PLATFORM PL_HP
#endif
#ifdef PLAT_AVIION
#define PLATFORM PL_AVIION
#endif
#ifdef PLAT_NCR
#define PLATFORM PL_NCR
#endif
#ifdef PLAT_SUN
#define PLATFORM PL_SUN
#endif
#ifdef PLAT_80X86
#define PLATFORM PL_80X86
#endif
#ifdef PLAT_UNISYS
#define PLATFORM PL_UNISYS
#endif
#ifdef PLAT_ALPHA
#define PLATFORM PL_ALPHA
#endif

/* if user did not specify platform, make a guess */

#ifndef PLATFORM
#if OPSYS==OS_VMS
#define PLATFORM PL_ALPHA
#endif
#if OPSYS==OS_VM
#define PLATFORM PL_IBM370
#endif
#if OPSYS==OS_MPE
#define PLATFORM PL_HP
#endif
#if OPSYS==OS_MSDOS
#define PLATFORM PL_80X86
#endif
#if OPSYS==OS_OS2
#define PLATFORM PL_80X86
#endif
#if OPSYS==OS_WINNT
#define PLATFORM PL_80X86
#endif
#ifdef __osf__
#define PLATFORM PL_ALPHA
#endif
#endif

#ifndef PLATFORM
#define PLATFORM PL_UNKNOWN
#endif

/* All the includes needed for a converted RPT C program; some are probably
   not necessary for "from scratch" C code, but the overhead is minimal
   so go ahead and include them.
*/

#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <stdio.h>
#include <math.h>
#include <stdarg.h>
#include <time.h>

/* OS dependent includes; note that the types.h header is non-ANSI
   but seems to be required many places.
*/

#if OPSYS==OS_UNIX
#include <sys/types.h>
#include <unistd.h>
#ifdef OPSYS2
#if OPSYS2==OS_LINUX
#include <errno.h>
#endif
#endif
#elif OPSYS==OS_VMS
#include <types.h>
#include <ssdef.h>   /* VMS error message codes */
#include <signal.h>
#elif OPSYS==OS_MSDOS
#include <alloc.h>   /* so the large memory model will work */
#endif

/* Alpha-specific stuff */

#if OPSYS==OS_UNIX
#if PLATFORM==PL_ALPHA
#ifndef A_OSF
#define A_OSF
#endif
#endif
#endif
      
/* NT-specific stuff */
#if OPSYS==OS_WINNT
#if PLATFORM==PL_80X86
void sleep(int secs);
#endif
#endif                 

/* CI18N Manual Mod for W1.1 enable c-linkage*/ 
#ifdef __cplusplus 
extern "C" { 
#endif 

/* get the enumeration of message codes */

#include "guaerror.h"

/* try to eliminate some development errors by including a file of
   names which may cause collisions on some platforms (e.g., dup is
   defined as a function in VAX C.
*/

#ifdef COLLISION_CHECK
#include "guaclsn.h"
#endif

/* include the header file which defines which products are installed. This
   file is generated via the new install process based on the subdirectories
   of $BANNER_HOME. It will also be generated by the General 4.0 upgrade.
*/
#include "guaprod.h"

/* include i18n support routines 
*/
#include "guanlsl.h"

/* define EXIT_SUCCESS and EXIT_FAILURE if they were not defined
   by stdlib.h
*/

#ifndef EXIT_SUCCESS
#define EXIT_SUCCESS 0
#endif
#ifndef EXIT_FAILURE
#define EXIT_FAILURE 1
#endif

/* now, for VMS, define EXIT_FAILURE so that it gives a better error
   message than NOMSG
*/

#if OPSYS==OS_VMS
#undef EXIT_FAILURE
#define EXIT_FAILURE SS$_ABORT
#endif

/* kludge to prevent "expression has no side-effects" warning under
   UNISYS UNIX implementation; this is a compiler "bug" affecting any
   program using variable argument lists
*/

#if PLATFORM==PL_UNISYS
#undef va_end
#define va_end(list)
#endif

/* the macros ALPHA and NUM are used by the function 'input' and some
   other routines */

#define ALPHA 0
#define NUM   1

/* macros for the mode parameter to functions containing SELECT statements */

#define FIRST_ROW 0     /* open cursor and get first row */
#define NEXT_ROW  1     /* get next row */
#define CLOSE_CURSOR 2  /* close the cursor */

/* these macros simplify the use of the 'compare' function - follows
   Digital DCL conventions
*/

#define EQ   1    /* relops for NUMSTR numbers */
#define NE   2
#define LT   3
#define LE   4
#define GT   5
#define GE   6
#define EQS  7
#define NES  8
#define LTS  9
#define LES  10   /* relops for strings */
#define GTS  11
#define GES  12

/* TRUE and FALSE are used to make clear when a boolean value is being
   assigned to an integer flag */

#define TRUE 1
#define FALSE 0

/* Memory allocation/deallocation functions/macros to insulate code
   from future changes to underlying memory structure.
*/

#define GETMEM(t,s) (t *)getmem(sizeof(t)*(s))
#define FREEMEM(p)  free(p)
void *getmem(int size);

/* The following macros simplify checking various ORACLE conditions
   after database access.
*/

#define ROWS_FOUND    sqlca.sqlcode==0
#define NO_ROWS_FOUND sqlca.sqlcode==1403
#define POSTORA       if ( sqlca.sqlcode < 0 ) dberror(_TMV(__FILE__),__LINE__)
#define POSTORA_API \
  ( sqlca.sqlcode >= 0 ? FALSE : dberror_api(_TMV(__FILE__),__LINE__,TRUE) )

/* macro to perform an Oracle-style nvl function to supply a value when
   the first argument is NULL
*/

#define NVL(v1,v2) ( *v1 ? v1 : (v2) )

/* macro to set a string to empty when the associated indicator variable
   indicates a NULL
*/

#define NULLFIX(v,i) if ( i == -1 ) *v = '\0'

/* ryo atexit style functions; atexit not implemented even with GNU C
   on the Sequent, so instead use regexit to register functions and
   then exit2os instead of exit
*/

typedef void (* regexit_t)(int exit_status);

void regexit(regexit_t fcn);
void exit2os(int flag);

/* sysdate emulates the ORACLE sysdate and supports most of ORACLE DATE
   formats */

TMCHAR *sysdate(TMCHAR *outdate,TMCHAR *format); 

/* default format for sysdate */

#define DEFAULT_DATE_FORMAT ORA_NLS_DATE_FORMAT

/* String functions */

TMCHAR *str2uc(TMCHAR *str);
TMCHAR *str2lc(TMCHAR *str);
TMCHAR *substr(TMCHAR *out_str,TMCHAR *in_str,int start,int len);
TMCHAR *leftpad(TMCHAR *str,int len,TMCHAR pad_char);
TMCHAR *rightpad(TMCHAR *str,int len,TMCHAR pad_char);
TMCHAR *ltrim(TMCHAR *str,TMCHAR *trim_chars);
TMCHAR *rtrim(TMCHAR *str,TMCHAR *trim_chars);
TMCHAR *strzip(TMCHAR *str);
TMCHAR *catstr(TMCHAR *target,int maxlen,...);

/* Miscellaneous functions */

int compare(TMCHAR *val1,TMCHAR *val2,int flag);
int inlist(TMCHAR *str,int type,...);
void input(TMCHAR *target,TMCHAR *prompt,int size,int type);
void prtmsg(int num,...);
TMCHAR *prtmode(void);

/* Math and conversion functions/macros for operating on NUMSTR character
   string representations of numbers.
*/

#define add(t,a1,a2)      addop(t,a1,a2,'+')
#define subtract(t,a1,a2) addop(t,a1,a2,'-')
TMCHAR *addop(TMCHAR *answer,TMCHAR *arg1,TMCHAR *arg2,TMCHAR oper);
TMCHAR *multiply(TMCHAR *answer,TMCHAR *arg1,TMCHAR *arg2);
TMCHAR *divide(TMCHAR *answer,TMCHAR *arg1,TMCHAR *arg2);
#if OPSYS==OS_UNIX
  #if PLATFORM==PL_HP
    TMCHAR *hp_round(TMCHAR *t,TMCHAR *s,int decs);
    #define round(t,s,d) hp_round(t,s,d) 
  #else
    TMCHAR *_round(TMCHAR *t,TMCHAR *s,int decs);
    #define round(t,s,d) _round(t,s,d)
  #endif
#else
  TMCHAR *_round(TMCHAR *t,TMCHAR *s,int decs);
  #define round(t,s,d) _round(t,s,d)   
#endif
int valnum(TMCHAR *num);
TMCHAR *tonum(TMCHAR *num,TMCHAR *str);
TMCHAR *tochar(TMCHAR *str,TMCHAR *num,TMCHAR *format);

/* OS aware file name handling routines - all take as a parameter a
   pointer to an instance of fn_struc, which contains fields for
   all pieces of a fully qualified filename as well as a full filename.
*/

typedef struct fn_struc
        {TMCHAR fname[80];
         TMCHAR dir[80];
         TMCHAR name[40];
         TMCHAR ext[40];
         TMCHAR vers[5]; } FNSTRUC;

void parsfn(FNSTRUC *f);
void makefn(FNSTRUC *f);
void initfn(FNSTRUC *f);
void getxnam(TMCHAR *p);

/* Structure to hold the decomposed executable filename, used by login process
   in guaorac2.  Var is actually located in guastdf.o.
*/

#ifndef _GUASTDF_C_
extern
#endif
FNSTRUC exefile;

/* ORACLE support function prototypes (functions in guaorac2.pc) */

void login(void);
int loglimit(int num);
void dberror(TMCHAR *fname,long lineno);
int dberror_api(TMCHAR *fname,long lineno,int return_on_api_error);
void dbexit(int exit_status);
void setglob(void);
TMCHAR *dateconv(TMCHAR *date);
void p_commit(void);
void p_rollback(void);

/* Explicitly declare sqlglm, since Oracle doesn't do it.  There is some
   question as to the correct format for buffer_size and message_length,
   but the doc says int.  If they really are longs in some places then
   some logic needs to be inserted here to do the right thing.
*/

void sqlglm(TMCHAR *message_buffer,size_t *buffer_size,size_t *message_length);

/* Variables for API error messages */

TMCHAR api_error_long[513];
TMCHAR api_error_copy[513];
int api_error_count;
TMCHAR *api_error_list[50];
int messaging_app_error;

/* In order to simplify the use of the Pro*C external datatype STRING,
   a different type is established for number strings (stored as
   char[27]'s, and for each possible string length for a converted
   rpt, from 1 to 255 characters (2 to 256 with null terminator).  The
   file guaorac.c has corresponding EXEC SQL TYPE statements for each
   of these typedefs.
*/

#if ! ( defined( _TMUNICODE) && defined (ORA_PROC))
/* Can use usual typdefs in pro*C */

typedef TMCHAR NUMSTR[27];

typedef TMCHAR CHAR2[2];
typedef TMCHAR CHAR3[3];
typedef TMCHAR CHAR4[4];
typedef TMCHAR CHAR5[5];
typedef TMCHAR CHAR6[6];
typedef TMCHAR CHAR7[7];
typedef TMCHAR CHAR8[8];
typedef TMCHAR CHAR9[9];
typedef TMCHAR CHAR10[10];
typedef TMCHAR CHAR11[11];
typedef TMCHAR CHAR12[12];
typedef TMCHAR CHAR13[13];
typedef TMCHAR CHAR14[14];
typedef TMCHAR CHAR15[15];
typedef TMCHAR CHAR16[16];
typedef TMCHAR CHAR17[17];
typedef TMCHAR CHAR18[18];
typedef TMCHAR CHAR19[19];
typedef TMCHAR CHAR20[20];
typedef TMCHAR CHAR21[21];
typedef TMCHAR CHAR22[22];
typedef TMCHAR CHAR23[23];
typedef TMCHAR CHAR24[24];
typedef TMCHAR CHAR25[25];
typedef TMCHAR CHAR26[26];
typedef TMCHAR CHAR27[27];
typedef TMCHAR CHAR28[28];
typedef TMCHAR CHAR29[29];
typedef TMCHAR CHAR30[30];
typedef TMCHAR CHAR31[31];
typedef TMCHAR CHAR32[32];
typedef TMCHAR CHAR33[33];
typedef TMCHAR CHAR34[34];
typedef TMCHAR CHAR35[35];
typedef TMCHAR CHAR36[36];
typedef TMCHAR CHAR37[37];
typedef TMCHAR CHAR38[38];
typedef TMCHAR CHAR39[39];
typedef TMCHAR CHAR40[40];
typedef TMCHAR CHAR41[41];
typedef TMCHAR CHAR42[42];
typedef TMCHAR CHAR43[43];
typedef TMCHAR CHAR44[44];
typedef TMCHAR CHAR45[45];
typedef TMCHAR CHAR46[46];
typedef TMCHAR CHAR47[47];
typedef TMCHAR CHAR48[48];
typedef TMCHAR CHAR49[49];
typedef TMCHAR CHAR50[50];
typedef TMCHAR CHAR51[51];
typedef TMCHAR CHAR52[52];
typedef TMCHAR CHAR53[53];
typedef TMCHAR CHAR54[54];
typedef TMCHAR CHAR55[55];
typedef TMCHAR CHAR56[56];
typedef TMCHAR CHAR57[57];
typedef TMCHAR CHAR58[58];
typedef TMCHAR CHAR59[59];
typedef TMCHAR CHAR60[60];
typedef TMCHAR CHAR61[61];
typedef TMCHAR CHAR62[62];
typedef TMCHAR CHAR63[63];
typedef TMCHAR CHAR64[64];
typedef TMCHAR CHAR65[65];
typedef TMCHAR CHAR66[66];
typedef TMCHAR CHAR67[67];
typedef TMCHAR CHAR68[68];
typedef TMCHAR CHAR69[69];
typedef TMCHAR CHAR70[70];
typedef TMCHAR CHAR71[71];
typedef TMCHAR CHAR72[72];
typedef TMCHAR CHAR73[73];
typedef TMCHAR CHAR74[74];
typedef TMCHAR CHAR75[75];
typedef TMCHAR CHAR76[76];
typedef TMCHAR CHAR77[77];
typedef TMCHAR CHAR78[78];
typedef TMCHAR CHAR79[79];
typedef TMCHAR CHAR80[80];
typedef TMCHAR CHAR81[81];
typedef TMCHAR CHAR82[82];
typedef TMCHAR CHAR83[83];
typedef TMCHAR CHAR84[84];
typedef TMCHAR CHAR85[85];
typedef TMCHAR CHAR86[86];
typedef TMCHAR CHAR87[87];
typedef TMCHAR CHAR88[88];
typedef TMCHAR CHAR89[89];
typedef TMCHAR CHAR90[90];
typedef TMCHAR CHAR91[91];
typedef TMCHAR CHAR92[92];
typedef TMCHAR CHAR93[93];
typedef TMCHAR CHAR94[94];
typedef TMCHAR CHAR95[95];
typedef TMCHAR CHAR96[96];
typedef TMCHAR CHAR97[97];
typedef TMCHAR CHAR98[98];
typedef TMCHAR CHAR99[99];
typedef TMCHAR CHAR100[100];
typedef TMCHAR CHAR101[101];
typedef TMCHAR CHAR102[102];
typedef TMCHAR CHAR103[103];
typedef TMCHAR CHAR104[104];
typedef TMCHAR CHAR105[105];
typedef TMCHAR CHAR106[106];
typedef TMCHAR CHAR107[107];
typedef TMCHAR CHAR108[108];
typedef TMCHAR CHAR109[109];
typedef TMCHAR CHAR110[110];
typedef TMCHAR CHAR111[111];
typedef TMCHAR CHAR112[112];
typedef TMCHAR CHAR113[113];
typedef TMCHAR CHAR114[114];
typedef TMCHAR CHAR115[115];
typedef TMCHAR CHAR116[116];
typedef TMCHAR CHAR117[117];
typedef TMCHAR CHAR118[118];
typedef TMCHAR CHAR119[119];
typedef TMCHAR CHAR120[120];
typedef TMCHAR CHAR121[121];
typedef TMCHAR CHAR122[122];
typedef TMCHAR CHAR123[123];
typedef TMCHAR CHAR124[124];
typedef TMCHAR CHAR125[125];
typedef TMCHAR CHAR126[126];
typedef TMCHAR CHAR127[127];
typedef TMCHAR CHAR128[128];
typedef TMCHAR CHAR129[129];
typedef TMCHAR CHAR130[130];
typedef TMCHAR CHAR131[131];
typedef TMCHAR CHAR132[132];
typedef TMCHAR CHAR133[133];
typedef TMCHAR CHAR134[134];
typedef TMCHAR CHAR135[135];
typedef TMCHAR CHAR136[136];
typedef TMCHAR CHAR137[137];
typedef TMCHAR CHAR138[138];
typedef TMCHAR CHAR139[139];
typedef TMCHAR CHAR140[140];
typedef TMCHAR CHAR141[141];
typedef TMCHAR CHAR142[142];
typedef TMCHAR CHAR143[143];
typedef TMCHAR CHAR144[144];
typedef TMCHAR CHAR145[145];
typedef TMCHAR CHAR146[146];
typedef TMCHAR CHAR147[147];
typedef TMCHAR CHAR148[148];
typedef TMCHAR CHAR149[149];
typedef TMCHAR CHAR150[150];
typedef TMCHAR CHAR151[151];
typedef TMCHAR CHAR152[152];
typedef TMCHAR CHAR153[153];
typedef TMCHAR CHAR154[154];
typedef TMCHAR CHAR155[155];
typedef TMCHAR CHAR156[156];
typedef TMCHAR CHAR157[157];
typedef TMCHAR CHAR158[158];
typedef TMCHAR CHAR159[159];
typedef TMCHAR CHAR160[160];
typedef TMCHAR CHAR161[161];
typedef TMCHAR CHAR162[162];
typedef TMCHAR CHAR163[163];
typedef TMCHAR CHAR164[164];
typedef TMCHAR CHAR165[165];
typedef TMCHAR CHAR166[166];
typedef TMCHAR CHAR167[167];
typedef TMCHAR CHAR168[168];
typedef TMCHAR CHAR169[169];
typedef TMCHAR CHAR170[170];
typedef TMCHAR CHAR171[171];
typedef TMCHAR CHAR172[172];
typedef TMCHAR CHAR173[173];
typedef TMCHAR CHAR174[174];
typedef TMCHAR CHAR175[175];
typedef TMCHAR CHAR176[176];
typedef TMCHAR CHAR177[177];
typedef TMCHAR CHAR178[178];
typedef TMCHAR CHAR179[179];
typedef TMCHAR CHAR180[180];
typedef TMCHAR CHAR181[181];
typedef TMCHAR CHAR182[182];
typedef TMCHAR CHAR183[183];
typedef TMCHAR CHAR184[184];
typedef TMCHAR CHAR185[185];
typedef TMCHAR CHAR186[186];
typedef TMCHAR CHAR187[187];
typedef TMCHAR CHAR188[188];
typedef TMCHAR CHAR189[189];
typedef TMCHAR CHAR190[190];
typedef TMCHAR CHAR191[191];
typedef TMCHAR CHAR192[192];
typedef TMCHAR CHAR193[193];
typedef TMCHAR CHAR194[194];
typedef TMCHAR CHAR195[195];
typedef TMCHAR CHAR196[196];
typedef TMCHAR CHAR197[197];
typedef TMCHAR CHAR198[198];
typedef TMCHAR CHAR199[199];
typedef TMCHAR CHAR200[200];
typedef TMCHAR CHAR201[201];
typedef TMCHAR CHAR202[202];
typedef TMCHAR CHAR203[203];
typedef TMCHAR CHAR204[204];
typedef TMCHAR CHAR205[205];
typedef TMCHAR CHAR206[206];
typedef TMCHAR CHAR207[207];
typedef TMCHAR CHAR208[208];
typedef TMCHAR CHAR209[209];
typedef TMCHAR CHAR210[210];
typedef TMCHAR CHAR211[211];
typedef TMCHAR CHAR212[212];
typedef TMCHAR CHAR213[213];
typedef TMCHAR CHAR214[214];
typedef TMCHAR CHAR215[215];
typedef TMCHAR CHAR216[216];
typedef TMCHAR CHAR217[217];
typedef TMCHAR CHAR218[218];
typedef TMCHAR CHAR219[219];
typedef TMCHAR CHAR220[220];
typedef TMCHAR CHAR221[221];
typedef TMCHAR CHAR222[222];
typedef TMCHAR CHAR223[223];
typedef TMCHAR CHAR224[224];
typedef TMCHAR CHAR225[225];
typedef TMCHAR CHAR226[226];
typedef TMCHAR CHAR227[227];
typedef TMCHAR CHAR228[228];
typedef TMCHAR CHAR229[229];
typedef TMCHAR CHAR230[230];
typedef TMCHAR CHAR231[231];
typedef TMCHAR CHAR232[232];
typedef TMCHAR CHAR233[233];
typedef TMCHAR CHAR234[234];
typedef TMCHAR CHAR235[235];
typedef TMCHAR CHAR236[236];
typedef TMCHAR CHAR237[237];
typedef TMCHAR CHAR238[238];
typedef TMCHAR CHAR239[239];
typedef TMCHAR CHAR240[240];
typedef TMCHAR CHAR241[241];
typedef TMCHAR CHAR242[242];
typedef TMCHAR CHAR243[243];
typedef TMCHAR CHAR244[244];
typedef TMCHAR CHAR245[245];
typedef TMCHAR CHAR246[246];
typedef TMCHAR CHAR247[247];
typedef TMCHAR CHAR248[248];
typedef TMCHAR CHAR249[249];
typedef TMCHAR CHAR250[250];
typedef TMCHAR CHAR251[251];
typedef TMCHAR CHAR252[252];
typedef TMCHAR CHAR253[253];
typedef TMCHAR CHAR254[254];
typedef TMCHAR CHAR255[255];
typedef TMCHAR CHAR256[256];
#else
/* _TMUNICODE and ORA_PROC are defined. Cannot use typedefs for TMCHAR */

#define NUMSTR TMCHAR

#define CHAR2 TMCHAR
#define CHAR3 TMCHAR
#define CHAR4 TMCHAR
#define CHAR5 TMCHAR
#define CHAR6 TMCHAR
#define CHAR7 TMCHAR
#define CHAR8 TMCHAR
#define CHAR9 TMCHAR
#define CHAR10 TMCHAR
#define CHAR11 TMCHAR
#define CHAR12 TMCHAR
#define CHAR13 TMCHAR
#define CHAR14 TMCHAR
#define CHAR15 TMCHAR
#define CHAR16 TMCHAR
#define CHAR17 TMCHAR
#define CHAR18 TMCHAR
#define CHAR19 TMCHAR
#define CHAR20 TMCHAR
#define CHAR21 TMCHAR
#define CHAR22 TMCHAR
#define CHAR23 TMCHAR
#define CHAR24 TMCHAR
#define CHAR25 TMCHAR
#define CHAR26 TMCHAR
#define CHAR27 TMCHAR
#define CHAR28 TMCHAR
#define CHAR29 TMCHAR
#define CHAR30 TMCHAR
#define CHAR31 TMCHAR
#define CHAR32 TMCHAR
#define CHAR33 TMCHAR
#define CHAR34 TMCHAR
#define CHAR35 TMCHAR
#define CHAR36 TMCHAR
#define CHAR37 TMCHAR
#define CHAR38 TMCHAR
#define CHAR39 TMCHAR
#define CHAR40 TMCHAR
#define CHAR41 TMCHAR
#define CHAR42 TMCHAR
#define CHAR43 TMCHAR
#define CHAR44 TMCHAR
#define CHAR45 TMCHAR
#define CHAR46 TMCHAR
#define CHAR47 TMCHAR
#define CHAR48 TMCHAR
#define CHAR49 TMCHAR
#define CHAR50 TMCHAR
#define CHAR51 TMCHAR
#define CHAR52 TMCHAR
#define CHAR53 TMCHAR
#define CHAR54 TMCHAR
#define CHAR55 TMCHAR
#define CHAR56 TMCHAR
#define CHAR57 TMCHAR
#define CHAR58 TMCHAR
#define CHAR59 TMCHAR
#define CHAR60 TMCHAR
#define CHAR61 TMCHAR
#define CHAR62 TMCHAR
#define CHAR63 TMCHAR
#define CHAR64 TMCHAR
#define CHAR65 TMCHAR
#define CHAR66 TMCHAR
#define CHAR67 TMCHAR
#define CHAR68 TMCHAR
#define CHAR69 TMCHAR
#define CHAR70 TMCHAR
#define CHAR71 TMCHAR
#define CHAR72 TMCHAR
#define CHAR73 TMCHAR
#define CHAR74 TMCHAR
#define CHAR75 TMCHAR
#define CHAR76 TMCHAR
#define CHAR77 TMCHAR
#define CHAR78 TMCHAR
#define CHAR79 TMCHAR
#define CHAR80 TMCHAR
#define CHAR81 TMCHAR
#define CHAR82 TMCHAR
#define CHAR83 TMCHAR
#define CHAR84 TMCHAR
#define CHAR85 TMCHAR
#define CHAR86 TMCHAR
#define CHAR87 TMCHAR
#define CHAR88 TMCHAR
#define CHAR89 TMCHAR
#define CHAR90 TMCHAR
#define CHAR91 TMCHAR
#define CHAR92 TMCHAR
#define CHAR93 TMCHAR
#define CHAR94 TMCHAR
#define CHAR95 TMCHAR
#define CHAR96 TMCHAR
#define CHAR97 TMCHAR
#define CHAR98 TMCHAR
#define CHAR99 TMCHAR
#define CHAR100 TMCHAR
#define CHAR101 TMCHAR
#define CHAR102 TMCHAR
#define CHAR103 TMCHAR
#define CHAR104 TMCHAR
#define CHAR105 TMCHAR
#define CHAR106 TMCHAR
#define CHAR107 TMCHAR
#define CHAR108 TMCHAR
#define CHAR109 TMCHAR
#define CHAR110 TMCHAR
#define CHAR111 TMCHAR
#define CHAR112 TMCHAR
#define CHAR113 TMCHAR
#define CHAR114 TMCHAR
#define CHAR115 TMCHAR
#define CHAR116 TMCHAR
#define CHAR117 TMCHAR
#define CHAR118 TMCHAR
#define CHAR119 TMCHAR
#define CHAR120 TMCHAR
#define CHAR121 TMCHAR
#define CHAR122 TMCHAR
#define CHAR123 TMCHAR
#define CHAR124 TMCHAR
#define CHAR125 TMCHAR
#define CHAR126 TMCHAR
#define CHAR127 TMCHAR
#define CHAR128 TMCHAR
#define CHAR129 TMCHAR
#define CHAR130 TMCHAR
#define CHAR131 TMCHAR
#define CHAR132 TMCHAR
#define CHAR133 TMCHAR
#define CHAR134 TMCHAR
#define CHAR135 TMCHAR
#define CHAR136 TMCHAR
#define CHAR137 TMCHAR
#define CHAR138 TMCHAR
#define CHAR139 TMCHAR
#define CHAR140 TMCHAR
#define CHAR141 TMCHAR
#define CHAR142 TMCHAR
#define CHAR143 TMCHAR
#define CHAR144 TMCHAR
#define CHAR145 TMCHAR
#define CHAR146 TMCHAR
#define CHAR147 TMCHAR
#define CHAR148 TMCHAR
#define CHAR149 TMCHAR
#define CHAR150 TMCHAR
#define CHAR151 TMCHAR
#define CHAR152 TMCHAR
#define CHAR153 TMCHAR
#define CHAR154 TMCHAR
#define CHAR155 TMCHAR
#define CHAR156 TMCHAR
#define CHAR157 TMCHAR
#define CHAR158 TMCHAR
#define CHAR159 TMCHAR
#define CHAR160 TMCHAR
#define CHAR161 TMCHAR
#define CHAR162 TMCHAR
#define CHAR163 TMCHAR
#define CHAR164 TMCHAR
#define CHAR165 TMCHAR
#define CHAR166 TMCHAR
#define CHAR167 TMCHAR
#define CHAR168 TMCHAR
#define CHAR169 TMCHAR
#define CHAR170 TMCHAR
#define CHAR171 TMCHAR
#define CHAR172 TMCHAR
#define CHAR173 TMCHAR
#define CHAR174 TMCHAR
#define CHAR175 TMCHAR
#define CHAR176 TMCHAR
#define CHAR177 TMCHAR
#define CHAR178 TMCHAR
#define CHAR179 TMCHAR
#define CHAR180 TMCHAR
#define CHAR181 TMCHAR
#define CHAR182 TMCHAR
#define CHAR183 TMCHAR
#define CHAR184 TMCHAR
#define CHAR185 TMCHAR
#define CHAR186 TMCHAR
#define CHAR187 TMCHAR
#define CHAR188 TMCHAR
#define CHAR189 TMCHAR
#define CHAR190 TMCHAR
#define CHAR191 TMCHAR
#define CHAR192 TMCHAR
#define CHAR193 TMCHAR
#define CHAR194 TMCHAR
#define CHAR195 TMCHAR
#define CHAR196 TMCHAR
#define CHAR197 TMCHAR
#define CHAR198 TMCHAR
#define CHAR199 TMCHAR
#define CHAR200 TMCHAR
#define CHAR201 TMCHAR
#define CHAR202 TMCHAR
#define CHAR203 TMCHAR
#define CHAR204 TMCHAR
#define CHAR205 TMCHAR
#define CHAR206 TMCHAR
#define CHAR207 TMCHAR
#define CHAR208 TMCHAR
#define CHAR209 TMCHAR
#define CHAR210 TMCHAR
#define CHAR211 TMCHAR
#define CHAR212 TMCHAR
#define CHAR213 TMCHAR
#define CHAR214 TMCHAR
#define CHAR215 TMCHAR
#define CHAR216 TMCHAR
#define CHAR217 TMCHAR
#define CHAR218 TMCHAR
#define CHAR219 TMCHAR
#define CHAR220 TMCHAR
#define CHAR221 TMCHAR
#define CHAR222 TMCHAR
#define CHAR223 TMCHAR
#define CHAR224 TMCHAR
#define CHAR225 TMCHAR
#define CHAR226 TMCHAR
#define CHAR227 TMCHAR
#define CHAR228 TMCHAR
#define CHAR229 TMCHAR
#define CHAR230 TMCHAR
#define CHAR231 TMCHAR
#define CHAR232 TMCHAR
#define CHAR233 TMCHAR
#define CHAR234 TMCHAR
#define CHAR235 TMCHAR
#define CHAR236 TMCHAR
#define CHAR237 TMCHAR
#define CHAR238 TMCHAR
#define CHAR239 TMCHAR
#define CHAR240 TMCHAR
#define CHAR241 TMCHAR
#define CHAR242 TMCHAR
#define CHAR243 TMCHAR
#define CHAR244 TMCHAR
#define CHAR245 TMCHAR
#define CHAR246 TMCHAR
#define CHAR247 TMCHAR
#define CHAR248 TMCHAR
#define CHAR249 TMCHAR
#define CHAR250 TMCHAR
#define CHAR251 TMCHAR
#define CHAR252 TMCHAR
#define CHAR253 TMCHAR
#define CHAR254 TMCHAR
#define CHAR255 TMCHAR
#define CHAR256 TMCHAR
#endif

#define _GUASTDF_H_
#endif
/*TMCI18N Manual Mod*/ 
#ifdef __cplusplus 
}  
#endif  
