/* AUDIT TRAIL:8.0 */
/* AUDIT TRAIL END */
#ifndef UOQCOM_H
#define UOQCOM_H

#define  LL_BEFORE              0
#define  LL_FIRST_MATCH         1

typedef enum
    {
    LL_FIRST, LL_NEXT, LL_PREV, LL_GETPOS
    } LLACTION;

/************************************************************************
* Link List support structures
************************************************************************/
typedef struct LLNODE *PLLNODE;

typedef struct LLNODE
    {
    PLLNODE  pNextLL;
    PLLNODE  pPrevLL;
    char    chData[1];
    } LLNODE;

typedef struct LLIST
    {
    long   cbDataLength;
    int      (*SortFunc)(void *, void *);
    PLLNODE  pFirstLL;
    PLLNODE  pLastLL;
    PLLNODE  pCurrentLL;
    } LLIST, *PLLIST;

/************************************************************************
* Link List Functions Prototypes
************************************************************************/

extern void LLInit(PLLIST pLLThis, long cbDataLength);
extern void LLSetSortFunc(PLLIST pLLThis, int (*SortFunc)(void *, void *));
extern void LLDeleteAll(PLLIST LLThis);
extern void LLAppend(PLLIST LLThis, void *pVoid);
extern void *LLNavigate(PLLIST LLThis, LLACTION dowhat);
extern void LLSetPosition(PLLIST LLThis, void *pVoid);
extern void *LLSearch(PLLIST pLList, void *pSearchKey, short sStopWhere);
extern void *LLInsert(PLLIST pLList, void *pData, short sHow);

extern int ValidateDate(char *pszDate, short *psValidInd);
extern void ConvDBLtoSZ(double dValue, char *pszString, char *pszMask);
extern void RightTrim(char *pszString);
extern char *FormatAcctNumber( char *pszAcctNumber, char *pszMask );
extern void AppendStrW_Space(char *pszStringOut, char *pszStringIn, long lLen);
extern double RoundDBL(double dNum, short sPlaces);



#endif
