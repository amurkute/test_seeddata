/*
*******************************************************************************
* Copyright (C) 1997-1999, International Business Machines Corporation and    *
* others. All Rights Reserved.                                                *
*******************************************************************************
*
* File MSGFMT.CPP
*
* Modification History:
*
*   Date        Name        Description
*   02/19/97    aliu        Converted from java.
*   03/20/97    helena      Finished first cut of implementation.
*   04/10/97    aliu        Made to work on AIX.  Added stoi to replace wtoi.
*   06/11/97    helena      Fixed addPattern to take the pattern correctly.
*   06/17/97    helena      Fixed the getPattern to return the correct pattern.
*   07/09/97    helena      Made ParsePosition into a class.
*   02/22/99    stephen     Removed character literals for EBCDIC safety
********************************************************************************

Mar 2002 Modified for TMCILIB + ICU2.1
Nov 2002 Modified for TMCILIB + ICU2.2
Mar 2004 Modified for TMCILIB + ICU2.8
Sep 2007 Modified for TMCILIB + ICU3.6

*/
/* AUDIT TRAIL: 8.0                                                         */
/* TAM 10/08/2007                                                           */
/* 1. Internationalization unicode conversion                               */
/* AUDIT TRAIL END                                                          */

#include "unicode/msgfmt.h"
#include "unicode/decimfmt.h"
#include "unicode/datefmt.h"
#include "unicode/smpdtfmt.h"
#include "unicode/choicfmt.h"
#include "unicode/ustring.h"
#include "unicode/ucnv_err.h"
#include "ustrfmt.h"
#include "util.h"
#include "unicode/uchar.h"

#include "msgfmttm.h"

#define COMMA             ((UChar)0x002C)
#define SINGLE_QUOTE      ((UChar)0x0027)
#define LEFT_CURLY_BRACE  ((UChar)0x007B)
#define RIGHT_CURLY_BRACE ((UChar)0x007D)

#define PERCENT			  ((UChar)0x0025)


static char chbuf[256];


/**
 * Convert a string to an unsigned decimal, ignoring rule whitespace.
 * @return a non-negative number if successful, or a negative number
 *         upon failure.
 */
static int32_t stou(const UnicodeString& string) {
    int32_t n = 0;
    int32_t count = 0;
    UChar32 c;
    for (int32_t i=0; i<string.length(); i+=U16_LENGTH(c)) {
        c = string.char32At(i);
    if (uprv_isRuleWhiteSpace(c)) {
            continue;
        }
        int32_t d = u_digit(c, 10);
        if (d < 0 || ++count > 10) {
            return -1;
        }
        n = 10*n + d;
    }
    return n;
}

/**
 * Convert an integer value to a string and append the result to
 * the given UnicodeString.
 */
static UnicodeString& itos(int32_t i, UnicodeString& appendTo) {
    UChar temp[16];
    uprv_itou(temp,16,i,10,0); // 10 == radix
    appendTo.append(temp);
    return appendTo;
}

//static UParseError parseErrorDummy;


MessageFormatTM::MessageFormatTM(const UnicodeString& pattern,
                             const Locale& newLocale,
                             UParseError& parseError,
                             UErrorCode& success)
:
  MessageFormat("",newLocale,success)
{
	fCPatternCapacity=0;
	applyPattern(pattern,parseError, success);
}


MessageFormatTM::MessageFormatTM(const UnicodeString& pattern,
                             const Locale& newLocale,
                             UErrorCode& success)
:
  MessageFormat("",newLocale,success)
{
	fCPatternCapacity=0;
    applyPattern(pattern, success);
}


void
MessageFormatTM::applyPattern(const UnicodeString& newPattern, 
                            UErrorCode& status)
{
    UParseError parseError;
    applyPattern(newPattern,parseError,status);
}
// -------------------------------------
// Applies the new pattern and returns an error if the pattern
// is not correct.
void
MessageFormatTM::applyPattern(const UnicodeString& pattern, 
                            UParseError& parseError,
                            UErrorCode& ec)
{
    if(U_FAILURE(ec)) {
        return;
    }
	  UBool foundPercent=FALSE;
	  //Comments see ICU baseline msgfmt.cpp
    UnicodeString segments[4];
    int32_t part = 0; 
    int32_t formatNumber = 0;
    UBool inQuote = FALSE;
    int32_t braceStack = 0;
    // Clear error struct
    parseError.offset = -1;
    parseError.preContext[0] = parseError.postContext[0] = (UChar)0;
    int32_t patLen = pattern.length();
    int32_t i;

    for (i=0; i<subformatCount; ++i) {
        delete subformats[i].format;
    }
    subformatCount = 0;
    argTypeCount = 0;

    for (i=0; i<patLen; ++i) {
        UChar ch = pattern[i];
        if (part == 0) {
            // In segment 0, recognize and remove quotes
            if (ch == SINGLE_QUOTE) {
                if (i+1 < patLen && pattern[i+1] == SINGLE_QUOTE) {
                    segments[0] += ch;
                    ++i;
                } else {
                    inQuote = !inQuote;
                }
            } else if (ch == LEFT_CURLY_BRACE && !inQuote) {
                // The only way we get from segment 0 to 1 is via an
                // unquoted '{'.
                part = 1;
            } else {
                segments[0] += ch;
            }
        } else if (inQuote) {
            // In segments 1..3, recognize quoted matter, and copy it
            // into the segment, together with the quotes.  This takes
            // care of '' as well.
            segments[part] += ch;
            if (ch == SINGLE_QUOTE) {
                inQuote = FALSE;
            }
        } else {
            // We have an unquoted character in segment 1..3
            switch (ch) {
            case COMMA:
                // Commas bump us to the next segment, except for segment 3,
                // which can contain commas.  See example above.
                if (part < 3)
                    part += 1;
                else
                    segments[3] += ch;
                break;
            case LEFT_CURLY_BRACE:
                // Handle '{' within segment 3.  The initial '{'
                // before segment 1 is handled above.
                if (part != 3) {
                    ec = U_PATTERN_SYNTAX_ERROR;
                    goto SYNTAX_ERROR;
                }
                ++braceStack;
                segments[part] += ch;
                break;
            case RIGHT_CURLY_BRACE:
                if (braceStack == 0) {
					          if (part!=2)
						            foundPercent=FALSE;
					          if (foundPercent) { //Hack in the Ansi format specifier support
						            makeFormatTM(formatNumber, segments, parseError,ec);
						         foundPercent=FALSE;

					          } else {
						           makeFormat(formatNumber, segments, parseError,ec);
					          }
                    if (U_FAILURE(ec)){
                        goto SYNTAX_ERROR;
                    }
                    formatNumber++;
                    segments[1].remove();
                    segments[2].remove();
                    segments[3].remove();
                    part = 0;
                } else {
                    --braceStack;
                    segments[part] += ch;
                }
                break;
			      case PERCENT:
				        if (part==2)
					          foundPercent=TRUE;
				        segments[part] += ch;
				        break;
            case SINGLE_QUOTE:
                inQuote = TRUE;
                // fall through (copy quote chars in segments 1..3)
            default:
                segments[part] += ch;
                break;
            }
        }
    }
    if (braceStack != 0 || part != 0) {
        // Unmatched braces in the pattern
        ec = U_UNMATCHED_BRACES;
        goto SYNTAX_ERROR;
    }
    fPattern = segments[0];
    return;

 SYNTAX_ERROR:
    syntaxError(pattern, i, parseError);
    for (i=0; i<subformatCount; ++i) {
        delete subformats[i].format;
    }
    argTypeCount = subformatCount = 0;
}



UnicodeString&
MessageFormatTM::format(const Formattable* source,
                      int32_t cnt,
                      UnicodeString& result,
                      FieldPosition& ignore,
                      UErrorCode& success) const
{
    if (U_FAILURE(success))
        return result;

    return format(source, cnt, result, ignore, 0, success);
}



//ICU 2.8 version - not changed for ICU 3.6
UnicodeString&
MessageFormatTM::format(const Formattable* arguments, 
                      int32_t cnt, 
                      UnicodeString& appendTo, 
                      FieldPosition& status, 
                      int32_t recursionProtection,
                      UErrorCode& success) const 
{
    // Allow NULL array only if cnt == 0
    if (cnt < 0 || (cnt && arguments == NULL)) {
        success = U_ILLEGAL_ARGUMENT_ERROR;
        return appendTo;
    }
    
    int32_t lastOffset = 0;
    for (int32_t i=0; i<subformatCount; ++i) {
        // Append the prefix of current format element.
        appendTo.append(fPattern, lastOffset, subformats[i].offset - lastOffset);
        lastOffset = subformats[i].offset;
        int32_t argumentNumber = subformats[i].arg;
        // Checks the scope of the argument number.
        if (argumentNumber >= cnt) {
            appendTo += LEFT_CURLY_BRACE;
            itos(argumentNumber, appendTo);
            appendTo += RIGHT_CURLY_BRACE;
            continue;
        }

        const Formattable *obj = arguments + argumentNumber;
        Formattable::Type type = obj->getType();

        // Recursively calling the format process only if the current
        // format argument refers to a ChoiceFormat object.
        Format* fmt = subformats[i].format;
        if (fmt != NULL) {
            UnicodeString arg;
            fmt->format(*obj, arg, success);

            // Needs to reprocess the ChoiceFormat option by using the
            // MessageFormat pattern application.
            if (fmt->getDynamicClassID() == ChoiceFormat::getStaticClassID() &&
                arg.indexOf(LEFT_CURLY_BRACE) >= 0) {
                MessageFormatTM temp(arg, fLocale,  success);
                // TODO: Implement recursion protection
                temp.format(arguments, cnt, appendTo, status, recursionProtection, success);
                if (U_FAILURE(success)) { 
                    return appendTo; 
                }
            }
            else {
                appendTo += arg;
            }
        }
        // If the obj data type is a number, use a NumberFormat instance.
        else if ((type == Formattable::kDouble) || 
                 (type == Formattable::kLong) ||
                 (type == Formattable::kInt64)) {

            const NumberFormat* nf = getDefaultNumberFormat(success);
            if (nf == NULL) { 
                return appendTo; 
            }
            if (type == Formattable::kDouble) {
                nf->format(obj->getDouble(), appendTo);
            } else if (type == Formattable::kLong) {
                nf->format(obj->getLong(), appendTo);
            } else {
                nf->format(obj->getInt64(), appendTo);
            }
        }
        // If the obj data type is a Date instance, use a DateFormat instance.
        else if (type == Formattable::kDate) {
            const DateFormat* df = getDefaultDateFormat(success);
            if (df == NULL) { 
                return appendTo; 
            }
            df->format(obj->getDate(), appendTo);
        }
        else if (type == Formattable::kString) {
            appendTo += obj->getString();
        }
        else {
            success = U_ILLEGAL_ARGUMENT_ERROR;
            return appendTo;
        }
    }
    // Appends the rest of the pattern characters after the real last offset.
    appendTo.append(fPattern, lastOffset, 0x7fffffff);
    return appendTo;
}

// -------------------------------------
// Checks which format instance we are really using based on the segments.

void
MessageFormatTM::makeFormatTM(int32_t formatNumber,
                              UnicodeString* segments,
                              UParseError& parseError,
                              UErrorCode& ec)
{
    if(U_FAILURE(ec))
        return ;

    // get the number
    int32_t argumentNumber = stou(segments[1]); // always unlocalized!
    if (argumentNumber < 0 ) {
        ec = U_INVALID_FORMAT_ERROR;
        return ;
    }

    if (!allocateSubformats(formatNumber+1) ||
        !allocateArgTypes(argumentNumber+1)) {
        ec = U_MEMORY_ALLOCATION_ERROR;
    }	

	  setAnsiPattern(argumentNumber, segments[2]);

    // Parse succeeded; record results in our arrays
    subformats[formatNumber].format = NULL;
    subformats[formatNumber].offset = segments[0].length();
    subformats[formatNumber].arg = argumentNumber;
    subformatCount = formatNumber+1;

	  argTypes[argumentNumber] = (Formattable::Type) FormattableTM::kAnsiPattern;
    if (argumentNumber+1 > argTypeCount) {
        argTypeCount = argumentNumber+1;
    }	


}
