/* AUDIT TRAIL: 8.0 */
/* AUDIT TRAIL END */
#ifndef UBRBILR_H
#define UBRBILR_H

#define    SINGLE_PARM               1
#define    MAX_PARMS                20
#define    MULTIPLE_SELECT_VALUE   100

/*-- Column Defines  ---------------------------------------------------------*/
/**************  CUST/PREM LINE  */
#define L1_COL1               0
#define L1_COL2               9
#define L1_COL3              50 
#define L1_COL4              60
#define L1_COL5              105

/**************  OPEN ITEM LINE  */
#define L2_COL1               0     /* service # */
#define L2_COL2               5     
#define L2_COL3              10
#define L2_COL4              15
#define L2_COL5              20
#define L2_COL6              32
#define L2_COL7              37
#define L2_COL8              47
#define L2_COL9              53
#define L2_COL10             63
#define L2_COL11             69
#define L2_COL12             80
#define L2_COL13             93
#define L2_COL14            L1_COL5 
#define L2_COL15            117
#define L2_COL16            122

/**************     BILL TOTALS  */
#define L3_COL1              0
#define L3_COL2              10
#define L3_COL3              22
#define L3_COL4              32
#define L3_COL5              44
#define L3_COL6              57
#define L3_COL7              69
#define L3_COL8              79
#define L3_COL9              91
#define L3_COL10             100
#define L3_COL11             112
#define L3_COL12             122

/**************  CYCLE TOTALS  */
#define L4_COL1              0
#define L4_COL2              10
#define L4_COL3              19
#define L4_COL4              25
#define L4_COL5              42
#define L4_COL6              52
#define L4_COL7              64
#define L4_COL8              91
#define L4_COL9             105

/**************  OPEN ITEM DETAIL */
#define L5_COL1              15
#define L5_COL2              27
#define L5_COL3              39
#define L5_COL4              50
#define L5_COL5              78
#define L5_COL6              80
#define L5_COL7              92

typedef enum 
   {PG_DEFAULT, PG_DETAIL, PG_CYCLE_TOTAL, PG_GRAND_TOTAL} PAGETYPE;           
/*----------------------------------------------------------------------------*/

#define EXEC_NAME            "UBRBILR"  /* the name of this program */
#define PAGE_WIDTH           131
#define DEFAULT_REPORT_TITLE "Billing Register"
/******************************************************************************/
/* parameter name strings                                                     */
/******************************************************************************/
#define   STR_LINES_PER_PAGE      "   Lines per page"
#define   STR_RECORD_COUNT        "     Record Count"
#define   STR_PRINTED_DATE        "     Printed date"
#define   STR_CYCLE_RANGE         "      Cycle range"
#define   STR_EXCEPTIONS_ONLY     "  Exceptions only"
#define   STR_OUT_OF_CYCLE_IND    "     Out of cycle"
#define   STR_NO_ACTIVITY_BILLS   "No Activity Bills"
/***************************************************************************/
typedef struct BREGKEY
   {
   char   szSTYP      [5];
   char   szSCATCode  [5];
   char   szSRATCode  [5];
   } BREGKEY, *PBREGKEY;

typedef struct BREG
   {
   BREGKEY   BRegKey;
   char      szCYCLCode      [ 6];
   char      szRegExcInd     [ 2];
   char      szRateDesc      [31];
   char      szRevenueInd    [ 2];
   char      szTaxableInd    [ 2];

   short     sChargedThisCycle;
   double    dBilledConsump;
   double    dBilledCharge;
   double    dDiscounts;
   double    dGrnBilledConsump;
   double    dGrnBilledCharge;
   double    dGrnDiscounts;
   } BREG, *PBREG;


#endif
