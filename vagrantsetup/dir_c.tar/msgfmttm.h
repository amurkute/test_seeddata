#ifndef _MSGFMTTM_
/* AUDIT TRAIL: 8.0                                                         */
/* TAM 10/08/2007                                                           */
/* 1. Internationalization unicode conversion                               */
/* AUDIT TRAIL: 8.1.0.1                                                     */
/* TAM 03/10/2009                                                           */
/* 1. Added #ifndef _MSGFMTTM_ logic.                                       */
/* AUDIT TRAIL END                                                          */
//#include <vector>
#include "unicode/umsg.h"
#include "unicode/msgfmt.h"
#include "unicode/fmtable.h"
#include <stdlib.h>
#include <stdio.h>

#ifndef _max
#define _max(a,b)  (((a) > (b)) ? (a) : (b))
#endif
#ifndef _min
#define _min(a,b)  (((a) < (b)) ? (a) : (b))
#endif

class FormattableTM : public Formattable {
public:
    enum Type
	{
        kDate	=Formattable::kDate		,   // Date
		kDouble	=Formattable::kDouble	,   // double
        kLong	=Formattable::kLong		,   // long
        kString	=Formattable::kString	,   // UnicodeString
        kArray	=Formattable::kArray	,	// Formattable[]
        kInt64  =Formattable::kInt64    ,	// int64
		kObject =Formattable::kObject	,	// UObject - getObject
		kAnsiPattern						// Extend ICU with Ansi type specifiers
    };	


};


/* 
extend class MessageFormat for dealing with %03d like formats (Ansi formats)

*/

//Derive class MessageFormatTM from MessageFormat.
//It should be the same as MessageFormat, except that it uses a different applyPattern.

class MessageFormatTM : public MessageFormat {
private:
	UnicodeString	**fCPattern; // store ansi type masks (%..). 
	int fCPatternCapacity;

public:
	~MessageFormatTM(){
		if (fCPattern && fCPatternCapacity) {
			for (int i=0; i<fCPatternCapacity;i++) {
				if (fCPattern[i])
					delete fCPattern[i];
			}
			free(fCPattern);
		}
	}
	
	//retVal = (UMessageFormat*) new MessageFormat(pattern,Locale(locale),*parseError,*status);
	inline	UnicodeString* getAnsiPattern(const int32_t argnum) 
	{ return fCPattern[argnum]; };
	void setAnsiPattern(const int32_t argnum, const UnicodeString pat)
	{
		const int growInc=10; //add 10 when increase is needed
		if (fCPatternCapacity==0) {
			fCPatternCapacity=_max(growInc,argnum+1);
			fCPattern=(UnicodeString**) malloc( sizeof(fCPattern[0]) * fCPatternCapacity);
			
			for (int i=0;fCPattern && i<fCPatternCapacity;i++)
				fCPattern[i]=NULL;
		}
		else if (fCPatternCapacity<argnum+1) {
			int newcap=argnum+growInc;
			fCPattern=(UnicodeString**) realloc( fCPattern,sizeof(fCPattern[0]) * newcap);
			for (int i=fCPatternCapacity;fCPattern && i<newcap;i++)
				fCPattern[i]=NULL;
			fCPatternCapacity=newcap;
		}
		fCPattern[argnum]=new UnicodeString(pat); 
		
#ifdef _TMUNICODE			
		//assume all strings in the argument list are UChar*
		//change the Ansi pattern accordingly (for ustdio u_sprintf replacement)
		switch (pat[pat.length()-1] ){
		case 's': //ICU 3.6 U - > S
			fCPattern[argnum]->replace(pat.length()-1,1,(UChar)'S');
			break;
		case 'c':
			fCPattern[argnum]->replace(pat.length()-1,1,(UChar)'C');
			break;
		default:
			break;
		}			
#endif
		
	};

	
    MessageFormatTM(
		const UnicodeString& pattern,
		const Locale& newLocale,
		UParseError& parseError,
		UErrorCode& success) ;

    MessageFormatTM(
		const UnicodeString& pattern,
		const Locale& newLocale,
		UErrorCode& success) ;

	virtual 
	void applyPattern(	const UnicodeString& newPattern, 
						UParseError& parseError,
						UErrorCode& success);
	virtual
	void applyPattern(	const UnicodeString& newPattern, 
						UErrorCode& status);

    UnicodeString& format(  const Formattable* source,
                            int32_t count,
                            UnicodeString& result,
                            FieldPosition& ignore,
                            UErrorCode& success) const;

    UnicodeString& format( const Formattable* arguments,
                            int32_t cnt,
                            UnicodeString& result,
                            FieldPosition& status,
                            int32_t recursionProtection,
                            UErrorCode& success) const;

	void  makeFormatTM(int32_t formatNumber,
                       UnicodeString* segments,
                       UParseError& parseError,
                       UErrorCode& ec);

 
};
#define _MSGFMTTM_
#endif
