/*TMCI18N BEGIN HEADER*/
#if !defined( _TMBSFRNOWD_H_EXISTS )
/* No Initialisation Required */                                               
#include "tmcilib.h"
static struct TMBundle _TMBSFRNOWD_H = {"sfrnowd.h",NULL,NULL,NULL,NULL};
#define _TMBSFRNOWD_H_EXISTS
#endif
/*TMCI18N END HEADER*/

/* AUDIT_TRAIL_MSGKEY_UPDATE
-- PROJECT : MSGKEY
-- MODULE  : SFRNOWD
-- SOURCE  : enUS
-- TARGET  : I18N
-- DATE    : Fri Mar 20 13:22:58 2015
-- MSGSIGN : #84357bdb4fd71eb5
END AUDIT_TRAIL_MSGKEY_UPDATE */

/* AUDIT_TRAIL_TM63
-- TranMan 6.3 
-- PROJECT : PVV_TEST
-- MODULE  : SFRNOWD
-- SOURCE  : enUS
-- TARGET  : I18N
-- DATE    : Tue Nov 06 06:44:35 2007
END AUDIT_TRAIL_TM63 */
/*****************************************************************************/
/* SFRNOWD.H Copyright 2015 Ellucian Company L.P. and its affiliates.        */
/*****************************************************************************/

/*****************************************************************************/
/*                                                                           */
/*       CONFIDENTIAL BUSINESS INFORMATION                                   */
/*                                                                           */
/*      **********************************                                   */
/*                                                                           */
/* THIS PROGRAM IS PROPRIETARY INFORMATION OF                                */
/* SYSTEMS AND COMPUTER TECHNOLOGY CORPORATION                               */
/* AND IS NOT TO BE COPIED, REPRODUCED, LENT OR                              */
/* DISPOSED OF, NOR USED FOR ANY PURPOSE OTHER                               */
/* THAN THAT FOR WHICH IT IS SPECIFICALLY PROVIDED                           */
/* WITHOUT THE WRITTEN PERMISSION OF SAID COMPANY                            */
/*                                                                           */
/*****************************************************************************/
/* SFRNOWD.H                                                                 */
/* Program Report -- Withdrawn Pending Status Change.                        */
/* AUDIT TRAIL: 4.3                                INIT    DATE              */
/* DRA 11JAN2000                                                             */
/* This Report was created for the Title IV Authorizations and Return of     */
/* Funds Enhancement.  Title IV Aid Loans and Grants funded by the           */
/* Federal Government under regulations initially established by the         */
/* Higher Education Act of 1965 and as amended.                              */
/* Reauthorization: Periodic review, modification, continuation of a         */
/* Federal Program.  Title IV was last reauthorized in 1998 with             */
/* significant changes to the required handling of Aid, if a student         */
/* withdraws from all classes.                                               */
/*                                                                           */
/* AUDIT TRAIL: 5.3.0.1                                INIT    DATE          */
/* 1. Defect 64902                                      JC   29-JUN-01       */
/* Problem...Program won't compile on VMS machine.                           */
/* Fix.......Moved two #define statements in #ifndef _SFRNOWD_C_             */
/*           statement from column 2 to column 1.                            */
/* 2. Defect 45663                                     DRA     28AUG2001     */
/* Problem...Trailing null missing from STR bind value.                      */
/* Fix.......Set the variable rptname from TMCHAR to[31] CHAR8.                  */
/* AUDIT TRAIL: 6.0                                                          */
/* 1. GPA/Grade/Credit Hours/../ Expansion project. DRA 08NOV2002            */
/*                                                                           */
/* AUDIT TRAIL: 7.3                                                          */
/* 1. Defect 92878                                      MAS  09-FEB-2006     */
/* Problem...Program doesn't select student who has no SFRSTCR records.      */
/* Fix.......In file sfrnowd.h, changed ENRLA to select students with        */
/*           active SFBETRM record. Also created "courses_found"             */
/*           variable. In file sfrnowd.pc, modified "process_enrl"           */
/*           function, to continue processing students who have no           */
/*           records fetched by "get_enrl_c". Also modified functions        */
/*           "print_details" and "name_sec", to eliminate course             */
/*           heading and blank line for students who have no courses.        */
/* 2. Defect 93486                                      JC   09-MAR-2006     */
/* Problem...Control report doesn't show Release number. It also prints      */
/*           START DATE twice, instead of START DATE and END DATE.           */
/* Fix.......In file sfrnowd.h, changed TITLE6 (control report title).       */
/*           In file sfrnowd.pc, defined variable "prt_title".  Also         */
/*           modified function "totalpage" as follows:                       */
/*           - Concatenated TITLE6 and version number into prt_title.        */
/*           - Changed third occurrence of T5 to T6, to print END DATE.      */
/*                                                                           */
/* AUDIT TRAIL: 7.3.3                                                        */
/* 1. Defect 1-28MPCI                                   JC   17-APR-2007     */
/*    Problem: Data for students who have no courses is sometimes incorrect. */
/*             Data is carried over from last student who had courses.       */
/*    Fix: 1) In sfrnowd.h, modified cursors get_enrl_c and get_hist_c.      */
/*            Removed the following line from the SELECT clause:             */
/*               F_ACCOUNT_BALANCE(:pidm)                                    */
/*         2) In sfrnowd.pc, modified functions get_enrl_data and            */
/*            get_hist_data.  Removed :bal_amt from the INTO clause of       */
/*            the FETCH, due to changes in sfrnowd.h cursors.                */
/*            Also added code to set variables to NULL or 0.000 when         */
/*            NO_ROWS_FOUND.                                                 */
/*         3) In sfrnowd.pc, modified function get_sfrstca, added the        */
/*            following to each SELECT clause:                               */
/*               F_ACCOUNT_BALANCE(sfrstca_pidm)                             */
/*                                                                           */
/* AUDIT TRAIL: 8.0                                                          */
/* 1. Migrated 7.x changes to 8.0                       JC   06-JUN-2007     */
/*                                                                           */
/* AUDIT TRAIL: 8.8                                                          */
/* 1. CR-000125282                                                           */
/*    JDC 03/20/2015                                                         */
/*    Ran re-key to ensure G$_NLS calls were properly coded                  */
/*                                                                           */
/* AUDIT TRAIL END                                                           */
/*****************************************************************************/

/*SCT data defined section.                                                  */
#ifndef _SFRNOWD_C_
#define STORE_CLASS extern
#else
#define STORE_CLASS /* */
#endif   

/*Value for array size.                                                      */
#define MAXSIZE 255   

/*Values for Boolean operations.                                             */
#define NO       _TMC("N") 
#define YES      _TMC("Y")
#define TRUE     1  
#define FALSE    0
#define NOTHING  _TMC("")
#define HISTORY  1
#define ENROLLED 2
#define ENROLLED 2

/*Values for file manipulation operations.                                   */
#define APPEND _TMC("a")    /*Append to current file.                              */
#define WRITE  _TMC("w")    /*Write to current file.                               */


/*Values for user entered parameters used by program.                        */
#define PARM1   _TMC("01")
#define PARM2   _TMC("02")
#define PARM3   _TMC("03")
#define PARM4   _TMC("04")
#define PARM5   _TMC("05")
#define PARM6   _TMC("06")
#define PARM7   _TMC("07")
#define PARM8   _TMC("08")
#define PARM9   _TMC("09")
#define PARM10  _TMC("10")
#define PARM11  _TMC("11") 
#define PARM12  _TMC("12")
#define PARM13  _TMC("13") 
#define PARM14  _TMC("14")

/*Special string literals for total page.                                    */
#define T1  TM_NLS_HGet( &_TMBSFRNOWD_H, "0000","TERM CODE                     : ")
#define T2  TM_NLS_HGet( &_TMBSFRNOWD_H, "0001","STUDENT LEVEL(S)              : ") 
#define T3  TM_NLS_HGet( &_TMBSFRNOWD_H, "0002","FINANCIAL AID SELECTION       : ")
#define T4  TM_NLS_HGet( &_TMBSFRNOWD_H, "0003","VERIFY ENROLLED               : ")
#define T5  TM_NLS_HGet( &_TMBSFRNOWD_H, "0004","START DATE                    : ")
#define T6  TM_NLS_HGet( &_TMBSFRNOWD_H, "0005","END DATE                      : ")
#define T7  TM_NLS_HGet( &_TMBSFRNOWD_H, "0006","VERIFY HISTORY                : ")
#define T8  TM_NLS_HGet( &_TMBSFRNOWD_H, "0007","GRADES WHICH REFLECT DROP     : ")
#define T9  TM_NLS_HGet( &_TMBSFRNOWD_H, "0008","CAMPUS                        : ")
#define T10 TM_NLS_HGet( &_TMBSFRNOWD_H, "0009","SORT ORDER                    : ")
#define T11 TM_NLS_HGet( &_TMBSFRNOWD_H, "0010","APPLICATION ID                : ")
#define T12 TM_NLS_HGet( &_TMBSFRNOWD_H, "0011","SELECTION ID                  : ")
#define T13 TM_NLS_HGet( &_TMBSFRNOWD_H, "0012","CREATOR ID                    : ")
#define T14 TM_NLS_HGet( &_TMBSFRNOWD_H, "0013","USER ID                       : ")
#define T15 TM_NLS_HGet( &_TMBSFRNOWD_H, "0014","TOTAL OF STUDENTS PROCESSED   : ")

/*Special string literals for various reasons.                               */
#define INIT   TM_NLS_HGet( &_TMBSFRNOWD_H, "0015","XX")
#define SELECT _TMC("")
#define TITLE1 TM_NLS_HGet( &_TMBSFRNOWD_H, "0016","STUDENTS ELIGIBLE TO ENROLL WHO HAVE NO ACTIVE REGISTRATION")
#define TITLE2 TM_NLS_HGet( &_TMBSFRNOWD_H, "0017","STUDENTS WITH TITLE IV AID")
#define TITLE3 TM_NLS_HGet( &_TMBSFRNOWD_H, "0018","STUDENTS WITH FINANCIAL AID")
#define TITLE4 TM_NLS_HGet( &_TMBSFRNOWD_H, "0019","ALL STUDENTS")
#define TITLE5 TM_NLS_HGet( &_TMBSFRNOWD_H, "0020","STUDENTS ELIGIBLE TO ENROLL WITH NO COURSES COMPLETED IN\
 HISTORY")
#define TITLE6 TM_NLS_HGet( &_TMBSFRNOWD_H, "0021","* * * REPORT CONTROL INFORMATION - SFRNOWD - Release ")

/*Special macros used in processing.                                         */
#define ARYCPY(arr1, arr2)  tmmemcpy(arr1, arr2, sizeof(arr1))

/*These macro get data from the user.                                        */
#define GET01  input(term,SELECT,7,ALPHA)
#define GET02  input(levl,SELECT,3,ALPHA)
#define GET03  input(aid_sel,SELECT,2,ALPHA)
#define GET04  input(enrl_val,SELECT,2,ALPHA)
#define GET05  input(start_date,SELECT,12,ALPHA)
#define GET06  input(end_date,SELECT,12,ALPHA)
#define GET07  input(hist_val,SELECT,2,ALPHA)
#define GET08  input(grade,SELECT,4,ALPHA)
#define GET09  input(campus,SELECT,3,ALPHA)
#define GET10  input(sort_ord,SELECT,2,ALPHA)
#define GET11  input(app_id,SELECT,31,ALPHA)
#define GET12  input(sel_id,SELECT,31,ALPHA)
#define GET13  input(crea_id,SELECT,31,ALPHA)
#define GET14  input(user_id,SELECT,31,ALPHA)

/*Dynamic SQL section for cursors.                                           */

#define ENRL1  _TMC("SELECT SPRIDEN_PIDM,\
		RPAD(SPRIDEN_ID, 9, ' '),\
		SPRIDEN_LAST_NAME,\
		SPRIDEN_FIRST_NAME,\
		SPRIDEN_MI,\
		X.SGBSTDN_LEVL_CODE,\
		X.SGBSTDN_CAMP_CODE,\
		X.SGBSTDN_COLL_CODE_1,\
		A.SFBETRM_ESTS_DATE\
		FROM   SPRIDEN, SFBETRM A, SGBSTDN X\
		WHERE  SPRIDEN_CHANGE_IND IS NULL\
		AND    X.SGBSTDN_TERM_CODE_EFF =\
                       (SELECT MAX(Y.SGBSTDN_TERM_CODE_EFF)\
			FROM   SGBSTDN Y\
			WHERE Y.SGBSTDN_PIDM = X.SGBSTDN_PIDM\
			AND   Y.SGBSTDN_TERM_CODE_EFF <= :term)\
		AND    X.SGBSTDN_LEVL_CODE IN\
		       (SELECT SPRCOLR_VALUE_ATYP\
			FROM   SPRCOLR\
	   		WHERE  SPRCOLR_JOB         = :rptname\
			AND    SPRCOLR_SESSIONID   = :sessionid\
			AND    SPRCOLR_PARM_NUMBER = '02')\
		AND    A.SFBETRM_TERM_CODE = :term\
		AND    A.SFBETRM_PIDM = SPRIDEN_PIDM\
		AND    X.SGBSTDN_PIDM = SPRIDEN_PIDM\
		AND    SPRIDEN_PIDM IN ")

#define ENRLA _TMC("(SELECT SFBETRM_PIDM\
		FROM   STVESTS, SFBETRM\
		WHERE  STVESTS_CODE = SFBETRM_ESTS_CODE\
		AND    STVESTS_WD_IND != 'Y'\
		AND    SFBETRM_TERM_CODE = :term\
		MINUS\
	        SELECT SFRSTCR_PIDM\
		FROM   STVRSTS, SFRSTCR\
		WHERE  STVRSTS_CODE = SFRSTCR_RSTS_CODE\
		AND    STVRSTS_INCL_SECT_ENRL = 'Y'\
                AND    STVRSTS_WITHDRAW_IND = 'N'\
		AND    SFRSTCR_TERM_CODE = :term) ")

#define ENRLB _TMC("(SELECT SFBETRM_PIDM\
		FROM   STVESTS, SFBETRM, GLBEXTR\
		WHERE  STVESTS_CODE = SFBETRM_ESTS_CODE\
		AND    STVESTS_WD_IND != 'Y'\
		AND    SFBETRM_TERM_CODE = :term\
		AND    SFBETRM_PIDM = TO_NUMBER(GLBEXTR_KEY)\
		AND    GLBEXTR_APPLICATION = UPPER(:app_id)\
		AND    GLBEXTR_SELECTION   = UPPER(:sel_id)\
		AND    GLBEXTR_USER_ID     = UPPER(:user_id)\
		AND    GLBEXTR_CREATOR_ID  = UPPER(:crea_id)\
		MINUS\
		SELECT SFRSTCR_PIDM\
		FROM   STVRSTS, SFRSTCR, GLBEXTR\
		WHERE  STVRSTS_CODE = SFRSTCR_RSTS_CODE\
		AND    STVRSTS_INCL_SECT_ENRL = 'Y'\
                AND    STVRSTS_WITHDRAW_IND = 'N'\
		AND    SFRSTCR_TERM_CODE = :term\
		AND    SFRSTCR_PIDM = TO_NUMBER(GLBEXTR_KEY)\
		AND    GLBEXTR_APPLICATION = UPPER(:app_id)\
		AND    GLBEXTR_SELECTION   = UPPER(:sel_id)\
		AND    GLBEXTR_USER_ID     = UPPER(:user_id)\
		AND    GLBEXTR_CREATOR_ID  = UPPER(:crea_id)) ")

#define CAMP   _TMC(" AND X.SGBSTDN_CAMP_CODE = :campus ")


#define ORDBID _TMC(" ORDER BY RPAD(SPRIDEN_ID, 9, ' ') ") 
#define ORDBNM _TMC(" ORDER BY SPRIDEN_LAST_NAME, SPRIDEN_FIRST_NAME,\
                 SPRIDEN_MI ")
#define ORDBLV _TMC(" ORDER BY X.SGBSTDN_LEVL_CODE, RPAD(SPRIDEN_ID, 9, ' ') ")

#define	HIST1  _TMC("SELECT SPRIDEN_PIDM,\
		RPAD(SPRIDEN_ID, 9, ' '),\
		SPRIDEN_LAST_NAME,\
		SPRIDEN_FIRST_NAME,\
		SPRIDEN_MI,\
		X.SGBSTDN_LEVL_CODE,\
		X.SGBSTDN_CAMP_CODE,\
		X.SGBSTDN_COLL_CODE_1,\
		A.SFBETRM_ESTS_DATE\
		FROM   SPRIDEN, SFBETRM A, SGBSTDN X\
		WHERE  SPRIDEN_CHANGE_IND IS NULL\
		AND    X.SGBSTDN_TERM_CODE_EFF =\
                       (SELECT MAX(Y.SGBSTDN_TERM_CODE_EFF)\
			FROM   SGBSTDN Y\
			WHERE Y.SGBSTDN_PIDM = X.SGBSTDN_PIDM\
			AND   Y.SGBSTDN_TERM_CODE_EFF <= :term)\
		AND    X.SGBSTDN_LEVL_CODE IN\
		       (SELECT SPRCOLR_VALUE_ATYP\
			FROM   SPRCOLR\
	   		WHERE  SPRCOLR_JOB         = :rptname\
			AND    SPRCOLR_SESSIONID   = :sessionid\
			AND    SPRCOLR_PARM_NUMBER = '02')\
		AND    A.SFBETRM_TERM_CODE = :term\
		AND    A.SFBETRM_PIDM = SPRIDEN_PIDM\
		AND    X.SGBSTDN_PIDM = SPRIDEN_PIDM\
		AND    SPRIDEN_PIDM IN ")
 
#define HISTA _TMC("(SELECT SHRTCKG_PIDM\
                FROM   STVESTS, SFBETRM B, SHRTCKG\
                WHERE  STVESTS_CODE = B.SFBETRM_ESTS_CODE\
                AND    STVESTS_WD_IND != 'Y'\
                AND    B.SFBETRM_TERM_CODE = SHRTCKG_TERM_CODE\
		AND    B.SFBETRM_PIDM = SHRTCKG_PIDM\
		AND    SHRTCKG_TERM_CODE = :term\
		MINUS\
		SELECT SHRTCKG_PIDM\
		FROM   SHRTCKG\
		WHERE  SHRTCKG_GRDE_CODE_FINAL NOT IN\
		       (SELECT SPRCOLR_VALUE_ATYP\
			FROM   SPRCOLR\
			WHERE  SPRCOLR_JOB         = :rptname\
			AND    SPRCOLR_SESSIONID   = :sessionid\
			AND    SPRCOLR_PARM_NUMBER = '08')\
		AND    SHRTCKG_TERM_CODE = :term) ")

#define HISTB _TMC("(SELECT SHRTCKG_PIDM\
                FROM   STVESTS, SFBETRM B, SHRTCKG, GLBEXTR\
                WHERE  STVESTS_CODE = B.SFBETRM_ESTS_CODE\
                AND    STVESTS_WD_IND != 'Y'\
                AND    B.SFBETRM_TERM_CODE = SHRTCKG_TERM_CODE\
		AND    B.SFBETRM_PIDM = SHRTCKG_PIDM\
		AND    SHRTCKG_TERM_CODE = :term\
                AND    SHRTCKG_PIDM = TO_NUMBER(GLBEXTR_KEY)\
		AND    GLBEXTR_APPLICATION = UPPER(:app_id)\
		AND    GLBEXTR_SELECTION   = UPPER(:sel_id)\
		AND    GLBEXTR_USER_ID     = UPPER(:user_id)\
		AND    GLBEXTR_CREATOR_ID  = UPPER(:crea_id)\
		MINUS\
		SELECT SHRTCKG_PIDM\
		FROM   SHRTCKG, GLBEXTR\
		WHERE  SHRTCKG_GRDE_CODE_FINAL NOT IN\
		       (SELECT SPRCOLR_VALUE_ATYP\
			FROM   SPRCOLR\
			WHERE  SPRCOLR_JOB         = :rptname\
			AND    SPRCOLR_SESSIONID   = :sessionid\
			AND    SPRCOLR_PARM_NUMBER = '08')\
		AND    SHRTCKG_TERM_CODE = :term\
		AND    SHRTCKG_PIDM = TO_NUMBER(GLBEXTR_KEY)\
		AND    GLBEXTR_APPLICATION = UPPER(:app_id)\
		AND    GLBEXTR_SELECTION   = UPPER(:sel_id)\
		AND    GLBEXTR_USER_ID     = UPPER(:user_id)\
		AND    GLBEXTR_CREATOR_ID  = UPPER(:crea_id)) ")

/*typedef TMCHAR TMCHAR0[500][5000];*/           /*For the dynamic sql statement       */
/*typedef TMCHAR TMCHAR0[50][500]; */

EXEC SQL BEGIN DECLARE SECTION;
    
     STORE_CLASS long   pidm;  
     STORE_CLASS TMCHAR  temp_val[2];
     STORE_CLASS TMCHAR  grde_ind[2];
     STORE_CLASS TMCHAR  sdate_ind[2];
     STORE_CLASS TMCHAR  edate_ind[2];
     STORE_CLASS TMCHAR  levl[3];
     STORE_CLASS TMCHAR  slevl[3];
     STORE_CLASS TMCHAR  parm_numberIn[3];
     STORE_CLASS TMCHAR  campus[4];
     STORE_CLASS TMCHAR  grade[7]; 
     STORE_CLASS TMCHAR  term[7]; 
     STORE_CLASS TMCHAR  rptname[8]; 
     STORE_CLASS TMCHAR start_date[12];
     STORE_CLASS TMCHAR end_date[12];  
     STORE_CLASS TMCHAR sessionid[31];
     STORE_CLASS TMCHAR user_id[31];
     STORE_CLASS TMCHAR app_id[31];
     STORE_CLASS TMCHAR sel_id[31];
     STORE_CLASS TMCHAR crea_id[31];
     STORE_CLASS BANNUMSTR(one_up_no);

     STORE_CLASS TMCHAR     status[3];
     STORE_CLASS TMCHAR     coll[3];
     STORE_CLASS TMCHAR     sec[4];
     STORE_CLASS TMCHAR     camp1[4];
     STORE_CLASS TMCHAR     camp2[4];
     STORE_CLASS TMCHAR     ptrm[4];
     STORE_CLASS TMCHAR     subj[5];
     STORE_CLASS TMCHAR     crn[6];
     STORE_CLASS TMCHAR     crse[6];
     STORE_CLASS TMCHAR     grde[7];
     STORE_CLASS TMCHAR     campcol[7];
     STORE_CLASS TMCHAR    stu_id[10];
     STORE_CLASS TMCHAR    sta_date[12];
     STORE_CLASS TMCHAR    las_date[12];
     STORE_CLASS TMCHAR    enrl[12];
     STORE_CLASS TMCHAR    last_chg[12];
     STORE_CLASS TMCHAR    first_name[16];
     STORE_CLASS TMCHAR	   mi[16];
     STORE_CLASS TMCHAR    last_name[60];
     STORE_CLASS double    bal_amt;
     STORE_CLASS double    tiv_acc_amt;
     STORE_CLASS double    tot_acc_amt;
     STORE_CLASS double    orig_chgs;
     STORE_CLASS double    non_orig_chgs;
     STORE_CLASS double    net_inst_chgs;

 EXEC SQL END DECLARE SECTION;

STORE_CLASS TMCHAR select_statement[5000]; /*The actual record statement         */
STORE_CLASS FNSTRUC  outfile;          /*The file struct's definition.       */
STORE_CLASS UFILE     *output_file;     /*The file pointer.                   */
/*****************************************************************************/
/*****************************************************************************/
/*****************************************************************************/
/*****************************************************************************/
/*                            VARIABLE SECTION                               */

STORE_CLASS int       batch_run; 
STORE_CLASS TMCHAR     aid_sel[2];
STORE_CLASS TMCHAR     enrl_val[2];
STORE_CLASS TMCHAR     hist_val[2];
STORE_CLASS TMCHAR     report_type[2];
STORE_CLASS TMCHAR     sort_ord[2];
STORE_CLASS int       dateIn;
STORE_CLASS long      size;
STORE_CLASS long      diff;
STORE_CLASS long      length;
STORE_CLASS TMCHAR    prev_stu_id[10]; 
STORE_CLASS TMCHAR     prev_slevl[3]; 
STORE_CLASS TMCHAR      stu_name[30];
STORE_CLASS short     IND1;           
STORE_CLASS short     page_no;       
STORE_CLASS short     line_count;   
STORE_CLASS short     state;
STORE_CLASS short     courses_found;
STORE_CLASS long      count_rec;
STORE_CLASS TMCHAR      *data[MAXSIZE];  

/*****************************************************************************/
/*****************************************************************************/
/*                            CURSOR SECTION                                 */
/*The cursors below are used in various processes to manipulate data in the  */
/*tables.                                                                    */
/*****************************************************************************/

/*Cursor to collect the parameter value for this job's run.                  */
 EXEC SQL DECLARE parm_cursor CURSOR FOR
      SELECT GJBPRUN_VALUE
      FROM   GJBPRUN
      WHERE  GJBPRUN_NUMBER = :parm_numberIn
      AND    GJBPRUN_JOB = UPPER(:rptname)
      AND    GJBPRUN_ONE_UP_NO = TO_NUMBER(:one_up_no);

#ifdef FINAID 
 EXEC SQL DECLARE tiv_amount CURSOR FOR 
      SELECT NVL(SUM(NVL(RPRATRM_ACCEPT_AMT,0)),0),
             NVL(SUM(NVL(RPRATRM_PAID_AMT,0)),0)
      FROM   RTVFSRC, RFRFFID, RFRBASE, RPRATRM
      WHERE  RPRATRM_PIDM         = :pidm
      AND    RPRATRM_TERM_CODE    = :term
      AND    RFRBASE_FUND_CODE    = RPRATRM_FUND_CODE
      AND    RTVFSRC_IND          = 'F'
      AND    RTVFSRC_CODE         = RFRBASE_FSRC_CODE
      AND    RFRBASE_FED_FUND_ID  = RFRFFID_FED_FUND_ID
      AND    RFRFFID_TITLE_IV_IND = 'Y'
      AND    RFRFFID_FED_FUND_ID  != 'GTIV';  

 EXEC SQL DECLARE tot_amount CURSOR FOR
      SELECT NVL(SUM(NVL(RPRATRM_ACCEPT_AMT,0)),0),
             NVL(SUM(NVL(RPRATRM_PAID_AMT,0)),0)
      FROM   RPRATRM
      WHERE  RPRATRM_TERM_CODE    = :term
      AND    RPRATRM_PIDM         = :pidm;
#endif

/*Get the LEVL parm values from sprcolr.                                    */
 EXEC SQL DECLARE atype_stu_levl CURSOR FOR
      SELECT SPRCOLR_VALUE_ATYP
      FROM   SPRCOLR
      WHERE  SPRCOLR_JOB         = :rptname
      AND    SPRCOLR_SESSIONID   = :sessionid
      AND    SPRCOLR_PARM_NUMBER = '02'
      ORDER BY SPRCOLR_VALUE_ATYP;

/*Get the GRADE parm values from sprcolr.                                   */
 EXEC SQL DECLARE atype_grade CURSOR FOR
      SELECT SPRCOLR_VALUE_ATYP
      FROM   SPRCOLR
      WHERE  SPRCOLR_JOB         = :rptname
      AND    SPRCOLR_SESSIONID   = :sessionid
      AND    SPRCOLR_PARM_NUMBER = '08'; 

/*Get student's enrollment information.                                     */
 EXEC SQL DECLARE get_enrl_c CURSOR FOR
      SELECT  RPAD(SFRSTCR_CRN, 5, ' '),
              RPAD(SFRSTCR_CAMP_CODE, 3, ' '),
              RPAD(SFRSTCR_RSTS_CODE, 2, ' '),
              SFRSTCR_RSTS_DATE,
              SFRSTCR_LAST_ATTEND,
              RPAD(SSBSECT_SUBJ_CODE, 4, ' '),
              RPAD(SSBSECT_CRSE_NUMB, 5, ' '),
              RPAD(SSBSECT_SEQ_NUMB, 3, ' '),
              RPAD(SSBSECT_PTRM_CODE, 3, ' ')
       FROM   SSBSECT, SFRSTCR
       WHERE  SSBSECT_CRN = SFRSTCR_CRN
       AND    SSBSECT_TERM_CODE = SFRSTCR_TERM_CODE
       AND    SFRSTCR_TERM_CODE = :term
       AND    SFRSTCR_PIDM = :pidm;

/*Get student's history information.                                        */
 EXEC SQL DECLARE get_hist_c CURSOR FOR
      SELECT  RPAD(SHRTCKN_CRN, 5, ' '),
              RPAD(SHRTCKN_CAMP_CODE, 3, ' '),
              RPAD(SHRTCKN_SUBJ_CODE, 4, ' '),
              RPAD(SHRTCKN_CRSE_NUMB, 5, ' '),
              RPAD(SHRTCKN_SEQ_NUMB, 3, ' '),
              RPAD(SHRTCKN_PTRM_CODE, 3, ' '), 
              RPAD(A.SHRTCKG_GRDE_CODE_FINAL, 6, ' ')
       FROM   SHRTCKG A, SHRTCKN
       WHERE  A.SHRTCKG_TERM_CODE = SHRTCKN_TERM_CODE
       AND    A.SHRTCKG_TCKN_SEQ_NO = SHRTCKN_SEQ_NO
       AND    A.SHRTCKG_PIDM = SHRTCKN_PIDM
       AND    SHRTCKN_TERM_CODE = :term
       AND    SHRTCKN_PIDM = :pidm
       AND    A.SHRTCKG_SEQ_NO = 
             (SELECT MAX(B.SHRTCKG_SEQ_NO)
                FROM SHRTCKG B
               WHERE B.SHRTCKG_TERM_CODE = SHRTCKN_TERM_CODE
                 AND B.SHRTCKG_TCKN_SEQ_NO = SHRTCKN_SEQ_NO
                 AND B.SHRTCKG_PIDM = SHRTCKN_PIDM);

/*BOTTOM*/  

