/*TMCI18N BEGIN HEADER*/
#if !defined( _TMBSFPAGRD_H_EXISTS )
/* No Initialisation Required */                                               
#include "tmcilib.h"
static struct TMBundle _TMBSFPAGRD_H = {"sfpagrd.h",NULL,NULL,NULL,NULL};
#define _TMBSFPAGRD_H_EXISTS
#endif
/*TMCI18N END HEADER*/

/* AUDIT_TRAIL_MSGKEY_UPDATE
-- PROJECT : MSGKEY
-- MODULE  : SFPAGRD
-- SOURCE  : enUS
-- TARGET  : I18N
-- DATE    : Fri Mar 20 13:22:57 2015
-- MSGSIGN : #901a6c17532cf97f
END AUDIT_TRAIL_MSGKEY_UPDATE */

/* AUDIT_TRAIL_TM63
-- TranMan 6.3 
-- PROJECT : PVV_TEST
-- MODULE  : SFPAGRD
-- SOURCE  : enUS
-- TARGET  : I18N
-- DATE    : Fri Oct 19 07:49:43 2007
END AUDIT_TRAIL_TM63 */
/*****************************************************************************/
/* SFPAGRD.H Copyright 2015 Ellucian Company L.P. and its affiliates.        */
/*****************************************************************************/
/*****************************************************************************/
/*                                                                           */
/*       CONFIDENTIAL BUSINESS INFORMATION                                   */
/*                                                                           */
/*      **********************************                                   */
/*                                                                           */
/* THIS PROGRAM IS PROPRIETARY INFORMATION OF                                */
/* SYSTEMS AND COMPUTER TECHNOLOGY CORPORATION                               */
/* AND IS NOT TO BE COPIED, REPRODUCED, LENT OR                              */
/* DISPOSED OF, NOR USED FOR ANY PURPOSE OTHER                               */
/* THAN THAT FOR WHICH IT IS SPECIFICALLY PROVIDED                           */
/* WITHOUT THE WRITTEN PERMISSION OF SAID COMPANY                            */
/*                                                                           */
/*****************************************************************************/
/* SFPAGRD.H                                                                 */
/* Program SFPAGRD.PC Header File.                                           */
/*                                                                           */
/* AUDIT TRAIL: 6.0                                  INIT    DATE            */
/* LM  01/15/2003                                                            */
/* Designed to update existing SFRSTCR record(s) with grade,user,date        */
/* for OL:R courses matching certain user entered criteia.                   */ 
/* AUDIT TRAIL: 7.4.0.1                                INIT    DATE          */
/* 1. Defect CMS-DFCT100522                            JC    08/15/2007      */
/* Problems:                                                                 */
/*   1) Does not delete records from GJBPRUN when it completes.              */
/*   2) Assigns grades to registrations that are not gradable.               */
/*   3) Assigns grades to traditional courses. Should only assign            */
/*      grades to open learning courses.                                     */
/* Fix: 1) Modified sfpagrd.pc, added function del_parms.                    */
/*      2) Modified sfpagrd.h, changed BASE_WHERE2 clause as follows:        */
/*           OLD:  AND STVRSTS_WITHDRAW_IND = 'N'                            */
/*           NEW:  AND STVRSTS_GRADABLE_IND = 'Y'                            */
/*      3) Modified sfpagrd.h, added following to BASE_WHERE2 clause:        */
/*           AND SFRSTCR_PTRM_CODE IS NULL                                   */
/* AUDIT TRAIL: 8.0 (I18N)                                                   */
/* Description: Internationalization Unicode Conversion                      */ 
/*                                                                           */
/* AUDIT TRAIL : 8.1                                                         */
/*  1. Defect 1-3TTEHV                                     JC  08/04/2008    */
/*     Change TM_NLS_Get to _TMC where no literals are being translated      */
/*     and in debug messages.                                                */
/*                                                                           */
/* AUDIT TRAIL: 8.8                                                          */
/* 1. CR-000125282                                                           */
/*    JDC 03/20/2015                                                         */
/*    Ran re-key to ensure G$_NLS calls were properly coded                  */
/*                                                                           */
/* AUDIT TRAIL END                                                           */
/*****************************************************************************/
#ifndef _SFPAGRD_C_
#define STORE_CLASS extern
#else
#define STORE_CLASS /* */
#endif   

EXEC SQL BEGIN DECLARE SECTION;

  STORE_CLASS BANNUMSTR(ask_one_up_no);
  STORE_CLASS TMCHAR  rptname[8];
  STORE_CLASS TMCHAR inst_name[31];
  STORE_CLASS TMCHAR report_title[61];
  STORE_CLASS TMCHAR cur_date[21];
  STORE_CLASS TMCHAR sessionid[31];
  STORE_CLASS TMCHAR sqluser[31];
  STORE_CLASS TMCHAR single_parm[31];  
  STORE_CLASS TMCHAR  something[2];
  STORE_CLASS TMCHAR  parm_number[3];
  STORE_CLASS TMCHAR parm_value[31];
  STORE_CLASS BANNUMSTR(rpt_one_up_no);
  STORE_CLASS TMCHAR this_function[30];
  STORE_CLASS TMCHAR this_statement[99];
  STORE_CLASS TMCHAR stu_first_name[16];
  STORE_CLASS TMCHAR stu_mi[16];
  STORE_CLASS TMCHAR stu_last_name[60];
  STORE_CLASS BANNUMSTR(stu_pidm);
  STORE_CLASS int    inst_pidm;
  STORE_CLASS int    grace_int;
  STORE_CLASS TMCHAR  grace_period[4];
  STORE_CLASS TMCHAR grace_date[12];
  STORE_CLASS TMCHAR  levl_code[3];
  STORE_CLASS TMCHAR no_of_patterns[10];
  STORE_CLASS TMCHAR  prev_crn[7];
  STORE_CLASS TMCHAR  prev_term[7];
  STORE_CLASS TMCHAR long_title1[31]; 
  STORE_CLASS TMCHAR long_title2[31];    
  STORE_CLASS TMCHAR long_title3[31];    
  STORE_CLASS TMCHAR long_title4[31];    
  STORE_CLASS TMCHAR  final_grade[7];
  STORE_CLASS int    str_length;

EXEC SQL END DECLARE SECTION;

/*typedef TMCHAR TMCHAR[10000][10000];
typedef TMCHAR TMCHAR[5000][5000]; */
STORE_CLASS TMCHAR select_statement1[10000]; 
STORE_CLASS TMCHAR  select_clause1[5000];

/*****************************************************************************/
/*                            VARIABLE SECTION                               */
/*****************************************************************************/  
/*Value for array size.                                                      */
#define MAXSIZE 255   
/*Values for Boolean operations.                                             */
#define NO      _TMC("N") 
#define YES     _TMC("Y")
#define TRUE    1  
#define FALSE   0  
#define NOTHING _TMC("")
/* 
#define SCT_DEBUG 1
*/
/*****************************************************************************/
/*                               SQL SECTION                                 */
/*                                                                           */
/* Values used to construct the dynamic sql statement.                       */
/* All Strings have no leading space, only trailing space for the            */
/* concatenation of strings.( Except OR clauses have leading spaces.)        */      
/*                                                                           */ 
/* Function Process_build responsible for ordering/logic of constructing     */
/* the statement. All alter_for_ functions responsible for assembling        */
/* & concatenating the string.  Function process_sql processes the statement */
/*****************************************************************************/     

#define SEL    _TMC("SELECT ")
#define FRM    _TMC("FROM ")
#define WHER   _TMC("WHERE ")
#define ORDER1 _TMC("ORDER BY 4,3,6,7 ")
#define ORDER2 _TMC("ORDER BY 6,7,4,3 ")

#define STATE1      _TMC("SPRIDEN_PIDM, SPRIDEN_ID, SPRIDEN_FIRST_NAME, SPRIDEN_LAST_NAME, SPRIDEN_MI, \
                     SFRAREG_TERM_CODE, SFRAREG_CRN, TO_CHAR(SFRAREG_COMPLETION_DATE,'DD-MON-YYYY'), \
                     NVL(SSBSECT_CRSE_TITLE,SCBCRSE_TITLE), SUBSTR(SSRSYLN_LONG_COURSE_TITLE,1,30), \
                     SUBSTR(SSRSYLN_LONG_COURSE_TITLE,31,30), SUBSTR(SSRSYLN_LONG_COURSE_TITLE,61,30), \
                     SUBSTR(SSRSYLN_LONG_COURSE_TITLE,91,20), SFRSTCR_LEVL_CODE ")

#define BASE_FRM     _TMC("SPRIDEN, SFRAREG, SFRSTCR, SSBSECT, SCBCRSE, SSRSYLN, STVRSTS ")

#define BASE_WHERE1 _TMC("SFRAREG_TERM_CODE = SFRSTCR_TERM_CODE \
                     AND SFRAREG_CRN = SFRSTCR_CRN ")

#define BASE_WHERE2 _TMC("AND SFRSTCR_TERM_CODE = SSBSECT_TERM_CODE \
                     AND SFRSTCR_CRN = SSBSECT_CRN \
                     AND SFRSTCR_PTRM_CODE IS NULL \
                     AND SFRSTCR_GRDE_CODE IS NULL \
                     AND SFRSTCR_GRDE_DATE IS NULL \
                     AND SFRAREG_EXTENSION_NUMBER = (SELECT MAX(SFRAREG_EXTENSION_NUMBER) \
                                                       FROM SFRAREG X \
                                                      WHERE X.SFRAREG_PIDM = SFRSTCR_PIDM \
                                                        AND X.SFRAREG_CRN = SFRSTCR_CRN \
                                                        AND X.SFRAREG_TERM_CODE = SFRSTCR_TERM_CODE) \
                     AND SFRSTCR_CRN = SSRSYLN_CRN(+) \
                     AND SFRSTCR_TERM_CODE = SSRSYLN_TERM_CODE(+) \
                     AND STVRSTS_CODE = SFRSTCR_RSTS_CODE \
                     AND STVRSTS_GRADABLE_IND = 'Y' \
                     AND SSBSECT_CRSE_NUMB = SCBCRSE_CRSE_NUMB \
                     AND SSBSECT_SUBJ_CODE = SCBCRSE_SUBJ_CODE \
                     AND SCBCRSE_EFF_TERM = (SELECT MAX(SCBCRSE_EFF_TERM) \
                                               FROM SCBCRSE Z \
                                              WHERE Z.SCBCRSE_SUBJ_CODE = SSBSECT_SUBJ_CODE \
                                                AND Z.SCBCRSE_CRSE_NUMB = SSBSECT_CRSE_NUMB \
                                                AND Z.SCBCRSE_EFF_TERM <= SSBSECT_TERM_CODE ) \
                     AND SFRAREG_PIDM = SFRSTCR_PIDM \
                     AND SPRIDEN_PIDM = SFRAREG_PIDM \
                     AND SPRIDEN_CHANGE_IND IS NULL ")

#define COND_DATE  _TMC("AND TO_DATE(TO_CHAR(TRUNC(SFRAREG_START_DATE), \
                   'DD-MON-YYYY'),'DD-MON-YYYY')BETWEEN \
                    TO_DATE(:range_date1, 'DD-MON-YYYY') \
                    AND TO_DATE(:range_date2, 'DD-MON-YYYY') ")

#define COND_GRACE _TMC("AND TO_DATE(TO_CHAR(TRUNC(SFRAREG_COMPLETION_DATE + :grace_int), \
                   'DD-MON-YYYY'),'DD-MON-YYYY') \
                   <= TO_DATE(TO_CHAR(SYSDATE,'DD-MON-YYYY'),'DD-MON-YYYY')  ")

#define INSTRUCT    _TMC("AND SFRAREG_INSTRUCTOR_PIDM = :inst_pidm ")

#define ANDTERMLIKE _TMC("AND ( SFRAREG_TERM_CODE LIKE ")
#define ORTERMLIKE  _TMC(" OR SFRAREG_TERM_CODE LIKE ")

#define ANDCRNLIKE _TMC("AND ( SFRAREG_CRN LIKE ")
#define ORCRNLIKE  _TMC(" OR SFRAREG_CRN LIKE ")

#define ANDSCHDLIKE _TMC("AND ( SSBSECT_SCHD_CODE LIKE ")
#define ORSCHDLIKE  _TMC(" OR SSBSECT_SCHD_CODE LIKE ")

#define ANDINSMLIKE _TMC("AND ( NVL(SSBSECT_INSM_CODE,'**') LIKE ")
#define ORINSMLIKE  _TMC(" OR NVL(SSBSECT_INSM_CODE,'**') LIKE ")

/*****************************************************************************/
/*                              MACRO SECTION.                               */
/* Used to accept user enter values when running from host.                  */
/*****************************************************************************/    
#define GET00  input(use_term,SELECT,2,ALPHA)
#define GET01  input(process_term,SELECT,7,ALPHA)
#define GET02  input(use_range,SELECT,2,ALPHA)
#define GET03  input(range_date1,SELECT,12,ALPHA)
#define GET04  input(range_date2,SELECT,12,ALPHA)
#define GET05  input(process_crn,SELECT,6,ALPHA)
#define GET06  input(schd_type,SELECT,4,ALPHA)
#define GET07  input(inst_method,SELECT,6,ALPHA)
#define GET08  input(instructor,SELECT,9,ALPHA)
#define GET09  input(ask_grace,SELECT, 4,NUM)
#define GET10  input(grade,SELECT, 7,ALPHA)
#define GET11  input(runmode,SELECT,2,ALPHA)
#define GET12  input(sort_order,SELECT,2,ALPHA)

#define PARM1   _TMC("01")
#define PARM2   _TMC("02")
#define PARM3   _TMC("03")
#define PARM4   _TMC("04")
#define PARM5   _TMC("05")
#define PARM6   _TMC("06")
#define PARM7   _TMC("07")
#define PARM8   _TMC("08")
#define PARM9   _TMC("09")
#define PARM10  _TMC("10")
#define PARM11  _TMC("11") 
#define PARM12  _TMC("12")

/*****************************************************************************/
/*                      STRING LITERAL SECTION                               */ 
/* Used mostly for formatting in control_rept function.                      */
/*****************************************************************************/    

#define S3 _TMC("                                                                ")
#define S1 _TMC("                                                              ")    
#define T1 TM_NLS_HGet( &_TMBSFPAGRD_H, "0000","                                                  Report Name : ")
#define T2 TM_NLS_HGet( &_TMBSFPAGRD_H, "0001","                                                         Term : ")
#define T3 TM_NLS_HGet( &_TMBSFPAGRD_H, "0002","                                              Start From Date : ")
#define T4 TM_NLS_HGet( &_TMBSFPAGRD_H, "0003","                                                Start To Date : ")
#define T5 TM_NLS_HGet( &_TMBSFPAGRD_H, "0004","                                                          CRN : ")
#define T6 TM_NLS_HGet( &_TMBSFPAGRD_H, "0005","                                                Schedule Type : ")
#define T7 TM_NLS_HGet( &_TMBSFPAGRD_H, "0006","                                         Instructional Method : ")
#define T8 TM_NLS_HGet( &_TMBSFPAGRD_H, "0007","                                                   Instructor : ")
#define T9 TM_NLS_HGet( &_TMBSFPAGRD_H, "0008","                                  Grade Deadline Grace Period : ")
#define T10 TM_NLS_HGet( &_TMBSFPAGRD_H, "0009","                                                        Grade : ")
#define T11 TM_NLS_HGet( &_TMBSFPAGRD_H, "0010","                                       Run Mode [Audit/Update]: ")
#define T12 TM_NLS_HGet( &_TMBSFPAGRD_H, "0011","                                                   Sort Order : ")
#define T13 TM_NLS_HGet( &_TMBSFPAGRD_H, "0012","                                      Processing Totals ....... ")
#define T14 TM_NLS_HGet( &_TMBSFPAGRD_H, "0013","                                             Records Selected : ")  
#define T15 TM_NLS_HGet( &_TMBSFPAGRD_H, "0014","                                              Records Updated : ")  
#define T16 TM_NLS_HGet( &_TMBSFPAGRD_H, "0015","                                                   Session ID : ")  
#define T17 TM_NLS_HGet( &_TMBSFPAGRD_H, "0016","* * * REPORT CONTROL INFORMATION - SFPAGRD - Release 8.8 * * *")
#define T18 TM_NLS_HGet( &_TMBSFPAGRD_H, "0017","                                                   Grace Date : ")
#define T19 TM_NLS_HGet( &_TMBSFPAGRD_H, "0018","* * * Process Aborted due to invalid parameter. * * *")        
#define SELECT TM_NLS_HGet( &_TMBSFPAGRD_H, "0019"," Enter SELECTION: ")
#define AUDIT  TM_NLS_HGet( &_TMBSFPAGRD_H, "0020","AUDIT MODE")
#define UPDATE TM_NLS_HGet( &_TMBSFPAGRD_H, "0021","UPDATE MODE")         
#define NONE    TM_NLS_HGet( &_TMBSFPAGRD_H, "0022","NONE")
#define PERC    _TMC("%")      

/*****************************************************************************/
/*                            VARIABLE SECTION                               */
/*****************************************************************************/    
STORE_CLASS int  audit_total;
STORE_CLASS int  update_total;
STORE_CLASS TMCHAR *data[MAXSIZE];
STORE_CLASS short Ind_01;       
STORE_CLASS TMCHAR stu_name[30];
STORE_CLASS long size;
STORE_CLASS long diff;
STORE_CLASS long length;    

/*****************************************************************************/
/*                            CURSOR SECTION                                 */
/*****************************************************************************/    
/*Cursor to collect the parameter value for this job's run.                  */
 EXEC SQL DECLARE parm_cursor CURSOR FOR
      SELECT GJBPRUN_VALUE
      FROM   GJBPRUN
      WHERE  GJBPRUN_NUMBER = :parm_number
      AND    GJBPRUN_JOB = UPPER(:rptname)
      AND    GJBPRUN_ONE_UP_NO = TO_NUMBER(:rpt_one_up_no)
      AND    GJBPRUN_VALUE <> '%';

/*Get the atype names to be deleted from sprcolr.                           */
 EXEC SQL DECLARE atype_value CURSOR FOR 
      SELECT SPRCOLR_VALUE_ATYP
      FROM   SPRCOLR
      WHERE  SPRCOLR_JOB         = UPPER(:rptname)
      AND    SPRCOLR_SESSIONID   = :sessionid
      AND    SPRCOLR_PARM_NUMBER = :parm_value;

/* ****************************************************************** */
/* BOTTOM                                                             */
/* ****************************************************************** */     
