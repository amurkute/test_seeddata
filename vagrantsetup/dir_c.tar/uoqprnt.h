#ifndef UOQPRNT_H
#define UOQPRNT_H
/******************************************************************************/
/* UOQPRNT.H Copyright (c) SCT Corporation 1994.  All rights reserved.        */
/******************************************************************************/

/***************************************************/
/*                                                 */
/*       CONFIDENTIAL BUSINESS INFORMATION         */
/*                                                 */
/*      **********************************         */
/*                                                 */
/*  THIS PROGRAM IS PROPRIETARY INFORMATION OF     */
/* SYSTEMS AND COMPUTER TECHNOLOGY CORPORATION     */
/* AND IS NOT TO BE COPIED, REPRODUCED, LENT OR    */
/* DISPOSED OF, NOR USED FOR ANY PURPOSE OTHER     */
/* THAN THAT FOR WHICH IT IS SPECIFICALLY PROVIDED */
/* WITHOUT THE WRITTEN PERMISSION OF SAID COMPANY  */
/*                                                 */
/***************************************************/

/******************************************************************************/
/*                               AUDIT TRAIL                                  */
/* ## INIT   DATE                                                             */
/* -- ---- -------- --------------------------------------------------------- */
/* 1  CJL  01/10/95 Initial creation.                                         */
/* 2  EBR  01/14/95 Moved PRINT_FILE typedef from uoqprnt.c to here.          */
/*                                                                            */
/* AUDIT TRAIL:8.0 */
/* AUDIT TRAIL END */
/******************************************************************************/

/*****************************************************************************

UOQPRNT -- Print functions

This group of functions gives the programmer the ability to output to a text
file using a row/column coordinate system.   When the print file is
initialized, the row and column coordinates are initialized to 0,0.  After
initialization, the programmer may specify any row and column coordinates as
parameters to any of the print output functions and the function will position
properly by inserting the correct number of CRLF, SPACES and/or BACKSPACES. The
row/column coordinates are automatically reset to 0,0 when the program  calls
FPageEject().  Also, if the program attempts to write to a row that is less
than the current row, the functions will perform FPageEject() and then will
position properly on the page.


Functions:

prow()             - returns current row coordinate.

pcol()             - returns current column coordinate.

FPageEject()       - ejects current page by inserting form feed or crlf's and
                     resets row/column coordinates to 0,0.

fprnt()            - positions properly on the page and outputs string to print
                     file.

PrintNumber        - positions on the page and formats double with correct
                     number of decimal places and outputs to print file. It
                     will also insert commas in the correct places. If the
                     formatted string is larger than width, the functions will
                     detect the overflow condition and output the OVERFLOW_CHAR.

fprntNumUF         - positions on page and prints double with correct number of
                     decimal places and outputs to the print file.  Does not
                     detect overflow condition.

fmprnt()           - Same as fprnt() but will limit the number of output
                     characters to the value passed in sLen.

fReplicate()       - positions properly on the page and will outputs the text
                     string to the output file the number of times specified in
                     sCount.

fPrintFileInit()   - opens the print file and records the form length and upper
                     case flag.  If the upper case flag is specified all text
                     will be converted to upper case before being output to the
                     print file.

fPrintFileClose()  - Closes the print file.

fChangePrintFile() - allows the functions to output to more than one print
                     file.  When you initialize a print file, always capture
                     the return value from fPrintFileInit().  You can then open
                     other print files and use this function with the captured
                     PRNT_HNDL to change the target of the print functions.

*******************************************************************************/

#define OVERFLOW_CHAR    '*'        /* character to fill numerics if overflow */

typedef void *PRNT_HNDL;

typedef struct PRINT_FILE
   {
   short     sCurRow;
   short     sCurCol;
   FILE     *fOutFile;
   long      lTotalLinesPrinted;
   short     sFormLength;            /* 0 = send '\f' else send proper number */
                                     /* of CRLF TO PUT AT TOP OF NEXT PAGE    */
   short     sUpperCaseFlag;
   } PRINT_FILE;

extern PRNT_HNDL fChangePrintFile(PRNT_HNDL NewFile);
extern PRNT_HNDL pPrintFileInit(char *pszFileName, short sFormLength,
                 short sUpperCaseFlag);
extern void      PrintFileClose(void);
extern char     *DblToDecStr(char *pszOutput, double dNumber, short sNumDecPlaces);
extern int       FGetTotalLinesPrinted(void);

extern short     prow(void);
extern short     pcol(void);

extern void      FPageEject(void);
extern void      fprnt(short sRow, short sCol, char *pszText);
extern void      PrintNumber(short sRow, short sCol, double dNum,
                             short sWidth, short sDecimalPlaces);
extern void      fPrntNumUF(short sRow, short sCol, double dNum, short sDecimals);
extern void      fPrntNumUFR(short sRow, short sCol, double dNum,
                           short sWidth, short sDecimals);
extern void      fmprnt(short sRow, short sCol, char *pszText, short sLen);
extern void      fReplicate(short sRow, short sCol, char *pszText, short sCount);
extern void      fprntFreeForm(short sBeginCol, short sEndCol, const char *szText);

#endif
