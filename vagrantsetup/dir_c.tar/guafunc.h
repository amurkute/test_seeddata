/*TMCI18N BEGIN HEADER*/
#if !defined( _TMBGUAFUNC_H_EXISTS )
/* No Initialisation Required */                                               
#include "tmcilib.h"
static struct TMBundle _TMBGUAFUNC_H = {"guafunc.h",NULL,NULL,NULL,NULL};
#define _TMBGUAFUNC_H_EXISTS
#endif
/*TMCI18N END HEADER*/

/* AUDIT_TRAIL_TM63
-- TranMan 6.3 
-- PROJECT : HEGDE_I18N
-- MODULE  : GUAFUNC
-- SOURCE  : enUS
-- TARGET  : I18N
-- DATE    : Mon Nov 12 01:43:36 2007
END AUDIT_TRAIL_TM63 */
/***************************************************************
  
            CONFIDENTIAL BUSINESS INFORMATION                                
                                                   
            *********************************     
                                                
   THIS PROGRAM IS PROPRIETARY INFORMATION OF SYSTEMS AND  
   COMPUTER TECHNOLOGY CORPORATION AND IS NOT TO BE COPIED, 
   REPRODUCED, LENT OR DISPOSED OF, NOR USED FOR ANY PURPOSE   
   OTHER THAN THAT FOR WHICH IT IS SPECIFICALLY PROVIDED
   WITHOUT THE WRITTEN PERMISSION OF THE SAID COMPANY
  
   *********************************************************
  
  Program Name  : guafunc.h
  Report Title  : Header file for guafunc.pc
  Author        : Tom Coker
  Date          : 05/17/95
  Description   : Prototypes for guafunc.pc


  Revision History:
  -----------------
  AUDIT TRAIL:  2.1.1
       Date:          Person:       Reason: 
       07/06/95       tmc           Added additional prototypes of functions
                                    called from guafunc.pc that reside in
                                    the application's report/process.
       04/02/97       JLJ           Added DELETE_GJBPRUN prototype of function
                      WO40894       that is being added to guafunc.pc. 
 
  AUDIT TRAIL : 8.0 (I18N) *//* AUDIT TRAIL END
***************************************************************/

#ifndef _GUAFUNC_H_

/* prototypes for guafunc.pc */

/******************************************************************************
* Functions that exist in guafunc.pc                                          *
******************************************************************************/
static int    Get_Command_Line_Parameters(int argc, TMCHAR *argv[]);
static void   Set_User_Name(void);
static void   Print_Report_Body(struct Page_Stats *current,int last_line);
static void   Initialize_Page_Stats(struct Page_Stats *current);
static void   Initialize_Break_Totals(int i);
static void   Execute_Page_Break(struct Page_Stats *current, int last_page);
static void   Print_Page_Header(struct Page_Stats *current, int last_page);
static void   Set_Date_Time_Orgname(void);
static void   Make_Select_String(void);
static void   Print_Report_Summary(struct Page_Stats *current, int last_line);
static void   Get_Parameter_Values(void);
static int    Check_Parm(void);
static void   set_err(void);
static void   cmdhelp(void);
static double Round(double v, int j);
static TMCHAR *Reformat_Amt(double amount, int no_of_decimals);
static void   Delete_GJBPRUN(void);   /* WO40894    */

/******************************************************************************
* Functions that are in the application's C report and called from guafunc.pc *
******************************************************************************/
static void   Fetch_A_Row_Of_Data(void);
static void   Print_Break_Totals(int i, struct Page_Stats *current, int last_line);
static void   Print_Detail_Line(struct Page_Stats *current, int last_line, int i);
static int    Get_Sort_Values(TMCHAR sortval[MAX_NO_OF_SORT_VARIABLES][80]);
static void   Print_Column_Headings(struct Page_Stats *current);

/* end local prototypes */


/* end prototypes */

#define _GUAFUNC_H_
#endif
