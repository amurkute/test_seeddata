/******************************************************************************/
/* UBPBPFM.PC - Bill Print Format Subroutines                                 */
/* Version for Poway.                                                         */
/* UBPBPFM.PC Copyright (c) SCT Corporation 1993.  All rights reserved.       */
/******************************************************************************/

/***************************************************/
/*                                                 */
/*       CONFIDENTIAL BUSINESS INFORMATION         */
/*                                                 */
/*      **********************************         */
/*                                                 */
/*  THIS PROGRAM IS PROPRIETARY INFORMATION OF     */
/* SYSTEMS AND COMPUTER TECHNOLOGY CORPORATION     */
/* AND IS NOT TO BE COPIED, REPRODUCED, LENT OR    */
/* DISPOSED OF, NOR USED FOR ANY PURPOSE OTHER     */
/* THAN THAT FOR WHICH IT IS SPECIFICALLY PROVIDED */
/* WITHOUT THE WRITTEN PERMISSION OF SAID COMPANY  */
/*                                                 */
/***************************************************/
/* UBPBPFM.PC                                                             */
/* Bill Print Format Subroutines                                          */
/*                                                                        */
/* This is the customer specific set of subroutines to be included in     */
/* program UBPBILP.PC.                                                    */
/* See that program's documentation for Tables, etc.                      */
/*                                                                        */
/* AUDIT TRAIL                                        INIT    DATE        */
/* -------------------------------------------------  ----  --------      */
/* Release: 1.1                                                           */
/* 1.  Broken out of UBPBILP.PC                       RMG   01-DEC-1993   */
/* 2.  Fixed problem with printing duplicate bills    EBR   27-APR-1994   */
/*     via UBADUPB for accts w/extended due dates.                        */
/*                                                                        */
/* AUDIT TRAIL: 8.0 */
/* AUDIT TRAIL END */
EXEC SQL BEGIN DECLARE SECTION;
  /* Column Definitions for Table: utrsrat */
  static CHAR2   utrsrat_rate_step_ind;
  /* Misc. variables */
  static NUMSTR  hold_urrshis_dos="";
  static CHAR2   hold_est_usage_ind="";
  static CHAR10  hold_prev_reading="";
  static CHAR10  hold_present_reading="";
  static CHAR9   hold_prev_date="";
  static CHAR9   hold_present_date="";
  static NUMSTR  hold_lastyr_dos;
  static NUMSTR  hold_lastyr_consump;
  static NUMSTR  scan_amount_due="";
  static NUMSTR  meter_diff;
  static CHAR12  total_string;
  static CHAR4   m_xx;
  static NUMSTR  m_garbage_tot;
  static NUMSTR  m_other_tot;
  static NUMSTR  m_grand_tot;
  static NUMSTR  rate;
  static CHAR7   rate_vbg;
  static NUMSTR  subtotal;
  static NUMSTR  prev_serv_num;
  static NUMSTR  tot_gallons;
  static NUMSTR  avg_gallons;
  static NUMSTR  lastyr_avg_gallons;
  static NUMSTR  avg_gallons_chg;
  static NUMSTR  pct_change;
EXEC SQL END DECLARE SECTION;

static void installation_init(void);
static void installation_body_init(void);
static void p_line_05_30_text(void);
static void p_message_line(void);
static void insert_blank_line(void);
static void line_31_multi(void);
static void line_47_multi(void);
static void update_bunch_code(void);
static void insert_multiple_pages(void);
static void print_address(void);
static void print_budget_footnote(void);
static void print_budget_line(void);
static void p_print_message_lines(void);
static void p_print_line_05(void);
static void p_print_line_15(void);
static void p_print_line_20(void);
static void p_print_line_21(void);
static void p_print_line_25(void);
static void p_print_line_48(void);
static void p_print_line_49(void);
static void print_detail_line(void);
static void print_detail_line_2(void);
static void print_detail_line_change_out_2(void);
static void print_detail_line_adjustments(void);
static void print_line_05_30_text(void);
static void print_blank_line(void);
static void print_sewer_header(void);
static void print_water_header(void);
static void print_unprinted_bill(void);
static void print_printed_bill(void);
static void uabopen_head(void);
static void uabopen_body(void);
static void uabopen_foot(void);
static void adjustment_head(void);
static void adjustment_body(void);
static void adjustment_foot(void);
static void get_poway_lastyr_cons_dos(void);
static void print_barcode_zip(void);
static void print_draft_next_month_msg(void);
static void print_draft_msg(void);
static void p_print_line_11_dupl(void);
static void p_print_line_12_draft(void);
static void print_rdup(void);
static void p_print_line_12_no_pay(void);
static void print_please_pay_msg(void);
static void p_print_line_12_please_pay(void);


  /****************************************************************************/
  /****************************************************************************/
  /*--------------------------------------------------------------------------*/
  /* Installation Initializations                                             */
  /*--------------------------------------------------------------------------*/
  /****************************************************************************/
  /****************************************************************************/

static void installation_init(void)
{
  /*  Line number that address lines should follow on page  */
  /*  To print address at very top, set to "0".             */
  strcpy(address_after_line,"5");
}

static void installation_body_init(void)
{
  return;
}

  /****************************************************************************/
  /****************************************************************************/
  /*--------------------------------------------------------------------------*/
  /*  print_unprinted_bill and print_printed_bill, top level control for      */
  /*  format modules.  Called from BODY in ubpbilp.pc                         */
  /*--------------------------------------------------------------------------*/
  /****************************************************************************/
  /****************************************************************************/

/* ************************************************************************** */
/* print bills that have never been printed before (printed_inds = 'N')       */
/* ************************************************************************** */

static void print_unprinted_bill(void)
{

  strcpy(prev_serv_num,"999999");

/* select the next bhst_tran_num from the sequence */

  select_ubsbhst(FIRST_ROW);

  strcpy(amount_due,"0");
  strcpy(adjustments,"0");

  strcpy(line_05_30_lineno,"28");

/* prev balance */

  tonum(prev_bal,null);
  select_prev_bal(FIRST_ROW);
  if ( !*prev_bal )
    strcpy(prev_bal,"0");
  else
    add(amount_due,amount_due,prev_bal);
  strcpy(text,"Previous Balance:                                      ");
  strcpy(amount,prev_bal);
  /*  strcpy(prev_bal,ubbbhst_prev_bal);  */
  /*  prtnum(ubbbhst_prev_bal,"99,999,999.99");  */
  /*  prtnum(prev_bal,"99,999,999.99");  */

/* adjustments            */
/*                        */
/*    .EQUAL adj_ind null */

    report(select_adjs_unprinted,adjustment_body,adjustment_head,adjustment_foot);

/*    .REPORT select_adjs_unprinted adjustment_body */

    add(amount_due,amount_due,adjustments);

/* payments */

    tonum(payments,null);
    select_payments_unbilled(FIRST_ROW);
    if ( *payments )
      strcpy(payments,"0");
    else
      subtract(amount_due,amount_due,payments);

/*    .SET text "Less Payments:" */

    strcpy(amount,payments);
    /*  strcpy(payments,ubbbhst_payments);  */

/* get balance of account */
/* At this point, as we are processing each open item, we do not yet know
   what the final amount due will be.  So we go get it and store it in
   amount_due_balance.  This field differs from amount_due, which will
   eventually be the same amount but is just being computed as we go along
   at this point in the logic.                                             */

    strcpy(bill_balance,"0");
    strcpy(payments_zero_bill,"0");
    select_payments_zero_bill(FIRST_ROW);
    uabopen_bill_balance(FIRST_ROW);
    subtract(amount_due_balance,bill_balance,payments_zero_bill);

/*  Commented out 1/25/94, RMG - test will be done right before UBRRECP
    insert anyhow, and some updates within UABOPEN get skipped if done here.

    if ((compare(amount_due_balance,"0",EQ))
      && (print_zero_balance_bills_var[0]=='N'))
        return;
*/

/* compute round up if necessary */

    if (ucracct_rdup_ind[0]=='Y' && *uobsysc_srat_code_rdup)
      insert_roundup();

/* open item charges */

    report(uabopen_selmacro_unprinted,uabopen_body,uabopen_head,uabopen_foot);

    if (compare(prev_serv_num,"1",EQ)) {
      strcpy(text,"    Total Water Charges                                ");
      strcpy(amount,subtotal);
      print_line_05_30_text();
      print_blank_line();
    }
    if (compare(prev_serv_num,"3",EQ)) {
      strcpy(text,"    Total Sewer Charges                                ");
      strcpy(amount,subtotal);
      print_line_05_30_text();
      print_blank_line();
    }

    subtract(balance_forward,prev_bal,payments);
    print_blank_line();
    strcpy(text,"Prior Charge / Credit                                       ");
      /* Poway change */
    strcpy(amount,balance_forward);   /* Poway change */
    print_line_05_30_text();   /* Poway change */

    if ( compare(amount_due,"0",LT) ) {
      strcpy(text,"Credit Balance ");
      strcpy(credit_bill_ind,"Y");
    }
    else {
      /*  Set message for 'Closing Bill' if appropriate here */
      if (ucracct_status_ind[0] == 'F')
        { strcpy(text,"Closing Bill"); }
      else
        { strcpy(text,"            "); }
      strcat(text,"                            Total Amount Due    ");
        /*  Poway Change above */
      strcpy(credit_bill_ind,null);
    }
    strcpy(amount,amount_due);
    print_blank_line();
    print_blank_line();
    print_line_05_30_text();
    print_blank_line();

/* if we had a budgeted service, print footnote explaining */
/* '*' beside charges                                      */

    print_budget_footnote();

    bank_drafts();                                        

    if (*uobsysc_srat_code_rdup)
      check_rdup_msg();

    if (ubtibil_type_ind[0] == 'D')
      p_print_line_11_dupl();

    if (ucbmbil_sub_pymt_ind[0]=='N')
      p_print_line_12_no_pay();

    p_print_line_05();
    p_print_line_15();
    p_print_line_20();
    p_print_line_21();
    p_print_line_25();
    p_print_line_48();
    p_print_line_49();

/* print the system-wide, customer-specific, and/or account specific */
/* bill message                                                      */

    strcpy(line_05_30_lineno,"45");
    p_print_message_lines();

/* if we have multi-page bills, duplicate line 47                     */
/* on all pages of the bill.  Also print the page number on all pages */

    if ( *multi_page_ind ) {
      count_pages();
      insert_multiple_pages();
    }
}                                        /* end print_unprinted_bill */

/* ************************************************************************** */
/* print bills that have been printed before (printed_inds = 'Y')             */
/* ************************************************************************** */

static void print_printed_bill(void)
{

  strcpy(prev_serv_num,"999999");

/* get the due date from one of the open items for this */
/* billing                                              */

  select_due_date_printed(FIRST_ROW);

  strcpy(amount_due,"0");
  strcpy(adjustments,"0");
  strcpy(line_05_30_lineno,"28");

/* prev balance */

  strcpy(text,"Previous Balance:                                     ");
  strcpy(amount,ubbbhst_prev_bal);
  strcpy(prev_bal,ubbbhst_prev_bal);

/* payments */

  strcpy(text,"Less Payments:                                       ");
  strcpy(amount,ubbbhst_payments);
  strcpy(payments,ubbbhst_prev_bal);

/* open item charges */

  report(uabopen_selmacro_printed,uabopen_body,uabopen_head,uabopen_foot);

  if (compare(prev_serv_num,"1",EQ)) {
    strcpy(text,"    Total Water Charges                                ");
    strcpy(amount,subtotal);
    print_line_05_30_text();
    print_blank_line();
  }
  if (compare(prev_serv_num,"3",EQ)) {
    strcpy(text,"    Total Sewer Charges                                ");
    strcpy(amount,subtotal);
    print_line_05_30_text();
    print_blank_line();
  }

/* adjustments */

  if ( compare(ubbbhst_adjustments,"0",NE) )
    strcpy(amount,ubbbhst_adjustments);

/* amount due */

    if ( compare(ubbbhst_ending_bal,"0",LT) ) {
      strcpy(text,"Credit Balance:                                             ");
      strcpy(credit_bill_ind,"Y");
    }
    else {
      strcpy(text,"Amount Due:                                                 ");
      strcpy(credit_bill_ind,null);
    }
    strcpy(amount,ubbbhst_ending_bal);
    strcpy(amount_due,ubbbhst_ending_bal);

    subtract(balance_forward,prev_bal,payments);
    print_blank_line();
    strcpy(text,"Prior Charge / Credit                                       ");
      /* Poway change */
    strcpy(amount,balance_forward);   /* Poway change */
    print_line_05_30_text();   /* Poway change */

    if ( compare(amount_due,"0",LT) ) {
      strcpy(text,"Credit Balance                                              ");
      strcpy(credit_bill_ind,"Y");
    }
    else {
      /*  Set message for 'Closing Bill' if appropriate here */
      if (ucracct_status_ind[0] == 'F')
        { strcpy(text,"Closing Bill"); }
      else
        { strcpy(text,"            "); }
      strcat(text,"                            Total Amount Due    ");
      /*  Poway Change above */
      strcpy(credit_bill_ind,null);
    }
    strcpy(amount,amount_due);
    print_blank_line();
    print_blank_line();
    print_line_05_30_text();
    print_blank_line();

/* if we had a budgeted service, print footnote explaining */
/* '*' beside charges                                      */

    print_budget_footnote();

    bank_drafts();

    if (*uobsysc_srat_code_rdup)
      check_rdup_msg();

    if (ubtibil_type_ind[0] == 'D')
      p_print_line_11_dupl();

    if (ucbmbil_sub_pymt_ind[0]=='N')
      p_print_line_12_no_pay();

    p_print_line_05();
    p_print_line_15();
    p_print_line_20();
    p_print_line_21();
    p_print_line_25();
    p_print_line_48();
    p_print_line_49();

/* print the system-wide, customer-specific, and/or account specific */
/* bill message                                                      */

    strcpy(line_05_30_lineno,"45");
    p_print_message_lines();

/* if we have multi-page bills, duplicate line 47                     */
/* on all pages of the bill.  Also print the page number on all pages */

    if ( *multi_page_ind ) {
      count_pages();
      insert_multiple_pages();
    }

}                                        /* end print_printed_bill */

  /****************************************************************************/
  /****************************************************************************/
  /*--------------------------------------------------------------------------*/
  /*   uabopen head and body.  Called from print_printed_bill,                */
  /*   print_unprinted_bill for each open item to print in center of page.    */
  /*--------------------------------------------------------------------------*/
  /****************************************************************************/
  /****************************************************************************/

/* ************************************************************************** */
/* uabopen head                                                               */
/* ************************************************************************** */

static void uabopen_head(void)
{
  select_serv_info(FIRST_ROW);
  test_for_budget();
  strcpy(break_serv_num,uabopen_serv_num);
  strcpy(total_budget_amount,"0");

  /*  Poway changes  */
  strcpy(hold_lastyr_dos,"");
  strcpy(hold_lastyr_consump,"");
  strcpy(hold_present_reading,"");
  strcpy(hold_prev_reading,"");
  strcpy(hold_urrshis_dos,"");
  strcpy(hold_est_usage_ind,"");
  strcpy(hold_prev_date,"");
  strcpy(hold_present_date,"");
  /*  End Poway changes  */

  uabopen_body();
}                                        /* end uabopen_head */

/* *********************************************************************** */
/* uabopen body                                                            */
/* *********************************************************************** */

static void uabopen_body(void)
{

/* check for service break */

  if ( compare(break_serv_num,uabopen_serv_num,NE) ) {
    /* if this was a budgeted_service */
    if ( *budgeted_service_ind )
      print_budget_line();
    test_for_budget();
    select_serv_info(FIRST_ROW);
    strcpy(break_serv_num,uabopen_serv_num);
  }

/* clear detail line fields */

    strcpy(ubbchst_billed_consump,"        ");
    strcpy(present_reading,"         ");
    strcpy(prev_reading,"         ");
    strcpy(urrshis_multiplier,"         ");
    strcpy(urrshis_high_low_excp," ");

    if (*uabopen_chrg_calc_num && *non_metered_ind) {
      /* select the non-metered info if we have the primary rate */
      select_dos_flat(FIRST_ROW);
      select_present_date_flat(FIRST_ROW);
      select_previous_date_flat(FIRST_ROW);
      /* print the open item detail */
      print_detail_line_2();
    }
    else {
      if (*uabopen_chrg_calc_num) {
        /* select the metered info if we have the primary rate */
        select_previous_reading(FIRST_ROW);
        select_change_out_reading(FIRST_ROW);
        select_dos(FIRST_ROW);
        if (change_out_ind[0]=='Y') {
          subtract(change_out_cons,change_out_reading,prev_reading_2);
          /* print_detail_line_change_out_2();  Poway change  */
          strcpy(change_out_ind,"N");
          select_present_reading(FIRST_ROW);
          sel_previous_reading_new_meter(FIRST_ROW);
          /* print the open item detail */
          print_detail_line();
        }
        select_previous_reading(FIRST_ROW);
        select_present_reading(FIRST_ROW);
        select_dos(FIRST_ROW);
        select_cons_history(FIRST_ROW);
        get_poway_lastyr_cons_dos();
        /* print the open item detail */
        print_detail_line_2();
      }
      else {
        select_previous_reading(FIRST_ROW);
        select_present_reading(FIRST_ROW);
        select_dos(FIRST_ROW);
        select_cons_history(FIRST_ROW);
        get_poway_lastyr_cons_dos();
        /* print the open item detail */
        print_detail_line_2();
      }
    }

/* total the adjustments for the open item we are currently processing. */

    tonum(uabadje_budget_variance,null);
    tonum(uabadje_billed_chg,null);
    strcpy(adj_ind,null);
    select_adjs_printed(FIRST_ROW);

/* total the charges */

    if ( *budgeted_service_ind && compare(budgeted_service_ind,"C",NES) ) {
      /* we have a budgeted service, add the budget charges to the */
      /* charges total and insert the budget charge line           */
      strcpy(budget_footnote,"Y");
      if ( *uabadje_budget_variance )
        add(uabopen_budget_variance,uabopen_budget_variance,uabadje_budget_variance);
      if ( *uabadje_billed_chg )
        add(uabopen_billed_chg,uabopen_billed_chg,uabadje_billed_chg);
      subtract(budget_amount,uabopen_billed_chg,uabopen_budget_variance);
      add(charges,charges,budget_amount);
      add(total_budget_amount,total_budget_amount,budget_amount);
    }
    else
      add(charges,charges,uabopen_billed_chg);

/* ********************************************************************* */
/* update routines - do not execute if in reprint mode                   */
/*   or, in sleep-wake, update-ind is off                                */
/* ********************************************************************* */

    if ( *reprint_date_var ||
      (*sleep_wake_ind && ubtibil_calc_update_ind[0] != 'Y') )
        return;

/* If the account has a payment arrangement, check the open item        */
/* and determine if it needs to be updated into uarpyar.  It needs to   */
/* be updated/inserted when:                                            */
/*  1) A debit open item is found with no due date (31-dec-2099) and    */
/*     has not been printed on a bill                                   */
/*  2) A debit adjustment is found that has not been printed on a bill. */

    if ( *ucracct_pmnt_arr ) {
      /* we have a payment arrangement, total the debit adjs for this */
      /* open item                                                    */
      strcpy(adj_ind,null);
      select_adjs_pay_arrng(FIRST_ROW);
      if ( *adj_ind )
        add(debit_adjs,debit_adjs,uabadje_balance);
      /* check to see if the open item has a due date and a debit amount */
      if (compare(uabopen_due_date,"31-DEC-2099",EQS) &&
        compare(uabopen_billed_chg,"0",GT) ) {
          /* we have a positive charge, update/insert a row to uarpyar */
          strcpy(amount,uabopen_billed_chg);
          update_insert_pmnt_arrng();
      }
    }

/* update the printed indicator, printed date, and due date in uabopen */

    update_uabopen();

/* ********************************************************************* */
/* end update routines                                                   */
/* ********************************************************************* */

}                                        /* end uabopen_body */

/* ************************************************************************** */
/* uabopen foot                                                               */
/* ************************************************************************** */

static void uabopen_foot(void)
{
  /* if this was a budgeted_service */
  if ( *budgeted_service_ind )
    print_budget_line();
  add(amount_due,amount_due,charges);
  strcpy(text,"Total New Charges                                      ");
  strcpy(amount,charges);
  /* print_line_05_30_text();  Poway change */
  /* print_blank_line();  Poway change */
}                                        /* end uabopen_foot */

  /****************************************************************************/
  /****************************************************************************/
  /*--------------------------------------------------------------------------*/
  /*   adjustment head, body, and foot.  Called from print_unprinted_bill.    */
  /*--------------------------------------------------------------------------*/
  /****************************************************************************/
  /****************************************************************************/

/* ************************************************************************** */
/*   a d j u s t m e n t   h e a d                                            */
/* ************************************************************************** */

static void adjustment_head(void)
{
  adjustment_body();
}

/* ************************************************************************** */
/*   a d j u s t m e n t   b o d y                                            */
/* ************************************************************************** */

static void adjustment_body(void)
{
  print_detail_line_adjustments();
  add(adjustments,adjustments,uabadje_balance);
  /* ********************************************************************** */
  /* update the printed indicator and printed date in uabadje               */
  /* if in sleep-wake mode and update-ind is off, skip updates              */
  /* ********************************************************************** */
  if (*sleep_wake_ind && ubtibil_calc_update_ind[0] != 'Y')
    return;
  update_uabadje();
}

/* ************************************************************************** */
/*   a d j u s t m e n t   f o o t                                            */
/* ************************************************************************** */

static void adjustment_foot(void)
{
  add(adjustments,adjustments,uabadje_balance);
  strcpy(amount,adjustments);
  strcpy(text,"Total Adjustments");
  print_line_05_30_text();
  print_blank_line();
}

  /****************************************************************************/
  /****************************************************************************/
  /*--------------------------------------------------------------------------*/
  /*   Get last year's consumption and DOS for Poway.                         */
  /*--------------------------------------------------------------------------*/
  /****************************************************************************/
  /****************************************************************************/

static void get_poway_lastyr_cons_dos(void)
{

  /* Get last year's consumption and DOS */
  /* Also store other fields for this metered service for later printing */

  if (*present_date && *prev_date) {
    exec sql
      select nvl(sum(nvl(urrshis_dos,0)),0)
        into :hold_lastyr_dos
        from uimsmgr.urrshis,
             uimsmgr.ubbchst
       where ubbchst_cust_code = :ucracct_cust_code
         and ubbchst_prem_code = :ucracct_prem_code
         and ubbchst_serv_num  = :uabopen_serv_num
         and ubbchst_charge_date between
           to_date(to_char(to_date(:prev_date,'MM/DD/YY'),'MM') ||
               '01' ||
               to_char(add_months(to_date(:prev_date,'MM/DD/YY'),-12),
                       'YYYY'),
             'MMDDYYYY')
           and
           to_date(to_char(to_date(:present_date,'MM/DD/YY'),'MM') ||
              to_char(last_day(to_date(:present_date,'MM/DD/YY')),'DD') ||
              to_char(add_months(to_date(:present_date,'MM/DD/YY'),-12),
                      'YYYY'),
            'MMDDYYYY')
         and urrshis_chrg_calc_num = ubbchst_chrg_calc_num
         and urrshis_actn_code <> 'SKIP';
    POSTORA;
  
    exec sql
      select nvl(sum(nvl(ubbchst_billed_consump,0) +
                 nvl(ubbchst_billed_consump_adj,0)),0)
        into :hold_lastyr_consump
        from uimsmgr.ubbchst
       where ubbchst_cust_code = :ucracct_cust_code
         and ubbchst_prem_code = :ucracct_prem_code
         and ubbchst_serv_num  = :uabopen_serv_num
         and ubbchst_charge_date between
           to_date(to_char(to_date(:prev_date,'MM/DD/YY'),'MM') ||
               '01' ||
               to_char(add_months(to_date(:prev_date,'MM/DD/YY'),-12),
                       'YYYY'),
             'MMDDYYYY')
           and
           to_date(to_char(to_date(:present_date,'MM/DD/YY'),'MM') ||
              to_char(last_day(to_date(:present_date,'MM/DD/YY')),'DD') ||
              to_char(add_months(to_date(:present_date,'MM/DD/YY'),-12),
                      'YYYY'),
            'MMDDYYYY');
    POSTORA;
  }
  else {                         
    strcpy(hold_lastyr_dos,"0");
    strcpy(hold_lastyr_consump,"0");
  }

  strcpy(hold_present_reading,present_reading);
  strcpy(hold_prev_reading,prev_reading);
  strcpy(hold_urrshis_dos,urrshis_dos);
  strcpy(hold_est_usage_ind,est_usage_ind);
  strcpy(hold_prev_date,prev_date);
  strcpy(hold_present_date,present_date);

}

  /****************************************************************************/
  /****************************************************************************/
  /*--------------------------------------------------------------------------*/
  /*           Report line creation                                           */
  /*--------------------------------------------------------------------------*/
  /****************************************************************************/
  /****************************************************************************/

/* ******************************************************************* */

static void p_line_05_30_text(void)
{
  EXEC SQL
   INSERT INTO uimsmgr.ubrbill
        (
        ubrbill_bill_num,
        ubrbill_page_num,
        ubrbill_line_num,
        ubrbill_sess_id,
        ubrbill_text
        )
   VALUES
        (
        TO_NUMBER(:billno),
        TO_NUMBER(:line_05_30_pageno),
        TO_NUMBER(:line_05_30_lineno),
        :session_id,
        lpad(:text,60)  ||
        '      ' ||
        lpad(to_char(TO_NUMBER(:amount),'999,999.99'),13)
        );
  POSTORA;
  /* re-retrieve line text for C usage */
  EXEC SQL SELECT ubrbill_text INTO :ubrbill_text
      FROM uimsmgr.ubrbill
      WHERE ubrbill_bill_num = TO_NUMBER(:billno)
        AND ubrbill_page_num = TO_NUMBER(:line_05_30_pageno)
        AND ubrbill_line_num = TO_NUMBER(:line_05_30_lineno)
        AND ubrbill_sess_id  = :session_id;
  POSTORA;
}                                        /* end p_line_05_30_text */

/* ******************************************************************* */
/* print a blank text line                                             */
/* ******************************************************************* */

static void insert_blank_line(void)
{
  EXEC SQL
   INSERT INTO uimsmgr.ubrbill
        (
        ubrbill_bill_num,
        ubrbill_page_num,
        ubrbill_line_num,
        ubrbill_sess_id,
        ubrbill_text
        )
   VALUES
        (
        TO_NUMBER(:billno),
        TO_NUMBER(:line_05_30_pageno),
        TO_NUMBER(:line_05_30_lineno),
        :session_id,
        '          '
        );
  POSTORA;
}                                        /* end insert_blank_line */

/* ******************************************************************* */
/* if multi-page print continued on next page message for line 05-30   */
/* overflow                                                            */
/* ******************************************************************* */

static void line_31_multi(void)
{
  if (compare(line_05_30_pageno,"1",EQ))
    strcpy(line_05_30_lineno,"54");
  else
    strcpy(line_05_30_lineno,"64");
  EXEC SQL
   INSERT INTO uimsmgr.ubrbill
        (
        ubrbill_bill_num,
        ubrbill_page_num,
        ubrbill_line_num,
        ubrbill_sess_id,
        ubrbill_text
        )
   VALUES
        (
        TO_NUMBER(:billno),
        TO_NUMBER(:line_05_30_pageno),
        TO_NUMBER(:line_05_30_lineno),
        :session_id,
'                                                         Continued on Next Page'
        );
  POSTORA;
}                                        /* end line_31_multi */

/* ******************************************************************* */
/* insert the system-wide, customer-specific, or account-specific      */
/* bill messages for Poway                                             */
/* ******************************************************************* */

static void p_message_line(void)
{
  strcpy(valid_ind,"N");
  exec sql select 'Y', ubrbill_text
    into :valid_ind, :ubrbill_text
    from uimsmgr.ubrbill
    where ubrbill_bill_num = TO_NUMBER(:billno)
      and ubrbill_page_num = TO_NUMBER(:pageno)
      and ubrbill_line_num = TO_NUMBER(:line_05_30_lineno)
      AND ubrbill_sess_id  = :session_id;
  POSTORA;
  if ( NO_ROWS_FOUND )
    { valid_ind[0]='\0'; }
  else
    { valid_ind[1]='\0'; }
  if (compare(valid_ind,"Y",EQS))
  {
    EXEC SQL
       UPDATE uimsmgr.ubrbill
         SET ubrbill_text =
           (select substr(:ubrbill_text,1,53)
             || substr(utvbmsg_message_text,1,32)
               FROM uimsmgr.utvbmsg
               WHERE utvbmsg_code = :bmsg_code)
         where ubrbill_bill_num = TO_NUMBER(:billno)
           and ubrbill_page_num = TO_NUMBER(:pageno)
           and ubrbill_line_num = TO_NUMBER(:line_05_30_lineno)
           AND ubrbill_sess_id  = :session_id;
    POSTORA;
  }
  else
  {
    EXEC SQL
       INSERT INTO uimsmgr.ubrbill
          (
           ubrbill_bill_num,
           ubrbill_page_num,
           ubrbill_line_num,
           ubrbill_sess_id,
           ubrbill_text
          )
       SELECT
           TO_NUMBER(:billno),
           TO_NUMBER(:pageno),
           TO_NUMBER(:line_05_30_lineno),
           :session_id,
           '                                                     ' ||
           substr(utvbmsg_message_text,1,32)
       FROM uimsmgr.utvbmsg
       WHERE utvbmsg_code = :bmsg_code;
    POSTORA;
  }
}                                        /* end p_message_line */

/* ******************************************************************* */
/* if multi-page print page number on the bill                         */
/* overflow                                                            */
/* ******************************************************************* */

static void line_47_multi(void)
{
  if (compare(pageno,"1",EQ))
    strcpy(lineno,"55");
  else
    strcpy(lineno,"65");
  EXEC SQL
   INSERT INTO uimsmgr.ubrbill
        (
        ubrbill_bill_num,
        ubrbill_page_num,
        ubrbill_line_num,
        ubrbill_sess_id,
        ubrbill_text
        )
   VALUES
        (
        TO_NUMBER(:billno),
        TO_NUMBER(:pageno),
        TO_NUMBER(:lineno),
        :session_id,
        '                                                                    '
        ||
        'Page ' ||
        to_char(TO_NUMBER(:pageno)) ||
        ' of '  ||
        to_char(TO_NUMBER(:page_count))
        );
  POSTORA;
}                                        /* end line_47_multi */

/* ************************************************************************** */
/* override the bunch code in the bill print collector table because          */
/* the user choice to bunch finals, credits, and/or inactives or              */
/* we have a multi-page bill                                                  */
/* Poway version:  just return without doing anything.                        */
/* ************************************************************************** */

static void update_bunch_code(void)
{
  return;
}                                        /* end update_bunch_code */

/* ************************************************************************** */
/* if we have a multiple page bill, duplicate the below lines on all          */
/* pages of the bill                                                          */
/* ************************************************************************** */

static void insert_multiple_pages(void)
{
  line_47_multi();
  while(1) {
    add(pageno,pageno,"1");
    if ( compare(pageno,page_count,GT) )
      return;
    line_47_multi();
  }
}                                        /* end insert_multiple_pages */

/* ************************************************************************** */
/* print the address lines                                                    */
/* ************************************************************************** */

static void print_address(void)
{

  print_barcode_zip();

/* clear the address lines */

  strcpy(address_line1_text,null);
  strcpy(address_line2_text,null);
  strcpy(address_line3_text,null);
  strcpy(address_line4_text,null);
  strcpy(address_line5_text,null);
  strcpy(address_line6_text,null);

/* load the address fields */

  EXEC SQL
   SELECT   '     ' ||
            rpad(substr(:ubrrecp_print_name,1,40),40)
     into :address_line1_text:Ind_01
     FROM  sys.dual;
  POSTORA;
  if ( NO_ROWS_FOUND ) {
    *address_line1_text='\0';
  }

  if ( *ubrrecp_street_line1 ) {
    EXEC SQL
     SELECT       '     ' ||
                  rpad(:ubrrecp_street_line1,15) ||
                  ' ' ||
                  rpad(:ubrrecp_street_line2,15) ||
                  ' ' ||
                  rpad(:ubrrecp_street_line3,15)
     into :address_line2_text:Ind_01
     FROM sys.dual;
    POSTORA;
    if ( NO_ROWS_FOUND ) {
      *address_line2_text='\0';
    }
  }

  if ( *ubrrecp_street_name ) {
    EXEC SQL
     SELECT       '     ' ||
                  rpad(substr(:ubrrecp_street_address,1,40),40)
     into :address_line3_text:Ind_01
     FROM sys.dual;
    POSTORA;
    if ( NO_ROWS_FOUND ) {
      *address_line3_text='\0';
    }
  }

  if ( *ubrrecp_street_line2 ) {
    EXEC SQL
     SELECT '     ' ||
              rpad(:ubrrecp_street_line2,40)
     into :address_line4_text:Ind_01
     FROM sys.dual;
    POSTORA;
    if ( NO_ROWS_FOUND ) {
      *address_line4_text='\0';
    }
  }
           
  if ( *ubrrecp_street_line3 ) {
    EXEC SQL
     SELECT '     '||
            rpad(:ubrrecp_street_line3,40)
     into :address_line5_text:Ind_01
     FROM sys.dual;                        
    POSTORA;
    if ( NO_ROWS_FOUND ) {
      *address_line5_text='\0';
    }
  }

  EXEC SQL
   SELECT '     ' ||
        rpad(
                :ubrrecp_city           ||
                ' '                     ||
                :ubrrecp_stat_code      ||
                '  '                    ||
                :ubrrecp_zip_1_5        ||
                decode(:ubrrecp_zip_7_10,
                        null,'',
                        '-' || :ubrrecp_zip_7_10),41) ||
        '                                   ' ||
        decode(:ucbmbil_sub_pymt_ind,
               'N','           ',
               to_char(to_date(decode(:reprint_date_var,
                                      null, decode(:deferred_due_date,
                                                   null,:due_date,
                                                   :deferred_due_date),
                                      :uabopen_due_date),
                               'DD-MON-YYYY'),
                       'MON DD YYYY'))
   into :address_line6_text:Ind_01
   FROM sys.dual;
  POSTORA;
  if ( NO_ROWS_FOUND ) {
    *address_line6_text='\0';
  }

/* print the address lines                       */
/*                                               */
/* customer name and cycle code - address line 1 */
/*                                               */
/*    #S 3                                       */

  newline();
  setmode(M_COLLIT);
  prtstr(address_line1_text);
  setmode(M_NORMAL);
  newline();
  add(prev_line_num,prev_line_num,"1");

/* attention line - address line 2 */

  if ( *address_line2_text ) {
    setmode(M_COLLIT);
    prtstr(address_line2_text);
    setmode(M_NORMAL);
    newline();
    add(prev_line_num,prev_line_num,"1");
  }

/* street number, street name, etc - address line 3 */

  if ( *address_line3_text ) {
    setmode(M_COLLIT);
    prtstr(address_line3_text);
    setmode(M_NORMAL);
    newline();
    add(prev_line_num,prev_line_num,"1");
  }

/* city, state and zip line - address line 6 */
/* Poway address line 6 also has due date  */

  if ( *address_line6_text ) {
    setmode(M_COLLIT);
    prtstr(address_line6_text);
    setmode(M_NORMAL);
    add(prev_line_num,prev_line_num,"1");
  }

}                                        /* end print_address */

/* ************************************************************************** */
/* print the barcode zip line                                                 */
/* ************************************************************************** */

static void print_barcode_zip(void)
{

  /* set ocr barcode and print */

  int j,
      process_code=0;   /* 0=do not print,
                           1=print 5-digit zip,
                           2=print 9-digit zip with default '99' delivery point,
                           3=print 9-digit zip with delivery point  */

  if (first_time_barcode == 1) {
    barcode_return = get_barcode_escapes();
    first_time_barcode = 0;
  }

  if (barcode_return > 0)
    return;

  for (j=0; j<5; j++) {
    if (!isdigit(ubrrecp_zip_1_5[j]))
      return;
  }
  process_code = 1;
  for (j=0; j<4; j++) {
    if (!isdigit(ubrrecp_zip_7_10[j]))
      break;
  }
  if (j==4) {
    process_code = 2;
    for (j=0; j<2; j++) {
      if (!isdigit(ubrrecp_delivery_point[j]))
        break;
    }
    if (j==2)
      process_code = 3;
  }

  if (process_code == 1) {
    EXEC SQL
      SELECT
        '          ' ||
        :baron_esc_parsed ||
        :ubrrecp_zip_1_5 ||
        :baroff_esc_parsed
      into :barcode_line_text
      from SYS.DUAL;
    POSTORA;
    if (NO_ROWS_FOUND)
      *barcode_line_text = '\0';
  }
  else {
    if (process_code == 2)
      strcpy(ubrrecp_delivery_point,"99");
    EXEC SQL
      SELECT
        '          ' ||
        :baron_esc_parsed ||
        :ubrrecp_zip_1_5 ||
        :ubrrecp_zip_7_10 ||
        :ubrrecp_delivery_point ||
        :baroff_esc_parsed
      into :barcode_line_text
      from SYS.DUAL;
    POSTORA;
    if (NO_ROWS_FOUND)
      *barcode_line_text = '\0';
  }

  newline();
  setmode(M_COLLIT);
  prtstr(barcode_line_text);
  setmode(M_NORMAL);
  newline();
  add(prev_line_num,prev_line_num,"1");

}                                        /* end print_barcode_zip */

/* ************************************************************************* */
/* if we had a budgeted service, print the footnote at the bottom            */
/* of the open item detail section                                           */
/* ************************************************************************* */

static void print_budget_footnote(void)
{
  if ( *budget_footnote ) {
    add(line_05_30_lineno,line_05_30_lineno,"1");
    strcpy(text,
      "'*'=Actual Charges For Budgeted Service Not Included in Amount Due");
    tonum(amount,null);
    print_line_05_30_text();
  }

}                                        /* end print_budget_footnote */

/* ************************************************************************** */
/* print budget line                                                          */
/* ************************************************************************** */

static void print_budget_line(void)
{
  select_budget_totals(FIRST_ROW);
  subtract(ytd_budget_charges,ytd_actual_charges,ytd_budget_variance);
  EXEC SQL
   SELECT 'YTD Actual: '                                        ||
          rpad(to_char(TO_NUMBER(:ytd_actual_charges),'9999999.99'),11)    ||
        '  YTD Budget: '                                        ||
          rpad(to_char(TO_NUMBER(:ytd_budget_charges),'9999999.99'),11)    ||
        decode(:budgeted_service_ind,
                'Y', '     Budget Amount:',
                'C', ' Settlement Amount:',
                     '                   ')
     into :text:Ind_01
     FROM sys.dual;
  POSTORA;
  if ( NO_ROWS_FOUND ) {
    *text='\0';
  }
  if ( compare(budgeted_service_ind,"Y",NES) ) {
    strcpy(amount,ytd_budget_variance);
    add(charges,charges,ytd_budget_variance);
    if (!*sleep_wake_ind ||
      (*sleep_wake_ind && ubtibil_calc_update_ind[0] == 'Y'))
        update_uarbudg();
  }
  else
    strcpy(amount,total_budget_amount);
  print_line_05_30_text();
  strcpy(total_budget_amount,"0");
}                                        /* end print_budget_line */

/* ************************************************************************** */
/* insert Poway line 05 into ubrbill collector table                          */
/* ************************************************************************** */

static void p_print_line_05(void)
{

/* load the bill into the ubrbill-bill collector */
/*                                               */
/* account, premises, cycle                      */

  strcpy(lineno,"5");
  EXEC SQL
   INSERT INTO uimsmgr.ubrbill
        (
        ubrbill_bill_num,
        ubrbill_page_num,
        ubrbill_line_num,
        ubrbill_sess_id,
        ubrbill_text
        )
     SELECT
         TO_NUMBER(:billno),
         TO_NUMBER(:pageno),
         TO_NUMBER(:lineno),
         :session_id,
         lpad(to_char(TO_NUMBER(:ucracct_cust_code)),9) ||
         '-' ||
         rpad(:ucracct_prem_code,7) ||
         '     ' ||
         rpad(substr (
             decode (ucbprem_street_number,'','',ucbprem_street_number||' ') ||
             decode (ucbprem_pdir_code_pre,'','',ucbprem_pdir_code_pre||' ') ||
             decode (ucbprem_street_name,'','',ucbprem_street_name||' ') ||
             decode (ucbprem_ssfx_code,'','',ucbprem_ssfx_code||' ') ||
                   ucbprem_pdir_code_post,1,38),38) ||
         ' Cycle #' ||
         :ucracct_cycl_code
       FROM uimsmgr.ucbprem
       WHERE ucbprem_code = :ucracct_prem_code;
  POSTORA;
}                                        /* end p_print_line_05 */

/* ************************************************************************** */
/* insert Poway line 15 into ubrbill collector table                          */
/* ************************************************************************** */

static void p_print_line_15(void)
{

/* load the bill into the ubrbill-bill collector */
/*                                               */
/* scan line - account, amount due               */

  if (first_time_scan == 1) {
    get_scan_escapes();
    first_time_scan = 0;
  }

  multiply(scan_amount_due,amount_due,"100");
  strcpy(lineno,"15");
  EXEC SQL
   INSERT INTO uimsmgr.ubrbill
        (
        ubrbill_bill_num,
        ubrbill_page_num,
        ubrbill_line_num,
        ubrbill_sess_id,
        ubrbill_text
        )
    VALUES
        (
          TO_NUMBER(:billno),
          TO_NUMBER(:pageno),
          TO_NUMBER(:lineno),
          :session_id,
          '                       ' ||
          :scanon_esc_parsed ||
          lpad(to_char(TO_NUMBER(:ucracct_cust_code)),9,'0') ||
          lpad(:ucracct_prem_code,7,'0') ||
          '   ' ||
          nvl(lpad(to_char(TO_NUMBER(:scan_amount_due),'0000000000'),11),0) ||
          '          ' ||
          nvl(lpad(to_char(TO_NUMBER(:amount_due),'99,999,999.99'),14),0)
          );
  POSTORA;
  strcpy(lineno,"16");
  EXEC SQL
   INSERT INTO uimsmgr.ubrbill
        (
        ubrbill_bill_num,
        ubrbill_page_num,
        ubrbill_line_num,
        ubrbill_sess_id,
        ubrbill_text
        )
    VALUES
        (
          TO_NUMBER(:billno),
          TO_NUMBER(:pageno),
          TO_NUMBER(:lineno),
          :session_id,
          :scanoff_esc_parsed
         );
  POSTORA;
}                                        /* end p_print_line_15 */

/* ************************************************************************** */
/* insert Poway line 20 into ubrbill collector table                          */
/* ************************************************************************** */

static void p_print_line_20(void)
{

/* load the bill into the ubrbill-bill collector */
/*                                               */
/* account, due date, amount due                 */

  strcpy(lineno,"20");
  EXEC SQL
   INSERT INTO uimsmgr.ubrbill
        (
        ubrbill_bill_num,
        ubrbill_page_num,
        ubrbill_line_num,
        ubrbill_sess_id,
        ubrbill_text
        )
    VALUES
        (
          TO_NUMBER(:billno),
          TO_NUMBER(:pageno),
          TO_NUMBER(:lineno),
          :session_id,
          '       ' ||
          lpad(to_char(TO_NUMBER(:ucracct_cust_code)),9,'0') ||
          lpad(:ucracct_prem_code,7,'0') ||
          '                  ' ||
          to_char(to_date(:printed_date,'DD-MON-YYYY'),'MON DD YYYY') ||
          '    ' ||
          decode(:ucbmbil_sub_pymt_ind,
                 'N','           ',
                 to_char(to_date(decode(:reprint_date_var,
                                        null, decode(:deferred_due_date,
                                                     null,:due_date,
                                                     :deferred_due_date),
                                        :uabopen_due_date),
                                 'DD-MON-YYYY'),
                         'MON DD YYYY')) ||
          '    ' ||
          nvl(lpad(to_char(TO_NUMBER(:amount_due),'99,999,999.99'),14),0)
          );
  POSTORA;
}                                        /* end p_print_line_20 */

/* ************************************************************************** */
/* insert Poway line 21 into ubrbill collector table                          */
/* ************************************************************************** */

static void p_print_line_21(void)
{

/* load the bill into the ubrbill-bill collector */
/*                                               */
/* service address                               */

  strcpy(lineno,"21");
  EXEC SQL
   INSERT INTO uimsmgr.ubrbill
        (
        ubrbill_bill_num,
        ubrbill_page_num,
        ubrbill_line_num,
        ubrbill_sess_id,
        ubrbill_text
        )
      SELECT
          TO_NUMBER(:billno),
          TO_NUMBER(:pageno),
          TO_NUMBER(:lineno),
          :session_id,
          '         ' ||
          rpad(substr (
              decode (ucbprem_street_number,'','',ucbprem_street_number||' ') ||
              decode (ucbprem_pdir_code_pre,'','',ucbprem_pdir_code_pre||' ') ||
              decode (ucbprem_street_name,'','',ucbprem_street_name||' ') ||
              decode (ucbprem_ssfx_code,'','',ucbprem_ssfx_code||' ') ||
                    ucbprem_pdir_code_post,1,38),38)
        FROM uimsmgr.ucbprem
        WHERE ucbprem_code = :ucracct_prem_code;
  POSTORA;
}                                        /* end p_print_line_21 */

/* ************************************************************************** */
/* insert Poway line 25 into ubrbill collector table                          */
/* ************************************************************************** */

static void p_print_line_25(void)
{

/* load the bill into the ubrbill-bill collector              */
/*                                                            */
/* service dates, dos, readings, units, est usage ind         */

  strcpy(lineno,"25");
  subtract(meter_diff,hold_present_reading,hold_prev_reading);
  if (compare(meter_diff,"0",EQ))
    { strcpy(total_string,"           "); }
  else {
    tochar(total_string,meter_diff,"99999");
    strcat(total_string," units");
  }
  EXEC SQL
   INSERT INTO uimsmgr.ubrbill
        (
        ubrbill_bill_num,
        ubrbill_page_num,
        ubrbill_line_num,
        ubrbill_sess_id,
        ubrbill_text
        )
    VALUES
        (
          TO_NUMBER(:billno),
          TO_NUMBER(:pageno),
          TO_NUMBER(:lineno),
          :session_id,
          '                   ' ||
          decode(:hold_prev_date,
                 NULL,'     ',
                 to_char(to_date(:hold_prev_date,'MM/DD/YY'),'MM/DD')) ||
          '   ' ||
          to_char(to_date(:hold_present_date,'MM/DD/YY'),'MM/DD') ||
          '   ' ||
          decode(TO_NUMBER(:hold_urrshis_dos),
                        null,'   ',
                        lpad(to_char(TO_NUMBER(:hold_urrshis_dos)),3)) ||
          '   ' ||
          lpad(:hold_prev_reading,5) ||
          '   ' ||
          lpad(:hold_present_reading,5) ||
          '   ' ||
          :total_string ||
          '            ' ||
          :hold_est_usage_ind
          );
  POSTORA;
}                                        /* end p_print_line_25 */

/* ************************************************************************** */
/* insert line 11 duplicate bill msg into ubrbill collector table             */
/* ************************************************************************** */

static void p_print_line_11_dupl(void)
{

/* duplicate bill message */

  strcpy(lineno,"11");

  EXEC SQL
   INSERT INTO uimsmgr.ubrbill
        (
        ubrbill_bill_num,
        ubrbill_page_num,
        ubrbill_line_num,
        ubrbill_sess_id,
        ubrbill_text
        )
    VALUES
        (
         TO_NUMBER(:billno),
         TO_NUMBER(:pageno),
         TO_NUMBER(:lineno),
         :session_id,
         'DUPLICATE BILL'
         );
  POSTORA;                   
}                                        /* end p_print_line_11_dupl */

/* ************************************************************************** */
/* insert line 12 draft msg into ubrbill collector table                     */
/* ************************************************************************** */

static void p_print_line_12_draft(void)
{

/* bank draft message */
/* This uses line 12, also used by p_print_line_12_no_pay; bank drafting and
   master bills are mutually exclusive, so a conflict should not occur.  */

  strcpy(lineno,"12");

  EXEC SQL
   INSERT INTO uimsmgr.ubrbill
        (
        ubrbill_bill_num,
        ubrbill_page_num,
        ubrbill_line_num,
        ubrbill_sess_id,
        ubrbill_text
        )
    VALUES
        (
          TO_NUMBER(:billno),
          TO_NUMBER(:pageno),
          TO_NUMBER(:lineno),
          :session_id,
          'DO NOT PAY - account is being drafted for the amount owed.'
          );
  POSTORA;         
}                                        /* end p_print_line_12_draft */

/* ************************************************************************** */
/* insert line 12 please pay msg into ubrbill collector table                 */
/* ************************************************************************** */

static void print_please_pay_msg(void)
{
  p_print_line_12_please_pay();
}

static void p_print_line_12_please_pay(void)
{

/* bank draft message */
/* This uses line 12, also used by p_print_line_12_no_pay; bank drafting and
   master bills are mutually exclusive, so a conflict should not occur.  */

  strcpy(lineno,"12");
                                                               
  EXEC SQL
   INSERT INTO uimsmgr.ubrbill
        (
        ubrbill_bill_num,
        ubrbill_page_num,
        ubrbill_line_num,
        ubrbill_sess_id,
        ubrbill_text
        )
    VALUES
        (
          TO_NUMBER(:billno),
          TO_NUMBER(:pageno),
          TO_NUMBER(:lineno),
          :session_id,
          'PLEASE PAY - amount is NOT being drafted.'
          );
  POSTORA;         
}                                        /* end p_print_line_12_please_pay */

/* ************************************************************************** */
/* insert line 12 no pay msg into ubrbill collector table                     */
/* ************************************************************************** */

static void p_print_line_12_no_pay(void)
{

/* no payment - master bills message */
/* This uses line 12, also used by p_print_line_12_draft; bank drafting and
   master bills are mutually exclusive, so a conflict should not occur.  */

  strcpy(lineno,"12");

  EXEC SQL
   INSERT INTO uimsmgr.ubrbill
        (
        ubrbill_bill_num,
        ubrbill_page_num,                                      
        ubrbill_line_num,
        ubrbill_sess_id,
        ubrbill_text
        )
    VALUES
        (
          TO_NUMBER(:billno),
          TO_NUMBER(:pageno),
          TO_NUMBER(:lineno),
          :session_id,
          'Do not pay - summary only.'
          );
  POSTORA;         
}                                        /* end p_print_line_12_no_pay */

/* ************************************************************************** */
/* print WATER header for Poway                                               */
/* ************************************************************************** */

static void print_water_header(void)
{
  if (compare(line_05_30_lineno,"44",LT) ||
    (compare(line_05_30_pageno,"1",GT) && compare(line_05_30_lineno,"54",LT)))
      ;
  else {
    line_31_multi();
    strcpy(multi_page_ind,"Y");
    strcpy(line_05_30_lineno,"39");
    add(line_05_30_pageno,line_05_30_pageno,"1");
  }
  EXEC SQL
   INSERT INTO uimsmgr.ubrbill
        (
        ubrbill_bill_num,
        ubrbill_page_num,
        ubrbill_line_num,
        ubrbill_sess_id,
        ubrbill_text
        )
    VALUES
        (
          TO_NUMBER(:billno),
          TO_NUMBER(:line_05_30_pageno),
          TO_NUMBER(:line_05_30_lineno),
          :session_id,
          'WATER'
          );
  POSTORA;
  add(line_05_30_lineno,line_05_30_lineno,"1");
}                                        /* end print_water_header */

/* ************************************************************************** */
/* print SEWER header for Poway                                               */
/* ************************************************************************** */

static void print_sewer_header(void)
{
  if (compare(line_05_30_lineno,"44",LT) ||
    (compare(line_05_30_pageno,"1",GT) && compare(line_05_30_lineno,"54",LT)))
      ;
  else {
    line_31_multi();
    strcpy(multi_page_ind,"Y");
    strcpy(line_05_30_lineno,"39");
    add(line_05_30_pageno,line_05_30_pageno,"1");
  }
  EXEC SQL
   INSERT INTO uimsmgr.ubrbill
        (
        ubrbill_bill_num,
        ubrbill_page_num,
        ubrbill_line_num,
        ubrbill_sess_id,
        ubrbill_text
        )
   VALUES
        (
        TO_NUMBER(:billno),
        TO_NUMBER(:line_05_30_pageno),
        TO_NUMBER(:line_05_30_lineno),
        :session_id,
        'SEWER'
        );
  POSTORA;
  add(line_05_30_lineno,line_05_30_lineno,"1");
}                                        /* end print_sewer_header */

/* ************************************************************************** */
/* insert Poway line 48 into ubrbill collector table                          */
/* ************************************************************************** */

static void p_print_line_48(void)
{

/* load the bill into the ubrbill-bill collector              */
/*                                                            */
/* History, line 1                                            */

  strcpy(lineno,"48");
  multiply(tot_gallons,meter_diff,"748");
  if (!*hold_urrshis_dos || compare(hold_urrshis_dos,"0",EQ))
    { strcpy(avg_gallons,"0"); }
  else
    { divide(avg_gallons,tot_gallons,hold_urrshis_dos); }
  EXEC SQL
   INSERT INTO uimsmgr.ubrbill
        (
        ubrbill_bill_num,
        ubrbill_page_num,
        ubrbill_line_num,
        ubrbill_sess_id,
        ubrbill_text
        )
    VALUES
        (
          TO_NUMBER(:billno),
          TO_NUMBER(:pageno),
          TO_NUMBER(:lineno),
          :session_id,
          'THIS YEAR           ' ||
          decode(TO_NUMBER(:hold_urrshis_dos),
                   null,'   0',
                   to_char(TO_NUMBER(:hold_urrshis_dos),'990')) ||
          '   ' ||
          decode(to_number(:meter_diff),
                   null,' 0000',
                   to_char(TO_NUMBER(:meter_diff),'0000')) ||
          '  ' ||
          decode(to_number(:avg_gallons),
                   null,' 00000',
                   to_char(TO_NUMBER(:avg_gallons),'00000'))
          );
  POSTORA;
}                                        /* end p_print_line_48 */

/* ************************************************************************** */
/* insert Poway line 49 into ubrbill collector table                          */
/* ************************************************************************** */

static void p_print_line_49(void)
{

/* load the bill into the ubrbill-bill collector              */
/*                                                            */
/* History, line 2                                            */

  strcpy(lineno,"49");
  multiply(tot_gallons,hold_lastyr_consump,"748");
  if (!*hold_lastyr_dos || compare(hold_lastyr_dos,"0",EQ))
    { strcpy(lastyr_avg_gallons,"0"); }
  else
    { divide(lastyr_avg_gallons,tot_gallons,hold_lastyr_dos); }
  subtract(avg_gallons_chg,avg_gallons,lastyr_avg_gallons);
  if (!*lastyr_avg_gallons || compare(lastyr_avg_gallons,"0",EQ))
    { strcpy(pct_change,"0"); }
  else
    { divide(pct_change,avg_gallons_chg,lastyr_avg_gallons); }
  EXEC SQL
   INSERT INTO uimsmgr.ubrbill
        (
        ubrbill_bill_num,
        ubrbill_page_num,
        ubrbill_line_num,
        ubrbill_sess_id,
        ubrbill_text
        )
    VALUES
        (
          TO_NUMBER(:billno),
          TO_NUMBER(:pageno),
          TO_NUMBER(:lineno),
          :session_id,
          'LAST YEAR           ' ||
          decode(TO_NUMBER(:hold_lastyr_dos),
                   null,'   0',
                   to_char(TO_NUMBER(:hold_lastyr_dos),'990')) ||
          '   ' ||
          decode(to_number(:hold_lastyr_consump),
                   null,' 0000',
                   to_char(TO_NUMBER(:hold_lastyr_consump),'0000')) ||
          '  ' ||
          decode(to_number(:lastyr_avg_gallons),
                   null,' 00000',
                   to_char(TO_NUMBER(:lastyr_avg_gallons),'00000')) ||
          decode(to_number(:pct_change),
                   null,'      ',
                   to_char(TO_NUMBER(:pct_change),'9999MI'))
          );
  POSTORA;
}                                        /* end p_print_line_49 */

/* ************************************************************************** */
/* print detail lines (meter readings, consumption, etc)                      */
/* ************************************************************************** */

static void print_detail_line(void)
{
  if (compare(line_05_30_lineno,"44",LT) ||
    (compare(line_05_30_pageno,"1",GT) && compare(line_05_30_lineno,"54",LT)))
      ;
  else {
    line_31_multi();
    strcpy(multi_page_ind,"Y");
    strcpy(line_05_30_lineno,"39");
    add(line_05_30_pageno,line_05_30_pageno,"1");
  }
  EXEC SQL
   INSERT INTO uimsmgr.ubrbill
        (
        ubrbill_bill_num,
        ubrbill_page_num,
        ubrbill_line_num,
        ubrbill_sess_id,
        ubrbill_text
        )
    VALUES
        (
          TO_NUMBER(:billno),
          TO_NUMBER(:line_05_30_pageno),
          TO_NUMBER(:line_05_30_lineno),
          :session_id,
          '    Meter Change Out:     '  ||
          decode(TO_NUMBER(:uabopen_chrg_calc_num),
                 null,'                                      ',
                 lpad(to_char(TO_NUMBER(:uabopen_billed_chg),'999,999.99'),
                      13))
        );
  POSTORA;
  /* re-retrieve line text for C usage */
  EXEC SQL SELECT ubrbill_text INTO :ubrbill_text
      FROM uimsmgr.ubrbill
      WHERE ubrbill_bill_num = TO_NUMBER(:billno)
        AND ubrbill_page_num = TO_NUMBER(:line_05_30_pageno)
        AND ubrbill_line_num = TO_NUMBER(:line_05_30_lineno)
        AND ubrbill_sess_id  = :session_id;
  POSTORA;
  add(line_05_30_lineno,line_05_30_lineno,"1");
}                                        /* end print_detail_line */

/* ************************************************************************** */
/* print detail lines (meter readings, consumption, etc)                      */
/* ************************************************************************** */

static void print_detail_line_2(void)
{
  EXEC SQL
    SELECT utrsrat_rate_step_ind
      into :utrsrat_rate_step_ind
      FROM uimsmgr.utrsrat
      WHERE utrsrat_srat_code = :uabopen_srat_code
        AND utrsrat_scat_code = :uabopen_scat_code;
  POSTORA;

  if (uabopen_serv_num[0] == '\0')
    { strcpy(uabopen_serv_num,"9999"); }

  if (compare(prev_serv_num,uabopen_serv_num,NE)) {
    if (compare(uabopen_serv_num,"1",EQ)) {
      print_water_header();
      strcpy(subtotal,"0");
    }
    if (compare(prev_serv_num,"1",EQ)) {
      strcpy(text,"    Total Water Charges                                ");
      strcpy(amount,subtotal);
      print_line_05_30_text();
      print_blank_line();
    }
    if (compare(uabopen_serv_num,"3",EQ)) {
      print_blank_line();
      print_sewer_header();
      strcpy(subtotal,"0");
    }
    if (compare(prev_serv_num,"3",EQ)) {
      strcpy(text,"    Total Sewer Charges                                ");
      strcpy(amount,subtotal);
      print_line_05_30_text();
      print_blank_line();
    }
    strcpy(prev_serv_num,uabopen_serv_num);
  }

  if (utrsrat_rate_step_ind[0]=='F') {
    divide(rate,uabopen_billed_chg,"2");
    strcpy(rate_vbg,"/Month");
  }
  else {
    strcpy(rate_vbg,"/Unit");
    EXEC SQL
      select utrrstp_charge_amt
        into :rate
        from uimsmgr.utrrstp
        where utrrstp_srat_code = :uabopen_srat_code
          and utrrstp_scat_code = :uabopen_scat_code
          and utrrstp_effect_date =
            (select max(utrrstp_effect_date)
               from uimsmgr.utrrstp
               where utrrstp_srat_code = :uabopen_srat_code
                 and utrrstp_scat_code = :uabopen_scat_code
                 and utrrstp_effect_date
                   <= to_date(:present_date,'MM/DD/YY'))
          and utrrstp_step_num =
            (select min(utrrstp_step_num)
               from uimsmgr.utrrstp
               where utrrstp_srat_code = :uabopen_srat_code
                 and utrrstp_scat_code = :uabopen_scat_code
                 and utrrstp_effect_date =
                   (select max(utrrstp_effect_date)
                      from uimsmgr.utrrstp
                      where utrrstp_srat_code = :uabopen_srat_code
                        and utrrstp_scat_code = :uabopen_scat_code
                        and utrrstp_effect_date
                          <= to_date(:present_date,'MM/DD/YY')));
    POSTORA;
    if (NO_ROWS_FOUND) {
      strcpy(rate,"0");
      strcpy(rate_vbg," ");
    }
  }

  if (compare(uabopen_serv_num,"1",EQ) || compare(uabopen_serv_num,"3",EQ))
    { add(subtotal,subtotal,uabopen_billed_chg); }

  if (compare(line_05_30_lineno,"44",LT) ||
    (compare(line_05_30_pageno,"1",GT) && compare(line_05_30_lineno,"54",LT)))
      ;
  else {
    line_31_multi();
    strcpy(multi_page_ind,"Y");
    strcpy(line_05_30_lineno,"39");
    add(line_05_30_pageno,line_05_30_pageno,"1");
  }
  EXEC SQL
   INSERT INTO uimsmgr.ubrbill
        (
        ubrbill_bill_num,
        ubrbill_page_num,
        ubrbill_line_num,
        ubrbill_sess_id,
        ubrbill_text
        )
    SELECT
          TO_NUMBER(:billno),
          TO_NUMBER(:line_05_30_pageno),
          TO_NUMBER(:line_05_30_lineno),
          :session_id,
          '  ' ||
          rpad(utvsrat_desc,40) ||
          lpad(to_char(to_number(:rate),'99.99'),6) ||
          :rate_vbg ||
          lpad(to_char(TO_NUMBER(:uabopen_billed_chg),'999,999.99'),12)
     FROM uimsmgr.utvsrat
    WHERE utvsrat_code = :uabopen_srat_code;
  POSTORA;
  add(line_05_30_lineno,line_05_30_lineno,"1");
}                                        /* end print_detail_line_2 */

/* ************************************************************************** */
/* print detail lines (meter readings, consumption, etc) for change out       */
/* ************************************************************************** */

static void print_detail_line_change_out_2(void)
{
  if (compare(line_05_30_lineno,"44",LT) ||
    (compare(line_05_30_pageno,"1",GT) && compare(line_05_30_lineno,"54",LT)))
      ;
  else {
    strcpy(multi_page_ind,"Y");
    strcpy(line_05_30_lineno,"39");
    add(line_05_30_pageno,line_05_30_pageno,"1");
  }
  EXEC SQL
   INSERT INTO uimsmgr.ubrbill
        (
        ubrbill_bill_num,
        ubrbill_page_num,
        ubrbill_line_num,
        ubrbill_sess_id,
        ubrbill_text
        )
    VALUES
        (
          TO_NUMBER(:billno),
          TO_NUMBER(:line_05_30_pageno),
          TO_NUMBER(:line_05_30_lineno),
          :session_id,
          /*  How to handle?  */
          decode(:non_metered_ind,
                 'Y','        ',
                 :prev_date)            ||
          ' '                                   ||
          decode(:non_metered_ind,
                 'Y','        ',
                 :change_out_date)              ||
          '  '                                  ||
          lpad(to_char(TO_NUMBER(:change_out_dos)),3)               ||
          ' '                                   ||
          lpad(nvl(:uabopen_srat_code,'    '),4)||
          ' '                                   ||
          decode(TO_NUMBER(:uabopen_chrg_calc_num),
                   null,'                                      ',
                   decode(:non_metered_ind,
                            null,lpad(:prev_reading,11),'           ') ||
                  ' '                                   ||
                   decode(:non_metered_ind,
                            null,lpad(to_char(TO_NUMBER(:change_out_reading)),
                                      14),
                                '              ') ||
                  ' '                                   ||
                   decode(:non_metered_ind,
                            null,lpad(to_char(TO_NUMBER(:change_out_cons)),11),
                          '           ')) ||
                  ' '                                   ||
                  lpad(nvl(:urrshis_high_low_excp,'  '),2)
        );
  POSTORA;
  /* re-retrieve line text for C usage */
  EXEC SQL SELECT ubrbill_text INTO :ubrbill_text
      FROM uimsmgr.ubrbill
      WHERE ubrbill_bill_num = TO_NUMBER(:billno)
        AND ubrbill_page_num = TO_NUMBER(:line_05_30_pageno)
        AND ubrbill_line_num = TO_NUMBER(:line_05_30_lineno)
        AND ubrbill_sess_id  = :session_id;
  POSTORA;
  add(line_05_30_lineno,line_05_30_lineno,"1");
}                                       /* end print_detail_line_change_out_2 */

/* ************************************************************************** */
/* print detail lines adjustments                                             */
/* ************************************************************************** */

static void print_detail_line_adjustments(void)
{

  if (uabopen_serv_num[0] == '\0')
    { strcpy(uabopen_serv_num,"9999"); }

  if (compare(prev_serv_num,uabopen_serv_num,NE)) {
    if (compare(uabopen_serv_num,"1",EQ)) {
      print_water_header();
      strcpy(subtotal,"0");
    }
    if (compare(prev_serv_num,"1",EQ)) {
      strcpy(text,"    Total Water Charges                                ");
      strcpy(amount,subtotal);
      print_line_05_30_text();
      print_blank_line();
    }
    if (compare(uabopen_serv_num,"3",EQ)) {
      print_sewer_header();
      strcpy(subtotal,"0");
    }
    if (compare(prev_serv_num,"3",EQ)) {
      strcpy(text,"    Total Sewer Charges                                ");
      strcpy(amount,subtotal);
      print_line_05_30_text();
      print_blank_line();
    }
    strcpy(prev_serv_num,uabopen_serv_num);
  }

  if (compare(uabopen_serv_num,"1",EQ) || compare(uabopen_serv_num,"3",EQ))
    { add(subtotal,subtotal,uabopen_billed_chg); }

  if (compare(line_05_30_lineno,"44",LT) ||
    (compare(line_05_30_pageno,"1",GT) && compare(line_05_30_lineno,"54",LT)))
      ;
  else {
    line_31_multi();
    strcpy(multi_page_ind,"Y");
    strcpy(line_05_30_lineno,"39");
    add(line_05_30_pageno,line_05_30_pageno,"1");
  }
  EXEC SQL
   INSERT INTO uimsmgr.ubrbill
        (
        ubrbill_bill_num,
        ubrbill_page_num,
        ubrbill_line_num,
        ubrbill_sess_id,
        ubrbill_text
        )
   SELECT TO_NUMBER(:billno),
          TO_NUMBER(:line_05_30_pageno),
          TO_NUMBER(:line_05_30_lineno),
          :session_id,
          ' ' ||
          decode(utradjm_desc,null,'                                        ',
                 rpad(utradjm_desc,40)) ||
          '            ' ||
          lpad(to_char(TO_NUMBER(:uabadje_balance),'999,999.99'),12)
     FROM uimsmgr.utradjm
    WHERE utradjm_code = :uabadje_adjm_code;
  POSTORA;
  /* re-retrieve line text for C usage */
  EXEC SQL SELECT ubrbill_text INTO :ubrbill_text
      FROM uimsmgr.ubrbill
      WHERE ubrbill_bill_num = TO_NUMBER(:billno)
        AND ubrbill_page_num = TO_NUMBER(:line_05_30_pageno)
        AND ubrbill_line_num = TO_NUMBER(:line_05_30_lineno)
        AND ubrbill_sess_id  = :session_id;
  POSTORA;
    add(line_05_30_lineno,line_05_30_lineno,"1");

}                                        /* end print_detail_line_adjustments */

/* ************************************************************************** */
/* print lines 05 thru 30 - text and dollar amount                            */
/* ************************************************************************** */

static void print_line_05_30_text(void)
{
  if (compare(line_05_30_lineno,"44",LT) ||
    (compare(line_05_30_pageno,"1",GT) && compare(line_05_30_lineno,"54",LT)))
      ;
  else {
    line_31_multi();
    strcpy(multi_page_ind,"Y");
    strcpy(line_05_30_lineno,"39");
    add(line_05_30_pageno,line_05_30_pageno,"1");
  }
  p_line_05_30_text();
  add(line_05_30_lineno,line_05_30_lineno,"1");
}                                        /* end print_line_05_30_text */

/* ************************************************************************** */
/* print bank draft messages                                                  */
/* ************************************************************************** */

static void print_draft_next_month_msg(void)
{
  if (compare(line_05_30_lineno,"44",LT) ||
    (compare(line_05_30_pageno,"1",GT) && compare(line_05_30_lineno,"54",LT)))
      ;
  else {
    strcpy(multi_page_ind,"Y");
    strcpy(line_05_30_lineno,"39");
    add(line_05_30_pageno,line_05_30_pageno,"1");
  }
  EXEC SQL
   INSERT INTO uimsmgr.ubrbill
        (
        ubrbill_bill_num,
        ubrbill_page_num,
        ubrbill_line_num,
        ubrbill_sess_id,
        ubrbill_text
        )
    VALUES
        (
         TO_NUMBER(:billno),
         TO_NUMBER(:line_05_30_pageno),
         TO_NUMBER(:line_05_30_lineno),
         :session_id,
         'Automatic account drafting will begin next month'
        );
  POSTORA;
  add(line_05_30_lineno,line_05_30_lineno,"1");
}                                        /* end print_draft_next_month_msg */

static void print_draft_msg(void)
{

  p_print_line_12_draft();
  if (compare(line_05_30_lineno,"44",LT) ||
    (compare(line_05_30_pageno,"1",GT) && compare(line_05_30_lineno,"54",LT)))
      ;
  else {
    strcpy(multi_page_ind,"Y");
    strcpy(line_05_30_lineno,"39");
    add(line_05_30_pageno,line_05_30_pageno,"1");
  }
  EXEC SQL
   INSERT INTO uimsmgr.ubrbill
        (
        ubrbill_bill_num,
        ubrbill_page_num,
        ubrbill_line_num,
        ubrbill_sess_id,
        ubrbill_text
        )
    VALUES
        (
         TO_NUMBER(:billno),
         TO_NUMBER(:line_05_30_pageno),
         TO_NUMBER(:line_05_30_lineno),
         :session_id,
         'Amount will be drafted on / around ' ||
         DECODE(:reprint_date_var,
                NULL, DECODE(:deferred_due_date,
                             NULL,TO_CHAR(TO_DATE(:due_date,'DD-MON-YYYY')
                                          - to_number(:uobsysc_days_draft),
                                          'DD-MON-YYYY'),
                             TO_CHAR(TO_DATE(:deferred_due_date,'DD-MON-YYYY')
                                     - to_number(:uobsysc_days_draft),
                                     'DD-MON-YYYY')),
                TO_CHAR(TO_DATE(:uabopen_due_date,'DD-MON-YYYY')
                        - to_number(:uobsysc_days_draft),
                        'DD-MON-YYYY'))
        );
  POSTORA;
  add(line_05_30_lineno,line_05_30_lineno,"1");
}                                        /* end print_draft_msg */

/* ************************************************************************** */
/* print roundup total for a year                                             */
/* ************************************************************************** */

static void print_rdup(void)
{
  if (compare(line_05_30_lineno,"44",LT) ||
    (compare(line_05_30_pageno,"1",GT) && compare(line_05_30_lineno,"54",LT)))
      ;
  else {
    strcpy(multi_page_ind,"Y");
    strcpy(line_05_30_lineno,"39");
    add(line_05_30_pageno,line_05_30_pageno,"1");
  }
  EXEC SQL
   INSERT INTO uimsmgr.ubrbill
        (
        ubrbill_bill_num,
        ubrbill_page_num,
        ubrbill_line_num,
        ubrbill_sess_id,
        ubrbill_text
        )
    VALUES
        (
         TO_NUMBER(:billno),
         TO_NUMBER(:line_05_30_pageno),
         TO_NUMBER(:line_05_30_lineno),
         :session_id,
         'Total Round Up Contributions for ' ||
         :year_vbg ||
         ' year: ' ||
         TO_CHAR(TO_NUMBER(:total_roundup),'999,999.99') ||
         '   Total Paid: ' ||
         TO_CHAR(TO_NUMBER(:total_roundup_paid),'999,999.99')
        );
  POSTORA;
  add(line_05_30_lineno,line_05_30_lineno,"1");
}                                        /* end print_rdup */

/* ************************************************************************** */
/* print a blank line                                                         */
/* ************************************************************************** */

static void print_blank_line(void)
{
  if (compare(line_05_30_lineno,"44",LT) ||
    (compare(line_05_30_pageno,"1",GT) && compare(line_05_30_lineno,"54",LT)))
      ;
  else {
    line_31_multi();
    strcpy(multi_page_ind,"Y");
    strcpy(line_05_30_lineno,"39");
    add(line_05_30_pageno,line_05_30_pageno,"1");
  }
  insert_blank_line();
  add(line_05_30_lineno,line_05_30_lineno,"1");
}

/* ************************************************************************** */
/* insert Poway messages into ubrbill collector table                         */
/* ************************************************************************** */

static void p_print_message_lines(void)
{

  if ( *bill_message_code && compare(system_bmsg_option,"A",NES) ) {
    /* insert system bill message */
    strcpy(bmsg_code,bill_message_code);
    p_message_line();
    add(line_05_30_lineno,line_05_30_lineno,"1");
  }

  if ( *ucbcust_bmsg_code ) {
    /* insert customer-specific message */
    strcpy(bmsg_code,ucbcust_bmsg_code);
    p_message_line();
    add(line_05_30_lineno,line_05_30_lineno,"1");
  }

  if ( *ucracct_bmsg_code && compare(system_bmsg_option,"S",NES) ) {
    /* insert account-specific message */
    strcpy(bmsg_code,ucracct_bmsg_code);
    p_message_line();
    add(line_05_30_lineno,line_05_30_lineno,"1");
  }

}                                        /* end p_print_message_lines */
