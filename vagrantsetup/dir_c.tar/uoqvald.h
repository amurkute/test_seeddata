/* AUDIT TRAIL:8.0 */
/* AUDIT TRAIL END */
#ifndef UOQVALD_H
#define UOQVALD_H

extern int UValidCycleParm(char *pszText, char *rpszCycleRange[]);

extern int  UValidateYesNo(char *pszParm, char *rpszParm[]);

#endif
