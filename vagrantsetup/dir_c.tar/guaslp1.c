/*TMCI18N BEGIN HEADER*/
#if !defined( tmBundle_EXISTS )
/* No Initialisation Required */
#include "tmcilib.h"
static struct TMBundle tmBundle = {"guaslp1.c",NULL,NULL,NULL,NULL};
#define tmBundle_EXISTS
#endif
/*TMCI18N END HEADER*/

/* AUDIT_TRAIL_TM63
-- TranMan 6.3
-- PROJECT : HEGDE_I18N
-- MODULE  : GUASLP1
-- SOURCE  : enUS
-- TARGET  : I18N
-- DATE    : Mon Nov 05 12:33:42 2007
END AUDIT_TRAIL_TM63 */
/* audit trail: 2.0                                  INIT   DATE */
/* 1. Create copylib for sleep/wake processes        SRS  06/23/93 */
/* audit trail:8.0 */
/* audit trail end */
#ifndef NO_SLEEP_SW

  static int     done_sleeping=1;
  /*static CHAR2   abnormalexit=_TMC("Y");*/
  /* HvT remove the need for run time initialization */
  static TMCHAR abnormalexit[2]={'Y',0};

  static int     runsw;
  static int     nextsw;
  static int     session_id;
  static int     fileext=0;
  static TMCHAR    cext[20]={0}/*TMCI18N CHANGED FROM ""*/;
  static TMCHAR    newfile[30]={0}/*TMCI18N CHANGED FROM ""*/;
  static TMCHAR    *outputfile;
  static TMCHAR printcom[255]={0}/*TMCI18N CHANGED FROM ""*/;

#endif
/* HvT Removed run time initialization */
