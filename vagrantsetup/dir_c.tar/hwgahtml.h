/*****************************************************************************/
/* HWGAHTML.H Copyright (c) SCT Corporation 1996.  All rights reserved       */
/*****************************************************************************/

              /***************************************************/
              /*                                                 */
              /*       CONFIDENTIAL BUSINESS INFORMATION         */
              /*                                                 */
              /*      **********************************         */
              /*                                                 */
              /*  THIS PROGRAM IS PROPRIETARY INFORMATION OF     */
              /* SYSTEMS AND COMPUTER TECHNOLOGY CORPORATION     */
              /* AND IS NOT TO BE COPIED, REPRODUCED, LENT OR    */
              /* DISPOSED OF, NOR USED FOR ANY PURPOSE OTHER     */
              /* THAN THAT FOR WHICH IT IS SPECIFICALLY PROVIDED */
              /* WITHOUT THE WRITTEN PERMISSION OF SAID COMPANY  */
              /*                                                 */
              /***************************************************/

/*****************************************************************************/
/* HWGAHTML.H                                                                */
/*                                                                           */
/* OWA HTP/HTF Emulation Procedures Header File                              */
/*                                                                           */
/* AUDIT TRAIL: 2.1.7                                         INIT    DATE   */
/* _________________________________________________________  ____  ________ */
/* 1. New header file for hwgahtml.c.                         KAS   04/23/96 */
/*                                                                           */
/* AUDIT TRAIL: 3.1                                                          */
/* 1. Add prototype for htp_img.                              RLH   09/04/98 */
/*                                                                           */
/* AUDIT TRAIL: 3.1.2                                         JDS   10/05/99 */
/* 1. Added new prototypes that will reference the external                  */
/*    cascading stylesheet to pick up background colors in                   */
/*    certain types of table data cells.                                     */
/*                                                                           */
/* AUDIT TRAIL : 8.0 (I18N) *//* AUDIT TRAIL END                                                           */
/*                                                                           */
/* ************************************************************************* */

/* Local prototypes */

void htp_html_open(FILE *fp);
void htp_html_close(FILE *fp);
void htp_head_open(FILE *fp);
void htp_head_close(FILE *fp);
void htp_body_open(FILE *fp);
void htp_body_close(FILE *fp);
void htp_title(FILE *fp, char *ctitle);
void htp_header(FILE *fp, int nsize, char *cheader);
void htp_hr(FILE *fp);
void htp_br(FILE *fp);
void htp_para(FILE *fp);
void htp_bold(FILE *fp, char *ctext);
void htp_italic(FILE *fp, char *ctext);
void htp_anchor(FILE *fp, char *curl, char *ctext, char *cname);
void htp_table_open(FILE *fp, char *cborder, char *calign);
void htp_table_plain_open(FILE *fp, char *cwidth);
void htp_table_datadisplay_open(FILE *fp, char *cwidth);
void htp_table_dataentry_open(FILE *fp, char *cwidth);
void htp_table_close(FILE *fp);
void htp_table_row_open(FILE *fp, char *calign);
void htp_table_row_close(FILE *fp);
void htp_table_header_open(FILE *fp, char *calign,
                           char *crowspan, char *ccolspan);
void htp_table_header_close(FILE *fp);
void htp_table_data(FILE *fp, char *crowspan, char *ccolspan);
void htp_table_data_open(FILE *fp, char *calign,
                         char *crowspan, char *ccolspan);
void htp_table_data_label_open(FILE *fp, char *calign,
                               char *crowspan, char *ccolspan);
void htp_table_data_header_open(FILE *fp, char *calign,
                                char *crowspan, char *ccolspan);
void htp_table_data_separator_open(FILE *fp, char *calign,
                                char *crowspan, char *ccolspan);
void htp_table_data_highlight_open(FILE *fp, char *calign,
                                char *crowspan, char *ccolspan);
void htp_table_data_white_open(FILE *fp, char *calign,
                               char *crowspan, char *ccolspan);
void htp_table_data_dead_open(FILE *fp, char *calign,
                              char *crowspan, char *ccolspan); 
void htp_table_data_close(FILE *fp);
void htp_img(FILE *fp, char *curl, char *calign, char *calt);
