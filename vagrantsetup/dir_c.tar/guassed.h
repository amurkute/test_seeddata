/* Object: guassed.h
   Author: John Morgan
 Mod Date: 08/15/95
  Release: General 2.1.5
*/

/***************************************************/
/*                                                 */
/*       CONFIDENTIAL BUSINESS INFORMATION         */
/*                                                 */
/*      **********************************         */
/*                                                 */
/*  THIS PROGRAM IS PROPRIETARY INFORMATION OF     */
/* SYSTEMS AND COMPUTER TECHNOLOGY CORPORATION     */
/* AND IS NOT TO BE COPIED, REPRODUCED, LENT OR    */
/* DISPOSED OF, NOR USED FOR ANY PURPOSE OTHER     */
/* THAN THAT FOR WHICH IT IS SPECIFICALLY PROVIDED */
/* WITHOUT THE WRITTEN PERMISSION OF SAID COMPANY  */
/*                                                 */
/***************************************************/

/* AUDIT TRAIL: 2.1.5                              INIT      DATE           */
/*                                                                          */
/* 1. New object; defines the SECRET_SEED1 and      JWM    08/15/95         */
/*    SECRET_SEED3 macros for use by login security                         */
/*    process.                                                              */
/*                                                                          */
/* AUDIT TRAIL : 8.0 (I18N) *//* AUDIT TRAIL END                                                          */

/* guassed - Secret Seed Header File
   Define your site's secret seeds below; be sure to append an 'L' to the
   end of the number so that the constant will be treated as the correct 
   type.
*/

#define SECRET_SEED1 12345678L
#define SECRET_SEED3 87651234L
