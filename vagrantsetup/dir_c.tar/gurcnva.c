/*TMCI18N BEGIN HEADER*/
#if !defined( tmBundle_EXISTS )
#include "tmcilib.h"
static struct TMBundle tmBundle = {"gurcnva.c",NULL,NULL,NULL,NULL};
#define tmBundle_EXISTS
#endif
/*TMCI18N END HEADER*/

/* AUDIT_TRAIL_MSGKEY_UPDATE
-- PROJECT : MSGKEY
-- MODULE  : GURCNVA
-- SOURCE  : enUS
-- TARGET  : I18N
-- DATE    : Sun Sep 20 08:00:19 2009
-- MSGSIGN : #bd1a4a5459404c07
END AUDIT_TRAIL_MSGKEY_UPDATE */

/*==========================================================================*/
/* AUDIT TRAIL: 8.0                                                         */
/* 1. New c lib to convert utf8 text files to std ascii.      PNN 04/01/2008*/
/*                                                                          */
/* AUDIT TRAIL: 8.2.0.1                                                     */
/* 1. Defect 1-6T9UUY                                         LVH 08/04/2009*/
/*      * changed concatenation of ".tmp" to "tmp"                          */
/*      * modified method of getting gurcnvc.map in VMS                     */
/*    This object has also been cloned for future use to create gurcnvb.c.  */
/*    The change is to call the new function gukcnva.f_translate instead of */
/*    using gurcnvc.map.                                                    */
/*                                                                          */
/* AUDIT TRAIL END                                                          */
/*==========================================================================*/
/* GURCNVB.C Copyright 2008 - 2009 SunGard.  All rights reserved.           */
/****************************************************************************/
/*                                                                          */
/* Copyright 2008 - 2009 SunGard.  All rights reserved.                     */
/*                                                                          */
/* SunGard or its subsidiaries in the U.S. and other countries is the owner */
/* of numerous marks, including "SunGard," the SunGard logo, "Banner,"      */
/* "PowerCAMPUS," "Advance," "Luminis," "UDC," and "Unified Digital Campus."*/
/* Other names and marks used in this material are owned by third parties.  */
/*                                                                          */
/* This [site/software] contains confidential and proprietary information   */
/* of SunGard and its subsidiaries. Use of this [site/software] is limited  */
/* to SunGard Higher Education licensees, and is subject to the terms and   */
/* conditions of one or more written license agreements between SunGard     */
/* Higher Education and the licensee in question.                           */
/*                                                                          */
/****************************************************************************/
#include "guastdf.h"

#define TRUE     1
#define FALSE    0
#define SAME     0
#define MAX_READ 1024
#define BANNER_HOME _TMC("BANNER_HOME")

static TMCHAR oneLine[MAX_READ] = {0};
static TMCHAR fNameIn[256]      = {0};
static TMCHAR fNameOut[256]     = {0};
static TMCHAR fNameTmp[256]     = {0};
static TMCHAR fNameMap[256]     = {0};
static int    mapCount          = 0;

static UFILE *fMap;
static UFILE *fIn;
static UFILE *fOut;
static UFILE *openFile(TMCHAR *fname, TMCHAR *flag);

static void utf8_to_ascii(TMCHAR *fnameIn, TMCHAR *fNameOut);

static void loadMap(TMCHAR *fname);
static void convertFile(void);
static void cleanupFiles(void);

/* List supports */
typedef struct nodeStruct
{
  TMCHAR *text;
  void   *ptr;
  int     isOwner;
  int     tag;
  int     index;
  struct  nodeStruct *next;  /* next node  */
  struct  listStruct *child; /* child list */
} nodeRec;

typedef nodeRec *nodeRecPtr;

typedef struct listStruct
{
  TMCHAR     *text;
  nodeRec    *head;
  nodeRec    *tail;
  nodeRec    *curNode;
  nodeRecPtr *array;
  int        count;
  int        sorted;
} listRec;

/* list functions */
static void     initList(listRec *list);
static void     clearList(listRec *list);
static void     indexList(listRec *list);
static void     sortList(listRec *list);
static listRec *newList(TMCHAR *text);
static void     freeList(listRec *list);
static nodeRec *addNode(listRec *list, TMCHAR *text);
static nodeRec *addObject(listRec *list, TMCHAR *text, void *ptr, int isOwner);
static nodeRec *firstNode(listRec *list);
static nodeRec *nextNode(listRec *list);
static int      findIndex(listRec *list, TMCHAR *text);
static nodeRec *findNode(listRec *list, TMCHAR *text);

static listRec *mapList;

/******************************************************************************/
static void utf8_to_ascii(TMCHAR *fileIn, TMCHAR *fileOut)
{
  char VMS_fNameMap[256];
#ifdef SCT_DEBUG
  tmprintf(&tmBundle, _TMC("Executing utf8_to_ascii\n"));
  tmfflush(tmstdout);
#endif

#if   OPSYS==OS_VMS
  strcpy(VMS_fNameMap,getenv("BAN_HOME"));
  /* remove trailing ']' from /trans/conc ban_home logical*/
  VMS_fNameMap[strlen(VMS_fNameMap)-1] = '\0';
  strcat(VMS_fNameMap, "general.com]gurcnvc.map");
  /* force back to UTF to proceed */
  tmstrcpy(fNameMap,_TMC(VMS_fNameMap));
#elif OPSYS==OS_MSDOS || OPSYS==OS_OS2 || OPSYS==OS_WINNT
  tmstrcpy(fNameMap, tmgetenv(BANNER_HOME));
  tmstrcat(fNameMap, _TMC("\\general\\misc\\gurcnvc.map"));
#else
  tmstrcpy(fNameMap, tmgetenv(BANNER_HOME));
  tmstrcat(fNameMap, _TMC("/general/misc/gurcnvc.map"));
#endif

  tmstrcpy(fNameIn, fileIn);
  tmstrcpy(fNameOut, fileOut);
  tmstrcpy(fNameTmp, fNameOut);

  if (tmstrcmp(fNameIn, fNameOut) == SAME)
    tmstrcat(fNameOut, _TMC("tmp"));

  mapList = newList(_TMC("List of mapping pairs"));
  loadMap(fNameMap);
  convertFile();
  cleanupFiles();
  freeList(mapList);

  tmprintf(&tmBundle, _TMC("File \"{0}\" converted successfully.\n"), fileIn);
}

/******************************************************************************/
static void loadMap(TMCHAR *fname)
{
  TMCHAR  before[2]       = {0};
  TMCHAR *temp            = NULL;
  TMCHAR  bom[MAX_READ]   = {0}; /* Byte-Order-Mark */
  int     i               = 0;
  int     len             = 0;
  int     size            = 0;

#ifdef SCT_DEBUG
  tmprintf(&tmBundle, _TMC("Executing loadMap\n"));
  tmfflush(tmstdout);
#endif

  mapCount = 0;
  tmstrcpy(before, _TMC(" "));

  fMap = openFile(fname, _TMC("r"));

  while (tmfgets(oneLine, MAX_READ, fMap))
  {
    if (mapCount == 0)
    { /* skip the BOM character? */
      tmstrcpy(bom, &oneLine[1]);
      tmstrcpy(oneLine, bom);
    }

    if (oneLine[0] != '#')
    {
      len = tmstrlen(oneLine);
      oneLine[len - 1] = '\0';

      for (i = 0; (i < len) && (oneLine[i] != '/'); i++);

      before[0] = oneLine[0];

      size = tmstrlen(&oneLine[i + 1]) + 1;
      temp = (TMCHAR *)addObject(mapList, before, (void *)malloc(sizeof(TMCHAR) * size), TRUE)->ptr;
      tmstrcpy(temp, &oneLine[i + 1]);

      mapCount++;
    }
  }

#ifdef SCT_DEBUG
  tmprintf(&tmBundle, _TMC("{0,%d} mapping pairs found in \"{1}\"\n"), mapCount, fname);
#endif

  sortList(mapList);
}

/******************************************************************************/
static void convertFile(void)
{
  TMCHAR  before[2]        = {0};
  TMCHAR *after            = NULL;
  TMCHAR *ptr              = NULL;
  int     i                = 0;
  int     j                = 0;
  int     len              = 0;
  int     found            = FALSE;

#ifdef SCT_DEBUG
  tmprintf(&tmBundle, _TMC("Executing convertFile\n"));
  tmfflush(tmstdout);
#endif

  fOut = openFile(fNameOut, _TMC("w"));
  tmstrcpy(before, _TMC(" "));

  fIn = openFile(fNameIn, _TMC("r"));
  while (tmfgets(oneLine, MAX_READ, fIn))
  {
    len = tmstrlen(oneLine);
    ptr = oneLine;

    for (i = 0; i < len; i++)
    {
      found = FALSE;
      before[0] = oneLine[i];
      if (oneLine[i] > 127)
      {
        j = findIndex(mapList, before);
        if (j != -1)
        {
          after = (TMCHAR *)mapList->array[j]->ptr;
          oneLine[i] = '\0';
          tmfprintf(&tmBundle, fOut, _TMC("{0}{1}"), ptr, after);
          ptr = &oneLine[i+1];
          found = TRUE;
        }
      }
    }

    if (!found)
      tmfprintf(&tmBundle, fOut, _TMC("{0}"), ptr);
  }
}

/******************************************************************************/
static void cleanupFiles(void)
{
#ifdef SCT_DEBUG
  tmprintf(&tmBundle, _TMC("Executing cleanupFiles\n"));
  tmfflush(tmstdout);
#endif

  if (fMap)
    tmfclose(fMap);
  if (fOut)
    tmfclose(fOut);
  if (fIn)
    tmfclose(fIn);

  if (tmstrcmp(fNameIn, fNameTmp) == SAME)
  { /* if name of the in file is same as out file, then rename the file */
    remove(tmtochar8(fNameIn));
    rename(tmtochar8(fNameOut), tmtochar8(fNameIn));
  }
}

/******************************************************************************/
static UFILE *openFile(TMCHAR *fname, TMCHAR *flag)
{
  UFILE *f;

#ifdef SCT_DEBUG
  tmprintf(&tmBundle, _TMC("Executing openFile\n"));
  tmfflush(tmstdout);
#endif

  f = tmfopen(&tmBundle, fname, flag);
  if (!f)
  {
    if (tmstrcmp(flag, _TMC("w")) == SAME)
      tmprintf(&tmBundle, TM_NLS_Get("0000","%Error% - Unable to create file \"{0}\" for output.\n"), fname);
    else
      tmprintf(&tmBundle, TM_NLS_Get("0001","%Error% - Unable to open file \"{0}\".\n"), fname);

    exit2os(EXIT_FAILURE);
    return NULL;
  }

  return f;
}

/******************************************************************************/
/* List functions *************************************************************/
/******************************************************************************/
static listRec *newList(TMCHAR *text)
{
  listRec *list = (listRec *)malloc(sizeof(listRec));
  list->text = (TMCHAR *)malloc(sizeof(TMCHAR) * tmstrlen(text) + 1);

  tmstrcpy(list->text, text);
  initList(list);
  return list;
}

/******************************************************************************/
static void freeList(listRec *list)
{
  clearList(list);
  free(list->text);
  free(list);
}

/******************************************************************************/
static void initList(listRec *list)
{
  list->head    = NULL;
  list->tail    = NULL;
  list->curNode = NULL;
  list->array   = NULL;
  list->count   = 0;
  list->sorted  = FALSE;
}

/******************************************************************************/
static void indexList(listRec *list)
{
  int i;

  /* free the array of pointers if it is indexed already */
  if (list->array != NULL)
    free(list->array);

  list->array = (nodeRecPtr *)malloc(sizeof(nodeRecPtr *) * (list->count + 1));
  firstNode(list);
  for (i = 0; i < list->count; i++)
  {
    list->array[i] = list->curNode;
    list->curNode->index = i;
    if (list->curNode->child != NULL)
      indexList(list->curNode->child);
    nextNode(list);
  }
}

/******************************************************************************/
int sortHelper(const void *a, const void *b)
{
  return tmstrcmp((*(nodeRecPtr *)a)->text, (*(nodeRecPtr *)b)->text);
}

static void sortList(listRec *list)
{
  int i;

  if (list->array == NULL)
    indexList(list);

  qsort(list->array, list->count, sizeof(nodeRecPtr *), sortHelper);

  for (i = 0; i < list->count; i++)
    list->array[i]->index = i;

  list->sorted = TRUE;
}

/******************************************************************************/
static listRec *addChild(nodeRec *node, TMCHAR *text)
{
  /* only one child list per node is supported */
  if (node->child == NULL)
    node->child = newList(text);

  else
  {
    free(node->child->text);
    node->child->text = (TMCHAR *)malloc(sizeof(TMCHAR) * tmstrlen(text) + 1);
    tmstrcpy(node->child->text, text);
  }

  return node->child;
}

/******************************************************************************/
static nodeRec *addNode(listRec *list, TMCHAR *text)
{
  nodeRec *node  = (nodeRec *)malloc(sizeof(nodeRec));
  node->text = (TMCHAR *)malloc(sizeof(TMCHAR) * tmstrlen(text) + 1);

  tmstrcpy(node->text, text);
  node->ptr   = NULL;
  node->next  = NULL;
  node->child = NULL;
  node->index = 0;

  if (list->head == NULL)
  {
    list->head    = node;
    list->tail    = node;
    list->curNode = node;
  }

  else
  {
    list->tail->next = node;
    list->tail       = node;
  }

  list->count++;

  if (list->array != NULL)
  { /* free the array of pointers if it is indexed already
       list must be manually reindex after an add */
    free(list->array);
    list->array  = NULL;
    list->sorted = FALSE;
  }

  return node;
}

/******************************************************************************/
static nodeRec *addObject(listRec *list, TMCHAR *text, void *ptr, int isOwner)
{
  nodeRec *node = addNode(list, text);
  node->ptr     = ptr;
  node->isOwner = isOwner;

  return node;
}

/******************************************************************************/
static void clearList(listRec *list)
{
  nodeRec *node     = list->head;
  nodeRec *nextNode;

  while (node != NULL)
  {
    nextNode = node->next;

    /* free any object attached to the node if it owned by the list */
    if ((node->ptr != NULL) && (node->isOwner == TRUE))
      free(node->ptr);

    /* clear any child list */
    if (node->child != NULL)
      clearList(node->child);

    /* free string */
    free(node->text);

    /* free the node it-self */
    free(node);
    node = nextNode;
  }

  /* if the list is indexed, free the array of pointers */
  if (list->array != NULL)
    free(list->array);

  initList(list);
}

/******************************************************************************/
static nodeRec *firstNode(listRec *list)
{
  list->curNode = list->head;
  return list->curNode;
}

/******************************************************************************/
static nodeRec *nextNode(listRec *list)
{
  if (list->curNode != NULL)
    list->curNode = list->curNode->next;
  return list->curNode;
}

/******************************************************************************/
int searchHelper(const void *a, const void *b)
{
  return tmstrcmp((TMCHAR *)a, (*(nodeRecPtr *)b)->text);
}

static int findIndex(listRec *list, TMCHAR *text)
{
  void *ptr;

  if (list->sorted == FALSE)
    sortList(list); /* for binary-search to work .. must be sorted */

  ptr = (void *)bsearch((void *)text, list->array, list->count, sizeof(nodeRecPtr *), searchHelper);

  if (ptr != NULL)
    return (*(nodeRecPtr *)ptr)->index;
  else
    return -1;
}

/******************************************************************************/
static nodeRec *findNode(listRec *list, TMCHAR *text)
{ /* uses findIndex() for fast binary-search */
  int i = findIndex(list, text);

  if (i >= 0)
    return list->array[i];
  else
    return NULL;
}
