/* AUDIT TRAIL: 8.0                                                         */
/* TAM 10/08/2007                                                           */
/* 1. Internationalization unicode conversion                               */
/* AUDIT TRAIL END                                                          */
#include "tmcilib.h"
extern "C" void TM_INIT_GLOBS (void);
extern "C" {
	TMInitGlob TM_INIT_VAR (TM_INIT_GLOBS);
}


