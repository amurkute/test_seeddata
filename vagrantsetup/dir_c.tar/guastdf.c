/*TMCI18N BEGIN HEADER*/
#if !defined( tmBundle_EXISTS )
/* No Initialisation Required */                                               
#include "tmcilib.h"
static struct TMBundle tmBundle = {"guastdf.cpp",NULL,NULL,NULL,NULL};
#define tmBundle_EXISTS
#endif
/*TMCI18N END HEADER*/

/* AUDIT_TRAIL_MSGKEY_UPDATE
-- PROJECT : MSGKEY
-- MODULE  : GUASTDF
-- SOURCE  : enUS
-- TARGET  : I18N
-- DATE    : Fri Mar 20 13:22:54 2015
-- MSGSIGN : #1ea9235841898fa5
END AUDIT_TRAIL_MSGKEY_UPDATE */

/* Object: guastdf.c
   Author: John Morgan
 Mod Date: 12/5/94
  Release: General 2.1
*/

/***************************************************/
/*                                                 */
/*       CONFIDENTIAL BUSINESS INFORMATION         */
/*                                                 */
/*      **********************************         */
/*                                                 */
/*  THIS PROGRAM IS PROPRIETARY INFORMATION OF     */
/* SYSTEMS AND COMPUTER TECHNOLOGY CORPORATION     */
/* AND IS NOT TO BE COPIED, REPRODUCED, LENT OR    */
/* DISPOSED OF, NOR USED FOR ANY PURPOSE OTHER     */
/* THAN THAT FOR WHICH IT IS SPECIFICALLY PROVIDED */
/* WITHOUT THE WRITTEN PERMISSION OF SAID COMPANY  */
/*                                                 */
/***************************************************/

/* AUDIT TRAIL: 2.0                                INIT      DATE           */
/*                                                                          */
/* 1. Moved getmem function from guarpfe.c to      GL      09/15/93         */
/*    here, to be available to all Pro*C programs.                          */
/* 2. Repaired a bug in tochar which caused        JWM     01/13/94         */
/*    incorrect behavior when called with a 'B'                             */
/*    format after a zero had been printed.                                 */
/* 3. Changed tonum to ignore leading blanks.      JWM     02/04/94         */
/*                                                                          */
/* AUDIT TRAIL: 2.1                                INIT      DATE           */
/*                                                                          */
/* 1. Changed prtmode for IBM (per AW testing.)    JWM     11/21/94         */
/* 2. Removed fflush(stdin) from input code.       JWM     11/21/94         */
/*    Some places this causes bizarre behavior.                             */
/* 3. Changed message type ERR to ERM since ERR    JWM     11/21/94         */
/*    is a reserved word under DG/AOS.                                      */
/* 4. Explicitly cast return value of memcpy       JWM     11/21/94         */
/*    to a char pointer before calling atol.                                */
/* 5. Cast some pointer arithmetic results to      JWM     12/05/94         */
/*    int to prevent compile warnings.                                      */
/* 6. Fixed tochar bug which caused a blank        JWM     05/04/95         */
/*    to be returned when argument was null.                                */
/*                                                                          */
/* AUDIT TRAIL: 2.1.5                              INIT      DATE           */
/*                                                                          */
/* 1. Security mods - getxnam function added.       JWM    08/15/95         */
/* 2. Removed OS_AOS references; added OS2 and NT.  JWM    08/16/95         */
/*                                                                          */
/* AUDIT TRAIL: 3.0                                INIT      DATE           */
/* 1. Added forward slash to DIRCHARS for OPSYS of                          */
/*    OS_MSDOS, OS_OS2, OS_WINNT                    TAM    05/28/97         */
/*                                                                          */
/* AUDIT TRAIL: 3.1                                INIT      DATE           */
/* 1. Renamed sysdate to lsysdate (l for local).    RLH    02/24/98         */
/*    Incorporate sysdate function into guaorac2.pc                         */
/*    where sysdate will be retrieved from the database.                    */
/*    Moved define of default_date_format to guastdf.h.                     */
/* 2. Corrected comments and expanded length and    RLH    03/02/98         */
/*    value in structure date_frm for seconds since                         */
/*    midnight from 4 SSSS to 5 SSSSS.                                      */
/*                                                                          */
/* AUDIT TRAIL: 5.1                                                         */
/* 1. JWM 03/16/2001                                                        */
/*    Defect 59690 - The DEC C 6.4 compiler is C99 compliant, and has       */
/*    introduced round as a reserved word; replace round with _round and    */
/*    use a macro to translate.                                             */
/*                                                                          */
/* AUDIT TRAIL: 8.0                                                         */
/* TAM 10/08/2007                                                           */
/* 1. Internationalization unicode conversion                               */
/*                                                                          */
/* AUDIT TRAIL: 8.8                                                         */
/* 1. CR-000125282                                                          */
/*    JDC 03/20/2015                                                        */
/*    Ran re-key to ensure G$_NLS calls were properly coded                 */
/* AUDIT TRAIL END                                                          */

/* guastdf.c contains functions of general use in both converted (via SCTCCONV)
   and native Pro*C programs.  The header file guastdf.h should be included
   in a compilation unit which will be linked with guastdf.o.

   Functions in this module are grouped as follows:

     exit functions     - replacement for ANSI atexit fcn
     lsysdate           - emulation of ORACLE sysdate fcn using ANSI time.h
     string functions   - various string related functions
     miscellaneous      - whatever
     math functions     - arithmetic and conversion operations on long
                          numbers represented as strings
     filename functions - fcns to simplify handling various filename
                          formats on different OSs
*/

#define _GUASTDF_C_
#include "guastdf.h"
#undef _GUASTDF_C_

/* include error file a second time (first time in guastdf.h) to get
   actual message table
*/

#include "guaerror.h"

/* macros used by math functions */

#define ADDBASE 100000000L     /* size of each "digit" */
#define MULTBASE 10000L        /* size of each "digit" */
#define ZEROSTR _TMC("+0000000000000000.00000000")
#define COPYARG(t,s) if ( *s ) tmstrcpy(t,s); \
                     else tmmemcpy(t,ZEROSTR,27); \
                     normal(t)

/* maximum number of functions which may be registered with regexit */

#define MAX_EXIT_FCNS 8

/* maximum size of user input string for input function */

#define MAX_INPUT_LEN 80

/* OS specific logic to find proper directory separator characters */

#if   OPSYS==OS_VMS
#define DIRCHARS _TMC(":]")
#elif OPSYS==OS_MSDOS || OPSYS==OS_OS2 || OPSYS==OS_WINNT
#define DIRCHARS _TMC(":\\/")
#elif OPSYS==OS_UNIX
#define DIRCHARS _TMC("/")
#elif OPSYS==OS_VM
#define DIRCHARS _TMC(" .")
#elif OPSYS==OS_MPE
#define DIRCHARS _TMC(".")
#else
#define DIRCHARS _TMC("/")
#endif

/* FPNUM - floating point representation for division */

typedef struct {int len;
                int exp;
                long int num[8];} FPNUM;

/* Prototypes for internal functions */

static void str2fp(FPNUM *outnum,TMCHAR *str);
static int fp2str(TMCHAR *str,FPNUM *innum);
static void multfp(FPNUM *answer,FPNUM *factor1,FPNUM *factor2);
static void normal(TMCHAR *n);

/******************/
/* exit functions */
/******************/

/* regexit and exit2os are replacements for the ANSI fcns atexit and
   exit, made necessary because atexit is not implemented under GNU C
   on Sequent PTX.  Application code should never terminate with the
   exit function; rather, exit via exit2os so that any program
   termination code is executed (e.g., releasing allocated memory,
   logging off ORACLE, etc.)
*/

/* regexit pushes a function pointer of type regexit_t onto a "stack"
   (implemented as an array); regexit_t is defined in guastdf.h, and
   is a pointer to a function of format:

      void function_name(int error_code);

   Up to MAX_EXIT_FCNS may be registered with regexit; additional
   attempts silently fail.
*/

static int regexit_count=0;
static regexit_t regexit_fcn[MAX_EXIT_FCNS];

void regexit(regexit_t fcn)
{
  if ( regexit_count < MAX_EXIT_FCNS )
    regexit_fcn[regexit_count++]=fcn;
}

/* exit2os pops function pointers off the regexit_fcn "stack" and executes
   the functions; EXIT_SUCCESS or EXIT_FAILURE (defined in stdlib.h) should
   be passed to exit2os and from here to called functions.  After all
   registered functions are processed, exit to the OS.
*/

void exit2os(int flag)
{
  for ( ; regexit_count ; regexit_fcn[--regexit_count](flag) );
  exit(flag);
}

/************/
/* lsysdate */
/************/

/* lsysdate takes as arguments a modified ORACLE style date format string and
   a target for the formatted date, and formats the current date into
   the target as requested.  Also returns a pointer to the target.  If
   a NULL pointer is provided for the target, then a pointer to a local
   static variable is returned.  Format elements recognized are:

     DD    - day of the month (1-31)
     MM    - month (1-12)
     MONTH - name of month (padded to 9 chars)
     MON   - 3-char month abbrev
     YYYY  - year with century
     YY    - 2-digit year
     HH24  - hours (24 hour clock)
     HH    - hours (12 hour clock)
     MI    - minutes (0-59)
     SSSSS - seconds since midnight
     SS    - seconds (0-59)
     AM    - am/pm indicator
     PM    - am/pm indicator

   Any characters in the format which are not recognized are passed
   through to the target unchanged.  For alpha format elements,
   (MONTH, MON, AM, PM), the case of the result is determined by the
   case of the format element: e.g., "MON" results in "JUN", "Mon"
   results in "Jun", and "mon" results in "jun".  All numeric elements
   are left padded with zeros.
*/

TMCHAR *lsysdate(TMCHAR *outdate,TMCHAR *format)
{
  time_t system_time;
  struct tm *loc_time;
  TMCHAR orig_format[80],temp_format[80],temp_str[80];
  int i,j,out_char,years,hours;
  long int temp_sec;
  static TMCHAR hold_time[80];

  /* Table of format elements - alpha switch indicates whether element
     is numeric or alpha, len is length of format element, value is
     a pointer to literal of format.  For elements which have initial
     characters in common (YY and YYYY for example), the longer element
     should come first.
  */

  static struct {int alpha;
                 int len;
                 TMCHAR *value;} date_frm[]=
        {{0,2,_TMC("DD")},
         {0,2,_TMC("MM")},
         {1,5,_TMC("MONTH")},
         {1,3,_TMC("MON")},
         {0,4,_TMC("YYYY")},
         {0,2,_TMC("YY")},
         {0,4,_TMC("HH24")},
         {0,2,_TMC("HH")},
         {0,2,_TMC("MI")},
         {0,5,_TMC("SSSSS")},
         {0,2,_TMC("SS")},
         {1,2,_TMC("AM")},
         {1,2,_TMC("PM")},
         {0,0,NULL}};

  static TMCHAR *month[]={TM_NLS_Get("0000","JANUARY  "),
                        TM_NLS_Get("0001","FEBRUARY "),
                        TM_NLS_Get("0002","MARCH    "),
                        TM_NLS_Get("0003","APRIL    "),
                        TM_NLS_Get("0004","MAY      "),
                        TM_NLS_Get("0005","JUNE     "),
                        TM_NLS_Get("0006","JULY     "),
                        TM_NLS_Get("0007","AUGUST   "),
                        TM_NLS_Get("0008","SEPTEMBER"),
                        TM_NLS_Get("0009","OCTOBER  "),
                        TM_NLS_Get("0010","NOVEMBER "),
                        TM_NLS_Get("0011","DECEMBER ")};

  /* if user did not provide an outdate target, use a local one and
     pass a pointer to it back to the user
  */

  if ( !outdate )
    outdate = hold_time;

  /* initialize output to a null string */

  *outdate='\0';

  /* Get current time in a tm structure loc_time */

  system_time = time(NULL);
  loc_time = (struct tm *)localtime(&system_time);

  /* If format argument provided, use it; otherwise default */

  if (format == NULL)
    tmstrcpy(orig_format,DEFAULT_DATE_FORMAT);
  else if (*format == '\0')
    tmstrcpy(orig_format,DEFAULT_DATE_FORMAT);
  else
    tmstrcpy(orig_format,format);

  /* temp_format is uppercase version of provided format */

  str2uc(tmstrcpy(temp_format,orig_format));

  /* Scan format string for recognized format elements and build output */

  i=0;
  out_char=0;
  while(temp_format[i])
    {

      /* If format element is found, j will index it */

      for ( j=0 ; date_frm[j].value ; j++ )

        /* 1st look at 1st char */

        if (temp_format[i] == date_frm[j].value[0] )
          {
            substr(temp_str,temp_format,i,date_frm[j].len);
            if ( !tmstrcmp(temp_str,date_frm[j].value) ) break;
          }

      /* Current char is not part of an element; add it to output */

      if ( ! date_frm[j].value )
        {
          outdate[out_char++]=orig_format[i++];
          outdate[out_char]='\0';
        }

      /* Evaluate a format element */

      else
        { switch (j)
            {
              case  0: /* DD */
                tmsprintf(&tmBundle, temp_str,_TMC("{0,%02d}"),loc_time->tm_mday);
                break;
              case  1: /* MM */
                tmsprintf(&tmBundle, temp_str,_TMC("{0,%02d}"),loc_time->tm_mon+1);
                break;
              case  2: /* MONTH */
                tmstrcpy(temp_str,month[loc_time->tm_mon]);
                break;
              case  3: /* MON */
                tmstrcpy(temp_str,month[loc_time->tm_mon]);
                temp_str[3]='\0';
                break;
              case  4: /* YYYY */
                years=loc_time->tm_year+1900;
                tmsprintf(&tmBundle, temp_str,_TMC("{0,%04d}"),years);
                break;
              case  5: /* YY */
                years=loc_time->tm_year+1900;
                tmsprintf(&tmBundle, temp_str,_TMC("{0,%04d}"),years);
                temp_str[0]=temp_str[2];
                temp_str[1]=temp_str[3];
                temp_str[2]='\0';
                break;
              case  6: /* HH24 */
                tmsprintf(&tmBundle, temp_str,_TMC("{0,%02d}"),loc_time->tm_hour);
                break;
              case  7: /* HH */
                hours=loc_time->tm_hour;
                if (hours > 12) hours-=12;
                tmsprintf(&tmBundle, temp_str,_TMC("{0,%02d}"),hours);
                break;
              case  8: /* MI */
                tmsprintf(&tmBundle, temp_str,_TMC("{0,%02d}"),loc_time->tm_min);
                break;
              case  9: /* SSSSS */
                temp_sec=loc_time->tm_sec+loc_time->tm_min*60;
                temp_sec+=(long int)loc_time->tm_hour*3600;
                tmsprintf(&tmBundle, temp_str,_TMC("{0,%05ld}"),temp_sec);
                break;
              case 10: /* SS */
                tmsprintf(&tmBundle, temp_str,_TMC("{0,%02d}"),loc_time->tm_sec);
                break;
              case 11: /* AM - fall through to PM since same output */
              case 12: /* PM */
                if (loc_time->tm_hour>=12 && loc_time->tm_hour<=23)
                  tmstrcpy(temp_str,_TMC("PM"));
                else
                  tmstrcpy(temp_str,_TMC("AM"));
                break;
            }
          if ( date_frm[j].alpha )
            {
              if (islower(orig_format[i]))
                str2lc(temp_str);
              else if (isupper(orig_format[i]) &&
                       islower(orig_format[i+1]))
                str2lc(&temp_str[1]);
            }
          tmstrcat(outdate,temp_str);
          out_char=tmstrlen(outdate);
          i+=date_frm[j].len;
        }
    }

  return outdate;
}

/********************/
/* string functions */
/********************/

/* str2uc converts each lower case character in str to uppercase, up
   to the terminating NULL, and then returns str.
*/

TMCHAR *str2uc(TMCHAR *str)
{
  TMCHAR *p;

  for ( p=str ; *p ; p++ )
    if (islower(*p))
      *p = toupper(*p);

  return str;
}

/* str2lc converts each upper case character in str to lowercase, up
   to the terminating NULL, and then returns str.
*/

TMCHAR *str2lc(TMCHAR *str)
{
  TMCHAR *p;

  for ( p=str ; *p ; p++ )
    if (isupper(*p))
      *p = tolower(*p);

  return str;
}

/* substr takes len characters, beginning at start, from in_str and places
   them in out_str.  Returns a pointer to out_str.  If there are not
   enough characters in in_str, takes as many as are available.  There is
   no boundary checking, so out_str should be of size at least len+1.
*/

TMCHAR *substr(TMCHAR *out_str,TMCHAR *in_str,int start,int len)
{
  tmstrncpy(out_str,in_str+start,len);
  *(out_str+len)='\0';

  return out_str;
}

/* leftpad left pads target string to specified length with pad_char.
   Returns pointer to target string; target is unmodified if it is already
   >= desired length.  No boundary checking, so str should be of at least
   length len+1.  Also, if strlen(str) > 255 there will be trouble.
*/

TMCHAR *leftpad(TMCHAR *str,int len,TMCHAR pad_char)
{
  int pads;
  static TMCHAR temp_str[256];

  pads=len-tmstrlen(str);
  if ( pads <= 0 )
    return str;

  tmstrcpy(temp_str,str);
  tmmemset(str,pad_char,pads);
  str[pads]='\0';
  tmstrcat(str,temp_str);

  return str;
}

/* rightpad right pads target string to specified length with pad_char.
   Returns pointer to target string; target is unmodified if it is already
   >= desired length.  No boundary checking, so str should be of at least
   length len+1.
*/

TMCHAR *rightpad(TMCHAR *str,int len,TMCHAR pad_char)
{
  int pads,str_len;

  str_len=tmstrlen(str);
  pads=len-str_len;
  if ( pads <= 0 )
    return str;

  tmmemset(str+str_len,pad_char,pads);
  str[len]='\0';

  return str;
}

/* ltrim trims characters in trim_chars from the left of str and returns
   a pointer to str.  If trim_chars is NULL then the set " \t\r\n\v\f"
   (space, tab, carriage return, new line, vertical tab, formfeed - the same
   set used by isspace) is used.  Trouble if the length of the trimmed
   string is greater than 255.
*/

TMCHAR *ltrim(TMCHAR *str,TMCHAR *trim_chars)
{
  int new_len;
  TMCHAR *p,temp[256];

  if (!trim_chars)
    trim_chars=_TMC(" \t\r\n\v\f");

  /* get out now if nothing to trim */

  if ( *str && !tmstrchr(trim_chars,*str) )
    return str;

  /* get to the first non-trim character in str */

  for ( p=str ; *p ; p++ )
    if ( !tmstrchr(trim_chars,*p) )
      break;

  /* get out if str was nothing but trim characters */

  if ( !*p )
    {
      *str='\0';
      return str;
    }

  /* find new length (including terminating null) */

  new_len=tmstrlen(p)+1;

  /* replace str with new version */

  tmmemcpy(temp,p,new_len);
  tmmemcpy(str,temp,new_len);

  return str;
}

/* rtrim trims characters in trim_chars from the right of str and returns
   a pointer to str.  If trim_chars is NULL then the set " \t\r\n\v\f"
   (space, tab, carriage return, new line, vertical tab, formfeed - the same
   set used by isspace) is used.
*/

TMCHAR *rtrim(TMCHAR *str,TMCHAR *trim_chars)
{
  TMCHAR *p;

  if (!trim_chars)
    trim_chars=_TMC(" \t\r\n\v\f");

  /* beginning at end of str, work backwards replacing each trim
     character with a null, until non-trim character or beginning
     of str is reached
  */

  for ( p=str+tmstrlen(str)-1 ; p>=str ; p-- )
    if ( tmstrchr(trim_chars,*p) )
      *p='\0';
    else
      break;

  return str;
}

/* strzip removes leading and trailing whitespace from str, and minimizes
   internal whitespace, replacing each series of space-equivalent
   characters (space, tab, carriage return, new line, vertical tab,
   form feed) with a single blank.  The zipped version of str must be
   less than 256 characters or results are undefined.
*/

TMCHAR *strzip(TMCHAR *str)
{
  TMCHAR *p,*q,*end_str1;

  /* take care of blank strings first */

  rtrim(str,NULL);
  if ( !*str )
    return str;

  /* get rid of leading space */

  ltrim(str,NULL);

  /* the dumb part; it would be more efficient to scan the string once, but
     the code is simpler if all white space is first translated to blanks,
     so take the easy way out and do it.
  */

  for ( p=str ; *p ; p++ )
    if ( tmstrchr(_TMC(" \t\r\n\v\f"),*p) )
      *p = ' ';

  /* now compressing the blanks is easy; look for double blanks and reduce
     the following string of blanks to one
  */

  for ( p=str ; (p=(TMCHAR *)tmstrstr(p,_TMC("  "))) != NULL ; )
    {
      end_str1 = p+1;
      for ( q=end_str1 ; *q == ' ' ; q++ );
      tmstrcpy(end_str1,q);
    }

  return str;
}

/* catstr creates a target string of maximum length maxlen from a variable
   number of input strings; the list of strings is terminated with a NULL
   pointer.  No boundary checking, so target should be at least maxlen+1
   bytes long.  maxlen should be <= 512.
*/

TMCHAR *catstr(TMCHAR *target,int maxlen,...)
{
  va_list ptr;
  static TMCHAR temp[512]; /* this should be large enough for any reasonable */
                         /* operations. */
  TMCHAR *str;

  va_start(ptr,maxlen);

  /* get the first string from list and copy into temp */

  str=va_arg(ptr,TMCHAR *);
  tmstrcpy(temp,str);

  /* concatenate additional strings to temp */

  while ( (str=va_arg(ptr,TMCHAR *)) != NULL )
    tmstrcat(temp,str);

  tmstrncpy(target,temp,maxlen);
  target[maxlen]='\0';

  va_end(ptr);

  return target;
}

/***************************/
/* miscellaneous functions */
/***************************/

/* compare does ORACLE style comparisons (i.e., anything involving a NULL
   is FALSE) between two strings or two NUMSTR numbers (val1 and val2) and
   returns TRUE or FALSE.  Flag indicates the type of comparison to be
   done (see guastdf.h for #defines.)
*/

int compare(TMCHAR *val1,TMCHAR *val2,int flag)
{
  TMCHAR num1[27],num2[27];
  int cval;

  /* if either operand is NULL, done */

  if ( !*val1 || !*val2 )
    return FALSE;

  /* following if..else block populates cval according to usual C rules:

      val1<val2  -1
      val1==val2  0
      val1>val2   1
  */

  if ( flag < EQS )  /* numeric comparison */
    {
      normal(tmstrcpy(num1,val1));
      normal(tmstrcpy(num2,val2));
      if ( *num1 != *num2 ) /* if signs differ magnitude irrelevant */
        cval=(*num1=='+' ? 1 : -1);
      else
        {
          cval=tmstrcmp(&num1[1],&num2[1]);
          if ( *num1 == '-' )
            cval *= -1;
        }
    }
  else /* simple string comparison */
    cval=tmstrcmp(val1,val2);


  /* using appropriate operator (number or string version) and cval
     return answer
  */

  switch( flag < EQS ? flag : flag-6 )
    {
      case EQ : return cval == 0;
      case NE : return cval != 0;
      case LT : return cval < 0;
      case GT : return cval > 0;
      case LE : return cval <= 0;
      case GE : return cval >= 0;
    }

  return FALSE; /* shouldn't get here, but keep the compiler happy */
}

/* inlist accepts a search argument str, a type flag (ALPHA or NUM, see
   guastdf.h) and a set of strings.  If str appears in the set, return TRUE,
   else return FALSE.  The set of strings must be terminated by a NULL
   pointer.
*/

int inlist(TMCHAR *str,int type,...)
{
  va_list ptr;
  int compare_type;
  TMCHAR *value;

  /* determine the correct macro for compare function once before
     entering comparison loop
  */

  if ( type==NUM )
    compare_type=EQ;
  else
    compare_type=EQS;

  /* for each string in list, compare str with it and exit
     if match found */

  va_start(ptr,type);
  while ( (value=va_arg(ptr,TMCHAR *)) != NULL )
    if ( compare(str,value,compare_type) )
      {
        va_end(ptr);
        return TRUE;
      }

  va_end(ptr);

  /* if we got here there was no match */

  return FALSE;
}

/* input is a generic user input routine; takes as arguments a target,
   a prompt string, the size of target (not including terminating null)
   and the datatype of target (ALPHA or NUM, see guastdf.h.)  Warning
   messages are given for long input or, for NUM, bad numbers.
*/

void input(TMCHAR *target,TMCHAR *prompt,int size,int type)
{
  TMCHAR buf[MAX_INPUT_LEN];
  TMCHAR *p;

  /* loop until valid input is given */

  for ( ; ; )
    {
      *buf='\0';  /* initialize to null string */
      tmprintf(&tmBundle, _TMC("{0}"),prompt);
      tmfflush(tmstdout);
      tmfgets(buf,MAX_INPUT_LEN,tmstdin);
      tmprintf(&tmBundle, _TMC("\n"));

      /* fgets includes the newline in the string; get rid of it */

      if ( (p=(TMCHAR *)tmstrchr(buf,'\n')) != NULL )
        *p='\0';

      if ( (int)tmstrlen(buf) > size )
        prtmsg(LONGINP);
      else if ( type==NUM && ! valnum(buf) )
        prtmsg(BADNUMB);
      else
        break;
    }

  tmstrcpy(target,buf);

  return;
}

/* prtmsg is the general messaging routine for both guastdf.c and guarpfe.c,
   and can easily be extended to become the only messaging routine for SCT
   code.  The header file guaerror.h defines the array of structures called
   msg, as well as an enumeration of mnemonic tags for each message;
   functions then call prtmsg with the tag as the first argument, and
   optional additional arguments depending on the particular message.  The
   actual message text defined in guaerror.h is in the format of a printf
   format string, and there should be enough arguments (of the appropriate
   types) passed to prtmsg to match the format elements of the message
   desired.  If the severity of the message is ERM (see error status
   enumeration in guaerror.h) then after printing the message prtmsg calls
   exit2os with EXIT_FAILURE.
*/

void prtmsg(int num,...)
{
  va_list ptr;
  static TMCHAR *msgtype[]={NULL,_TMC("WRN"),_TMC("ERM")}; /* text of message levels */
  static int closing_flag=FALSE;
  static int error_status=MSG;     /* highest severity message printed */
  TMCHAR *fname;

  /* reset static variables (used when a new output file is opened) */

  if ( num == PRGOPEN )
    {
      closing_flag = FALSE;
      error_status = MSG;
      return;
    }

  /* special "switch" so that an exit2os which causes an error does not
     result in recursion
  */

  if ( num == PRGCLOS )
    {
      closing_flag = TRUE;
      return;
    }

  va_start(ptr,num);
  if (msg[num].type > error_status)
    error_status=msg[num].type;

  /* application code may think it is exiting normally; set it straight
     if errors have been received
  */

  if ( num == CMPNORM && error_status > MSG )
    num = error_status==WRN ? CMPWARN : CMPERRO;

  /* only print prefix (message_type-message_code) for warnings and errors */

  if (msg[num].type > MSG)
    tmfprintf(&tmBundle, tmstderr,_TMC("{0}-{1}: "),msgtype[msg[num].type],msg[num].code);

  /* print message text with user arguments */

  tmvfprintf(&tmBundle, tmstderr,msg[num].text,ptr);
  tmfprintf(&tmBundle, tmstderr,_TMC("\n"));

  /* if it is an I/O error, then also use perror to get more information */

  if ( num == IOERROR )
    {
      /* restarting the vararg list to get the filename works so far, but
         could be trouble some places
      */

      va_start(ptr,num);
      fname=va_arg(ptr,TMCHAR *);
      tmperror(fname);
    }
  tmfflush(tmstderr);
  va_end(ptr);

  /* if an ERM message and not in closing mode, get out! */

  if (msg[num].type==ERM && !closing_flag)
    exit2os(EXIT_FAILURE);
}

/* prtmode returns a pointer to a static character string representing the
   proper mode for an fopen for a listing file on the current operating
   system
*/

TMCHAR *prtmode(void)
{
#if OPSYS==OS_VM
  static TMCHAR *print_mode=_TMC("w, recfm=A"); /* IBM carriage control */
#else
  static TMCHAR *print_mode=_TMC("w");
#endif

  return print_mode;
}

/* getmem is called by the macro GETMEM to allocate size bytes of memory,
   and terminate with an error if the malloc fails.  A void pointer to
   the newly allocated block is returned.  Function prototype is in
   guastdf.h
*/

void *getmem(int size)
{
  void *ptr;

  if ( (ptr=(void *)malloc(size)) == NULL )
    prtmsg(NOMEMOR,size);

  return ptr;
}

/******************/
/* Math functions */
/******************/

/* In order to provide near-ORACLE precision in C, it is necessary to
   use other than built-in C datatypes to represent large numbers.
   ORACLE stores all numbers in a floating point format with up to 38
   digits of precision, while the maximum guaranteed precision of
   a C double-precision floating point number is 10 digits.  Code converted
   via SCTCCONV treats all numbers as the character string type NUMSTR,
   a char[27] with 16 digits to the left and 8 digits to the right of
   the decimal point.  Other SCT written code which requires large numbers
   will also be able to use this numeric format.

   The following functions perform various arithmetic and conversion
   operations on NUMSTRs.  When using a NUMSTR with ORACLE, the
   programmer should use TO_NUMBER explicitly; on output, no additional
   code is necessary.
*/

/* addop implements both addition and subtraction; the first three arguments
   should all be char pointers (to NUMSTR variables,) with the first being
   the answer (target) and the next two being the two operands; the last
   argument is the operator, either '+' or '-'.  addop is usually called
   via the macros add and subtract (defined in guastdf.h).  Actual ops are
   performed on long ints, using very basic alogorithms.  Overflow causes
   program termination via a call to prtmsg.
*/

TMCHAR *addop(TMCHAR *answer,TMCHAR *arg1,TMCHAR *arg2,TMCHAR op)
{
  /* each NUMSTR is split into 3 8 digit pieces to perform the math */

  long int oper1_a,oper1_b,oper1_c;
  long int oper2_a,oper2_b,oper2_c;
  int carry,borrow,addflag,compare;
  TMCHAR *oper1_ptr,*oper2_ptr;
  TMCHAR temp[9];
  TMCHAR larg1[27],larg2[27];

  /* use local copies of args, since they may be literals */

  COPYARG(larg1,arg1);
  COPYARG(larg2,arg2);

  /* adjust sign of second argument based on operator */

  if ( op == '-' )
    *larg2 = ( *larg2 == '+' ) ? '-' : '+';

  /* if signs are the same, then op is addition */

  addflag = (*larg1 == *larg2);
  if ( addflag )
    {
      oper1_ptr=larg1;
      oper2_ptr=larg2;
    }

  /* otherwise, op is subtraction */

  else
    {
      /* we want the largest argument first, so assign
         oper1_ptr and oper2_ptr accordingly.           */

      compare=tmstrcmp(&larg1[1],&larg2[1]);

      /* oper1 will contain larger argument for subtraction */

      if ( compare < 0 ) /* first arg is smaller */
        {
          oper1_ptr=larg2;
          oper2_ptr=larg1;
        }
      else if ( compare > 0 ) /* second arg is smaller */
        {
          oper1_ptr=larg1;
          oper2_ptr=larg2;
        }
      else /* magnitudes are equal - result is 0; return answer now */
        {
          tmmemcpy(answer,ZEROSTR,27);
          return answer;
        }
    }

  /* now break each number into 8-digit pieces and convert to long int */

  temp[8]='\0';
  oper1_c=tmatol((TMCHAR *)tmmemcpy(temp,oper1_ptr+1,8));
  oper1_b=tmatol((TMCHAR *)tmmemcpy(temp,oper1_ptr+9,8));
  oper1_a=tmatol((TMCHAR *)tmmemcpy(temp,oper1_ptr+18,8));
  oper2_c=tmatol((TMCHAR *)tmmemcpy(temp,oper2_ptr+1,8));
  oper2_b=tmatol((TMCHAR *)tmmemcpy(temp,oper2_ptr+9,8));
  oper2_a=tmatol((TMCHAR *)tmmemcpy(temp,oper2_ptr+18,8));

  /* do addition */

  if ( addflag )
    {
      oper1_a += oper2_a;
      carry = (oper1_a >= ADDBASE);
      if ( carry )
        {
          oper1_a -= ADDBASE;
          oper1_b++;
        }

      oper1_b += oper2_b;
      carry = (oper1_b >= ADDBASE);
      if ( carry )
        {
          oper1_b -= ADDBASE;
          oper1_c++;
        }

      oper1_c += oper2_c;
      if ( oper1_c >= ADDBASE )
        prtmsg(OVERFLW);
    }

  /* do subtraction */

  else
    {
      oper1_a -= oper2_a;
      borrow = (oper1_a < 0);
      if ( borrow )
        {
          oper1_a += ADDBASE;
          oper1_b--;
        }

      oper1_b -= oper2_b;
      borrow = (oper1_b < 0);
      if ( borrow )
        {
          oper1_b += ADDBASE;
          oper1_c--;
        }

      oper1_c -= oper2_c;
    }

  /* rebuild a NUMSTR style number string */

  /*TMCI18N Manual Fix Make sure to use Ansi formatting, not Localised*/
  tmsprintf(&tmBundleCNum, answer,_TMC("{0,%c}{1,%08ld}{2,%08ld}.{3,%08ld}\0"),
          *oper1_ptr,oper1_c,oper1_b,oper1_a);  
   /*TMCI18N Manual Fix END*/

  return answer;
}

/* multiply takes as arguments a target (and returns a pointer to the target)
   and two operands; all args should be NUMSTR style number strings.
   The operands are converted into 4-digit long integers, and a simple
   arithmetic algorithm is used to compute the product.  Overflow causes
   program termination via a call to the prtmsg function.
*/

TMCHAR *multiply(TMCHAR *answer,TMCHAR *arg1,TMCHAR *arg2)
{
  long int factor1[6],factor2[6],result[12];
  int i,j,len1,len2;
  TMCHAR sign;
  TMCHAR temp_str[24],temp_num[5];
  TMCHAR larg1[27],larg2[27];

  COPYARG(larg1,arg1);
  COPYARG(larg2,arg2);

  /* create integer arrays from arguments - code
     repeated for each argument (instead of a
     function call) in order to speed up processing */

  temp_num[4]='\0';

  /* first, get rid of sign and decimal point */

  tmmemcpy(temp_str,larg1+1,16);
  tmmemcpy(temp_str+16,larg1+18,8);

  /* now, populate the array of integers; when done, len1 will reflect
     the offset of the first non-zero integer in the factor1 array
  */

  len1=6;
  for ( i=5 ; i>=0 ; i-- )
    if ( (factor1[i]=tmatol((TMCHAR *)tmmemcpy(temp_num,temp_str+(i*4),4))) > 0 )
      len1=i;

  /* same as preceeding, but for factor2 */

  tmmemcpy(temp_str,larg2+1,16);
  tmmemcpy(temp_str+16,larg2+18,8);
  len2=6;
  for ( i=5 ; i>=0 ; i-- )
    if ( (factor2[i]=tmatol((TMCHAR *)tmmemcpy(temp_num,temp_str+(i*4),4))) > 0 )
      len2=i;

  /* check for zeros */

  if ( len1 == 6 || len2 == 6 )
    {
      tmmemcpy(answer,ZEROSTR,27);
      return answer;
    }

  /* determine sign of answer */

  sign=(*larg1 == *larg2) ? '+' : '-';

  /* initialize result */

  for ( i=0 ; i<12 ; result[i++]=0 );

  /* using len1 and len2 (so we don't do more multiplications than
     necessary) populate the result array with the products of
     individual multiplications
  */

  for ( i=5 ; i>=len1 ; i--)
    for ( j=5 ; j>=len2 ; j--)
      if ( factor1[i] && factor2[j] )
        result[i+j+1]+=factor1[i]*factor2[j];

  /* result is twice as large as the factors; since the factors represent
     16.8 numbers, result represents 32.16; as we go through looking for
     carries, round up so that we look good to 8 decimal points.  Also,
     if there is anything larger in the result than can be represented
     get out with an overflow.
  */

  for ( i=11 ; i>=len1+len2 ; i--)
    {
      if ( result[i] >= MULTBASE )
        {
          result[i-1]+=result[i]/MULTBASE;
          result[i]%=MULTBASE;
        }
      if ( i>=10 )  /* round per ORACLE: >= 0.5 rounds up */
        if ( result[i] >= MULTBASE/2 )
          result[i-1]++;
    }

  /*TMCI18N Manual Fix Make sure to use Ansi formatting, not Localised*/
  tmsprintf(&tmBundleCNum, answer,_TMC("{0,%c}{1,%04ld}{2,%04ld}{3,%04ld}{4,%04ld}.{5,%04ld}{6,%04ld}\0"),sign,
          result[4],result[5],result[6],result[7],result[8],result[9]);
  /*TMCI18N Manual Fix END*/

  if ( result[0] || result[1] || result[2] || result[3] )
    prtmsg(OVERFLW);

  return answer;
}

/* divide takes as arguments a target (and returns a pointer to the target)
   and two operands; all args should be NUMSTR style number strings.
   This was the most difficult of the basic arithmetic operators to
   implement; the method chosen was to convert the numbers into
   a simple floating point representation, and then use Newton-Raphson
   iterations to approximate the reciprocal of the divisor.  A simple
   multiplication then gives the result.  Overflow or division by zero
   causes program termination via a call to the prtmsg function.
*/

TMCHAR *divide(TMCHAR *answer,TMCHAR *arg1,TMCHAR *arg2)
{
  FPNUM factor1,factor2,current,next,result;
  int i;
  TMCHAR temp_str[60];
  TMCHAR work_str[60];
  long int temp_result[9];
  TMCHAR larg1[27],larg2[27];

  COPYARG(larg1,arg1);
  COPYARG(larg2,arg2);

  /* check for zeros */

  if ( ! tmstrcmp(larg1,ZEROSTR) )
    {
      tmmemcpy(answer,ZEROSTR,27);
      return answer;
    }
  if ( ! tmstrcmp(larg2,ZEROSTR) )
    prtmsg(ZERODIV);

  str2fp(&factor1,larg1);
  str2fp(&factor2,larg2);

  /* find the inverse of factor2 using Newton-Raphson iterations

        x[i+1] = x[i] * (2 - a * x[i])

     where x=1/a.
     We choose an x[0] that is close to the actual x to guarantee
     convergence.                                                 */

  /*TMCI18N Manual Fix Make sure to use Ansi formatting, not Localised*/
  tmsprintf(&tmBundleCNum, work_str,_TMC("{0,number,0.00000000000000000000000000000000}"),1.0/tmatof(&tmBundle, arg2) );
  /*TMCI18N Manual Fix END */
  tmstrcpy(temp_str,*work_str == '-' ? work_str+1 : work_str);
  leftpad(temp_str,49,'0');
  str2fp(&current,temp_str);
  for ( ; ; )
    {
      multfp(&result,&factor2,&current);
      /* exit if result sufficiently close to 1 */
      if ( (result.exp==0 && result.len==0 && result.num[0]==1) ||
           (result.exp==0 && result.len==7 && result.num[6]<500) ||
           (result.exp== -1 && result.len==7 && result.num[6]>9500) )
        {
          next.len=current.len;
          next.exp=current.exp;
          for (i=0 ; i<=current.len ; i++)
            next.num[i] = current.num[i];
          break;
        }

      /* result should now be in the range 0<result<2
         and exp either 0 or -1; find 2-result        */

      if ( result.exp == 0 ) /* result is > 1 */
        {
          for ( i=1 ; i<result.len ; i++ )
            result.num[i-1]=MULTBASE-1-result.num[i];
          result.num[result.len-1]=MULTBASE-result.num[result.len];
          result.len--;
          result.exp = -1;
        }
      else   /* result is < 1; answer will be 1.x, so truncate */
        {
          temp_result[result.len+1]=MULTBASE-result.num[result.len];
          for ( i=result.len-1 ; i>=0 ; i-- )
            temp_result[i+1]=MULTBASE-1-result.num[i];
          result.len++;
          if ( result.len == 8 )
            result.len=7;
          for ( i=0 ; i<=result.len ; i++ )
            result.num[i]=temp_result[i];
          *result.num=1;
          result.exp=0;
        }

      multfp(&next,&current,&result);

      current.len=next.len;
      current.exp=next.exp;
      for ( i=0 ; i<=next.len ; i++)
        current.num[i]=next.num[i];
    }

  /* next is now a good approximation of 1/factor2,
     so find our real answer
  */

  multfp(&result,&factor1,&next);

  if ( ! fp2str(answer,&result) )
    prtmsg(OVERFLW);

  /* derive sign of answer from original args */

  *answer=(*larg1 == *larg2) ? '+' : '-';

  return answer;
}

/* str2fp takes the argument str (either a normalized NUMSTR or a
   temporary 16.32 number (used for division processing) and converts
   it into a FPNUM (the target argument).  In this FPNUM, each "digit"
   is base 10000, and a length (number of digits) and exponent (location
   of decimal point) is also included.
*/

static void str2fp(FPNUM *outnum,TMCHAR *str)
{
  TMCHAR temp_num[5];
  TMCHAR temp_str[48];
  int i,maxndx,first,ndx;
  long int tnum;

  temp_num[4]='\0';

  if ( tmstrlen(str) == 26 && str[17] == '.' ) /* number is normalized */
    {
      tmmemcpy(temp_str,str+1,16);
      tmmemcpy(temp_str+16,str+18,8);
      maxndx=5;
    }
  else  /* temporary long number (16.32) */
    {
      tmmemcpy(temp_str,str,16);
      tmmemcpy(temp_str+16,str+17,32);
      maxndx=11;
    }

  /* initialize output */

  for ( i=0 ; i<8 ; outnum->num[i++]=0 );

  /* build floating point structure - behavior undefined if not a
     normalized NUMSTR or temporary long number from divide
  */

  first = -1;
  ndx = 0;
  for (i=0 ; i<=maxndx ; i++)
    {
      if ( ndx > 7 )
        break;
      tnum=tmatol((TMCHAR *)tmmemcpy(temp_num,temp_str+(i*4),4));
      if ( first < 0 )
        {
          if ( tnum )
            {
              first=i;
              outnum->num[ndx++]=tnum;
            }
        }
      else
        outnum->num[ndx++]=tnum;
    }

  for (i=ndx-1 ; i>0 ; i--)
    if ( outnum->num[i] )
      break;

  outnum->exp = 3-first;
  outnum->len = i;
}

/* fp2str is the reverse of the previous routine; it takes a target string
   argument str (and returns a pointer to str) and a pointer to a floating
   point FPNUM called innum.  If innum can be represented in NUMSTR format,
   fp2str will populate str and return TRUE; otherwise it returns FALSE.
*/

static int fp2str(TMCHAR *str,FPNUM *innum)
{
  long int temp_num[7];
  int i,pos;

  /* initialize output */

  tmmemcpy(str,ZEROSTR,27);

  /* exp>3 would mean more than 4 base 10000 digits present in innum;
     too big for NUMSTR */

  if ( innum->exp > 3 )
    return FALSE;

  /* exp<-2 indicates answer is effectively zero */

  if ( innum->exp < -2 )
    return TRUE;

  /* initialize integer array */

  for ( i=0 ; i<7 ; temp_num[i++]=0 );

  /* populate integer array */

  for ( i=0 ; i<=innum->len ; i++ )
    {
      if ( (pos=3-innum->exp+i) > 6 )
        break;
      temp_num[pos]=innum->num[i];
    }

  /* round if necessary */

  if ( temp_num[6] >= MULTBASE/2 )
    {
      temp_num[5]++;
      for ( i=5 ; i>0 ; i--)
        {
          if ( temp_num[i] >= MULTBASE )
            {
              temp_num[i-1]+=temp_num[i]/MULTBASE;
              temp_num[i]%=MULTBASE;
            }
          else
            break;
        }
      if ( *temp_num >= MULTBASE )
        return FALSE;
    }

  /* create a NUMSTR and return */
  /*TMCI18N Manual Fix Make sure to use Ansi formatting, not Localised*/
  tmsprintf(&tmBundleCNum, str,_TMC("+{0,%04ld}{1,%04ld}{2,%04ld}{3,%04ld}.{4,%04ld}{5,%04ld}\0"),
          temp_num[0],temp_num[1],temp_num[2],
          temp_num[3],temp_num[4],temp_num[5]);
  /*TMCI18N Manual Fix END*/

  return TRUE;
}

/* multfp is used by divide to multiply FPNUM style floating point
   numbers; it takes three FPNUM pointer arguments (answer and two
   factors) and returns a pointer to answer.
*/

static void multfp(FPNUM *answer,FPNUM *factor1,FPNUM *factor2)
{
  long int result[10];
  int i,j,k,offset;

  /* initialize result */

  for ( i=0 ; i<10 ; result[i++]=0 );

  /* build the result array with products of individual multiplications */

  for ( i=0 ; i<=factor1->len ; i++)
    for ( j=0 ; j<=factor2->len ; j++)
      {
        k=i+j+1;
        if ( k<10 && factor1->num[i] && factor2->num[j] )
          result[k]+=factor1->num[i]*factor2->num[j];
      }

  /* round if necessary */

  if ( result[9] >= MULTBASE/2 )
    result[8]++;

  /* take care of any carries */

  for ( i=8 ; i>0 ; i--)
    if ( result[i] >= MULTBASE )
      {
        result[i-1]+=result[i]/MULTBASE;
        result[i]%=MULTBASE;
      }

  /* determine exponent of answer depending on whether high order digit
     of result is non-zero */

  if ( *result )
    {
      answer->exp=factor1->exp+factor2->exp+1;
      offset=0;
    }
  else
    {
      answer->exp=factor1->exp+factor2->exp;
      offset=1;
    }

  /* build answer from result */

  for (i=0 ; i<8 ; i++)
    {
      answer->num[i]=result[i+offset];
      if ( answer->num[i] )
        answer->len=i;
    }
}

/* normal takes as an argument a char pointer (innum) containing a numeric
   string and formats it as a NUMSTR:

       000000000011111111112222222
       012345678901234567890123456

       sdddddddddddddddd.dddddddd0

   where s is either '+' or '-', each d represents a digit (including
   non-significant 0s), '.' is the decimal point, and '0' is the
   terminating null.
*/

static void normal(TMCHAR *innum)
{
  int i,dec_pos,pos,first_digit;
  TMCHAR worknum[27];

  /* If number string is null return */

  if (!*innum )
    return;

  /* If number string is already formatted return */

  if ((*innum == '-' || *innum == '+') &&
      innum[17] == '.' && tmstrlen(innum) == 26) return;

  /* make a valid number string out of the input string */

  tonum(worknum,innum);

  /* now normalize back into innum */

  tmmemcpy(innum,ZEROSTR,27);

  /* get the sign if there is one */

  if (*worknum == '-' || *worknum == '+')
    {
      first_digit=1;
      *innum = *worknum;
    }
  else
    first_digit=0;

  /* now move the actual digits into innum */

  dec_pos=0;
  while (worknum[dec_pos] != '.' && worknum[dec_pos] )
    dec_pos++;
  i=dec_pos-1;
  pos=16;
  while ( i >= first_digit )
    innum[pos--]=worknum[i--];
  if (worknum[dec_pos] == '.')
    {
      i=dec_pos+1;
      pos=18;
      while (worknum[i])
        innum[pos++] = worknum[i++];
    }
}

/* round takes three arguments; a char pointer target (also returned),
   a char pointer source, and the number of decimal places after the
   decimal point to round to.  target should be a NUMSTR (char[27]).
   Valid values for decplaces (decimal places) range from 0 to 8, anything
   else causes an error.
*/

TMCHAR *_round(TMCHAR *target,TMCHAR *source,int decplaces)
{
  static TMCHAR *round_vals[]=
         {_TMC("+0000000000000001.00000000"),
          _TMC("+0000000000000000.10000000"),
          _TMC("+0000000000000000.01000000"),
          _TMC("+0000000000000000.00100000"),
          _TMC("+0000000000000000.00010000"),
          _TMC("+0000000000000000.00001000"),
          _TMC("+0000000000000000.00000100"),
          _TMC("+0000000000000000.00000010")};

  /* validate decplaces - let 8 through, but just don't do anything
     with it */

  if ( decplaces < 0 || decplaces > 8 )
    prtmsg(BADDECN,decplaces);

  /* if source is a null string we're done */

  if ( ! *source )
    {
      *target='\0';
      return target;
    }

  if ( source != target )
    tmstrcpy(target,source);
  normal(target);

  if ( decplaces == 8 )
    return target;

  /* now round if necessary */

  if ( target[decplaces+18] >= '5' )
    {
      if ( *target == '+' )
        add(target,target,round_vals[decplaces]);
      else
        subtract(target,target,round_vals[decplaces]);
    }

  /* zero out now insignificant digits */

  tmmemset(&target[decplaces+18],'0',8-decplaces);

  return target;
}

/* valnum takes a single character pointer argument, p, and returns
   TRUE if it is a valid number, FALSE otherwise.  Valid in this
   context implies the ability to be held in a NUMSTR variable.
*/

int valnum(TMCHAR *p)
{
  int nl,nr;

  nl=0;
  nr=0;

  if ( ! *p )
    return TRUE;  /* NULLs are valid numbers */

  /* check for signs */

  if ( *p == '+' || *p == '-' )
    p++;

  /* add up digits to left of decimal point */

  while (isdigit(*p))
    {
      nl++;
      p++;
    }

  /* now look for optional decimal point and digits to right of
     decimal point */

  if ( *p == '.' )
    {
      p++;
      while (isdigit(*p))
        {
          nr++;
          p++;
        }
    }

  /* if number is valid, p should be pointing to terminating null */

  if ( *p || nl > 16 || nr > 8 || nl+nr == 0 )
    return FALSE;

  return TRUE;
}

/* tonum takes two arguments; a char pointer to a target (num) which should
   be of type NUMSTR and is also returned, and a char pointer str.  As much
   of string as possible is interpreted as a number and moved to num; the
   first character which is invalid for a number brings the conversion to
   a halt.
*/

TMCHAR *tonum(TMCHAR *num,TMCHAR *str)
{
  int digits;
  TMCHAR *p;

  /* handle nulls */

  if ( !*str )
    {
      *num='\0';
      return num;
    }

  /* skip leading white space */

  for ( ; *str == ' ' ; str++ );

  /* get sign if any */

  p=num;
  if ( *str=='+' || *str=='-' )
    *(p++) = *(str++);

  /* get up to 16 digits to left of decimal point */

  digits=0;
  while(isdigit(*str))
    {
      digits++;
      *(p++) = *(str++);
      if ( digits==16 )
        break;
    }

  if ( digits==0 )
    *(p++)='0';

  /* get decimal point if present; otherwise done */

  if ( *str=='.' )
    *(p++) = *(str++);
  else
    {
      *p='\0';
      return num;
    }

  /* get up to 8 digits to right of decimal point */

  digits=0;
  while(isdigit(*str))
    {
      digits++;
      *(p++) = *(str++);
      if ( digits==8 )
        break;
    }

  if ( digits==0 )
    *(p++)='0';

  *p='\0';

  return num;
}

/* tochar converts the contents of the char pointer value into the target
   out_str (also returned), using the char pointer format to determine
   the appearance of the resulting string.  Virtually any format element
   recognized by ORACLE's RPT program is handled.
*/
/*
TMCI18N. Format result according to current locale.
Currently deals with grouping, decimal and currency.
May need to implement +-0 (see ICU)
Assume value is formatted according to US rules.
*/
TMCHAR *tochar(TMCHAR *out_str,TMCHAR *value,TMCHAR *format)
{
  int blank_flag=FALSE,currency_flag=FALSE;
  int deficit_flag=FALSE,hide_dec=FALSE;
  int i,digits,out_len,dec_places;
  TMCHAR work_format[40],temp_format[9];
  TMCHAR *dec_pos,*f,*p,*zero_pad;
  TMCHAR work_value[27];
  TMCHAR *currency_symbol=_TMC("$");

  *out_str = '\0';

  if ( ! *value )
    return out_str;

  tmstrcpy(out_str,_TMC(" "));

  str2uc(tmstrcpy(work_format,format));
  f=work_format;

  /* first deal with 'L' (length) formats - used for conversion from
     numeric string to character string, specifies the maximum length
     of the converted string.                                         */
  /* TMCI18N L format becomes LX format */

  if ( *f=='L' && *(f+1)=='X')
    {
	  f++; // skip 'X'
      out_len=tmatoi(++f);

      p=work_value;
      if ( *value=='-' || *value=='+' )
        {
          if ( *value=='-' )
            *(p++)='-';
          value++;
        }

      while ( *value=='0' ) value++;
      digits=0;
      while ( isdigit(*value) )
        {
          digits++;
          *(p++) = *(value++);
        }
      if ( digits==0 )
        *(p++)='0';
      if ( *value == '.' )
        {
          //*(p++) = *(value++);
          *(p++) = tmBundle.numDecSep[0];
		  value++;
          while ( isdigit(*value) )
            *(p++) = *(value++);
          p--;
          while ( *p=='0' ) p--;
          if ( isdigit(*p) ) p++;
        }
      *p='\0';
      substr(out_str,work_value,0,out_len);

      return out_str;
    }

  /* only allowable leading elements ( prior to 9 or 0 )
     are 'B' and '$'; strip them off and set appropriate flags  */

  for ( ; *f=='B' || *f=='$' || *f=='L' ; f++ )
    if ( *f=='B' )
       blank_flag=TRUE;
    else
	{ 
       currency_flag=TRUE;
	   if (*f=='L')
		   currency_symbol=tmBundle.currencySymbol;
	}
  /* only allowable trailing switch is 'PR'; strip it off if present */

  if ( (p = (TMCHAR *)tmstrstr(f,_TMC("PR"))) != NULL )
    {
      *p='\0';
      deficit_flag=TRUE;
    }

  /* find decimal position, and if marked by 'V' set hide_decimal
     flag; also, set zero_pad to position at which to start zero
     padding     */

  if ( ! ((dec_pos=tmstrchr(f,'.') )||(dec_pos=tmstrchr(f,'D') )) )
    {
      zero_pad = &f[tmstrlen(f)];
      dec_pos=tmstrchr(f,'V');
      if ( dec_pos )
        hide_dec=TRUE;
    }
  else
    zero_pad=dec_pos+1;

  /* calculate number of decimal places and round if necessary */

  if ( dec_pos )
    dec_places=tmstrlen(f)-((int)(dec_pos-f))-1;
  else
    dec_places=0;
  round(work_value,value,dec_places);

  /* exit with a blank if rounded value is zero and blank flag is on */

  if ( blank_flag )
    if ( ! tmstrcmp(work_value,ZEROSTR) )
      return out_str;

  /* If no decimal point, set dec_pos to closing null of format */

  if ( ! dec_pos )
    dec_pos = &f[tmstrlen(f)];

  /* Fill f with digits to left of decimal position */

  i=16;
  p=dec_pos-1;
  while ( p>=f )
    switch (*p)
      {
		case 'G' : *(p--)=tmBundle.numGrpSep[0]; break;
        case '0' : zero_pad=p;
        case '9' : *p=work_value[i--];
        default  : 	p--;
      }

  /* check for overflow of the format and return if found */

  for ( ; i ; i-- )
    if ( work_value[i] != '0' )
      {
        for ( p=f ; *p ; p++ )
          if ( tmstrchr(_TMC("1234567890"),*p) ) *p='#';
        if ( currency_flag )
          tmstrcat(out_str,currency_symbol);
        tmstrcat(out_str,f);
        return out_str;
      }

  /* fill f with digits to right of decimal */

  if ( dec_places )
    {
      i=18;
	  if ( *dec_pos == 'D' )
		  *dec_pos=tmBundle.numDecSep[0];
      p=dec_pos+1;
      while ( *p )
        switch (*p)
          {
            case '0' : if ( p < zero_pad )
                         zero_pad=p;
            case '9' : *p=work_value[i++];
                       p++;
          }
    }

  /* remove leading zeros up to zero_pad */

  for ( p=f ; *p && p<zero_pad ; p++ )
    if ( tmstrchr(_TMC("123456789"),*p) )
      break;
    else if ( *p == '0' || *p == ',' || *p ==tmBundle.numGrpSep[0] )
      *p = ' ';

  /* remove the 'V' if present */

  if ( hide_dec )
    {
      *dec_pos='\0';
      tmstrcpy(temp_format,dec_pos+1);
      tmstrcat(f,temp_format);
    }

  while ( *f==' ' ) f++;  /* ltrim the blanks */

  /* last blank check - if blank flag is on and only <0.,> characters
     left in f, then exit now */

  if ( blank_flag )
    {
      for ( p=f ; *p ; p++ )
        if ( tmstrchr(_TMC("123456789"),*p) )
          break;
      if ( !*p )
        return(out_str);
    }

  /* now put in sign or deficit indicator and optional dollar sign */

  if ( *work_value == '-' )
    {
      if ( deficit_flag )
        tmstrcpy(out_str,_TMC("<"));
      else
        tmstrcpy(out_str,_TMC("-"));
    }
  if ( currency_flag )
    tmstrcat(out_str,currency_symbol);
  tmstrcat(out_str,f);
  if ( deficit_flag && *work_value == '-' )
    tmstrcat(out_str,_TMC(">"));

  return out_str;
}

/**********************/
/* filename functions */
/**********************/

/* parsfn takes as an argument a pointer to a FNSTRUC filename descriptor
   structure.  The filename portion of this structure should be populated
   before calling.  Using appropriate logic for the current OS, filename
   will be broken down into directory, name, extension, and version.
*/

void parsfn(FNSTRUC *f)
{
  int i;
  TMCHAR temp[80],*p;

  /* Do IBM and MPE first, since they are different from all others.
     Under VM file names are of format

        fn ft mode

     where fn is filename, ft is filetype (extension equivalent) and
     mode is the logical disk drive (directory equivalent.)  However,
     when inputting filename arguments from the user, I followed ORACLE's
     lead and require periods to separate the various pieces.

     Under HP/MPE file names are of format

        fn.group.acct

     where fn is the filename, group is equivalent to extension, and
     acct is equivalent to directory.
  */

#if OPSYS==OS_VM || OPSYS==OS_MPE

  tmstrcpy(temp,f->fname);
  p=tmstrtok(temp,DIRCHARS);
  if ( p )
    {
      tmstrcpy(f->name,p);
      p=tmstrtok(NULL,DIRCHARS);
      if ( p )
        {
          tmstrcpy(f->ext,p);
          p=tmstrtok(NULL,DIRCHARS);
          if ( p )
            tmstrcpy(f->dir,p);
        }
    }

#else

  /* find directory spec if present - temp
     will contain remainder of name */

  for ( i=tmstrlen(f->fname)-1 ;
        i>=0 && !tmstrchr(DIRCHARS,f->fname[i]) ; i-- );
  if ( i >= 0 )
    {
      tmstrncpy(f->dir,f->fname,++i);
      f->dir[i]='\0';
      tmstrcpy(temp,f->fname+i);
    }
  else
    {
      *f->dir = '\0';
      tmstrcpy(temp,f->fname);
    }

  /* if on a VAX, extract the version if present - temp will
     now contain filename and extension   */

  *f->vers = '\0';
#if OPSYS==OS_VMS
  if ( (p=tmstrchr(temp,';')) != NULL )
    {
      tmstrcpy(f->vers,p+1);
      *p='\0';
    }
#endif

  /* now look for an extension if present and finish up */

  if ( ! (p=tmstrchr(temp,'.')) )
    *f->ext = '\0';
  else
    {
      tmstrcpy(f->ext,p+1);
      *p='\0';
    }
  tmstrcpy(f->name,temp);

#endif
}

/* makefn takes as an argument a pointer to an FNSTRUC file descriptor
   structure, and reverses the process of parsfn; directory, name, extension,
   and version and reconstituted into a valid full filename for the current
   OS.
*/

void makefn(FNSTRUC *f)
{
#if OPSYS==OS_MPE

  tmstrcpy(f->fname,f->name);
  if ( *f->ext )
    {
      tmstrcat(f->fname,_TMC("."));
      tmstrcat(f->fname,f->ext);
      if ( *f->dir )
        {
          tmstrcat(f->fname,_TMC("."));
          tmstrcat(f->fname,f->dir);
        }
    }

#elif OPSYS==OS_VM

  tmstrcpy(f->fname,f->name);
  if ( *f->ext )
    {
      tmstrcat(f->fname,_TMC(" "));
      tmstrcat(f->fname,f->ext);
      if ( *f->dir )
        {
          tmstrcat(f->fname,_TMC(" "));
          tmstrcat(f->fname,f->dir);
        }
    }

#else

  tmstrcpy(f->fname,f->dir);
  tmstrcat(f->fname,f->name);

#if OPSYS==OS_VMS
  tmstrcat(f->fname,_TMC("."));
  tmstrcat(f->fname,f->ext);
  if ( *f->vers )
    {
      tmstrcat(f->fname,_TMC(";"));
      tmstrcat(f->fname,f->vers);
    }
#else
  if ( *f->ext )
    {
      tmstrcat(f->fname,_TMC("."));
      tmstrcat(f->fname,f->ext);
    }
#endif

#endif
}

/* initfn takes a pointer to an FNSTRUC structure as an argument and
   initializes all elements to null strings.
*/

void initfn(FNSTRUC *f)
{
  *f->fname='\0';
  *f->dir='\0';
  *f->name='\0';
  *f->ext='\0';
  *f->vers='\0';
}

/* getxnam takes a pointer to a character as an argument (usually argv[0])
   and fills the global structure exefile with the decomposed file name
   of the currently executing program
*/

void getxnam(TMCHAR *p)
{
  tmstrcpy(exefile.fname,p);
  parsfn(&exefile);
}


