/*TMCI18N BEGIN HEADER*/
#if !defined( tmBundle_EXISTS )
/* No Initialisation Required */                                               
#include "tmcilib.h"
static struct TMBundle tmBundle = {"guarpfe.c",NULL,NULL,NULL,NULL};
#define tmBundle_EXISTS
#endif
/*TMCI18N END HEADER*/

/* AUDIT_TRAIL_MSGKEY_UPDATE
-- PROJECT : MSGKEY
-- MODULE  : GUARPFE
-- SOURCE  : enUS
-- TARGET  : I18N
-- DATE    : Fri Jan 09 08:49:42 2015
-- MSGSIGN : #e30a9db42569573d
END AUDIT_TRAIL_MSGKEY_UPDATE */

/* Object: guarpfe.c
   Author: John Morgan
 Mod Date: 6/17/94
  Release: General 2.1
*/

/*****************************************************************************/
/*                                                                           */
/* Copyright 1994 - 2015 ellucian. All rights reserved.                      */
/*                                                                           */
/*****************************************************************************/

/* AUDIT TRAIL: 2.0                                INIT      DATE           */
/*                                                                          */
/* 1. Fix problem with prtstr function.            SRS     07/21/93         */
/* 2. Fixed the fix to the prtstr function.        JWM     07/30/93         */
/* 3. Changed report function to return TRUE       SRS     09/02/93         */
/*    or FALSE                                                              */
/* 4. Moved GETMEM macro from here to guastdf.h;   GL      09/15/93         */
/*    moved getmem function from here to guastdf.c,                         */
/*    to make them available to all Pro*C routines,                         */
/*    both converted and native.                                            */
/* 5. Replaced all occurrences of function free    GL      09/22/93         */
/*    with macro FREEMEM.  Macro will allow for                             */
/*    any future changes to how memory is freed                             */
/*    across multiple platforms, systems.                                   */
/* 6. Fixed storage bug in get_rpf_word that       JWM     03/04/94         */
/*    appeared on Alpha machines; made cur_word                             */
/*    static.                                                               */
/* 7. Changed rptopen to _rptopen so that macro    JWM     03/04/94         */
/*    from guarpfe.h can do cast on argv for IBM.                           */
/*                                                                          */
/* AUDIT TRAIL: 2.0.2                              INIT      DATE           */
/*                                                                          */
/* 1. Fixed newpage behavior when centering is     JWM     06/17/94         */
/*    on and in last column - change made to                                */
/*    setmode function.                                                     */
/*                                                                          */
/* AUDIT TRAIL: 2.1                                INIT      DATE           */
/*                                                                          */
/* 1. Force column flush in setmode function       JWM     04/25/94         */
/*    when centering is turned on.                                          */
/*                                                                          */
/* AUDIT TRAIL: 2.1.5                              INIT      DATE           */
/*                                                                          */
/* 1. Security mods - exefile processing now done   JWM    08/15/95         */
/*    with getxnam.                                                         */
/* 2. Added chkcflag and setcflag functions to      JWM    08/16/95         */
/*    query/change the command-line flags.                                  */
/* 3. T_DEFINE2 support added to table function     JWM    08/16/95         */
/*    to allow table definition calls from guaprpf.                         */
/*                                                                          */
/* AUDIT TRAIL: 5.4.0.1                                                     */
/*                                              HCHENG     02/12/2002       */
/* 1. Modified 'table' function name to '_table' for Tru64 Unix only.       */
/*                                                                          */
/* AUDIT TRAIL: 8.0                                                         */
/* TAM 10/08/2007                                                           */
/* 1. Internationalization unicode conversion                               */
/*                                                                          */
/* AUDIT TRAIL: 8.7.3                                                       */
/* DJD 01/6/2014                                                            */
/* Defect 1-2D5A72                                                          */
/* 1. Modified function rptopen to handle the -y argument containing        */
/*    the location of the credential file and copy the user id and          */
/*    password from there into userpass                                     */
/* AUDIT TRAIL END                                                          */

/* guarpfe.c contains functions used by converted (via SCTCCONV) Pro*C
   programs, primarily to emulate RPF functionality, but also to do
   other tasks which are common to all converted programs.  The header
   file guarpfe.h should be included in any compilation unit which will
   be linked with guarpfe.o.

   Functions in this module are grouped as follows:

     RPF emulation functions - external visibility
     RPT support functions - external visibility
     table manipulation functions
     word handling functions
     output/line handling functions
     miscellaneous functions

   The data structures/functions in guarpfe attempt to emulate the
   behavior of the RPF product from ORACLE.  RPF is a table/column
   oriented text processor.  The basic element is the table, which
   contains one or more columns.  A table is "begun" or invoked from
   within a column in another table.  A default table with one column
   256 characters in length exists at startup, and the first user
   table invoked is then contained in the default column.  Within
   a single column, more text may be added than will fit; this text
   is justified according to the current justification setting and
   carried over to the next line.  Various other features such as
   underlining, centering, etc. are also supported.
*/

#include "guarpfe.h"

/* global variables with external visibility */

short int sqltrace_flag=FALSE,trace_flag=FALSE;

/* Flag variables for the various command-line parameters; calls to chkcflag
   can be used to query the current settings, and calls to setcflag can
   be used to set them to new values.
*/

static short int uc_flag=FALSE,
                 eject_flag=FALSE,
                 ff_flag=FALSE,
                 reverse_flag=FALSE,
                 rpf_flag=FALSE;

/* shorthand macros to simplify access to complex data structures */

#define CUR_COL cur_table->cur_col

#define CUR_LINE CUR_COL->cur_line

/* functional macros to shorten/simplify source code */

#define CHECK_LITERAL(s) if ( literal_flag || \
                             (cur_table && CUR_COL->literal_flag )) \
                           prtmsg(NONLITC,s)

#define CHECKIO if (tmferror(ofile)) prtmsg(IOERROR,outfile.fname);

/**********************************************/
/* typedefs for RPF emulation data structures */
/**********************************************/

/* TOKEN:  offset - integer offset into line
           text   - text of token
           uline  - underline string for token (NULL if no underline)
           next   - next token in list
*/

typedef struct token_struct
        {int offset;
         TMCHAR *text;
         TMCHAR *uline;
         struct token_struct *next;} TOKEN;

/* LINE:  lineno      - line number of this line
          first_token - head of token list
          last_token  - tail of token list
          line_used   - flag to indicate if line ever had tokens in it
          next        - next line in list
*/

typedef struct line_struct
        {long int lineno;
         TOKEN *first_token;
         TOKEN *last_token;
         short int line_used;
         struct line_struct *next;} LINE;

/* WORD:  str         - text of word
          len         - strlen(word)
          pad         - # of blanks after word
          ul_flag     - TRUE if word is underlined
          ul_pad_flag - TRUE if blanks after word underlined
          prev        - previous word in list
          next        - next word in list
*/

typedef struct word_struct
        {TMCHAR *str;
         int len;
         int pad;
         short int ul_flag;
         short int ul_pad_flag;
         struct word_struct *prev;
         struct word_struct *next;} WORD;

/* COL_DEF:  start - offset in current table for column (starts at 0)
             len   - length of column (can be 0 for remainder of table)
             next  - next column definition in list
*/

typedef struct col_def_struct
        {int start;
         int len;
         struct col_def_struct *next;} COL_DEF;

/* COLUMN:  start         - offset on line for column
            len           - length of column
            cur_line      - pointer to current line
            right_justify - TRUE if right-justification turned on
            justify_flag  - J_RIGHT, J_LEFT, or J_FULL
            center_flag   - TRUE if centering turned on for column
            uline_flag    - TRUE if underlining turned on for column
            literal_flag  - TRUE if column in literal mode
            concat_flag   - TRUE if concatenation turned on for next word
            last_col      - TRUE if last column in line
            next          - next column in list
*/

typedef struct column_struct
        {int start;
         int len;
         LINE *cur_line;
         short int right_justify;
         short int justify_flag;
         short int center_flag;
         short int uline_flag;
         short int literal_flag;
         short int concat_flag;
         short int last_col;
         struct column_struct *next;} COLUMN;

/* TABLE:  start       - offset of table in containing column
           len         - total length of all columns in table
           first_col   - point to top of column list
           cur_col     - currently active column in table
           first_line  - head of line list
           last_line   - tail of line list
           last_lineno - max line number used by table
           last_table  - TRUE if table contained in last column of line
           prev        - previous table on table stack
*/

typedef struct table_struct
        {int start;
         int len;
         COLUMN *first_col;
         COLUMN *cur_col;
         LINE *first_line;
         LINE *last_line;
         long int last_lineno;
         short int last_table;
         struct table_struct *prev;} TABLE;

/**********************************/
/* prototypes for local functions */
/**********************************/

/* table manipulation functions */

static void push_table(int tab);
static void pop_table(void);
static void free_table_def(int tab);
static void add_col(int start,int len);

/* word handling functions */

static TMCHAR *get_rpf_word(TMCHAR *buffer,int *len,int *pad);
static void add_word(TMCHAR *word,int len,int pad);
static void push_word(WORD *w);
static void pop_word(void);
static void push_token(TMCHAR *text,TMCHAR *uline);

/* output/line handling functions */

static void print_pending(LINE *cur_line);
static void print_line(void);
static void addtext(TMCHAR *buffer,TMCHAR *text,int start,int *pos);
static void output_text(TMCHAR *str1,TMCHAR *str2);
static void start_page(void);
static void end_page(void);
static void print_text(TMCHAR *format,...);

/* miscellaneous functions */

static void cmdhelp(void);
static LINE *get_next_line(LINE *l);
static void literal_prep(void);
static void build_title(TMCHAR **target,TMCHAR *str,int width);
static void rpfprt(int lf_flag,TMCHAR *fmt,...);

/**************************/
/* local global variables */
/**************************/

static short int literal_flag;
static int line_count;           /* lines printed to current page */
static unsigned long int total_lines=0;  /* total lines output */
static LINE *head_line;          /* lowest numbered line not yet output */
static TABLE *cur_table;         /* currently active table */

/* buffers to hold 256 blanks and underlines to speed up processing of
   various buffers
*/

static TMCHAR ul_buf[256],bl_buf[256];

/* output file structure and pointer */

static FNSTRUC outfile;
static UFILE *ofile;

/* structure to group together all variables relating to page format

   pformat:  top_margin    - skip this many lines at top of page
             bottom_margin - last printable line on page
             pgnum_type    - type of page_numbering (a la RPF #SPN)
             pgnum_skip    - lines to skip after page number
             pgnum_sect    - for pgnum_type==1, section number
             pgnum         - number of current output page
             pgnum_prefix  - string of blanks to put pgnum at proper position
             title1        - pointer to first title line
             title2        - pointer to second title line
*/

static struct
       {int top_margin;
        int bottom_margin;
        int pgnum_type;
        int pgnum_skip;
        int pgnum_sect;
        int pgnum;
        TMCHAR pgnum_prefix[251];
        TMCHAR *title1;
        TMCHAR *title2;} pformat;

/* wlist - only one word list (for current column) ever necessary, since
   moving to new column purges word list to the line buffers

   wlist:  first    - head word in list
           last     - tail word in list
           more     - TRUE if word pending addition to list (max col length)
           len      - total length of all words and pads (except last pad)
           count    - number of words in list
           ul_count - numbe of underlined words in list
*/

static struct
       {WORD *first;
        WORD *last;
        short int more;
        int len;
        int count;
        int ul_count;} wlist;

/* RPF allows user-defined tables from 0 to 29; use 30 for the
   indent table and 31 for the default table
*/

static COL_DEF *table_def[32];

/***************************/
/* RPF emulation functions */
/***************************/

/* The following functions emulate various RPF commands or tags; some
   RPF operations have been grouped into a single function, but most
   have a one-to-one correspondence.  All RPF emulation functions are
   of type void, and if the rpf_flag is set to TRUE (via a command-line
   switch) they will output RPF tags and text to the output file.  Most
   make use of the CHECK_LITERAL macro, which will cause a call to
   prtmsg if either literal mode or column literal mode is currently
   active.
*/

/* colskip takes one argument, cnt, which is the number of lines to
   skip in the current column; equivalent to #CS
*/

void colskip(int cnt)
{
  if ( rpf_flag )
    {
      rpfprt(TRUE,_TMC("#CS {0,number,integer}\n"),cnt);
      return;
    }

  CHECK_LITERAL(_TMC("colskip"));

  if ( cnt < 1 )
    prtmsg(BADCSKA);

  newline(); /* get rid of any current stuff in column */

  /* put a null token into cnt lines */

  for ( ; cnt ; cnt-- )
    {
      push_token(NULL,NULL);
      CUR_LINE=get_next_line(CUR_LINE);
    }
}

/* concat takes no arguments; turns on the concat_flag in the current
   column, equivalent to #CONCAT.  Effect (in add_word) is to cause the
   next word output in the current column to be appended to the previous
   word.
*/

void concat(void)
{
  if ( rpf_flag )
    {
      rpfprt(TRUE,_TMC("#CONCAT\n"));
      return;
    }

  CHECK_LITERAL(_TMC("concat"));
  CUR_COL->concat_flag=TRUE;
}

/* indent takes a single integer argument, value, the number of spaces
   to begin indenting in the current column, equivalent to #I.  RPF
   treats indent as an open of an implicit table (which must be
   explicitly closed) so we do the same.  Equivalent to defining/invoking
   a table with one column beginning at value and extending to the
   end of the current column.
*/

void indent(int value)
{
  if ( rpf_flag )
    {
      rpfprt(TRUE,_TMC("#I {0,number,integer}\n"),value);
      return;
    }

  CHECK_LITERAL(_TMC("indent"));
  if ( value < 1 )
    prtmsg(BADINDA);

  if ( value > CUR_COL->len )
    prtmsg(LONGIND,value);
  table_def[30]->start=value-1; /* table[30] reserved for indent table */
  push_table(30);
}

/* justify takes one integer argument, flag, which should be one of
   the following macros (defined in guarpfe.h):

     flag            RPF tag
     -------         -------
     J_RIGHT         #R
     J_FULL          #FR
     J_LEFT          #RR

   J_RIGHT toggles the right_justification switch in the current column,
   while the other two values set the justify_flag appropriately.
*/

void justify(int flag)
{
  if ( !rpf_flag )
    {
      CHECK_LITERAL(_TMC("justify"));
      newline();
    }

  switch(flag)
    {
      case J_RIGHT : if ( rpf_flag )
                       rpfprt(TRUE,_TMC("#R\n"));
                     else
                       CUR_COL->right_justify = !CUR_COL->right_justify;
                     break;
      case J_FULL  : if ( rpf_flag )
                       rpfprt(TRUE,_TMC("FR\n"));
                     else
                       CUR_COL->justify_flag = flag;
                     break;
      case J_LEFT  : if ( rpf_flag )
                       rpfprt(TRUE,_TMC("#RR\n"));
                     else
                       CUR_COL->justify_flag = flag;
                     break;
      default      : prtmsg(BADJUSA);
    }
}

/* newcol takes no arguments, equivalent to #NC.  Cleans out the
   current column and moves to the next column, or if current column is
   the last, move back to the first.
*/

void newcol(void)
{
  if ( rpf_flag )
    {
      rpfprt(TRUE,_TMC("#NC\n"));
      return;
    }

  CHECK_LITERAL(_TMC("newcol"));

  /* first, force a cleanup of any text still in the column */

  newline();

  /* update last_line used by table if necessary */

  if ( CUR_LINE->lineno > cur_table->last_lineno )
    {
      cur_table->last_line=CUR_LINE;
      cur_table->last_lineno=CUR_LINE->lineno;
    }

  /* if there are more columns, go to the next; otherwise output pending
     lines and return to the first column */

  if ( CUR_COL->next )
    {
      CUR_COL=CUR_COL->next;
      CUR_LINE=cur_table->first_line;
    }
  else
    {
      if ( CUR_COL->last_col )
        print_pending(cur_table->last_line);
      CUR_COL=cur_table->first_col;
      cur_table->first_line=cur_table->last_line;
      CUR_LINE=cur_table->first_line;
    }

  /* underlining is turned off by moving to a new column */

  CUR_COL->uline_flag = FALSE;
}

/* newline takes no arguments, equivalent to #N; formats the current
   word list into a token and and then calls push_token to add it to
   the current line
*/

void newline(void)
{
  TMCHAR work[256]={0}/*TMCI18N CHANGED FROM ""*/,uwork[256]={0}/*TMCI18N CHANGED FROM ""*/; /* max string length */
  TMCHAR *p;
  int blanks,words,x,fulljust,tlen=0;
  WORD *w,*next_word;

  if ( rpf_flag )
    {
      rpfprt(TRUE,_TMC("#N\n"));
      return;
    }

  CHECK_LITERAL(_TMC("newline"));

  /* if there are any words in word list */

  if ( wlist.first )
    {
      /* blanks is the number of blanks to put in front of first word
         if right justification or centering is turned on
      */

      blanks=CUR_COL->len - wlist.len;
      if ( CUR_COL->center_flag )
        blanks /= 2;

      /* words is the actually the number of pads after words; i.e.,
         candidates for insertion of blanks for full justification
      */

      words=wlist.count-1;
      wlist.last->pad=0;  /* null out the pad on the last word */

      /* update the current length of the work buffer(s) with any
         necessary leading spaces for right justification or
         centering
      */

      if ( (CUR_COL->right_justify || CUR_COL->center_flag) && blanks )
        {
          tmmemcpy(work,bl_buf,blanks);
          if ( wlist.ul_count )
            tmmemcpy(uwork,bl_buf,blanks);
          tlen+=blanks;
        }

      /* build a flag once to indicate if full justification is in effect */

      fulljust=(CUR_COL->justify_flag==J_FULL &&
                !(CUR_COL->right_justify || CUR_COL->center_flag));

      /* now start building the work buffer(s) with the proper formatting */

      for ( w=wlist.first ; w ; )
        {
          tmmemcpy(&work[tlen],w->str,w->len+1);

          /* underline if necessary */

          if ( wlist.ul_count )
            tmmemcpy(&uwork[tlen],w->ul_flag ? ul_buf : bl_buf,w->len);
          tlen += w->len;

          /* calculate new pad for full justification */

          if ( fulljust && w->pad && words && wlist.more )
            {
              x=blanks/words;
              blanks-=x;
              words--;
              w->pad+=x;
            }

          if ( w->pad )
            {
              tmmemcpy(&work[tlen],bl_buf,w->pad);

              /* underline if necessary */

              if ( wlist.ul_count )
                tmmemcpy(&uwork[tlen],w->ul_pad_flag ? ul_buf : bl_buf,w->pad);

              tlen += w->pad;
            }

          /* get current to the next word and free up storage for the
             current word
          */

          next_word=w->next;
          FREEMEM(w->str);
          FREEMEM(w);
          w=next_word;
        }

      /* clear out word list pointers */

      wlist.first=NULL;
      wlist.last=NULL;

      /* null terminate the work buffer */

      work[tlen] = '\0';

      /* if any underlining, rtrim blanks from the underline buffer */

      if ( wlist.ul_count)
        {
          uwork[tlen] = '\0';
          p=tmstrrchr(uwork,'_');
          *(++p)='\0';
        }

      /* now move the work areas to the output line */

      push_token(work,*uwork ? uwork : NULL);

      /* another skipline/literal kludge */

      if ( CUR_COL->last_col )
        CUR_LINE->line_used = FALSE;

      /* increment to a new line */

      CUR_LINE=get_next_line(CUR_LINE);
    }

  /* if center or center and underline turned on, turn them off */

  if ( CUR_COL->center_flag )
    {
      CUR_COL->center_flag=FALSE;
      CUR_COL->uline_flag=FALSE;
    }

  /* signal that it is now safe to add a word to the list */

  wlist.more=FALSE;
}

/* newpage takes no arguments, equivalent to #NP; if necessary it does
   some cleanup and then calls end_page to get to a new page
*/

void newpage(void)
{
  if ( rpf_flag )
    {
      rpfprt(TRUE,_TMC("#NP\n"));
      return;
    }

  CHECK_LITERAL(_TMC("newpage"));

  /* if newpage called while in last column, with text already added,
     then newpage will follow current line instead of preceding it
  */

  if ( wlist.first && CUR_COL->last_col )
    {
      newline();                /* clean line */
      print_pending(CUR_LINE);  /* print the completed line */
      if ( line_count )         /* newpage only if print_pending */
        end_page();             /* didn't cause one */
    }
  else
    end_page();
}

/* pgformat takes two integer arguments, the top and bottom margins for
   the page; equivalent to #PAGE.  Valid values are 0<=top<66 and
   1<bottom<=66
*/

void pgformat(int top,int bottom)
{
  if ( rpf_flag )
    {
      rpfprt(TRUE,_TMC("#PAGE {0,number,integer} {1,number,integer}\n"),top,bottom);
      return;
    }

  CHECK_LITERAL(_TMC("pgformat"));
  if ( top < 0 || top > 65 || bottom < 2 || bottom > 66 || bottom < top )
    prtmsg(BADPGFA);

  pformat.top_margin=top;
  pformat.bottom_margin=bottom;
}

/* pgnum takes five integer arguments; equivalent to #SPN.  Arguments are:

    type  - page numbering style - options are (where n is page number):
            1: m-n where m is section
            2: -n-
            3: n.
            4: n
    pos   - offset on line to print page number
    skip  - number of lines to skip after page number
    start - start numbering with page start
    sect  - section (for type=1)
*/

void pgnum(int type,int pos,int skip,int start,int sect)
{
  if ( rpf_flag )
    {
      rpfprt(FALSE,_TMC("#SPN {0,number,integer} {1,number,integer} {2,number,integer} {3,number,integer} "),type,pos,skip,start);
      if ( type==1 )
        rpfprt(FALSE,_TMC("{0,number,integer} "),sect);
      rpfprt(TRUE,_TMC("#\n"));
      return;
    }

  CHECK_LITERAL(_TMC("pgnum"));

  if ( skip < 1 || start < 1 || sect < 0 )
    prtmsg(BADPGNA);
  if ( type < 1 || type > 4 )
    prtmsg(BADPGNT);
  if ( pos < 1 || pos > 250 )
    prtmsg(BADPGNP);

  pformat.pgnum_type=type;
  pformat.pgnum_skip=skip-1;
  pformat.pgnum_sect=sect;
  pformat.pgnum=start;

  /* pgnum_prefix is a null terminated string of length pos-1 */

  if ( --pos )
    tmmemcpy(pformat.pgnum_prefix,bl_buf,pos);
  pformat.pgnum_prefix[pos]='\0';
}

/* pgraph takes no arguments, equivalent to #P.  Forces a newline in the
   current column and then adds five blanks (six with pad) to word list.
*/

void pgraph(void)
{
  if ( rpf_flag )
    {
      rpfprt(TRUE,_TMC("P\n"));
      return;
    }

  CHECK_LITERAL(_TMC("pgraph"));

  if ( CUR_COL->len < 5 )
    prtmsg(LONGPAR,CUR_COL->len);

  newline();
  add_word(_TMC("     "),5,0);
}

/* setmode takes one integer argument, mode, which should be one of the
   following macros (defined in guarpfe.h):

     mode             RPF tag
     --------         -------
     M_CENTER         #CEN
     M_UNDER          #UL
     M_CENUND         #CUL
     M_COLLIT         #CL
     M_LITER          #L
     M_NORMAL         #
*/

void setmode(int mode)
{
  if ( rpf_flag )
    {
      switch(mode)
        {
          case M_CENTER : rpfprt(TRUE,_TMC("#CEN\n"));
                          break;
          case M_UNDER  : rpfprt(TRUE,_TMC("#UL\n"));
                          break;
          case M_CENUND : rpfprt(TRUE,_TMC("#CUL\n"));
                          break;
          case M_COLLIT : rpfprt(TRUE,_TMC("#CL\n"));
                          break;
          case M_LITER  : rpfprt(TRUE,_TMC("#L\n"));
                          break;
          case M_NORMAL : rpfprt(TRUE,_TMC("#\n"));
                          break;
          default       : prtmsg(BADSETA);
        }
      return;
    }

  /* only setmode(M_NORMAL) valid if in literal mode */

  if ( literal_flag || CUR_COL->literal_flag)
    {
      if ( mode != M_NORMAL )
        prtmsg(NONLITS);
      literal_flag=FALSE;
      CUR_COL->literal_flag=FALSE;
      return;
    }

  /* M_COLLIT - column literal mode */

  if ( mode == M_COLLIT )
    {
      newline();
      CUR_COL->literal_flag=TRUE;
      return;
    }

  /* M_LITER - literal mode */

  if ( mode == M_LITER )
    {
      literal_prep();
      literal_flag=TRUE;
      return;
    }

  /* now check for invalid modes */

  if ( mode != M_NORMAL && mode != M_UNDER &&
       mode != M_CENTER && mode != M_CENUND)
    prtmsg(BADSETA);

  /* any remaining mode cancels the previous modes, so in effect do
     a setmode(M_NORMAL) before continuing */

  if ( CUR_COL->uline_flag )
    {
      if ( wlist.last )
        wlist.last->ul_pad_flag=FALSE;
      CUR_COL->uline_flag=FALSE;
    }

  /* Kludge to do page breaks correctly; code in newpage to handle the
     case of a newpage when in the last column and text has been added
     to the column works incorrectly if that text is centered and
     centering was explicitly turned off.  In that case use newcol to
     get back to where we started.
  */

  if ( CUR_COL->center_flag )
    {
      if ( CUR_COL->last_col )
        {
          newcol();
          while ( !CUR_COL->last_col )
            newcol();
        }
      else
        newline();
    }

  /* do the remaining modes, M_UNDER, M_CENTER, M_CENUND */

  if ( mode==M_UNDER || mode==M_CENUND )
    CUR_COL->uline_flag=TRUE;
  if ( mode==M_CENTER || mode==M_CENUND )
    {
      newline();
      CUR_COL->center_flag=TRUE;
    }
}

/* skipline takes one integer argument, cnt, the number of lines to
   skip; equivalent to #S.  Like turning on literal mode, skipline
   purges output to the output file in interesting ways via the
   function literal_prep.
*/

void skipline(int cnt)
{
  if ( rpf_flag )
    {
      rpfprt(TRUE,_TMC("#S {0,number,integer}\n"),cnt);
      return;
    }

  CHECK_LITERAL(_TMC("skipline"));
  if ( cnt<1 )
    prtmsg(BADSKPA);

  /* skipline acts like a literal output of blank lines, so treat it
     the same as a literal */

  literal_prep();

  for ( ; cnt ; cnt-- )
    output_text(_TMC(""),NULL);
}

/* table takes a variable number of integers as arguments, depending
   on the value of the first argument, an integer called mode (should
   be one of the following macros, defined in guarpfe.h):

     mode         RPF tag    additional args
     --------     -------    ---------------
     T_DEFINE     #DT        table_num,col1_start,col1_end,...,NULL
     T_BEGIN      #T         table_num
     T_END        #TE        n/a
     T_DEFINE2    n/a        table_num,int_array_pointer

   Note that for table(T_DEFINE...) two arguments must be supplied for
   each column, and the entire list of column definitions must be
   NULL terminated.
*/

/* under 5.1a of Tru64 Unix, the table function collides with a system include,
   so use _table to work around
*/

#if OPSYS==OS_UNIX && PLATFORM==PL_ALPHA
void _table(int mode,...)
#else
void table(int mode,...)
#endif    
{
  va_list ptr;
  int tab,col_start,col_end,prev_end;
  COL_DEF *c,*cur_col_def;
  int *ip;

  if ( !rpf_flag )
    CHECK_LITERAL(_TMC("table"));

  /* table end is very simple; just pop the current table off the table
     stack
  */

  if ( mode==T_END )
    {
      if ( rpf_flag )
        rpfprt(TRUE,_TMC("#TE\n"));
      else
        {
          if ( !cur_table->prev )
            prtmsg(EXTRATE);
          pop_table();
        }
    }
  else
    {

      /* for other three options, get the table number */

      va_start(ptr,mode);
      tab=va_arg(ptr,int);
      if ( tab < 0 || tab > 29 ) /* invalid table number */
        {
          va_end(ptr);
          prtmsg(BADTABN,tab);
        }

      /* beginning a table is just as easy; just push it onto the stack */

      if ( mode==T_BEGIN )
        {
          if ( rpf_flag )
            rpfprt(TRUE,_TMC("#T {0,number,integer}\n"),tab);
          else
            {
              if ( !table_def[tab] )
                {
                  va_end(ptr);
                  prtmsg(UNDFTAB,tab);
                }
              push_table(tab);
            }
        }

      /* defining a table is a little more interesting;
         get/validate/translate column definitions from
         the argument list until no more to be had
      */

      else if ( mode==T_DEFINE || mode==T_DEFINE2 )
        {
          if (rpf_flag)
            rpfprt(FALSE,_TMC("#DT {0,number,integer} "),tab);
          else
            {
              if ( table_def[tab] ) /* override current def of table */
                {
                  prtmsg(MULTTAB,tab);
                  free_table_def(tab);
                }
              cur_col_def=NULL;
            }

          /* get first column start */

          if ( mode==T_DEFINE )
            col_start=va_arg(ptr,int);
          else
            {
              ip=va_arg(ptr,int *);
              col_start = *ip;
            }
          col_end=0;
         

          /* loop until start is NULL */

          while(col_start)
            {
              prev_end=col_end;
              if ( mode==T_DEFINE )
                col_end=va_arg(ptr,int);
              else
                col_end = *(++ip);
              if (rpf_flag)
                rpfprt(FALSE,_TMC("{0,number,integer} {1,number,integer} "),col_start,col_end);
              else
                {
                  /* add a column definition to the end of
                     the proper table_def entry
                  */

                  if ( col_end > 255 )
                    {
                      va_end(ptr);
                      prtmsg(BADCEND,col_end);
                    }
                  c=GETMEM(COL_DEF,1);
                  c->next=NULL;
                  if ( cur_col_def )
                    cur_col_def->next=c;
                  else
                    table_def[tab]=c;

                  /* only one column in a table (the last) can have an
                     end of 0 (remainder of containing column
                  */

                  if ( cur_col_def )
                    if ( !cur_col_def->len && !col_end )
                      prtmsg(BADCDEF,tab);

                  if ( (col_end != 0 && col_end < col_start) ||
                        col_start<=prev_end )
                    {
                      va_end(ptr);
                      prtmsg(BADCDEF,tab);
                    }

                  /* adjust start from offsets beginning at 1 to true
                     C offsets (begin at 0)
                  */

                  c->start=col_start-1;
                  if ( col_end )
                    c->len=col_end-col_start+1;
                  else
                    c->len=0;
                  cur_col_def=c;
                }
              /* get next column start */
              if ( mode==T_DEFINE )
                col_start=va_arg(ptr,int);
              else
                col_start = *(++ip);
            }
          if ( rpf_flag )
            rpfprt(TRUE,_TMC("#\n"));
          /* better be at least one column */
          else if ( !cur_col_def )
            {
              va_end(ptr);
              prtmsg(NOCOLMS);
            }
        }
      else
        prtmsg(BADTABA,mode);
      va_end(ptr);
    }
}

/* title takes three arguments, an integer width and two character pointers
   str1 and str2; equivalent to #TTL.  str2 may be a NULL pointer if
   only one line of title is desired.  The function build_title is used
   to actually parse/format the title strings.
*/

void title(int width,TMCHAR *str1,TMCHAR *str2)
{
  if ( rpf_flag )
    {
      rpfprt(FALSE,_TMC("#TTL {0,number,integer} {1} "),width,str1);
      if ( str2 )
        rpfprt(FALSE,_TMC("| {0} "),str2);
      rpfprt(TRUE,_TMC("#\n"));
      return;
    }

  CHECK_LITERAL(_TMC("title"));
  if ( width < 1 || width > 255 )
    prtmsg(BADTTLW,width);

  build_title(&pformat.title1,str1,width);
  build_title(&pformat.title2,str2,width);
}

/*************************/
/* RPT support functions */
/*************************/

/* rptopen takes three arguments, a char pointer, userpass, to a target
   for an ORACLE userid/password string, and argc and argv, intended
   to be passed unchanged from the command line.  The purpose of rptopen
   is to take care of various cleanup/setup chores necessary for every
   converted RPT, such as parsing the command line parms, opening the
   output file, etc.  The functions rptinit is also called to initialize
   various data structures for RPF emulation.
*/

void _rptopen(TMCHAR *userpass,int argc,TMCHAR *argv[])
{
  int cnt,i,next_arg;
  TMCHAR *default_ext=_TMC("lis");  /* default extension for output file */
  TMCHAR *ofile_name=NULL;
  
  /* Variables for retrieving credentials from a file */
  TMCHAR cUserName[31]={0}/*TMCI18N CHANGED FROM ""*/;
  TMCHAR cUserNameFromFile[31]={0}/*TMCI18N CHANGED FROM ""*/;
  TMCHAR cUserPassFromFile[62]={0}/*TMCI18N CHANGED FROM ""*/;
  
  TMCHAR csInCredsFile[255]={0}/*TMCI18N CHANGED FROM ""*/;
  TMCHAR csInCredsLine[61]={0}/*TMCI18N CHANGED FROM ""*/;
  
  UFILE *incredsfile;

  /* fill in the executable file name structure */
  getxnam(*argv);
  
  /* parse the command line parameters */

  for ( cnt=1 ; cnt<argc && *argv[cnt] == '-' ; cnt++ )
    if ( ! argv[cnt][1] )
      cmdhelp();
    else
      for ( i=1,next_arg=FALSE ; argv[cnt][i] && !next_arg ; i++ )
        switch(argv[cnt][i])
          {
            /* -f: use formfeeds to break pages (default is blank lines) */
            case 'f' : ff_flag=TRUE;
                       break;
            /* -i: do an initial newpage before user output */
            case 'i' : eject_flag=TRUE;
                       break;
            /* -u: uppercase all output */
            case 'u' : uc_flag=TRUE;
                       break;
            /* -r: output an RPF file instead of a listing file */
            case 'r' : rpf_flag=TRUE;
                       default_ext=_TMC("rpf");
                       break;
            /* -t: sets a global flag so that application code will
                   generate an ORACLE .trc file */
            case 't' : sqltrace_flag=TRUE;
                       break;
            /* -v: switches order of underline/text printing
                   default is underlines first */
            case 'v' : reverse_flag=TRUE;
                       break;
            /* -o: specify an output file */
            case 'o' : if ( argv[cnt][i+1] )
                         cmdhelp();
                       ofile_name=argv[++cnt];
                       next_arg=TRUE;
                       break;
            /* -x: internal debugging trace tool - if .pc file generated
                   with -x switch, this will cause each function to
                   echo its name to stdout upon entry */
            case 'x' : trace_flag=TRUE;
                       break;
            /* -y: indicates where the location of the credential file is */
            case 'y' : if ( argv[cnt][i+1] )
                         cmdhelp();
                       next_arg=TRUE;
                  tmstrcpy(csInCredsFile,argv[++cnt]);
                  break;
            default  : cmdhelp();
          }
  
  /* create a valid output file name */

  initfn(&outfile);
  if ( ofile_name )     /* user specified output file */
    {
      tmstrcpy(outfile.fname,ofile_name);
      parsfn(&outfile);
      /* use default extension if user did not specify one */
      if ( !*outfile.ext )
        setfile(NULL,NULL,default_ext,NULL);
    }
  /* if user did not specify an output file, use the name of the executable
     with the default extension */
  else
    setfile(NULL,exefile.name,default_ext,NULL);

  /* after all switches parsed, the next argument is interpreted as an
     ORACLE userid/password; any additional arguments cause an error
  */
  
  *userpass='\0';
  if ( cnt==argc-1 )
    tmstrcpy(userpass,argv[cnt]);
  else if ( cnt!=argc )
    cmdhelp();

  /* **********************************************************************
       Argument -y indicates filename to be opened. Read (obtain credential
       information) from logical file gurinso_######.in if the test is
       specific to the default password value of /NOTVALIDPASSWD
     **********************************************************************
  */
  if ( tmstrstr(userpass,_TMC("/NOTVALIDPASSWD")) );
   {
     incredsfile = tmfopen(&tmBundle, csInCredsFile, _TMC("r"));
     
      if (incredsfile)
      {
        tmfgets(csInCredsLine,sizeof(csInCredsLine),incredsfile);
        tmstrncpy(cUserPassFromFile,csInCredsLine,tmstrlen(csInCredsLine) - 1);
        tmstrcpy(userpass,cUserPassFromFile);
     
        tmfclose(incredsfile);
        incredsfile = NULL;
      }
   }
  
  /* initialize data structures */

  rptinit();

  /* register function to free memory and close output file (moved from
     rptinit so that sleep/wake will function properly)
  */

  regexit(rptclose);
}

/* setfile takes char pointers to directory, name, extension, and version
   strings, and modifies the contents of the FNSTRUC variable outfile
   accordingly; any argument which is NULL results in no change to
   the corresponding outfile member.  A call to makefn reconstructs
   outfile.fname, and a pointer to fname is returned.
*/

TMCHAR *setfile(TMCHAR *dir,TMCHAR *name,TMCHAR *ext,TMCHAR *vers)
{
  if ( dir )
    tmstrcpy(outfile.dir,dir);
  if ( name )
    tmstrcpy(outfile.name,name);
  if ( ext )
    tmstrcpy(outfile.ext,ext);
  if ( vers )
    tmstrcpy(outfile.vers,vers);
  makefn(&outfile);

  return outfile.fname;
}

/* rptinit opens outfile for output and initializes data structures
   in preparation for report output.  It is a separate function from
   rptopen so that it may be called to open a new output file; it is
   also called by the standalone RPF emulator SCTRPF.
*/

void rptinit(void)
{
  int i;

  /* open the output file for writing; if output is a listing file
     use prtmode to get the proper mode argument for the current OS
  */

  if ( !(ofile=tmfopen(&tmBundle, outfile.fname,rpf_flag ? _TMC("w") : prtmode())) )
    prtmsg(IOERROR,outfile.fname);

  /* initial page eject if user specified -i switch */

  if ( eject_flag )
    newpage();

  /* if we're in RPF mode, don't need to do anything else */

  if ( rpf_flag )
    return;

  /* reset static variables in prtmsg */

  prtmsg(PRGOPEN);

  /************************/
  /* initialize variables */
  /************************/

  literal_flag = FALSE;
  line_count = 0;
  total_lines = 0;
  head_line = NULL;
  cur_table = NULL;

  pformat.top_margin = 0;
  pformat.bottom_margin = 66;
  pformat.pgnum_type = 0;
  pformat.pgnum_skip = 0;
  pformat.pgnum_sect = 0;
  pformat.pgnum = 0;
  pformat.pgnum_prefix[0] = '\0';
  pformat.title1 = NULL;
  pformat.title2 = NULL;

  wlist.first = NULL;
  wlist.last = NULL;
  wlist.more = FALSE;
  wlist.len = 0;
  wlist.count = 0;
  wlist.ul_count = 0;

  /* initialize table definitions */

  for ( i=0 ; i<30 ; i++ )
    table_def[i]=NULL;

  /* define indent table */

  table_def[30]=GETMEM(COL_DEF,1);
  table_def[30]->start=0;
  table_def[30]->len=0;
  table_def[30]->next=NULL;

  /* define default table */

  table_def[31]=GETMEM(COL_DEF,1);
  table_def[31]->start=0;
  table_def[31]->len=255;
  table_def[31]->next=NULL;

  /* make default table */

  push_table(31);

  /* initialize blank and underline buffers */
  /*TMCI18N fix bug: the number of UChars <> sizeof(ul_buf)*/
  tmmemset(ul_buf,'_',sizeof(ul_buf)/sizeof(ul_buf[0]));
  tmmemset(bl_buf,' ',sizeof(bl_buf)/sizeof(bl_buf[0]));
}

/* rptclose takes a single int argument, exit_status, which should be
   one of the macros EXIT_SUCCESS or EXIT_FAILURE (defined in stdlib.h.)
   It prints any pending output and frees memory prior in preparation
   for either program exit or a new call to rptinit.
*/

void rptclose(int exit_status)
{
  int i;
  LINE *l,*next_line;
  WORD *w,*next_word;
  TOKEN *t,*next_token;

  /* if normal exit, check for errors such as literals still open
     - signal to prtmsg that closing is in progress, otherwise things
     could get weird */

  prtmsg(PRGCLOS);
  if ( exit_status==EXIT_SUCCESS && !rpf_flag )
    {
      if ( literal_flag )
        prtmsg(NOLTTRM);
      if ( CUR_COL->literal_flag )
        prtmsg(NOCLTRM);
    }

  /* try to output any text that is laying around by popping all tables */

  if ( !rpf_flag )
    while ( cur_table )
      pop_table();

  /* close the output file (if it got opened) */

  if ( ofile )
    {
      tmfclose(ofile);
      ofile=NULL;
    }

  /* print out closing messages */

  if ( exit_status == EXIT_SUCCESS )
    prtmsg(CMPNORM,exefile.name);
  else
    prtmsg(CMPERRO,exefile.name);
  prtmsg(LINSOUT,total_lines,outfile.fname);

  /* no more cleanup if in rpf mode */

  if ( rpf_flag )
    return;

  /* clear table definitions */

  for ( i=0 ; i<31 ; i++ )
    if ( table_def[i] )
      free_table_def(i);

  /* clear line buffers */

  for ( l=head_line ; l ; )
    {
      next_line=l->next;
      for ( t=l->first_token ; t ; )
        {
          next_token=t->next;
          if ( t->text )
            FREEMEM(t->text);
          if ( t->uline )
            FREEMEM(t->uline);
          t=next_token;
        }
      FREEMEM(l);
      l=next_line;
    }

  /* free words */

  for ( w=wlist.first ; w ; )
    {
      next_word=w->next;
      if ( w->str )
        FREEMEM(w->str);
      FREEMEM(w);
      w=next_word;
    }

  /* free title buffers */

  if ( pformat.title1 )
    FREEMEM(pformat.title1);
  if ( pformat.title2 )
    FREEMEM(pformat.title2);
}

/* prtstr takes a single char pointer argument, str, which is added to
   the output stream according to current setting of literal flags,
   column, table, etc.
*/

void prtstr(TMCHAR *str)
{
  int len,pad;
  TMCHAR *word,temp_str[256];

  if ( rpf_flag )
    {
      rpfprt(TRUE,_TMC("{0}\n"),str);
      return;
    }

  /* if literal mode is on, just send str directly to output file */

  if ( literal_flag )
    {
      output_text(str,NULL);
      return;
    }

  /* if column literal mode is on, create a token from str and place
     it into the current line buffer for the column
  */

  if ( CUR_COL->literal_flag )
    {
      /* warn if str too long for column */

      if ( (int)tmstrlen(str) > CUR_COL->len )
        prtmsg(LONGLIT,tmstrlen(str),CUR_COL->len);

      /* move the string (might be a literal) to a buffer in case mods
         need to be made; make sure to null terminate it in case it is
         too long (for column or temp size).
      */

      tmstrncpy(temp_str,str,255);
      temp_str[CUR_COL->len] = '\0';

      /* rtrim blanks */

      rtrim(temp_str,NULL);

      /* add a token to the list for the line containing the literal */

      push_token(temp_str,NULL);

      /* increment to a new line */

      CUR_LINE=get_next_line(CUR_LINE);

      return;
    }

  /* otherwise, break str into words and use add_word to place in
     word list
  */

  word=get_rpf_word(str,&len,&pad);
  while(word)
    {
      add_word(word,len,pad);
      word=get_rpf_word(NULL,&len,&pad);
    }
}

/* prtnum takes two arguments, a char pointer num to a NUMSTR style numeric
   string and a char pointer format to an RPT style format, converts num
   to a formatted string and sends it to prtstr.
*/

void prtnum(TMCHAR *num,TMCHAR *format)
{
  TMCHAR tempstr[80];

  tochar(tempstr,num,format);
  if ( rpf_flag )
    {
      rpfprt(TRUE,_TMC("{0}\n"),tempstr);
      return;
    }

  prtstr(tempstr);
}

/* report emulates the RPT .REPORT command; it takes four function pointers
   as arguments:

     arg       prototype             description
     ------    ------------------    -------------------------------------
     selfcn    int fcn(int mode);    driving select for report
     body      void fcn(void);       function to be executed for each
                                     row but first
     head      void fcn(void);       function to be executed for first row
     foot      void fcn(void);       function to be executed for last row

   selfcn and body must be provided; head and foot are optional and may
   be replaced by NULL pointers.
*/

int report(selfcn_t selfcn,voidfcn_t body,voidfcn_t head,voidfcn_t foot)
{
  if ( selfcn(FIRST_ROW) )
    {
      if ( head )
        head();
      else
        body();
      while ( selfcn(NEXT_ROW) )
        body();
      if ( foot )
        foot();
      return TRUE;
    }
  return FALSE;
}

/* chkcflag is used to interrogate the current setting of one of the 
   command-line flags.  It returns the current setting, and takes as a 
   parameter one of the CL_ macros defined in guarpfe.h.
*/

int chkcflag(int flag)
{
  switch(flag)
    {
      case CL_UC    : return uc_flag;
      case CL_EJECT : return eject_flag;
      case CL_FF    : return ff_flag;
      case CL_REV   : return reverse_flag;
      case CL_RPF   : return rpf_flag;
      default       : prtmsg(BADINDA,_TMC("chkcflag"));
    }

  return FALSE; /* never get here, but keep C happy */
}

/* setcflag is used to change the current setting of one of the command-line 
   flags.  It takes two paremeters; the first is one of the CL_ macros 
   defined in guarpfe.h, and the second is the new value for that parameter.
   WARNING: changing these flags once any output has begun may cause 
   interesting behavior in the output!
*/

void setcflag(int flag,short val)
{
  switch(flag)
    {
      case CL_UC    : uc_flag=val;
                      break;
      case CL_EJECT : eject_flag=val;
                      break;
      case CL_FF    : ff_flag=val;
                      break;
      case CL_REV   : reverse_flag=val;
                      break;
      case CL_RPF   : rpf_flag=val;
                      break;
      default       : prtmsg(BADINDA,_TMC("setcflag"));
    }
}

/********************************/
/* table manipulation functions */
/********************************/

/* push_table takes a single int argument tab; the corresponding table is
   pushed onto the table stack and a list of columns is created.  The
   current column is set to the first column of the new table.
*/

static void push_table(int tab)
{
  TABLE *t;
  COL_DEF *c;

  /* create a new table entry */

  t=GETMEM(TABLE,1);

  /* push onto top of stack */

  if ( cur_table )
    {
      /* get the invoking column to the next clear line */

      newline();

      /* stack stuff */

      t->prev=cur_table;

      /* inherit start, length, etc. from containing column */

      t->start=CUR_COL->start;
      t->len=CUR_COL->len;
      t->last_table=CUR_COL->last_col;
      t->last_line=CUR_COL->cur_line;
      t->last_lineno=t->last_line->lineno;
      t->first_line=CUR_COL->cur_line;
    }
  else /* only get here when creating first (default) table */
    {
      t->prev=NULL;

      /* default table is len 255, starting at 0 */

      t->start=0;
      t->len=255;
      t->last_table=TRUE;
      t->first_line=get_next_line(NULL);
      t->last_line=t->first_line;
      t->last_lineno=t->last_line->lineno;
    }

  /* add columns to table */

  t->first_col=NULL;
  cur_table=t;
  for (c=table_def[tab] ; c ; c=c->next)
    add_col(c->start,c->len);

  /* set CUR_COL and CUR_LINE and done */

  CUR_COL=cur_table->first_col;
  CUR_LINE=cur_table->first_line;
}

/* pop_table takes no arguments; after purging any pending output from the
   current table, it pops the table stack, releasing table/column memory
   in the process.
*/

static void pop_table(void)
{
  TABLE *t;
  COLUMN *c,*next_col;

  /* practicing safe computing */

  if ( !cur_table )
    return;

  /* clear any pending output from current column */

  newline();

  /* update last_line used by table if necessary */

  if ( CUR_LINE->lineno > cur_table->last_lineno )
    {
      cur_table->last_line=CUR_LINE;
      cur_table->last_lineno=CUR_LINE->lineno;
    }

  /* print any outstanding lines if this is the last table */

  if ( cur_table->last_table )
    print_pending(cur_table->last_line);

  t=cur_table;

  /* if not the last thing on the stack */

  if ( t->prev )
    {
      cur_table=t->prev;

      /* roll up last line used in table to be current line of invoking
         column
      */

      CUR_LINE=t->last_line;

      /* update last_line used by table if necessary */

      if ( CUR_LINE->lineno > cur_table->last_lineno )
        {
          cur_table->last_line=CUR_LINE;
          cur_table->last_lineno=CUR_LINE->lineno;
        }
    }
  else
    cur_table=NULL;

  /* free memory used by table and columns */

  for ( c=t->first_col ; c ; )
    {
      next_col=c->next;
      FREEMEM(c);
      c=next_col;
    }
  FREEMEM(t);
}

/* free_table_def takes a single int argument tab, and frees storage
   for the associated column definition list.
*/

static void free_table_def(int tab)
{
  COL_DEF *c,*next_col_def;

  for ( c=table_def[tab] ; c ; )
    {
      next_col_def=c->next;
      FREEMEM(c);
      c=next_col_def;
    }
}

/* add_col takes two int arguments, start and len, and adds a column entry
   to the column list for the current table.  A len of 0 indicates that
   column should extent to the end of the containing table.
*/

static void add_col(int start,int len)
{
  COLUMN *c;

  /* create a new COLUMN entry and add to end of list */

  c=GETMEM(COLUMN,1);
  if ( ! cur_table->first_col )  /* first column in list */
    cur_table->first_col=c;
  else
    {
      CUR_COL->next=c;
      CUR_COL->last_col=FALSE;
    }

  /* error if column too long for table */

  if ( start+len > cur_table->len )
    prtmsg(LONGTAB);

  /* column start made absolute to line, rather than relative to table */

  c->start=cur_table->start + start;
  if ( len )
    c->len=len;
  else
    c->len=cur_table->len-start;

  /* initialize all fields for column */

  c->right_justify=FALSE;
  c->justify_flag=J_FULL;
  c->center_flag=FALSE;
  c->uline_flag=FALSE;
  c->literal_flag=FALSE;
  c->concat_flag=FALSE;
  c->last_col=cur_table->last_table;
  c->next=NULL;

  /* while columns are being added CUR_COL will point to the last column
     added
  */

  CUR_COL=c;
}

/***************************/
/* word handling functions */
/***************************/

/* get_rpf_word searches buffer for blank delimited words, following
   RPF rules for periods, spaces, and escapes (backslashes.)  It
   returns a pointer to an RPF word stored in a local static variable,
   or NULL when there are no more words in buffer; also, len
   and pad are set to the length of the word and the number of blanks
   to place after the word (for period processing.)  Like strtok, the first
   call should specify buffer; subsequent calls should use NULL for
   the first argument.
*/

static TMCHAR *get_rpf_word(TMCHAR *buffer,int *len,int *pad)
{
  TMCHAR *p;
  static TMCHAR *next_word;
  static TMCHAR cur_word[256];

  /* if buffer specified, that's where we start */

  if ( buffer )
    next_word=buffer;

  /* ltrim blanks */

  for ( ; *next_word==' ' ; next_word++ );

  /* no more words in buffer */

  if ( !*next_word )
    return NULL;

  /* now we know where the current word starts; build into temp_word and
     when done next_word will point to the character after the current
     word
  */

  p=cur_word;
  *len = 0;
  while ( *next_word && *next_word != ' ' )
    {
      if ( *next_word == '\\' )
        next_word++;
      if ( *next_word )
        {
          *p++ = *next_word++;
          (*len)++;
        }
    }

  *p='\0';

  /* take care of a trailing escape with no following blank */

  if ( !*cur_word )
    return NULL;

  /* there are normally two blanks after a period; make it only one
     if the text is being centered (clears multitudes of CSRs!)
  */

  if ( cur_word[*len-1]=='.' )
    *pad=2;
  else
    *pad=1;

  return cur_word;
}

/* add_word takes three arguments; a char pointer to a word, and an int
   len and pad, the length of the word and spaces after word respectively.
   The word is added to the word list; if the word takes the length
   of the word list past the column length then newline clears the
   word list before the current word is added.
*/

static void add_word(TMCHAR *word,int len,int pad)
{
  WORD *w;

  /* allocate space for the word */

  w=GETMEM(WORD,1);

  /* if concatatenation is in effect and there is a previous word, pop
     the previous word off the list and concatenate word to it, updating
     pads, lengths, etc. accordingly
  */

  if ( CUR_COL->concat_flag && wlist.last )
    {
      w->str=GETMEM(TMCHAR,wlist.last->len+len+1);
      tmstrcpy(w->str,wlist.last->str);
      tmstrcat(w->str,word);
      w->ul_flag=wlist.last->ul_flag;
      w->ul_pad_flag=wlist.last->ul_pad_flag;
      w->len=wlist.last->len+len;
      w->pad=pad;
      pop_word();
    }

  /* otherwise, move word into the allocated WORD structure with
     appropriate lengths, pads and flags
  */

  else
    {
      w->str=GETMEM(TMCHAR,len+1);
      tmmemcpy(w->str,word,len+1);

      w->pad=pad;
      w->len=len;

      if ( CUR_COL->uline_flag )
        {
          w->ul_flag=TRUE;
          w->ul_pad_flag=TRUE;
        }
      else
        {
          w->ul_flag=FALSE;
          w->ul_pad_flag=FALSE;
        }
    }

  /* warning if the word is too long for the column */

  if ( w->len > CUR_COL->len )
    {
      prtmsg(LONGTOK,w->str,CUR_COL->len);
      w->len = CUR_COL->len;
      w->str[w->len] = '\0';
    }

  /* if adding the word to the list exceeds column length, purge the
     word list with newline before adding word
  */

  if ( wlist.first && (wlist.len + wlist.last->pad + w->len > CUR_COL->len) )
    {
      /* error if entire word list will not fit in column when centered */
      if ( CUR_COL->center_flag )
        prtmsg(LONGCEN,CUR_COL->len);
      wlist.more=TRUE;   /* so full justification will work */
      newline();
    }

  /* finally, add the word to the word list */

  push_word(w);

  /* if concatenation was on we're done with it now */

  CUR_COL->concat_flag=FALSE;
}

/* push_word and pop_word update the word list by either adding or
   removing a word from the end of the list; also, a count of words
   with a trailing pad (non-zero) is maintained, as well as the
   number of words underlined in the list and the current total
   length of all words in the list (except for the trailing pad
   of the last word)
*/

/* push_word takes one argument, w, a pointer to a WORD structure, and
   adds the word to the word list, updating lengths and counts
*/

static void push_word(WORD *w)
{
  if ( wlist.first )  /* at least one word in list */
    {
      wlist.last->next=w;
      w->prev=wlist.last;
      wlist.len += wlist.last->pad;
    }
  else               /* first word in list */
    {
      wlist.first=w;
      w->prev=NULL;
      wlist.len=0;
      wlist.ul_count=0;
      wlist.count=0;
    }

  wlist.last=w;
  wlist.last->next=NULL;
  wlist.len += wlist.last->len;
  if ( wlist.last->ul_flag )
    wlist.ul_count++;
  if ( wlist.last->pad )
    wlist.count++;
}

/* pop_word pops the last word off the word list, updates lengths and
   counts for the list, and frees storage for the word
*/

static void pop_word(void)
{
  WORD *w;

  w=wlist.last;

  if ( ! w )
    return;

  wlist.last=wlist.last->prev;
  if ( wlist.last )
    {
      wlist.last->next = NULL;
      wlist.len -= wlist.last->pad;
    }
  else
    wlist.first = NULL;

  if ( w->pad )
    wlist.count--;
  if ( w->ul_flag )
    wlist.ul_count--;
  wlist.len -= w->len;

  if ( w->str )
    FREEMEM(w->str);
  FREEMEM(w);
}

/* push_token takes as arguments a string and an optional underline
   string, creates a token from them and pushes it onto the current
   line's token list, and then increments the current column's
   line pointer
*/

static void push_token(TMCHAR *text,TMCHAR *uline)
{
  TOKEN *t;
  int len;

  /* first build a token with the text and (maybe) underlines */

  t=GETMEM(TOKEN,1);
  t->offset=CUR_COL->start;
  t->next=NULL;
  if (text && *text)
    {
      len=tmstrlen(text)+1;
      t->text=GETMEM(TMCHAR,len);
      tmmemcpy(t->text,text,len);
    }
  else
    t->text=NULL;
  if (uline && *uline)
    {
      len=tmstrlen(uline)+1;
      t->uline=GETMEM(TMCHAR,len);
      tmmemcpy(t->uline,uline,len);
    }
  else
    t->uline=NULL;

  /* This is a kludge to emulate RPF behavior; in short, completely
     blank lines are never printed, unless the partial contents of
     a line have already been printed due to a skip line or literal,
     and then nothing else is added to the line.  This means that
     depending on the data, a skipline(1) could result in two lines
     being skipped.  The line_used flag means that once upon a time
     the line had some tokens in it, so the print_line function will
     print it out, even if it is currently blank.  Ugly but firmly
     entrenched in dozens of programs, so here it is, reproduced for
     your pleasure.
  */

  CUR_LINE->line_used = TRUE;

  /* now add the token to the current line's token list */

  if ( CUR_LINE->first_token )
    CUR_LINE->last_token->next=t;
  else
    CUR_LINE->first_token=t;
  CUR_LINE->last_token=t;
}

/**********************************/
/* output/line handling functions */
/**********************************/

/* print_pending takes a pointer to LINE as an argument, and by calling
   print_line causes all lines up to but not including the argument line
   to be printed to the output file; after each line is printed, its
   storage is released.
*/

static void print_pending(LINE *cur_line)
{
  LINE *next_line;

  while(head_line != cur_line)
    {
      next_line=head_line->next;
      print_line();
      FREEMEM(head_line);
      head_line=next_line;
    }
}

/* print_line prints the contents of head_line to the output file, and
   frees all tokens from the line; the line itself is not freed, however
   due to weirdness with literals and skiplines
*/

static void print_line(void)
{
  TMCHAR buffer[256]={0}/*TMCI18N CHANGED FROM ""*/,ubuffer[256]={0}/*TMCI18N CHANGED FROM ""*/;
  int pos=0,upos=0;
  TOKEN *t,*next_token;

  /* trying to emulate RPF behavior with lines that were
     partially output as a result of a skipline or literal */

  if ( !head_line->first_token && !head_line->line_used )
    return;

  /* construct the buffer (text) and ubuffer (underlines) from token list */

  for ( t=head_line->first_token ; t ; )
    {
      next_token=t->next;
      if ( t->text )
        {
          addtext(buffer,t->text,t->offset,&pos);
          FREEMEM(t->text);
        }
      if ( t->uline )
        {
          addtext(ubuffer,t->uline,t->offset,&upos);
          FREEMEM(t->uline);
        }
      FREEMEM(t);
      t=next_token;
    }

  head_line->first_token=NULL;
  head_line->last_token=NULL;

  /* send the buffer(s) to output_text */

  if ( *ubuffer )
    output_text(buffer,ubuffer);
  else
    output_text(buffer,NULL);
}

/* addtext places the string pointed to by text into buffer at offset
   start; pos is updated to be the offset of the new terminating null
   of buffer.
*/

static void addtext(TMCHAR *buffer,TMCHAR *text,int start,int *pos)
{
  int diff;

  /* if start is past the current end of buffer, copy in enough blanks
     to fill in empty space
  */

  if ( start > *pos )
    {
      diff = start - *pos;
      tmmemcpy(&buffer[*pos],bl_buf,diff);
      *pos += diff;
    }
  tmstrcpy(&buffer[*pos],text);
  *pos += tmstrlen(text);
}

/* output_text takes two char pointer arguments; the first is the text
   string to be printed, and the second is an optional underline string.
   Only output_text, start_page, and end_page call print_text to write
   to the output file; even literals go through this routine so that
   page breaks, titles, and page numbering can be handled correctly.
*/

static void output_text(TMCHAR *str1,TMCHAR *str2)
{
  /* take care of the bottom margin, since we only want to go to
     a new page if there is data to go on it
  */

  if ( line_count>=pformat.bottom_margin )
    end_page();

  /* if output_text is called when line_count is zero, then do any necessary
     top of page processing */

  if ( !line_count )
    start_page();

  /* if -u switch, uppercase output */

  if ( uc_flag )
    str2uc(str1);

  /* RPF used to support a switch to reverse the order of string/underline
     (default is underlines first, then a carriage return, then the
     text.)  This was provided for devices that did not allow overstriking.
     RPF no longer supports this feature, but the -v switch does the
     same thing here.
  */

  if ( str2 )
    {
      if ( reverse_flag )
        print_text(_TMC("{0}\r{1}\n"),str1,str2);
      else
        print_text(_TMC("{0}\r{1}\n"),str2,str1);
    }
  else
    print_text(_TMC("{0}\n"),str1);
}

/* start_page takes no arguments; it is called to print page numbers,
   titles, and handle the top margin
*/

static void start_page(void)
{
  int i;

  /* skip the top margin */

  for ( i=0 ; i < pformat.top_margin ; i++)
    print_text(_TMC("\n"));

  /* print page number if turned on */

  if ( pformat.pgnum_type )
    {
      switch(pformat.pgnum_type)
        {
          case 1 : print_text(_TMC("{0}{1,number,integer}-{2,number,integer}\n"),pformat.pgnum_prefix,
                              pformat.pgnum_sect,pformat.pgnum);
                   break;
          case 2 : if ( pformat.pgnum != 1 )
                     print_text(_TMC("{0}-{1,number,integer}-"),pformat.pgnum_prefix,
                                pformat.pgnum);
                   else
                     print_text(_TMC("{0}\n"),pformat.pgnum_prefix);
                   break;
          case 3 : print_text(_TMC("{0}{1,number,integer}.\n"),pformat.pgnum_prefix,pformat.pgnum);
                   break;
          case 4 : print_text(_TMC("{0}{1,number,integer}\n"),pformat.pgnum_prefix,pformat.pgnum);
        }
      pformat.pgnum++;

      /* if title and page number both specified, skip a line between
         them; pgnum_skip blank lines follow title, if present
      */

      if ( pformat.title1 )
        print_text(_TMC("\n"));
      else
        for ( i=0 ; i<pformat.pgnum_skip ; i++ )
          print_text(_TMC("\n"));
    }

  /* print title with optional second line */

  if ( pformat.title1 )
    {
      print_text(_TMC("{0}\n"),pformat.title1);
      if ( pformat.title2 )
        print_text(_TMC("{0}\n"),pformat.title2);

      /*  if page numbering turned on, print pgnum_skip blank lines */

      if ( pformat.pgnum_type )
        for ( i=0 ; i<pformat.pgnum_skip ; i++ )
          print_text(_TMC("\n"));

      /* otherwise skip just one */

      else
        print_text(_TMC("\n"));
    }

  /* if total header info is more than pagesize then exit */

  if ( line_count > pformat.bottom_margin )
    prtmsg(LONGHDR);
}

/* end_page ends the current page by outputting either newlines or a
   formfeed to fill up the current page
*/

static void end_page(void)
{
  /* if current page is empty then call start_page to print header */

  if ( !line_count )
    start_page();

  /* now move to a new page */

  if ( ff_flag )
    {
      tmfprintf(&tmBundle, ofile,_TMC("\f"));
      tmfflush(ofile);
      CHECKIO;
    }
  else
    while ( line_count < 66 )  /* page size hardcoded, just like RPF! */
      print_text(_TMC("\n"));

  line_count=0;
}

/* print_text accepts a format string and a variable argument list, and
   uses vfprintf to send output to the output file.  A variety of house
   keeping is done, such as incrementing line counters, checking for I/O
   errors, etc.
*/

static void print_text(TMCHAR *format,...)
{
  va_list ptr;

  va_start(ptr,format);
  tmvfprintf(&tmBundle, ofile,format,ptr);

  /* flushing the output seems to be the only way to make sure that ferror
     (called in CHECKIO) picks up I/O errors in a timely fashion.
  */

  tmfflush(ofile);
  CHECKIO;

  va_end(ptr);
  line_count++;
  total_lines++;
}

/***************************/
/* miscellaneous functions */
/***************************/

/* cmdhelp is called by rptopen if an unrecognized command-line argument
   is received; no arguments, and exits with EXIT_FAILURE on completion.
*/

static void cmdhelp(void)
{
  TMCHAR *msg[]={
       TM_NLS_Get("0000","[-fiurv] [-o output_file] [userid[/password]]"),
       TM_NLS_Get("0001","       -f Formfeed for page eject"),
       TM_NLS_Get("0002","       -i Initial page eject"),
       TM_NLS_Get("0003","       -u Upper case output"),
       TM_NLS_Get("0004","       -r Generate Rpf file"),
       TM_NLS_Get("0005","       -t Turn on sql_trace"),
       TM_NLS_Get("0006","       -v ReVerse underline order (default is underline first)"),
       TM_NLS_Get("0007","       -x Extended debugging; notifies entry to each function"),
       TM_NLS_Get("0008","       -o Specify Output file"),
       NULL};
  int i;

  tmprintf(&tmBundle, TM_NLS_Get("0009","\nUsage: {0} "),exefile.name);
  for ( i=0 ; msg[i] ; tmputs(msg[i++]) );

  exit2os(EXIT_FAILURE);
}

/* get_next_line returns a LINE pointer to the next line after l; if
   l is the last line in the list a new line is created.  head_line
   is the head pointer to the current list of lines.
*/

static LINE *get_next_line(LINE *l)
{
  LINE *next_line;
  static long int next_lineno=1;

  /* need to create a new line if the argument is null (first line
     of report) or if there is no next line */

  if ( !l || (l && !l->next) )
    {
      next_line=GETMEM(LINE,1);
      next_line->lineno=next_lineno++;
      next_line->next=NULL;
      next_line->line_used=FALSE;
      next_line->first_token=NULL;
      next_line->last_token=NULL;
    }

  if ( !l )
    head_line=next_line;
  else if ( l->next )
    next_line=l->next;
  else
    l->next=next_line;

  return next_line;
}

/* literal_prep is called when literal mode is turned on or a skip_line
   is performed.  The behavior is bizarre, so stick all the kludges here
   in one place */

static void literal_prep(void)
{
  newline();
  if ( head_line->first_token )
    {
      if ( CUR_COL->last_col )
        print_pending(CUR_COL->cur_line);
      print_line();
    }
}

/* build_title takes as arguments a pointer to a character pointer, target,
   a char pointer str, and an int width.  str is formatted according
   to RPF rules for escapes, periods, etc. into dynamically allocated
   storage (address of which is placed in target,) and centered according
   to width.
*/

static void build_title(TMCHAR **target,TMCHAR *str,int width)
{
  int len,pad;
  int prev_pad=0,diff,title_len=0;
  TMCHAR *word,temp_title[256]={0}/*TMCI18N CHANGED FROM ""*/;

  /* override previous title string */

  if ( *target )
    {
      FREEMEM(*target);
      *target=NULL;
    }

  /* if str is NULL we're done */

  if ( !str )
    return;

  /* break str into words and reconstruct into temp_title; track the
     length while we're at it
  */

  word=get_rpf_word(str,&len,&pad);
  while ( word )
    {
      if ( prev_pad )
        {
          tmmemcpy(&temp_title[title_len],bl_buf,prev_pad);
          title_len += prev_pad;
        }
      prev_pad = pad;
      tmmemcpy(&temp_title[title_len],word,len+1);
      title_len += len;
      word=get_rpf_word(NULL,&len,&pad);
    }

  /* title has to fit in a line of size width */

  if ( title_len > width )
    prtmsg(LONGTTL);

  /* now center the temporary title into the target */

  diff = (width - title_len) / 2;          /* will be >= 0 */
  *target = GETMEM(TMCHAR,title_len+diff+1);
  if ( diff )
    tmmemcpy(*target,bl_buf,diff);
  tmmemcpy(*target+diff,temp_title,title_len+1);

  /* uppercase the title if -u flag specified */

  if ( uc_flag )
    str2uc(*target);
}

/* rpfprt has an int argument lf_flag to indicate whether total_lines
   should be incremented, a string argument fmt, and a variable list of
   additional arguments; vfprintf is used to send the output to the
   output file.  This function is used only if the rpf flag is turned on.
*/

static void rpfprt(int lf_flag,TMCHAR *fmt,...)
{
  va_list ptr;

  va_start(ptr,fmt);
  tmvfprintf(&tmBundle, ofile,fmt,ptr);

  /* as with print_text, flushing is the only way to insure that ferror
     gives an accurate response
  */

  tmfflush(ofile);
  CHECKIO;

  if ( lf_flag )
    total_lines++;

  va_end(ptr);
}
