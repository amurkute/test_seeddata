/* AUDIT TRAIL: 8.0                                                         */
/* TAM 10/08/2007                                                           */
/* 1. Internationalization unicode conversion                               */
/* AUDIT TRAIL: 8.1.0.1                                                     */
/* TAM 03/10/2009                                                           */
/* 1. Added OPSYS_VMS check for disable 4786 pragma.                        */
/* 2. Added \n to tmfprintf error message in                                */
/*    TMBundleArray::setSymbols(TMBundle *tmResB)                           */
/*                                                                          */
/* 8.2 Paper Fix Version of tmcilib.cpp                                     */
/*       includes fixes for defect 1-40WK37 and 1-4EEY5P                    */
/*                                                                          */
/* AUDIT TRAIL END                                                          */
/*
Implementation of TM_NLS_Get
Use C++ class TMBundleArray for Resource bundle management
(automatic open/close all the required resource bundles)
*/
#ifndef OPSYS_VMS
#pragma warning (disable : 4786)
#endif
#include <map>

#include <stdlib.h>
#ifdef _MSC_VER
#include <io.h>
#else
#include <unistd.h>
#include <errno.h>
#endif
#include <stdio.h>
#include <ctype.h>
#include "unicode/uloc.h"
#include "unicode/umsg.h"
#include "mutex.h"
#include "unicode/unistr.h"
#include "unicode/numfmt.h"
#include "unicode/uchar.h"
#include "unicode/unum.h"
#include "unicode/rbnf.h"

#include "ufile.h"
#include "tmcilib.h"
#include "umsgtm.h"

#ifdef _TMUNICODE
#include <string>
#endif

#ifndef _max
#define _max(a,b)  (((a) > (b)) ? (a) : (b))
#endif
#ifndef _min
#define _min(a,b)  (((a) < (b)) ? (a) : (b))
#endif


using namespace std;

#ifdef _DEBUG10
#define dbgmsg(n) printf("Debug %d\n",n)
#else
#define dbgmsg(n)
#endif

#define NVL( a, b) (a)?(a):(b)

/* buffer to hold Oracle Nls Data */
static struct 
{ 
	TMCHAR DATE_FORMAT[64];
	TMCHAR TIME_FORMAT[64];
	TMCHAR DATE_TIME_FORMAT[64];
} ORA_NLS = {
	{'D','D','-','M','O','N','-','Y','Y','Y','Y',0},
	{'H','H',':','M','I',':','S','S',' ','A','M',0},
	{'D','D','-','M','O','N','-','Y','Y','Y','Y',' ','H','H',':','M','I',':','S','S',' ','A','M',0}
};

extern "C" {

	TM_API TMBundle tmBundleCNum = {"tmcilib.cpp","en_US_POSIX",NULL,NULL,NULL};

	TM_API UFILE *tmstdout=u_finit(stdout, NULL,NULL);
    TM_API UFILE *tmstdin =u_finit(stdin,  NULL,NULL);
    TM_API UFILE *tmstderr=u_finit(stderr, NULL,NULL);

	TM_API TMCHAR *ORA_NLS_DATE_FORMAT=ORA_NLS.DATE_FORMAT;
	TM_API TMCHAR *ORA_NLS_TIME_FORMAT=ORA_NLS.TIME_FORMAT;
	TM_API TMCHAR *ORA_NLS_DATE_TIME_FORMAT=ORA_NLS.DATE_TIME_FORMAT;
}

static char *def_locale=NULL; 
static char locale_buf[30];
static char *def_codepage=NULL;
static char codepage_buf[30];

static UChar dummyarg[2]={0,0};

//Class to make sure all UFiles are properly closed
#define MAXUFILES 200
class UFiles {
	UFILE* openedUFile[200];
	int maxcount;
public:
	UFiles();
	~UFiles();
	void Open(UFILE* uf);
	void Close(UFILE* uf);
	void CloseAll();
};

UFiles::UFiles(){
	maxcount=-1;
	for (int i=0;i<MAXUFILES;i++)
		openedUFile[i]=NULL;
}



void UFiles::Open(UFILE* uf){
	int i;
	for (i=0;i<MAXUFILES && openedUFile[i];i++);
	if (i<MAXUFILES) {
		openedUFile[i]=uf;
		maxcount=_max(maxcount,i);
	}
	
}

void UFiles::Close(UFILE* uf){
	if (uf) {
		for (int i=0;i<=maxcount ;i++){
			if (openedUFile[i]==uf){
				u_fclose(openedUFile[i]);
				openedUFile[i]=NULL;
				return;
			}
		}
	}
}

void UFiles::CloseAll(){
	for (int i=0;i<=maxcount;i++){
		if (openedUFile[i]){
			u_fclose(openedUFile[i]);
			openedUFile[i]=NULL;
		}
	}
	maxcount=-1;
}

UFiles::~UFiles(){
	CloseAll();
}

UFiles uFiles;

// Convenience function to copy a char text to utf16 
TM_API
TMCHAR* tmcpyfromchar8(TMCHAR *dst, const TMCHAR8 *src) {
#ifdef _TMUNICODE
	if (dst==NULL) {
		static TMCHAR nuldstbuff[4096];
		return u_uastrcpy(nuldstbuff,src);		
	} else {
		u_uastrcpy(dst,src);
	}
#else
	if (dst==NULL)
		return (char*) src;
	else
		strcpy(dst,src);
#endif
	return dst;
}


#define tmprint_en printf

// Define the  'opposite' of TMCHAR 
#ifdef _TMUNICODE
#define _TMANTICHAR char
#else
#define _TMANTICHAR UChar
#endif
// Class StrMap: a container to store:
// 1. missing resource strings in TMCHAR format
// 2. Or if TMCHAR ~ char, the converted (from UChar) resource strings
class StrMap {
	typedef map< int, TMCHAR*, less<int> > BasicStrMapT;
	typedef BasicStrMapT::value_type BasicStrMapVal;
	

	BasicStrMapT Map;
public:
	void Insert(char* key, TMCHAR* str);
	TMCHAR* Get(char* key, _TMANTICHAR* deft=NULL);
	~StrMap();
};

StrMap::~StrMap() {
	BasicStrMapT::iterator it;
	for (it=Map.begin();it!=Map.end();it++){
		free(it->second);
	}
	//free all the str
}

void StrMap::Insert(char* key, TMCHAR* str){
	int keynum=atoi(key);
	
	Map.insert(BasicStrMapVal(keynum, str));
}

/* define a STRLEN that works for char and UChar */
#define STRLEN( a ) (sizeof(a[0])==1?strlen((char*)a):u_strlen((UChar*)a))

TMCHAR* StrMap::Get(char* key, _TMANTICHAR* deft){
	int keynum=atoi(key);
	BasicStrMapT::iterator it;
	#ifdef _TMUNICODE
	/* Fix issue with "x" keys */
	if ((key[0]==0 || (keynum==0 && key[0]!='0')) && deft) {
		return TM2UChar(deft);
	}
	#endif	
	if ((it=Map.find(keynum))!=Map.end()) {
		return it->second;
	}
	if (deft) {
		TMCHAR *res=(TMCHAR*)malloc( sizeof(TMCHAR) * (STRLEN(deft) +1) );
		#ifdef _TMUNICODE
			u_uastrcpy(res,deft);
		#else
			u_austrcpy(res,deft);
		#endif

		this->Insert(key,res);
		return res;
	}
	return NULL;	
}

#ifdef _TMUNICODE

/*	A second map for Unicode Strings that not need translation
	To be used for _TMC when wchar_t does not match UChar
*/
class TMCStrMap {
	typedef map< string, TMCHAR*, less<string> > BasicStrMapT;
	typedef BasicStrMapT::value_type BasicStrMapVal;
	BasicStrMapT Map;
	TMCHAR shortstr[128][2];

public:
	TMCHAR* Insert(char* key);
	TMCHAR* Get(char* key);
	//TMCHAR8* Get(UChar* key);
	TMCStrMap();
	~TMCStrMap();
};

TMCStrMap::TMCStrMap(){  
  for (int i=0;i<128;i++) {
    shortstr[i][0]=i;
    shortstr[i][1]=0;
  }
}

TMCStrMap::~TMCStrMap() {
	BasicStrMapT::iterator it;
	for (it=Map.begin();it!=Map.end();it++){
#ifdef _DEBUG10
		printf("freeing %s\n"),it->it.first);
#endif
		free(it->second);
	}
}

TMCHAR* TMCStrMap::Insert(char* key){
	int len=strlen(key);
	TMCHAR* str=(TMCHAR*)malloc(sizeof(TMCHAR) * (len +1));
	u_uastrcpy(str,key);
	Map.insert(BasicStrMapVal(key, str));
	return str;
}

TMCHAR* TMCStrMap::Get(char* key){

  static TMCHAR emptystr[1]={0}; 
  /* Short strings (<=1 char) use a simple table */

  if (key==NULL)
  	return NULL;
  else if (key[0]==0)
  	return emptystr;
  else if (false){ //( (unsigned char)key[0]<128 && key[1]==0 ) {
	//don't understand why but coredumps occur on Solaris when using this
	return shortstr[key[0]];
  }
  else 
  {
	BasicStrMapT::iterator it;
	if ((it=Map.find(key))==Map.end())
		return Insert(key);
	else
		return it->second;
  }
}

///////////////////////////////////////
class TMCStr8Map {
	typedef map< string, char*, less<string> > BasicStrMapT;
	typedef BasicStrMapT::value_type BasicStrMapVal;
	BasicStrMapT Map;
public:
	const TMCHAR8* Get(UChar* key);
	~TMCStr8Map();
};

TMCStr8Map::~TMCStr8Map() {

	/* Map stores only keys. Nothing to be free'd */
}


const TMCHAR8* TMCStr8Map::Get(UChar* key){
	BasicStrMapT::iterator it;
	char* tempkey = (char*) malloc(tmstrlen(key)+1);
	if (tempkey){
		char* result = NULL;
		u_austrcpy(tempkey,key);
		it=Map.begin();
		it=Map.insert(it,BasicStrMapVal(tempkey,NULL));
		free(tempkey);
		return it->first.c_str();
	}
	return NULL;
}


//////////////////////////////////////////////////
// Store pairs of type 8 bit string - TMCHAR* ////
//////////////////////////////////////////////////
class NamedResourceMap {
	typedef map< string, TMCHAR*, less<string> > BasicStrMapT;
	typedef BasicStrMapT::value_type BasicStrMapVal;
	BasicStrMapT Map;
public:
	const TMCHAR* Get(char* context, char* key);
	const TMCHAR* Insert(char* context, char* key, TMCHAR* val);
	~NamedResourceMap();
};

NamedResourceMap::~NamedResourceMap() {
	BasicStrMapT::iterator it;
	for (it=Map.begin();it!=Map.end();it++){
#ifdef _DEBUG10
		printf("Freeing Resource Named by %s\n"),it->it.first);
#endif
		free(it->second);
	}
}


const TMCHAR* NamedResourceMap::Insert(char* context, char* key, TMCHAR* val){
	int len=tmstrlen(val);
	TMCHAR* valstr=(TMCHAR*)malloc(sizeof(TMCHAR) * (len +1));
	// make a concatenated key.
	string ctxkey=string(context) + key;
	tmstrcpy(valstr,val);
	Map.insert(BasicStrMapVal(ctxkey, valstr));
	return valstr;
}

const TMCHAR* NamedResourceMap::Get(char* context, char* key){
	BasicStrMapT::iterator it;
	string ctxkey=string(context) + key;
	if ((it=Map.find(ctxkey))==Map.end()) {
		return NULL;
	}
	else {
		return it->second;
	}
/*
	return NULL;
*/
}

// a global instance of this class...
NamedResourceMap namedResourceMap;
// c interfaces 
extern "C"
TM_API const TMCHAR* namedResourceGet(char* context, char* key){
	return namedResourceMap.Get(context,key);
}

extern "C"
TM_API const TMCHAR* namedResourceInsert(char* context, char* key, TMCHAR* val){
	return namedResourceMap.Insert(context,key,val);
}



/////////////////////////////////////////////////////
/* 
a function to convert from TMCHAR* to char*
*/
extern "C"
TM_API TMCHAR8* tmtochar8(TMCHAR* src){
	static TMCStr8Map tmCStr8Map;
	return (TMCHAR8*) tmCStr8Map.Get(src);
}


extern "C"
TM_API TMCHAR* TM2UChar(char *str8){
	static TMCStrMap tmCStrMap;
	return tmCStrMap.Get(str8);
}

#endif //_TMUNICODE

class TMBundleArray {
	unsigned int arcnt;
	bool tm_bundle_debug;
	TMBundle* tmResBA[100];
public:
	TMBundleArray();
	~TMBundleArray();
	void Add(TMBundle *tmResB);
	void setSymbols(TMBundle *tmResB);
	void setSymbol(TMCHAR *dstsym, UChar *srcsym, UErrorCode err);

//Added for TM62EE/SR1
	RuleBasedNumberFormat *spellOut_fmt;
	char spellOut_locale[100];
};

void TMBundleArray::setSymbol(TMCHAR *dstsym, UChar *srcsym, UErrorCode err){
	if (!U_SUCCESS(err)) {
		tmfprintf(&tmBundleCNum,tmstderr,
			TM_NLS_HGet(&tmBundleCNum,"x","*ERROR* ICU failed to obtain localized number/currency format symbol for {0,%c}: {1} \n"),
			dstsym[0],
			tmcpyfromchar8(NULL, (TMCHAR8*)u_errorName(err))
		);
		return;
	}

	if (u_strlen(srcsym) > 1) {
		tmfprintf(&tmBundleCNum,tmstderr,
			TM_NLS_HGet(&tmBundleCNum,"x","*WARNING* ICU localized number/currency format symbol for ''{0,%c}''>1 character. Implementation restriction guastdf.cpp.\n"),
			dstsym[0]
		);
		return;
	}
#ifdef _TMUNICODE
	dstsym=u_strcpy(dstsym,srcsym);
#else
	dstsym=u_austrcpy(dstsym,srcsym);
#endif

}
void TMBundleArray::setSymbols(TMBundle *tmResB) {
	UNumberFormat *numFormatICU=NULL;
	int srcLen=0;
	UChar	srcBuf[TMNUMSYMBOLSIZE];
	UParseError	parseErr;
	UErrorCode	status=U_ZERO_ERROR;
	tmcpyfromchar8(tmResB->numDecSep,".");
	tmcpyfromchar8(tmResB->numGrpSep,",");
	tmcpyfromchar8(tmResB->currencySymbol,"$");

	if (tmResB->locale[0]) {
		numFormatICU=unum_open  (  
			UNUM_CURRENCY,	//UNumberFormatStyle    style,  
			NULL,			//const UChar			*pattern,  
			0,				//int32_t				patternLength,  
			tmResB->locale,	//const char			*locale,  
			&parseErr,		//UParseError			*parseErr,  
			&status			//UErrorCode			*status 
			) ; 
		if (U_SUCCESS(status)) {
			srcLen = unum_getSymbol(
				numFormatICU,
				UNUM_DECIMAL_SEPARATOR_SYMBOL,
				srcBuf,
				sizeof(srcBuf),
				&status);
			setSymbol(tmResB->numDecSep, srcBuf,status);
			srcLen = unum_getSymbol(
				numFormatICU,
				UNUM_GROUPING_SEPARATOR_SYMBOL,
				srcBuf,
				sizeof(srcBuf),
				&status);
			setSymbol(tmResB->numGrpSep, srcBuf,status);
			srcLen = unum_getSymbol(
				numFormatICU,
				UNUM_CURRENCY_SYMBOL,
				srcBuf,
				sizeof(srcBuf),
				&status);
			setSymbol(tmResB->currencySymbol, srcBuf,status);		
			
		} else {
			tmfprintf(&tmBundleCNum,tmstderr,
				TM_NLS_HGet(&tmBundleCNum,"x","*ERROR* ICU failed to open number format for locale {0}\n")
				,tmcpyfromchar8(NULL,tmResB->locale)
			);
		}
		if (numFormatICU)
			unum_close(numFormatICU);
	} else {
		tmfprintf(&tmBundleCNum,tmstderr,
			TM_NLS_HGet(&tmBundleCNum,"x","*ERROR* locale not set for resource bundle {0}")
			,tmcpyfromchar8(NULL,tmResB->bundleName)
		);
	}

}

TMBundleArray::TMBundleArray(){

	arcnt=0;
	// Get the default locale and codepage
	def_locale=getenv(RUN_LOCALE);
	tm_bundle_debug = 'Y'== ((char*)NVL(getenv("TM_BUNDLE_DEBUG"),"N"))[0];

	if (!def_locale){
		def_locale=(char*)uloc_getDefault();
		if (def_locale) {
			strcpy(locale_buf, uloc_getDefault());
			def_locale=locale_buf;
		}
	}
	def_codepage=getenv(RUN_CODEPAGE);
	if (!def_codepage){
		//set tmstdin to the default codepage
		u_fsetcodepage( NULL, tmstdin);
		def_codepage=(char*)u_fgetcodepage(tmstdin);
		if (def_codepage){
			strcpy(codepage_buf,def_codepage);
			def_codepage=codepage_buf;
		}
	}
	{
		char *env;
		if (env=getenv("NLS_DATE_FORMAT")) {
			#ifdef _TMUNICODE
			u_uastrcpy(ORA_NLS_DATE_FORMAT,env);
			#else
			strcpy(ORA_NLS_DATE_FORMAT,env);
			#endif
		}
		if (env=getenv("NLS_TIME_FORMAT")) {
			char buf[256];
			char *b=buf ,*e=env;
			/* Remove fractional seconds. */
			for (;*e && b-buf<sizeof(buf)-1; e++) {
				if (toupper(*e)=='X' || toupper(*e)=='F')
					;
				else
					*b++=*e;
			}
			*b=0;
			#ifdef _TMUNICODE
			u_uastrcpy(ORA_NLS_TIME_FORMAT,buf);
			#else
			strcpy(ORA_NLS_TIME_FORMAT,buf);
			#endif
			tmstrcpy(ORA_NLS_DATE_TIME_FORMAT,ORA_NLS_DATE_FORMAT);
			tmstrcat(ORA_NLS_DATE_TIME_FORMAT,tmcpyfromchar8(NULL," "));
			tmstrcat(ORA_NLS_DATE_TIME_FORMAT,ORA_NLS_TIME_FORMAT);
		}		
	}


	spellOut_fmt=NULL;
	spellOut_locale[0]=(char)0;
	if (tm_bundle_debug) {
		puts("Constructor of TMBundleArray");
		printf("Locale=%s Codepage=%s\n",def_locale,NVL(def_codepage,"<NULL>"));
	}
	this->Add(&tmBundleCNum); //Add the bundle now so it always has index 0
}

TMBundleArray::~TMBundleArray(){
	if (tm_bundle_debug) 
		puts("\nDestructor of TMBundleArray");

	for (unsigned int i=0;i<arcnt;i++){
		if (tmResBA[i]->uResB)
			ures_close(tmResBA[i]->uResB);
		if (tm_bundle_debug && i)
			printf("Closed ResourceBundle %d %s \n",i, NVL(tmResBA[i]->bundleName,""));
	
		delete (StrMap*)tmResBA[i]->strmap;
	}
	if (spellOut_fmt)
		delete spellOut_fmt;
}

void TMBundleArray::Add(TMBundle *tmResB){
	
	UErrorCode		 status = U_ZERO_ERROR;
	if (!tmResB->locale)
		tmResB->locale=def_locale;
	if (!tmResB->codepage)
		tmResB->codepage=def_codepage;
	
	tmResB->uResB = ures_open(tmResB->bundleName, tmResB->locale ,&status);
	if(U_SUCCESS(status) && tmResB->uResB != NULL) {
		;//Do nothing
	}
	else {
		if (tm_bundle_debug && tmResB!=&tmBundleCNum ){ // don't print a warning for missing this bundle
			printf("Error opening resource bundle %d %s_%s: %s\n",
				   arcnt,tmResB->bundleName,tmResB->locale,u_errorName(status));
		}
		if (tmResB->uResB) {	 
			ures_close(tmResB->uResB);
			if (tm_bundle_debug)
				printf("Closed ICU bundle with address: %p\n",tmResB->uResB);
		}
		tmResB->bundleName=NULL; // prevent multiple attempts to open
	}
	tmResBA[arcnt++]=tmResB;
	tmResB->strmap = (void*) new StrMap;
	if (strcmp(tmResB->locale, NVL(u_fgetlocale(tmstdin),"")))	{	
		u_fsetlocale(tmstdout,tmResB->locale);
		u_fsetlocale(tmstdin,tmResB->locale);
		u_fsetlocale(tmstderr,tmResB->locale);
	}
	u_fsetcodepage(tmResB->codepage,tmstdout);
	u_fsetcodepage(tmResB->codepage,tmstdin);
	u_fsetcodepage(tmResB->codepage,tmstderr );
	setSymbols(tmResB);
	if (tm_bundle_debug) {		
		fflush(stdout);
		if (arcnt==1) {
			tmprintf(&tmBundleCNum,tmcpyfromchar8(NULL,"ORA_NLS_DATE_FORMAT={0}\n"),ORA_NLS_DATE_FORMAT);
			tmprintf(&tmBundleCNum,tmcpyfromchar8(NULL,"ORA_NLS_TIME_FORMAT={0}\n"),ORA_NLS_TIME_FORMAT);
		} else {
			printf("Initialized ResourceBundle %d %s\n",arcnt-1,NVL(tmResB->bundleName,""));
		}
		fflush(stdout);
	}
}

static TMBundleArray TMBundles;

/* 
The main message routine. Returns a TMCHAR* result, which is either UChar* or char*,
depending on a switch.

  A problem is that two conversions are required when not in Unicode mode, because we want to 
  make use of the ICU Resource bundle mechanism and Message formatting routines.
  
*/
extern "C" TM_API TMCHAR* 
TM_B_NLS_Get(TMBundle *tmResB, char* numkey, char* strkey) {
	int32_t		resource_length=0;
	UErrorCode	status = U_ZERO_ERROR;	
	//const char *loc;
	UChar  *ures=NULL;	
#ifdef _DEBUG10    
    printf("Called TM_B_NLS_Get(...,%s,...)\n", strkey);
#endif
	if (tmResB->uResB == NULL) {
		if (tmResB->bundleName!=NULL) {
			TMBundles.Add(tmResB);	
			// Issue first get didn't get translation
			if (tmResB->uResB)
				ures = (UChar*) ures_getStringByKey(tmResB->uResB, numkey, &resource_length, &status);
		}
	}
	else {
		//Why get loc? It is never used. Is it to set the status?
		//Comment it out.
		//loc=ures_getLocale(tmResB->uResB, &status);
		//get a pointer to the string that lives somewhere in mem until the bundle is closed
		ures = (UChar*) ures_getStringByKey(tmResB->uResB, numkey, &resource_length, &status);
	}

	if (ures==NULL || ! U_SUCCESS(status)|| ures[0]==0) {
		#ifdef _DEBUG10
			printf ("Returning Default string %s\n", strkey);
		#endif
		#ifdef _TMUNICODE
			//Get Unicode version from Map (insert first if needed)
			ures=((StrMap*)tmResB->strmap)->Get(numkey,strkey);
			return ures;
		#else
			return strkey;
		#endif
	}
	#ifdef _DEBUG10
		printf("Got resource %s from bundle length=%d, ures=",numkey,resource_length);
		u_fputs(ures, tmstdout);
			fflush(u_fgetfile(tmstdout));
		printf("\n");
	#endif
	#ifdef _TMUNICODE
		return ures;
	#else
		return ((StrMap*)tmResB->strmap)->Get(numkey,ures);
    #endif
}

//#include "unicode/ucnv.h"
extern "C" TM_API UChar** args2UChar_open(int argc, const char** argv, char* codepage) {
	UErrorCode status=U_ZERO_ERROR;
	UConverter *conv;
	UChar *target;
	int i,len;
	UChar **newargs = new UChar*[argc+1]; //needs to be deleted
	conv=ucnv_open(codepage, &status);
	for ( i=0;i<argc;i++){
		len=strlen(argv[i]);
		target= new UChar[len+1];
		status=U_ZERO_ERROR;
		len = ucnv_toUChars(conv, target, len+1, argv[i], len, &status);
		target[len]=0;
		if(U_FAILURE(status)) {
			printf("Error %s converting command line argument to UChar: %s",u_errorName(status),argv[i]);
			newargs[i]=dummyarg;
			printf("\n	conv  = %p\n",conv);
			printf("\n	target= %p\n",target);
			printf("\n	len   = %d\n",len);
		}
		else {
			newargs[i]=target;
		}
	}
	newargs[i]=NULL;
	ucnv_close(conv);
	return newargs;
}

extern "C" TM_API void args2UChar_close(int argc, UChar** argv) {
	for (int i=0;i<argc;i++){
		if (argv[i])
			delete argv[i];
	}
	delete argv;
}

//////// 

extern "C" TM_API int 
tmprintf(struct TMBundle *tmResB, const TMCHAR * pattern, ...){
	// Maybe need to switch copepage for stdout?
	va_list argptr/*=NULL*/;
	va_start(argptr, pattern);
	int32_t		 		 actual_length=tmvfprintf(tmResB,tmstdout,pattern,argptr);
	va_end(argptr);
    return actual_length;
}

extern "C" TM_API int 
tmvprintf(struct TMBundle *tmResB, const TMCHAR * pattern, va_list argptr){
	return tmvfprintf(tmResB,tmstdout,pattern,argptr);
}

extern "C" TM_API int 
tmfprintf(struct TMBundle *tmResB, UFILE *ustream, const TMCHAR * pattern, ...){
	va_list argptr /*=NULL*/;
	va_start(argptr, pattern);
	int32_t		 		 actual_length=tmvfprintf(tmResB,ustream,pattern,argptr);
	va_end(argptr);
    return actual_length;
}

extern "C"  TM_API int 
tmvfprintf(struct TMBundle *tmResB, UFILE *ustream, const TMCHAR *pattern, va_list argptr){
      int32_t           actual_length=0,max_length, resource_length;
      UErrorCode  status = U_ZERO_ERROR;
      TMCHAR            *ubuf;
      if (tmResB->uResB == NULL && tmResB->bundleName!=NULL){
            TMBundles.Add(tmResB);
      }
      const unsigned int minPatLength=3;
      status = U_ZERO_ERROR;
      resource_length=tmstrlen(pattern);
      if (resource_length <minPatLength) { //short string cannot contain a {...} pattern
            ubuf=(TMCHAR*) pattern;
            actual_length=resource_length;
      } else {            
            #ifdef _NOFIXARGPTR
              #ifdef va_copy
                 //If not defined we have a problem - let compiler complain, then need to find another macro that copies a va_list
                 va_list argptr2;
                 va_copy(argptr2,argptr);
                 #define APCPY argptr2
              #endif
            #else
              #define APCPY argptr
            #endif 
            max_length = resource_length+256;
            ubuf = (TMCHAR*) malloc(max_length * sizeof(TMCHAR));
            actual_length=tmu_vformatMessage(   
                  tmResB->locale, pattern, resource_length,
                  ubuf,
                  max_length,       argptr, &status);
            if (status== U_BUFFER_OVERFLOW_ERROR) {
                  TMCHAR *tmp;
                  status=U_ZERO_ERROR;
                  max_length=actual_length+1;
                  //next gives warning: cast to pointer from integer of different size but no clue how to get rid of it.
                  //realloc seems to return integer not void * as it is supposed to do.
                  tmp = (TMCHAR*) realloc(ubuf, max_length * sizeof(TMCHAR) );
                  if (tmp) {
	                  ubuf=tmp;
	                  actual_length=tmu_vformatMessage(   
	                        tmResB->locale, pattern, resource_length,
	                        ubuf,
	                        max_length,       APCPY, &status);
	               }
            }
              
            #ifdef _NOFIXARGPTR
               va_end(APCPY);
            #endif
      }
#ifdef _TMUNICODE
      actual_length=u_file_write(ubuf,actual_length, ustream);
#else
      if (tmfputs(ubuf,ustream)<0)
            actual_length=0;
#endif
      if (resource_length >= minPatLength) // We did malloc a buffer. Free it.
            free(ubuf);
      return actual_length;
}

extern "C"  TM_API int 
tmsprintf(struct TMBundle *tmResB, TMCHAR *buffer, const TMCHAR *pattern, ...){
	va_list argptr /*=NULL*/;
	va_start(argptr, pattern);
	int32_t	actual_length=tmvsprintf(tmResB,buffer,pattern,argptr);
	va_end(argptr);
    return actual_length;
}

extern "C"  TM_API int 
tmvsprintf(struct TMBundle *tmResB, TMCHAR *buffer, const TMCHAR *pattern, va_list argptr){
	int32_t		actual_length=0,max_length, resource_length;
	UErrorCode	status = U_ZERO_ERROR;
	if (tmResB->uResB == NULL && tmResB->bundleName!=NULL){
		TMBundles.Add(tmResB);
	}
	status = U_ZERO_ERROR;
	resource_length=tmstrlen(pattern);
	if (resource_length <3) { //short string cannot contain a {...} pattern
   		actual_length=resource_length;
   		tmstrcpy(buffer,pattern);
	} else {	
		// I think max_length=-1 leads to bug.
		max_length = (1<<30); // just go for a positive big number	
		actual_length=tmu_vformatMessage(   
			tmResB->locale, pattern, resource_length,
			buffer,
			max_length, argptr, &status);
	}	
	return actual_length;
}

extern "C"  TM_API UFILE*
tmfopen(struct TMBundle *tmResB, const TMCHAR *filename,const TMCHAR *perm){
	UFILE* f;

#ifdef _TMUNICODE
	char *fn, *pm;
	char fnbuf[FILENAME_MAX];
	char pmbuf[20];
	fn=u_austrcpy(fnbuf,filename);
	pm=u_austrcpy(pmbuf,perm);
#endif

	if (tmResB->uResB == NULL && tmResB->bundleName!=NULL){
		TMBundles.Add(tmResB);
	}
#ifdef _TMUNICODE
	f=u_fopen(fn,pm, tmResB->locale, tmResB->codepage);
#else
	f=u_fopen(filename,perm, tmResB->locale, tmResB->codepage);
#endif

	//Maybe write a BOM if encoding is UTFxx?
	if (f)
		uFiles.Open(f);
	return f;
}

extern "C"  TM_API void
tmfclose(UFILE* f){
	uFiles.Close(f);
}

extern "C"  TM_API void
tmfcloseall(){
	uFiles.CloseAll();
}


extern "C" TM_API int
tmferror(UFILE* f){
	return ferror(f->fFile);
}



#ifdef _MSC_VER
#define fileno _fileno
#define isatty _isatty
#endif
extern "C" TM_API TMCHAR*
tmfgets(TMCHAR* s,int n, UFILE* f){
#ifdef _TMUNICODE

	//Not Sure if still a problem. Lets try u_fgets again
	//#define tmfgets(us,n,f) u_fgets(f,n,us)
	if (!isatty(fileno(u_fgetfile(f))))
		return u_fgets(s,n,f);
	else // need to be better, but for now ...
	{   
		FILE* cf=u_fgetfile(f);
		wchar_t *wbuf,*wres;
		int i;
		wbuf=new wchar_t[n+1];
		wres=fgetws(wbuf,n,u_fgetfile(f));
		for (i=0; wbuf[i] && i<n ;i++) {
			s[i]=wbuf[i];
		};
		s[i]=0;
		/* got characters from terminal. Do we need to convert anything still?*/
		delete wbuf;
		if (feof(cf))
			return NULL;
		else
			return s;
        //return fgetws(s,n,u_fgetfile(f));
	}

#else
	return fgets(s,n,u_fgetfile(f));
#endif
}

#ifdef _TMUNICODE
extern "C" TM_API void 
tmperror(TMCHAR* msg){
	int tmperrno=errno;
	if ((msg) && msg[0])
		tmfputs(msg,tmstderr);
	/* maybe better to convert strerror to unicode first and use tmfputs?*/
	fputs(strerror(tmperrno),stderr);
}

/* convert. Allow source and dst to be the same by using a temp buffer */
extern "C" TM_API TMCHAR* tmfromchar8(TMCHAR* dst, const TMCHAR8 *src, const int len_in) {
	static TMCHAR tempbuf[1024];
	int len=len_in;
	if (len<=0) {
		len=strlen(src);		
	}
	if ((void*)dst==(void*)src) {
		if (len> (sizeof tempbuf)/(sizeof tempbuf[0]) -1 )
			len=(sizeof tempbuf)/(sizeof tempbuf[0])-1;
		u_uastrncpy(tempbuf,src,len);
		u_strncpy(dst,tempbuf,len);
	}
	else { // assume no overlap (not sure if u_strncpy can handle)
		u_uastrncpy(dst,src,len);
	}
	dst[len]=0;
	return dst;
}




extern "C" TM_API TMCHAR* 
tmstrrchr(const TMCHAR* instr, TMCHAR inch){
	/*	Could do a mapping to ICU function, but do an implementation in this
		release to avoid the need for recompilation of existing code.
	*/
	return u_strrchr(instr,inch);
}
/* strtok replacement making use of ICU u_strtok_r
because of the static sState it is not safe to call other routines with tmstrtok
(but that is the same with strtok)
*/
extern "C" TM_API TMCHAR* 
tmstrtok(UChar *src, const UChar *delim){
	static UChar *sState;
	return u_strtok_r(src, delim, &sState);
}


/* Internationalised strtol */
extern "C" TM_API long
tmstrtol( const TMCHAR *nptr, TMCHAR **endptr, int base ){
	char charbuf[256];
	char *endptrc;
	long result;
	int i;
	// Copy the  nptr to a char buffer transforming digits into ascii if needed
	for (i=0; nptr[i] && i<255;i++) {
		if (nptr[i]<128) { // ascii char, just copy
			charbuf[i]=(char) nptr[i];
		} else { // use ICU to transform into a ascii digit
			charbuf[i]=u_forDigit(u_digit(nptr[i],base),base);
		}
	}
	if (i<256)
		charbuf[i]=0;
	else
		charbuf[255]=0;
	result=strtol(charbuf,&endptrc,base);
	*endptr= (TMCHAR*) nptr+(endptrc-charbuf);
	return result;
}
/* Internationalised strtoul - almost a copy of previous function.*/
extern "C" TM_API unsigned long
tmstrtoul( const TMCHAR *nptr, TMCHAR **endptr, int base ){
	char charbuf[256];
	char *endptrc;
	unsigned long result;
	int i;
	// Copy the  nptr to a char buffer transforming digits into ascii if needed
	for (i=0; nptr[i] && i<255;i++) {
		if (nptr[i]<128) { // ascii char, just copy
			charbuf[i]=(char) nptr[i];
		} else { // use ICU to transform into a ascii digit
			charbuf[i]=u_forDigit(u_digit(nptr[i],base),base);
		}
	}
	if (i<256)
		charbuf[i]=0;
	else
		charbuf[255]=0;
	result=strtoul(charbuf,&endptrc,base);
	*endptr= (TMCHAR*) nptr+(endptrc-charbuf);
	return result;
}

/* 
return value of UChar digit for most languages in the world
assume hexadecimal notation will use ascii A-F / a-f for digits between 10 and 15
*/
#define C_MINUS	-1
#define C_PLUS	-2
#define C_NOT_A_DIGIT -3

int digitval(UChar c,int base=10){
	static UChar plus[]	={0x2b,0};
	static UChar minus[]={0x2d,0};
	int val=-1;
	val=u_digit(c,base);
	if (0<=val && val<base)
		return val;
	if (tmstrchr(minus,c))
		return C_MINUS;
	if (tmstrchr(plus,c))
		return C_PLUS;

	return C_NOT_A_DIGIT;
}




/* atoi replacement. TODO return 0 when conversion error */
extern "C" TM_API int
tmatoi(const TMCHAR* nstr){
	int sign=1;
	int dig=C_NOT_A_DIGIT;
	int result=0;
	bool found_digit=false;
	TMCHAR *c=(TMCHAR*) nstr;
	for (;*c && !(found_digit && dig==C_NOT_A_DIGIT);c++){
		dig=digitval(*c,10);
		switch (dig){
		case C_MINUS:
			if (!found_digit)
				sign=-sign;
			break;
		case C_PLUS:
		case C_NOT_A_DIGIT:
			break;
		default:
			result=10*result+dig;
			found_digit=true;
			break;
		}
	}
	if (sign==1)
		return result;
	return -result;
}

extern "C" TM_API long 
tmatol(const TMCHAR* nstr){
	int sign=1;
	int dig=C_NOT_A_DIGIT;
	long result=0L;
	bool found_digit=false;
	TMCHAR *c=(TMCHAR*) nstr;
	for (;*c && !(found_digit && dig==C_NOT_A_DIGIT);c++){
		dig=digitval(*c,10);
		switch (dig){
		case C_MINUS:
			if (!found_digit)
				sign=-sign;
			break;
		case C_PLUS:
		case C_NOT_A_DIGIT:
			break;
		default:
			result=10*result+dig;
			found_digit=true;
			break;
		}
	}
	if (sign==1)
		return result;
	return -result;
}

/* to interpret string floats a locale is required so use tmResB*/
extern "C" TM_API double
tmatof(struct TMBundle *tmResB, const TMCHAR* nstr){
	static TMCHAR flpat[]={'%','l','f',0} /*%lf*/;
	TMCHAR* start;
	TMCHAR buf[64];
	double res=0;
	
	// u_sscanf_u fails on a '+'. Ignore it
	for (start=(TMCHAR*) nstr; *start==' '||*start=='\t' || digitval(*start)==C_PLUS; start++);

	//create a copy of the string as u_fclose gives a memory violation otherwise
	tmstrncpy(buf,start,tmcharsizeof(buf)-1);		
	UFILE* uf=u_fstropen(buf,tmcharsizeof(buf)-1,tmResB->locale);
	if (uf) {
		u_fscanf_u(uf,flpat,&res);
		u_fclose(uf);
	}
	return res;
}

#else // !_TMUNICODE ...

extern "C" TM_API int  
tmfputs(const char* s,UFILE* f){
	int n=strlen(s);
	UChar* us=new UChar[n+1];
	if (us) {
		us=u_uastrcpy(us,s);
		n=u_file_write(us, n, f);
		delete us;
		return n;
	}
	return -1;
}

#endif  //_TMUNICODE

#ifdef _TMUNICODE
extern "C" TM_API int tmsystem(TMCHAR* ucomd){
	int res=0;
	int len=tmstrlen(ucomd)+1;
	char *comd=new char[len];
	if (comd) {
		u_austrcpy(comd,ucomd);
		res=system(comd);
		delete comd;
		return res;
	}
	return 1;
}
#endif

// TM62EE/SR1

//Function to spell out a number.
//Assume txt_out is long enough to contain the result.
//There is no size checking.
extern "C" TM_API 
TMCHAR* spellOutNumber(struct TMBundle *tmResB, double num_in, TMCHAR *txt_out)
{
	UErrorCode status=U_ZERO_ERROR;
	UnicodeString result;
	if (TMBundles.spellOut_fmt==NULL || strcmp(TMBundles.spellOut_locale,tmResB->locale))
	{
		if (TMBundles.spellOut_fmt!=NULL) //Means locale has changed. Drop the old formatter.
			delete TMBundles.spellOut_fmt;
		TMBundles.spellOut_fmt= new RuleBasedNumberFormat(URBNF_SPELLOUT, Locale(tmResB->locale), status);
		if (U_FAILURE(status)) {
			printf("*ERROR* No spell out method available for %s\n",tmResB->locale);
			return NULL;
		}
		strcpy(TMBundles.spellOut_locale,tmResB->locale);
		/* Try to set to simplified  will use default when not available */
		TMBundles.spellOut_fmt->setDefaultRuleSet("%simplified", status);
		status=U_ZERO_ERROR;
	}

	TMBundles.spellOut_fmt->format(num_in,result,status);
#ifdef _TMUNICODE
	result.extract(txt_out,result.length(),status);
#else
	result.extract(0,result.length(),txt_out);
#endif
	txt_out[result.length()]=(TMCHAR)0;
	return txt_out;
}

extern "C" TM_API 
TMCHAR* spellOutNumStr(struct TMBundle *tmResB, TMCHAR *numstr_in, TMCHAR *txt_out)
{
	/* 
	Precision is limited to ~ 15 digits. Will not bother for now. 
	Banner spell out method returns wrong results for much smaller numbers.
	*/
	double d_num=tmatof(&tmBundleCNum,numstr_in);
	return spellOutNumber(tmResB,d_num,txt_out);
}

