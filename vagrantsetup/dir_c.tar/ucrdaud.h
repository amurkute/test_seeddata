/* Copyright (c) SCT Corporation 1995.  All rights reserved.              */
/*                                                                        */
/* UCRDAUD.H                                   19-MAY-1995                */
/*                                                                        */
/* Deposit Audit Listing -- Header File                                   */
/*                                                                        */
/* AUDIT TRAIL                                        INIT     DATE       */
/* -------------------------------------------------  ----  -----------   */
/* Release: 1.0                                                           */
/*                                                                        */
/* 1.  Initial Version                                EBR   19-MAY-1995   */
/*                                                                        */
/* AUDIT TRAIL: 8.0 */
/* AUDIT TRAIL END */
#ifndef UCRDAUD_INCLUDED
#define UCRDAUD_INCLUDED

   /*  Define UCRDTRN transaction types  */

#define CREATED          '1'
#define COLLECTED        '2'
#define REFUNDED_DEP     '3'
#define APPLIED_DEP      '4'
#define ACCUM_INT        '5'
#define REFUNDED_INT     '6'
#define APPLIED_INT      '7'
#define TRANSFERRED_FROM '8'
#define TRANSFERRED_TO   '9'

   /* Local function prototypes */

   static void  bal_header(void);
   static char *mvdash(char *, char *);
   static int   retrieve_parms(void);
   static void  print_amt(float, char, char);
   static void  headings(int);
   static int   validate_date(void);
   static void  cmdhelp(void);
   static char  DepositTransfer(long, long, char *, long, double);
   static void  InitHostVars(void);

#endif
