/* AUDIT TRAIL:8.0 */
/* AUDIT TRAIL END */
/* ***************************************** */
/*                 guaprod.h                 */
/* generated on Sat Jul 31 13:33:37 EDT 1999 */
/* ***************************************** */
#define ALUMNI
#define ALUWEB
#define ARSYS
#define BANINAS
#define EXEWEB
#define FACWEB
#define FINAID
#define FINANCE
#define GENERAL
#define GENWEB
#define HELP
#define IMAGING
#define INFOACC
#define INHOUSE
#define JOBSUB
#define MICRFAID
#define PAYROLL
#define PAYWEB
#define POSNCTL
#define SCOMWEB
#define STUDENT
#define STUWEB
#define UTLFILE
#define VRBRITE
#define VREPOS
#define VRSTUDENT
#define WF
#define WINFMT
#define WTLWEB
/* ***************************************** */
/*              guaprod.h - end              */
/* ***************************************** */
