/*****************************************************************************/
/* HWGAWBIS.H  Copyright (c) SCT Corporation 1996.  All rights reserved      */
/*****************************************************************************/

              /***************************************************/
              /*                                                 */
              /*       CONFIDENTIAL BUSINESS INFORMATION         */
              /*                                                 */
              /*      **********************************         */
              /*                                                 */
              /*  THIS PROGRAM IS PROPRIETARY INFORMATION OF     */
              /* SYSTEMS AND COMPUTER TECHNOLOGY CORPORATION     */
              /* AND IS NOT TO BE COPIED, REPRODUCED, LENT OR    */
              /* DISPOSED OF, NOR USED FOR ANY PURPOSE OTHER     */
              /* THAN THAT FOR WHICH IT IS SPECIFICALLY PROVIDED */
              /* WITHOUT THE WRITTEN PERMISSION OF SAID COMPANY  */
              /*                                                 */
              /***************************************************/

/*****************************************************************************/
/* HWGAWBIS.H                                                                */
/*                                                                           */
/* BANNER Web Page Generation Routines Header File                           */
/*                                                                           */
/* AUDIT TRAIL: 2.1.7                                         INIT    DATE   */
/* _________________________________________________________  ____  ________ */
/* 1. New header file for hwgawbis.pc                         KAS   04/11/96 */
/*                                                                           */
/* AUDIT TRAIL: 2.1.11                                        INIT    DATE   */
/* _________________________________________________________  ____  ________ */
/* 1. Modified close_html_doc and print_info                  KAS   04/11/96 */
/*                                                                           */
/* AUDIT TRAIL : 8.0 (I18N) *//* AUDIT TRAIL END                                                           */
/*                                                                           */
/* ************************************************************************* */

/* Local prototypes */

void   close_html_doc(FILE *fp, char *release_no);
char   *format_time(char *time_str);
int    instr(char *str1, char *str2);
void   open_html_doc(FILE *fp, char *name, 
                                   char *title_text, char *header_text);
void   print_info(FILE *fp, char *name, char *label_str);

