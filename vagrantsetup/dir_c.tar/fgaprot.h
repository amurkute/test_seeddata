/*TMCI18N BEGIN HEADER*/
#if !defined( _TMBFGAPROT_H_EXISTS )
/* No Initialisation Required */                                               
#include "tmcilib.h"
static struct TMBundle _TMBFGAPROT_H = {"fgaprot.h",NULL,NULL,NULL,NULL};
#define _TMBFGAPROT_H_EXISTS
#endif
/*TMCI18N END HEADER*/

/* AUDIT_TRAIL_MSGKEY_UPDATE
-- PROJECT : MSGKEY
-- MODULE  : FGAPROT
-- SOURCE  : enUS
-- TARGET  : I18N
-- DATE    : Thu Jun 27 08:00:56 2013
-- MSGSIGN : #0000000000000000
END AUDIT_TRAIL_MSGKEY_UPDATE */

/* AUDIT_TRAIL_TM63
-- TranMan 6.3 
-- PROJECT : HEGDE_I18N
-- MODULE  : FGAPROT
-- SOURCE  : enUS
-- TARGET  : I18N
-- DATE    : Wed Oct 10 02:49:16 2007
END AUDIT_TRAIL_TM63 */
/*
   Copyright 1994-2013 Ellucian Company L.P. and its affiliates.
*/
/*UnicodeSedFixed*/
/*UnicodeSedFixed*/
/***************************************************************************/
/* Audit Trail: 2.0                                                        */
/* Added New variables for posting and related pieces.  SP 12/09/94        */
/* Audit Trail: 2.0.2                                                      */
/* Added New variables for posting and related pieces.  SP 12/11/94        */
/* Audit Trail: 2.0.4                                                      */
/* Added is_discount variable for stores             DG/SP 04/21/95        */
/* Audit Trail: 2.0.5
   Added cnec_processed variable for credit memo check cancellation.
   Added grant_posting variable for grant reversals during check cancellation.*/
/* Audit Trail:  2.0.7
   Added variables for stores check cancellation and O030 rewrite   LR      */
/* Audit Trail: 2.1.11
   copied from the 2.0.7 version of posting   */
/* Audit Trail: 3.0
 1. Signoff ....... Lakshmi Radhakrishnan 10-FEB-1997
    Mods.....Full Compliance - year 2000
             1. Removed declaration of variables post_grnt_yr,hold_grnt_yr,
                grant_month, trans_month and grant period and added to
                fgppdoc module of posting.
            */
/* Audit Trail: 3.1
 1. Signoff ... Anandhi Pitchai   03-JUL-1997
    Mods....... Added  variables for Grants enhancement
                sysc_defer_grant_ind, grant_rate_acct_exists,grant_exists,
                fgbtrnd_defer_grant_ind
2. Signoff...Lakshmi Radhakrishnan 30-oct-1997
   Mods......ABAL rewrite enhancement. Removed all abal related functions.
             added function abal_do_nsf with parameters.
            */
/* Audit Trail: 4.0
 1. Signoff ....... Jeff Chen 11-JUN-1998
    Mods.....Grant Billing Enhancement
             1. Added procedure exec_doc_gbill() for Grant Billing.

 2. Signoff.....Lakshmi Radhakrishnan 10-AUG-1998
    Mods.....Encumbrance open close document
            1. Added function doc_exec_eocd
            2. do_eocd_doc_reset
 3. Signoff....Lakshmi Radhakrishnan 19-oct-98
    Mods.......ACH mods. Change ftvbank to gxvbank .
*/
/* Audit Trail: 4.0.1
   for EMS project
   Signoff...Xiaoyuan Liu 6-Apr-99
   1. add two variable sp_gift_date and sp_emc_units
   2. add a new function ins_fnbuntd insert transaction into fnbuntd table
*/
/* Audit Trail: 4.1
   for internal defect 41-0050
   Signoff...Tom Rayer 3-Dec-99
   1. compile errors
   2. add a new function ins_fnbuntd insert transaction into fnbuntd table
*/
/* Audit Trail: 5.0 */
/* Audit Trail: 5.3.1
   1. Fixed assets modifications LR 2/14/02
*/
/* Audit Trail: 6.0                                                        */
/* 1. Defect....None                                                       */
/* Signoff.....Srivalli Pillutla 4/23/03                                   */
/* Problem.... Compile Warning on Currdate size.                           */
/* Fix.........Commented out currdate nd currtime. MAy be reserved words.  */
/*               and Not being used anyway.                                */
/* AUdit Trail: 7.3
  1. Signoff....Lakshmi Radhakrishnan 31-aug-2006
     Modifications...Adding new function local_postora_api and variable j
                     for use in local_postora_api.
*/
/* Audit Trail: 8.0
   1. BGourlie  01-OCT-2007
      Added sp_encb_origin to carry Req and PO Origin Code to Encumbrance 
      Data Origin.
*/
/* Audit Trail:8.0 (i18n)
   1. Internationalization Unicode Conversion */

/* Audit Trail: 8.9
   1.  Signoff...Pradeep Kumar Mallapuram     25-Jun-2013
       RPE.......1-G32Z5
       Problem...Encumbering F&A indirect costs
       Fix.......Added below listed global variables :
                 - post_other_data to store the value 
                 for FGBTRND_OTHER_DATA column and 	
                 - src_doc_rucl_code to store the IDCED source
                 document rule code to exclude from Grant ledger.
*/       

/* Audit Trail: 8.10.1.7
   1.  Signoff...Anandhi Pitchai     15-Jun-2016
       RPE.......CR-000139298
       Problem...FGRACTG not posting individual amounts from purchase orders created from requisitions 
                 when there are multiple commodity line items.
       Fix.......Added below listed global variables :
                 - sp_trans_nonbase_amt
                 - req_liq_foreign_curr_ind
                 indicator set for POLQ rule and the document is in foreign currency
*/       

/* Audit Trail End.                                                        */
/***************************************************************************/

#ifndef _FGRACTG_C_
#define STORE_CLASS extern
#else
#define STORE_CLASS /* */
#endif

#define NEG(NUM) ((*NUM) == '-' ? 1 : 0)
#define ABSNSTR(NUM) multiply(NUM,NUM, (NEG(NUM) ? _TMC("-1") : _TMC("1")) )

#define prot_rel_ver _TMC("8.9")

EXEC SQL BEGIN DECLARE SECTION;


  STORE_CLASS BANNUMSTR(ask_one_up_no_var);

  STORE_CLASS TMCHAR  date_var[26];
/* Commented out due to compile warning. Currdate may be a reserved word.*/
/* These vars are not being used anywhere anyway. Sri 4/24/03 */
/*  STORE_CLASS TMCHAR   currdate[9],
    currtime; */

  STORE_CLASS BANNUMSTR(linelimit);
                      STORE_CLASS BANNUMSTR(one);
                      STORE_CLASS BANNUMSTR(pageno);
  STORE_CLASS int count;
  STORE_CLASS TMCHAR  post_it[2];
  STORE_CLASS int j;

/* Application variables */
/*                       */
/*  Gubinst variables    */

  STORE_CLASS TMCHAR   gubinst_operating_system_ind[4];

/* Ask variable to control looping for new wake-up */

  STORE_CLASS TMCHAR   continue_sw[2];

/*  APPD VARIABLES */

  STORE_CLASS BANNUMSTR(fobappd_seq_code);
  STORE_CLASS TMCHAR  fobappd_doc_num[16];
  STORE_CLASS BANNUMSTR(fobappd_seq_num);
  STORE_CLASS TMCHAR   fobappd_bank_num[4];
  STORE_CLASS TMCHAR  fobappd_activity_date[15];

/* Rule Process variables */
/*                        */
/*  RULP VARIABLES        */

  STORE_CLASS TMCHAR   ftvrulp_rucl_code[5],
                      ftvrulp_proc_code[5];
  STORE_CLASS BANNUMSTR(ftvrulp_rulp_code);
  STORE_CLASS TMCHAR   ftvrulp_posting_action[2],
                      ftvrulp_accrual_impact[2],
                      ftvrulp_amt_ind[2],
                      ftvrulp_post_zero_ind[2];

  STORE_CLASS TMCHAR   ftvrulp_coas_code_override[7],
                      ftvrulp_acci_code_override[7],
                      ftvrulp_fund_code_override[7],
                      ftvrulp_orgn_code_override[7],
                      ftvrulp_acct_code_override[7],
                      ftvrulp_prog_code_override[7],
                      ftvrulp_actv_code_override[7],
                      ftvrulp_locn_code_override[7];

/*  FTVTRAT Variables */

  STORE_CLASS TMCHAR   ftvtrat_coas_code[2],
                      ftvtrat_ar_coas_code[2],
                      farintx_rebate_ind[2];
  STORE_CLASS TMCHAR   ftvtrat_fund_code[7],
                      ftvtrat_acct_code[7],
                      ftvtrat_ar_fund_code[7],
                      ftvtrat_ar_acct_code[7];
  STORE_CLASS BANNUMSTR(ftvtrat_exempt_pct);

/* Rebate dollar adjustment variables */

  STORE_CLASS BANNUMSTR(prjd_trans_amt);
  STORE_CLASS TMCHAR  pre_farintx_rowid[21];
  STORE_CLASS TMCHAR   pre_sp_rucl_code[5];
  STORE_CLASS BANNUMSTR(pre_sp_trans_amt);
  STORE_CLASS BANNUMSTR(pre_sp_convert_amt);
  STORE_CLASS TMCHAR   pre_ftvtrat_coas_code[2];
  STORE_CLASS TMCHAR   pre_ftvtrat_fund_code[7];
  STORE_CLASS TMCHAR   pre_ftvtrat_acct_code[7];
  STORE_CLASS TMCHAR  pre_sp_trans_desc[36];
  STORE_CLASS TMCHAR   pre_ftvtrat_ar_coas_code[2];
  STORE_CLASS TMCHAR   pre_ftvtrat_ar_fund_code[7];
  STORE_CLASS TMCHAR   pre_ftvtrat_ar_acct_code[7];
  STORE_CLASS TMCHAR   pre_farintx_rebate_ind[2];
  STORE_CLASS TMCHAR   pre_farintx_pay_tax_to[2];
  STORE_CLASS BANNUMSTR(pre_ftvtrat_exempt_pct);
  STORE_CLASS BANNUMSTR(fabinvh_vend_pidm);
  STORE_CLASS TMCHAR   fgbtrnh_curr_code[5];
  STORE_CLASS TMCHAR sp_trans_date_for_ic_cs[15];
  STORE_CLASS TMCHAR sp_trans_date_save[15];


/*  GTVCURR Variables */

  STORE_CLASS TMCHAR   gtvcurr_ap_acct[7];
  STORE_CLASS TMCHAR   gtvcurr_exch_acct[7];

/*  JOURNAL HEADER VARIABLES */

  STORE_CLASS TMCHAR   sp_doc_num[9];
  STORE_CLASS TMCHAR  sp_trans_date[15];
  STORE_CLASS TMCHAR  fgbjvch_activity_date[15];


/*        usage changed to sp_trans_desc */

  STORE_CLASS BANNUMSTR(sp_doc_amt);
  STORE_CLASS BANNUMSTR(po_total_doc_amt);
  STORE_CLASS BANNUMSTR(fprpoda_appr_amt_pct);
  STORE_CLASS TMCHAR   sp_auto_jrnl_id[4];
  STORE_CLASS TMCHAR   sp_reversal_ind[2];
  STORE_CLASS TMCHAR   sp_cr_memo_ind[2];
  STORE_CLASS TMCHAR   sp_status_ind[2];
  STORE_CLASS TMCHAR   sp_req_bid_ind[2];

/*  DETAIL VARIABLES */

  STORE_CLASS TMCHAR   invc_final_pmt_ind[2];
  STORE_CLASS BANNUMSTR(total_podt_comm_final);
  STORE_CLASS BANNUMSTR(total_invc_comm_final);
  STORE_CLASS BANNUMSTR(sp_submission_number);
  STORE_CLASS BANNUMSTR(sp_chk_submission_num);
  STORE_CLASS BANNUMSTR(sp_item_num);
  STORE_CLASS BANNUMSTR(sp_seq_num);
  STORE_CLASS BANNUMSTR(sp_serial_num);
  STORE_CLASS TMCHAR  sp_user_id[31];
  STORE_CLASS TMCHAR  ffbotag_user_id[31];  /* for fixed assets */
  STORE_CLASS TMCHAR    ffbotag_cap_ind;
  STORE_CLASS BANNUMSTR(ffbotag_submission_num);
  STORE_CLASS BANNUMSTR(ffbotag_doc_seq_num);
  STORE_CLASS TMCHAR   sp_rucl_code[5];
  STORE_CLASS TMCHAR   sp_rucl_code_save[5];
  STORE_CLASS TMCHAR   sp_rucl_code_rsv[5];
  STORE_CLASS TMCHAR   sp_rucl_code_intx[5];
  STORE_CLASS TMCHAR   sp_rucl_code_gross[5];
  STORE_CLASS TMCHAR   sp_rucl_code_liq[5];
  STORE_CLASS TMCHAR   sp_rucl_code_disc[5];
  STORE_CLASS TMCHAR   sp_rucl_code_tax[5];
  STORE_CLASS TMCHAR   sp_rucl_code_intx_h[5];
  STORE_CLASS TMCHAR   sp_rucl_code_addl[5];
  STORE_CLASS BANNUMSTR(sp_trans_amt);
  STORE_CLASS BANNUMSTR(sp_gross_amt);
  STORE_CLASS BANNUMSTR(sp_dist_pct);
  STORE_CLASS TMCHAR   sp_dr_cr_ind[2];
  STORE_CLASS TMCHAR   sp_gross_dr_cr_ind[2];
  STORE_CLASS BANNUMSTR(sp_disc_amt);
  STORE_CLASS TMCHAR   sp_disc_dr_cr_ind[2];
  STORE_CLASS BANNUMSTR(sp_tax_amt);
  STORE_CLASS TMCHAR   sp_tax_dr_cr_ind[2];
  STORE_CLASS BANNUMSTR(sp_addl_chrg_amt);
  STORE_CLASS TMCHAR   sp_addl_chrg_dr_cr_ind[2];
  STORE_CLASS BANNUMSTR(sp_fed_whold_amt);
  STORE_CLASS TMCHAR   sp_fed_whold_dr_cr_ind[2];
  STORE_CLASS BANNUMSTR(sp_st_whold_amt);
  STORE_CLASS TMCHAR   sp_st_whold_dr_cr_ind[2];
  STORE_CLASS BANNUMSTR(sp_consol_amt);
  STORE_CLASS BANNUMSTR(sp_convert_consol_amt);
  STORE_CLASS TMCHAR   sp_consol_dr_cr_ind[2];
  STORE_CLASS BANNUMSTR(sp_consol_amt_prior);
  STORE_CLASS BANNUMSTR(sp_convert_consol_amt_pri);
  STORE_CLASS TMCHAR  sp_trans_desc[36];
  STORE_CLASS BANNUMSTR(sp_fa_cap_amt);

/* Variables related Bo mods release 1.10.4 */

/* One time vendor mod */

  STORE_CLASS TMCHAR  sp_one_time_vend[36];
  STORE_CLASS TMCHAR   sp_fsyr_code[3];
  STORE_CLASS TMCHAR   sp_acci_code[7];
  STORE_CLASS TMCHAR   sp_coas_code[2];
  STORE_CLASS TMCHAR   sp_fund_code[7];
  STORE_CLASS TMCHAR   sp_orgn_code[7];
  STORE_CLASS TMCHAR   sp_acct_code[7];
  STORE_CLASS TMCHAR   sp_prog_code[7];
  STORE_CLASS TMCHAR   sp_actv_code[7];
  STORE_CLASS TMCHAR   sp_locn_code[7];
  STORE_CLASS TMCHAR   sp_bank_code[3];

/* release IM */

  STORE_CLASS TMCHAR   sp_bank_code_pool[3];
  STORE_CLASS TMCHAR   sp_doc_ref_num[9];
  STORE_CLASS BANNUMSTR(sp_item_ref_num);
  STORE_CLASS BANNUMSTR(sp_seq_ref_num);
  STORE_CLASS BANNUMSTR(sp_vendor_pidm);
  STORE_CLASS TMCHAR   sp_encd_num[9];
  STORE_CLASS BANNUMSTR(sp_encd_item_num);
  STORE_CLASS BANNUMSTR(hold_sp_encd_item_num);
  STORE_CLASS BANNUMSTR(sp_encd_seq_num);
  STORE_CLASS TMCHAR   sp_encb_type[2];
  STORE_CLASS TMCHAR   sp_bud_dispn[2];
  STORE_CLASS TMCHAR   sp_bud_id[7];
  STORE_CLASS TMCHAR   sp_cmt_type[2];
  STORE_CLASS BANNUMSTR(sp_cmt_pct);
  STORE_CLASS TMCHAR   sp_dep_num[9];
  STORE_CLASS TMCHAR   sp_encb_action_ind[2];
  STORE_CLASS TMCHAR   sp_prjd_code[9];
  STORE_CLASS TMCHAR   sp_acct_code_cash[7];
  STORE_CLASS TMCHAR   sp_accrual_ind[2];
  STORE_CLASS TMCHAR   sp_budget_period[3];
  STORE_CLASS TMCHAR   sp_posting_period[3];
  STORE_CLASS TMCHAR   sp_check_type_ind[2];
  STORE_CLASS TMCHAR   sp_abal_override[2];

/* Release IM */

  STORE_CLASS TMCHAR  sp_trade_date[15];
  STORE_CLASS TMCHAR  sp_settlement_date[15];
  STORE_CLASS TMCHAR  sp_exercise_date[15];
  STORE_CLASS TMCHAR  sp_industry_symbol[11];
  STORE_CLASS BANNUMSTR(sp_imgr_pidm);
  STORE_CLASS BANNUMSTR(sp_pool_imgr_pidm);
  STORE_CLASS TMCHAR   sp_rsnc_code[3];
  STORE_CLASS TMCHAR   sp_transfer_ind[2];
  STORE_CLASS BANNUMSTR(sp_carrying_value);
  STORE_CLASS BANNUMSTR(sp_amortization);
  STORE_CLASS BANNUMSTR(sp_num_of_units);
  STORE_CLASS BANNUMSTR(sp_unit_price);
  STORE_CLASS BANNUMSTR(sp_commission_amt);
  STORE_CLASS BANNUMSTR(sp_stk_dividend);
  STORE_CLASS BANNUMSTR(sp_other_amt);
  STORE_CLASS BANNUMSTR(sp_base_consol_amt);
  STORE_CLASS BANNUMSTR(sp_im_consol_amt);
  STORE_CLASS BANNUMSTR(sp_cash_dividend_amt);
  STORE_CLASS BANNUMSTR(sp_im_dividend_amt);
  STORE_CLASS BANNUMSTR(sp_num_of_options);
  STORE_CLASS BANNUMSTR(sp_num_of_options_ex);
  STORE_CLASS BANNUMSTR(sp_option_cost);
  STORE_CLASS BANNUMSTR(sp_im_option_cost);
  STORE_CLASS TMCHAR   sp_gift_ind[2];
  STORE_CLASS TMCHAR   sp_pool_coas_code[2];
  STORE_CLASS TMCHAR   sp_pool_fund_code[7];
  STORE_CLASS TMCHAR  sp_cusip[13];
  STORE_CLASS BANNUMSTR(sp_im_trans_amt);
  STORE_CLASS BANNUMSTR(sp_pool_trans_amt);
  STORE_CLASS BANNUMSTR(sp_interest_amt);
  STORE_CLASS BANNUMSTR(sp_im_interest_amt);
  STORE_CLASS BANNUMSTR(sp_nominal_interest_amt);
  STORE_CLASS BANNUMSTR(sp_im_nominal_interest_amt);
  STORE_CLASS BANNUMSTR(sp_cd_amt);
  STORE_CLASS BANNUMSTR(sp_cd_rate);
  STORE_CLASS TMCHAR  sp_issued_date[15];
  STORE_CLASS TMCHAR  sp_maturity_date[15];
  STORE_CLASS TMCHAR  sp_rollover_date[15];
  STORE_CLASS BANNUMSTR(sp_interest_rate);
  STORE_CLASS TMCHAR  sp_open_date[15];
  STORE_CLASS TMCHAR  sp_close_date[15];
  STORE_CLASS TMCHAR  sp_os_cusip_number[13];
  STORE_CLASS TMCHAR  sp_start_date[15];
  STORE_CLASS TMCHAR  sp_expiration_date[15];
  STORE_CLASS BANNUMSTR(sp_num_shares_per_optn);
  STORE_CLASS BANNUMSTR(sp_strike_price);
  STORE_CLASS BANNUMSTR(sp_disc_prem_rate);
  STORE_CLASS TMCHAR   sp_disc_security_ind[2];
  STORE_CLASS BANNUMSTR(sp_pai_amt);
  STORE_CLASS BANNUMSTR(sp_aggr_pai_amt);
  STORE_CLASS BANNUMSTR(sp_im_pai_amt);
  STORE_CLASS BANNUMSTR(sp_disc_prem_amt);
  STORE_CLASS BANNUMSTR(sp_im_disc_prem_amt);
  STORE_CLASS BANNUMSTR(sp_yield_rate);
  STORE_CLASS TMCHAR  sp_callable_date[15];
  STORE_CLASS TMCHAR  sp_called_date[15];
  STORE_CLASS BANNUMSTR(sp_par_value);
  STORE_CLASS BANNUMSTR(sp_nominal_rate);
  STORE_CLASS TMCHAR   is_last_record[2];
  STORE_CLASS BANNUMSTR(round_error_from);
  STORE_CLASS BANNUMSTR(round_error_to);
  STORE_CLASS TMCHAR   farintx_pay_tax_to[2];
  STORE_CLASS TMCHAR   pre_doc_ref_num[9];
  STORE_CLASS BANNUMSTR(pre_item_ref_num);
  STORE_CLASS BANNUMSTR(farinvc_convert_gross_amt);
  STORE_CLASS BANNUMSTR(farinvc_convert_disc_amt);
  STORE_CLASS BANNUMSTR(farinvc_convert_tax_amt);
  STORE_CLASS BANNUMSTR(farinvc_convert_addl_amt);
  STORE_CLASS BANNUMSTR(sp_ratio);
  STORE_CLASS BANNUMSTR(sp_trans_amt_rsv);
  STORE_CLASS BANNUMSTR(sp_convert_amt_rsv);
  STORE_CLASS TMCHAR   sp_curr_code[5];
  STORE_CLASS TMCHAR   sp_disb_agent_ind[2];
  STORE_CLASS TMCHAR   sp_blanket_code[9];
  STORE_CLASS BANNUMSTR(sp_convert_amt);
  STORE_CLASS BANNUMSTR(ftvrqpo_single_acctg_amt);
  STORE_CLASS BANNUMSTR(sp_exchange_amt);
  STORE_CLASS BANNUMSTR(sp_exchange_diff_amt);
  STORE_CLASS BANNUMSTR(sp_convert_gross_amt);
  STORE_CLASS BANNUMSTR(sp_convert_disc_amt);
  STORE_CLASS BANNUMSTR(sp_convert_tax_amt);
  STORE_CLASS BANNUMSTR(sp_convert_addl_chrg_amt);
  STORE_CLASS BANNUMSTR(sp_trans_amt_prior);
  STORE_CLASS BANNUMSTR(sp_convert_amt_prior);
  STORE_CLASS BANNUMSTR(sp_exchange_amt_prior);
  STORE_CLASS BANNUMSTR(sp_gross_amt_prior);
  STORE_CLASS BANNUMSTR(sp_disc_amt_prior);
  STORE_CLASS BANNUMSTR(sp_tax_amt_prior);
  STORE_CLASS BANNUMSTR(sp_addl_chrg_amt_prior);
  STORE_CLASS BANNUMSTR(sp_convert_gross_amt_prio);
  STORE_CLASS BANNUMSTR(sp_convert_disc_amt_prior);
  STORE_CLASS BANNUMSTR(sp_convert_tax_amt_prior);
  STORE_CLASS BANNUMSTR(sp_convert_addl_chrg_var);
  STORE_CLASS BANNUMSTR(sp_convert_rebate_amt);      /* Added new for Rebates */
  STORE_CLASS BANNUMSTR(sp_rebate_amt);              /* Added new for Rebates */
  STORE_CLASS BANNUMSTR(sp_convert_rebate_amt_rsv);  /* Added new for Rebates */
  STORE_CLASS BANNUMSTR(sp_rebate_amt_rsv);          /* Added new for Rebates */
  STORE_CLASS BANNUMSTR(pre_sp_convert_rebate_amt);  /* Added new for Rebates */
  STORE_CLASS BANNUMSTR(pre_sp_rebate_amt);          /* Added New for Rebates */
  STORE_CLASS TMCHAR   sp_inventory_po_ind[2];
  STORE_CLASS TMCHAR   fpbpohd_single_acctg_ind[2];
  STORE_CLASS TMCHAR   fabinvh_single_acctg_ind[2];

/* Release 2.0       */
/* New IM VARIABLES  */

  STORE_CLASS TMCHAR   sp_acct_code_inc_exp[7];
  STORE_CLASS TMCHAR   sp_orgn_code_inc_exp[7];
  STORE_CLASS TMCHAR   sp_prog_code_inc_exp[7];
  STORE_CLASS BANNUMSTR(sp_im_other_amt);
  STORE_CLASS BANNUMSTR(sp_eff_interest_amt);
  STORE_CLASS TMCHAR   sp_indv_source_ind[2];
  STORE_CLASS TMCHAR   sp_inc_exp_ind[2];
  STORE_CLASS TMCHAR  sp_put_date[15];
  STORE_CLASS BANNUMSTR(pty_dp_expense);
  STORE_CLASS BANNUMSTR(sp_cos);
  STORE_CLASS BANNUMSTR(sp_proceeds);
  STORE_CLASS TMCHAR   im_gl_ind[2];
  STORE_CLASS BANNUMSTR(im_proceeds);
  STORE_CLASS BANNUMSTR(im_avg_cost);
  STORE_CLASS BANNUMSTR(im_cos);
  STORE_CLASS BANNUMSTR(im_basis);
  STORE_CLASS BANNUMSTR(im_temp_amt);
  STORE_CLASS BANNUMSTR(im_curr_value);
  STORE_CLASS TMCHAR   sys_defined_ind[2];
  STORE_CLASS TMCHAR   im_indv_source_ind[2];
  STORE_CLASS TMCHAR   im_bank_code_ac[7];
  STORE_CLASS BANNUMSTR(im_imgr_code_ac);
  STORE_CLASS TMCHAR   im_hist_cost_ind[2];
  STORE_CLASS TMCHAR   bnd_rucl_code[5];
  STORE_CLASS TMCHAR   ftvfund_fbal_ind[5];
  STORE_CLASS TMCHAR   ftvfbal_acct_code_fbal[7];
  STORE_CLASS TMCHAR   fobsysc_multiple_fb_acct_ind[2];
  STORE_CLASS TMCHAR   bnd_acct_code[7];
  STORE_CLASS TMCHAR   bnd_rsnc_code[3];
  STORE_CLASS BANNUMSTR(bnd_sold_carry_value);
  STORE_CLASS BANNUMSTR(coll_im_other_amt);

/*  Release 2.0 IM RLO          */

  STORE_CLASS TMCHAR f_settlement_date[15];
  STORE_CLASS TMCHAR f_maturity_date[15];
  STORE_CLASS BANNUMSTR(f_num_of_bonds);
  STORE_CLASS BANNUMSTR(f_par_value);
  STORE_CLASS BANNUMSTR(f_disc_prem_rate);
  STORE_CLASS BANNUMSTR(f_nominal_rate);
  STORE_CLASS BANNUMSTR(f_yield_rate);
  STORE_CLASS TMCHAR  f_signed[2];
  STORE_CLASS TMCHAR settlement_date[15];
  STORE_CLASS TMCHAR first_in_date[15];
  STORE_CLASS TMCHAR second_in_date[15];
  STORE_CLASS BANNUMSTR(num_months);

   STORE_CLASS BANNUMSTR(prev_yield_rate);
   STORE_CLASS BANNUMSTR(bnd_yield_rate);
   STORE_CLASS BANNUMSTR(new_yield_rate);
   STORE_CLASS BANNUMSTR(carry_value);
   STORE_CLASS BANNUMSTR(prev_carry_value);
   STORE_CLASS BANNUMSTR(amort_amt);
   STORE_CLASS BANNUMSTR(bnd_amortization);
   STORE_CLASS BANNUMSTR(prev_amort_amt);
   STORE_CLASS BANNUMSTR(nominal_int);
   STORE_CLASS BANNUMSTR(out_nominal_int);
   STORE_CLASS BANNUMSTR(prev_nominal_int);
   STORE_CLASS BANNUMSTR(prev_disc_prem_rate);
   STORE_CLASS BANNUMSTR(prev_eff_int);
   STORE_CLASS BANNUMSTR(eff_int);
   STORE_CLASS TMCHAR prev_settle_date[15];
   STORE_CLASS TMCHAR first_date[15];
   STORE_CLASS TMCHAR prev_first_date[15];
   STORE_CLASS BANNUMSTR(prev_num_of_bonds);
   STORE_CLASS BANNUMSTR(mon);
   STORE_CLASS BANNUMSTR(bond_years);
   STORE_CLASS BANNUMSTR(first);
   STORE_CLASS BANNUMSTR(disc_prem_rate);
   STORE_CLASS BANNUMSTR(par_value);
   STORE_CLASS BANNUMSTR(nominal_rate);


/* Release 1.10 */

  STORE_CLASS TMCHAR   sp_blanket_ind[2];
  STORE_CLASS TMCHAR   close_ench_ind[2];
  STORE_CLASS TMCHAR  save_trans_desc[36];
  STORE_CLASS BANNUMSTR(enc_liq_amt);
  STORE_CLASS BANNUMSTR(enc_liq_amt_e023);      /* Rel 2.0 */


/* release 1.10 */

  STORE_CLASS BANNUMSTR(rev_enc_liq_amt);

/*  LEDGER AMOUNT VARIABLES                                                  */
/*                                                                           */
/* *=======================================================================* */
/*                                                                           */
/*             FGBENCH - Encumbrance Ledger Header                           */
/*                                                                           */
/* *=======================================================================* */

/* Release 1.10                                     */

  STORE_CLASS TMCHAR   fgbench_source_ind[2];

/* *=======================================================================* */
/*                                                                           */
/*             FGBENCD - Encumbrance Ledger Detail                           */
/*                                                                           */
/* *=======================================================================* */

  STORE_CLASS TMCHAR  fgbencd_rowid[21];
  STORE_CLASS TMCHAR   fgbencd_coas_code[2];
  STORE_CLASS TMCHAR   fgbencd_acci_code[7];
  STORE_CLASS TMCHAR   fgbencd_fund_code[7];
  STORE_CLASS TMCHAR   fgbencd_orgn_code[7];
  STORE_CLASS TMCHAR   fgbencd_acct_code[7];
  STORE_CLASS TMCHAR   fgbencd_prog_code[7];
  STORE_CLASS TMCHAR   fgbencd_actv_code[7];
  STORE_CLASS TMCHAR   fgbencd_locn_code[7];
  STORE_CLASS TMCHAR   fgbencd_status[2];

/* Release 1.10 */

  STORE_CLASS TMCHAR  fgbencp_rowid[21];
  STORE_CLASS TMCHAR   fgbencp_fsyr_code[3];

/*  POSTING CODES */

  STORE_CLASS TMCHAR   post_rucl_code[5];
  STORE_CLASS TMCHAR  post_fsyr_code[10];
  STORE_CLASS TMCHAR  post_fsyr_code_hold[5];
  STORE_CLASS TMCHAR   post_acci_code[7];
  STORE_CLASS TMCHAR   post_coas_code[15];
  STORE_CLASS TMCHAR   post_fund_code[25];
  STORE_CLASS TMCHAR   post_orgn_code[25];
  STORE_CLASS TMCHAR   post_acct_code[25];
  STORE_CLASS TMCHAR   post_acct_code_save[7];
  STORE_CLASS TMCHAR   post_prog_code[7];
  STORE_CLASS TMCHAR   post_actv_code[7];
  STORE_CLASS TMCHAR   post_locn_code[7];
  STORE_CLASS TMCHAR   post_accrual_ind[2];
  STORE_CLASS TMCHAR   post_period_hold[3];
  STORE_CLASS TMCHAR   post_period[15];
  STORE_CLASS TMCHAR   post_budget_period[3];
  STORE_CLASS TMCHAR   post_budget_period_hold[3];
  STORE_CLASS BANNUMSTR(post_trans_amt);
  STORE_CLASS BANNUMSTR(post_trans_amt_save);
  STORE_CLASS BANNUMSTR(post_trans_amt_rsv);
  STORE_CLASS BANNUMSTR(o014_o016_amt);
  STORE_CLASS TMCHAR   post_other_data[31];  /* RPE - 1-G32Z5*/
  STORE_CLASS TMCHAR   src_doc_rucl_code[5];  /* RPE - 1-G32Z5*/  

/* Release IM */

  STORE_CLASS BANNUMSTR(post_im_trans_amt);
  STORE_CLASS TMCHAR   post_pool_fund_code[7];
  STORE_CLASS TMCHAR   post_pool_coas_code[2];
  STORE_CLASS BANNUMSTR(post_num_of_units);

/* RELEASE 1.10 */

  STORE_CLASS BANNUMSTR(post_trans_amt_rev);
  STORE_CLASS BANNUMSTR(post_trans_amt_diff);
  STORE_CLASS BANNUMSTR(post_dr_amt);
  STORE_CLASS BANNUMSTR(post_cr_amt);
  STORE_CLASS BANNUMSTR(post_adopt_bud);
  STORE_CLASS BANNUMSTR(post_bud_adjt);
  STORE_CLASS BANNUMSTR(post_ytd_actv);
  STORE_CLASS BANNUMSTR(post_encumb);
  STORE_CLASS BANNUMSTR(post_bud_rsrv);
  STORE_CLASS BANNUMSTR(post_acctd_bud);
  STORE_CLASS BANNUMSTR(post_temp_bud);

/* Data fields used by the 'E' Posting Routines */

  STORE_CLASS BANNUMSTR(post_orig_encb);
  STORE_CLASS BANNUMSTR(post_encb_adjt);
  STORE_CLASS BANNUMSTR(post_encb_liq);


  STORE_CLASS BANNUMSTR(exxx_encp_bal_inp);
  STORE_CLASS BANNUMSTR(exxx_encp_bal_calc);
  STORE_CLASS TMCHAR   exxx_opal_field_code[3];
  STORE_CLASS TMCHAR   exxx_opal_sign[2];
  STORE_CLASS TMCHAR   exxx_carryfwd_err[2];
  STORE_CLASS TMCHAR   exxx_fsyr_code[3];
  STORE_CLASS TMCHAR   exxx_gl_dr_cr_ind[2];
  STORE_CLASS TMCHAR   exxx_normal_sign[2];
  STORE_CLASS TMCHAR   exxx_encumb_num_save[9];
  STORE_CLASS TMCHAR   exxx_encumb_item_save[9];
  STORE_CLASS TMCHAR   exxx_encumb_seq_save[9];
  STORE_CLASS TMCHAR   exxx_work_fsyr_code[3];

/* Release 1.10 */

  STORE_CLASS BANNUMSTR(cmt_enc_rev);
  STORE_CLASS TMCHAR   cmt_distr_control_ind[2];
  STORE_CLASS TMCHAR   cmt_invc_part_pmt[2];
  STORE_CLASS TMCHAR   po_prior_non_con[2];
  STORE_CLASS TMCHAR   po_prior_yr_count[2];
  STORE_CLASS TMCHAR   post_mods_exist[2];
  STORE_CLASS TMCHAR   exxx_exist_prior[2];
  STORE_CLASS TMCHAR   post_cmt_type[2];
  STORE_CLASS TMCHAR   post_cmt_type_save[2];
  STORE_CLASS BANNUMSTR(post_cmt_pct);
  STORE_CLASS TMCHAR   post_budg_disp[2];
  STORE_CLASS TMCHAR   post_budget_roll[2];
  STORE_CLASS BANNUMSTR(post_budget_roll_pct);

  STORE_CLASS TMCHAR   exxx_process_ind[2];

/* exxx_process_ind:  C ==> Close encumbrance                            */
/*                    R ==> Reopen encumbrance                           */
/*                   "" ==> neither closing or reopening encumbrance     */
/*                                                                       */
/* This indicator is needed so that transactions with multiple pieces    */
/* (i.e. those transactions with gross, discount, tax, and addl amounts) */
/* can be processed as one transaction when closing and reopening.       */
/*                                                                       */
/*     PROCESS INDICATORS                                                */

  STORE_CLASS TMCHAR   reimb_oh[2];
  STORE_CLASS TMCHAR   match_fund[2];
  STORE_CLASS TMCHAR   rev_accr[2];
  STORE_CLASS TMCHAR   bypass_trans[2];
  STORE_CLASS TMCHAR   bako_del_status[2];

/*  CALCULATION HOLD FIELDS */

  STORE_CLASS BANNUMSTR(sum_reimb_amt_cr);
  STORE_CLASS BANNUMSTR(sum_reimb_amt_cr_a);
  STORE_CLASS BANNUMSTR(reimb_amt_cr);
  STORE_CLASS BANNUMSTR(reimb_amt_dr);
  STORE_CLASS BANNUMSTR(match_amt_cr);
  STORE_CLASS BANNUMSTR(match_amt_dr);
  STORE_CLASS BANNUMSTR(rev_accr_amt);
  STORE_CLASS BANNUMSTR(match_oh_amt);
  STORE_CLASS BANNUMSTR(rev_oh_amt);
  STORE_CLASS BANNUMSTR(rev_match_amt);
  STORE_CLASS BANNUMSTR(hold_reimb_amt_dr);
  STORE_CLASS BANNUMSTR(hold_reimb_amt_cr);
  STORE_CLASS BANNUMSTR(hold_match_amt_dr);
  STORE_CLASS BANNUMSTR(hold_match_amt_cr);
  STORE_CLASS BANNUMSTR(hold_match_fund_cr);
  STORE_CLASS BANNUMSTR(cost_match_fund_cr);
  STORE_CLASS BANNUMSTR(hold_cost_sh_overhead_amt);
  STORE_CLASS BANNUMSTR(hold_rev_oh_amt);
  STORE_CLASS BANNUMSTR(hold_match_amt);
  STORE_CLASS BANNUMSTR(hold_rev_accr_amt);
  STORE_CLASS BANNUMSTR(work_indc_pct);
  STORE_CLASS BANNUMSTR(work_cost_pct);
  STORE_CLASS TMCHAR   null_ind[2];
  STORE_CLASS TMCHAR   ind_labor[2];
  STORE_CLASS TMCHAR   ind_dirct[2];
  STORE_CLASS TMCHAR   ind_mod[2];
  STORE_CLASS TMCHAR   firsttime[2];
  STORE_CLASS TMCHAR  error_message[33];

/*  CHECK VARIABLES */

/*  CONTROL ACCOUNT VARIABLES */

  STORE_CLASS TMCHAR   ftvactl_acct_code_control[7];
  STORE_CLASS TMCHAR   ftvactl_acct_code_offset[7];
  STORE_CLASS TMCHAR   ftvactl_acct_code_control_py[7];
  STORE_CLASS TMCHAR   ftvactl_acct_code_offset_py[7];

/*  ACCOUNT VARIABLES */

  STORE_CLASS TMCHAR   ftvacct_atyp_code[3];
  STORE_CLASS TMCHAR   ftvacct_normal_bal[2];
  STORE_CLASS TMCHAR   ftvacct_acct_code_asset[7];

/*  ACCOUNT TYPE VARIABLES */

  STORE_CLASS TMCHAR   ftvatyp_atyp_code[3];
  STORE_CLASS TMCHAR   ftvatyp_atyp_code_pred[3];
  STORE_CLASS TMCHAR   ftvatyp_internal_atyp_code[3];
  STORE_CLASS TMCHAR   ftvatyp_normal_bal[2];
  STORE_CLASS TMCHAR   rpt_atyp_code[3];

/*  BANK VARIABLES */

  STORE_CLASS TMCHAR   gxvbank_acct_code_cash[7];
  STORE_CLASS TMCHAR   gxvbank_acct_code_interfund[7];
  STORE_CLASS TMCHAR   gxvbank_fund_code[7];

/*  COAS VARIABLES */

  STORE_CLASS TMCHAR   ftvcoas_acct_code_fund_due_to[7];
  STORE_CLASS TMCHAR   ftvcoas_acct_code_fund_due_fr[7];
  STORE_CLASS TMCHAR   ftvcoas_acct_code_fund_bal[7];
  STORE_CLASS TMCHAR   ftvcoas_acct_code_accrual_ap[7];
  STORE_CLASS TMCHAR   ftvcoas_acct_code_accrual_ar[7];

/* COST SHARE LEVEL VARIABLES */

  STORE_CLASS TMCHAR   cost_apply_to[2];
  STORE_CLASS TMCHAR  cost_eff_date[21];
  STORE_CLASS TMCHAR  cost_term_date[10];
  STORE_CLASS TMCHAR   cost_basis[2];
  STORE_CLASS TMCHAR   cost_memo_ind[2];
  STORE_CLASS BANNUMSTR(cost_std_rate);
  STORE_CLASS TMCHAR   cost_status_ind[2];
  STORE_CLASS TMCHAR   csap_acct_frm[7];
  STORE_CLASS TMCHAR   csap_acct_to[7];
  STORE_CLASS BANNUMSTR(csap_appl_rate);
  STORE_CLASS TMCHAR   cscn_acci_code[7];
  STORE_CLASS TMCHAR   cscn_fund_code[7];
  STORE_CLASS TMCHAR   cscn_orgn_code[7];
  STORE_CLASS TMCHAR   cscn_acct_code[7];
  STORE_CLASS TMCHAR   cscn_prog_code[7];
  STORE_CLASS TMCHAR   cscn_actv_code[7];
  STORE_CLASS TMCHAR   cscn_locn_code[7];
  STORE_CLASS BANNUMSTR(cscn_contrib_pct);
  STORE_CLASS TMCHAR   cscn_credit_acct[7];

/*  FSYR VARIABLES */

  STORE_CLASS TMCHAR   ftvfsyr_eoy_accr_status_ind[2];

/* Release 1.10 */

  STORE_CLASS TMCHAR   ftvfsyr_fsyr_code[3];

/*  FTYP VARIABLES */

  STORE_CLASS TMCHAR   ftvftyp_ftyp_code_pred[3];
  STORE_CLASS TMCHAR   ftvftyp_fund_code_cap[7];
  STORE_CLASS TMCHAR   ftvftyp_acct_code_cap[7];

/*  FUND VARIABLES */

  STORE_CLASS TMCHAR   ftvfund_ftyp_code[3];
  STORE_CLASS TMCHAR   ftvfund_fund_code_plant[7];
  STORE_CLASS TMCHAR   ftvfund_acct_code_plant[7];

/* Release IM */

  STORE_CLASS TMCHAR   ftvfund_acct_code_pool[7];
  STORE_CLASS TMCHAR   ftvfund_acct_code_fund_bal[7];
  STORE_CLASS TMCHAR   ftvfund_pool_ind[2];
  STORE_CLASS TMCHAR   ftvfund_acct_code_real_gain[7];
  STORE_CLASS TMCHAR   ftvfund_orgn_code_real_gain[7];
  STORE_CLASS TMCHAR   ftvfund_prog_code_real_gain[7];
  STORE_CLASS TMCHAR   ftvfund_acct_code_real_loss[7];
  STORE_CLASS TMCHAR   ftvfund_orgn_code_real_loss[7];
  STORE_CLASS TMCHAR   ftvfund_prog_code_real_loss[7];
  STORE_CLASS TMCHAR   ftvfund_acct_code_accr_int[7];
  STORE_CLASS TMCHAR   ftvfund_orgn_code_accr_int[7];
  STORE_CLASS TMCHAR   ftvfund_prog_code_accr_int[7];
  STORE_CLASS TMCHAR   ftvfund_acct_code_receivable[7];
  STORE_CLASS TMCHAR   ftvfund_acct_code_undst_earn[7];
  STORE_CLASS TMCHAR   ftvfund_orgn_code_undst_earn[7];
  STORE_CLASS TMCHAR   ftvfund_prog_code_undst_earn[7];
  STORE_CLASS TMCHAR   ftvfund_acct_code_income_np[7];
  STORE_CLASS TMCHAR   ftvfund_orgn_code_income_np[7];
  STORE_CLASS TMCHAR   ftvfund_prog_code_income_np[7];
  STORE_CLASS TMCHAR   ftvfund_acct_code_spend_excs[7];
  STORE_CLASS TMCHAR   ftvfund_acct_code_py_rt_earn[7];

/* release IM                */
/* COLLECTOR TABLE VARIABLES */

  STORE_CLASS TMCHAR  coll_cusip[13];
  STORE_CLASS TMCHAR  coll_industry_symbol[11];
  STORE_CLASS TMCHAR   coll_rucl_code[5];
  STORE_CLASS BANNUMSTR(coll_item_num);
  STORE_CLASS BANNUMSTR(coll_seq_num);
  STORE_CLASS TMCHAR   coll_coas_code[2];
  STORE_CLASS TMCHAR   coll_fund_code[7];
  STORE_CLASS TMCHAR   coll_rsnc_code[3];
  STORE_CLASS TMCHAR  coll_user_id[31];
  STORE_CLASS BANNUMSTR(coll_submission_number);
  STORE_CLASS BANNUMSTR(coll_serial_num);
  STORE_CLASS TMCHAR  coll_trans_date[15];
  STORE_CLASS TMCHAR   coll_fsyr_code[3];
  STORE_CLASS TMCHAR   coll_acct_code[7];
  STORE_CLASS BANNUMSTR(coll_imgr_pidm);
  STORE_CLASS TMCHAR   coll_posting_period[3];
  STORE_CLASS TMCHAR   coll_pool_coas_code[2];
  STORE_CLASS TMCHAR  coll_trade_date[15];
  STORE_CLASS TMCHAR  coll_settlement_date[15];
  STORE_CLASS TMCHAR   coll_pool_fund_code[7];
  STORE_CLASS BANNUMSTR(coll_pool_imgr_pidm);
  STORE_CLASS TMCHAR   coll_transfer_ind[2];
  STORE_CLASS BANNUMSTR(coll_num_of_units);
  STORE_CLASS BANNUMSTR(coll_unit_price);
  STORE_CLASS BANNUMSTR(coll_commission_amt);
  STORE_CLASS BANNUMSTR(coll_tax_amt);
  STORE_CLASS BANNUMSTR(coll_other_amt);
  STORE_CLASS BANNUMSTR(coll_im_consol_amt);
  STORE_CLASS BANNUMSTR(coll_im_dividend_amt);
  STORE_CLASS TMCHAR   coll_gift_ind[2];
  STORE_CLASS TMCHAR   coll_bank_code[3];
  STORE_CLASS TMCHAR   coll_bank_code_pool[3];
  STORE_CLASS TMCHAR  coll_exercise_date[15];
  STORE_CLASS BANNUMSTR(coll_num_of_options);
  STORE_CLASS BANNUMSTR(coll_im_option_cost);
  STORE_CLASS BANNUMSTR(coll_num_of_options_ex);
  STORE_CLASS TMCHAR  coll_os_cusip_number[13];
  STORE_CLASS TMCHAR  coll_start_date[15];
  STORE_CLASS TMCHAR  coll_expiration_date[15];
  STORE_CLASS BANNUMSTR(coll_num_shares_per_optn);
  STORE_CLASS BANNUMSTR(coll_strike_price);
  STORE_CLASS BANNUMSTR(coll_disc_prem_rate);
  STORE_CLASS TMCHAR   coll_disc_security_ind[2];
  STORE_CLASS BANNUMSTR(coll_im_pai_amt);
  STORE_CLASS BANNUMSTR(coll_im_interest_amt);
  STORE_CLASS BANNUMSTR(coll_im_disc_prem_amt);
  STORE_CLASS BANNUMSTR(coll_yield_rate);
  STORE_CLASS BANNUMSTR(coll_im_nominal_interest_amt);
  STORE_CLASS TMCHAR  coll_issued_date[15];
  STORE_CLASS TMCHAR  coll_maturity_date[15];
  STORE_CLASS TMCHAR  coll_callable_date[15];
  STORE_CLASS BANNUMSTR(coll_par_value);
  STORE_CLASS BANNUMSTR(coll_nominal_rate);
  STORE_CLASS TMCHAR  coll_called_date[15];
  STORE_CLASS BANNUMSTR(coll_aggr_pai_amt);
  STORE_CLASS BANNUMSTR(coll_interest_rate);
  STORE_CLASS TMCHAR  coll_open_date[15];
  STORE_CLASS TMCHAR  coll_close_date[15];
  STORE_CLASS BANNUMSTR(coll_cd_amt);
  STORE_CLASS BANNUMSTR(coll_cd_rate);
  STORE_CLASS TMCHAR  coll_rollover_date[15];

/* Release 2.0       */

  STORE_CLASS TMCHAR  coll_acct_code_inc_exp[7];
  STORE_CLASS TMCHAR  coll_orgn_code_inc_exp[7];
  STORE_CLASS TMCHAR  coll_prog_code_inc_exp[7];
  STORE_CLASS TMCHAR coll_put_date[15];
  STORE_CLASS BANNUMSTR(coll_cash_dividend_amt);


/* FUND LEVEL VARIABLES */

  STORE_CLASS TMCHAR  fund_eff_date[10];
  STORE_CLASS TMCHAR   fund_acct_code_rev[7];
  STORE_CLASS TMCHAR   fund_acct_code_accr[7];
  STORE_CLASS TMCHAR   fund_cost_code_grnt[7];
  STORE_CLASS TMCHAR   fund_indc_code[7];

/* INDIRECT COST LEVEL VARIABLES */

  STORE_CLASS TMCHAR   indc_apply_to[2];
  STORE_CLASS TMCHAR   indc_basis[2];
  STORE_CLASS BANNUMSTR(indc_std_rate);
  STORE_CLASS TMCHAR   indc_status_ind[2];
  STORE_CLASS TMCHAR   indc_memo_ind[2];
  STORE_CLASS TMCHAR  indc_eff_date[21];
  STORE_CLASS TMCHAR  indc_term_date[10];
  STORE_CLASS TMCHAR   indc_indirect_acct_code[7];
  STORE_CLASS TMCHAR   inap_acct_frm[7];
  STORE_CLASS TMCHAR   inap_acct_to[7];
  STORE_CLASS BANNUMSTR(inap_appl_rate);
  STORE_CLASS TMCHAR   inrc_acci_code[7];
  STORE_CLASS TMCHAR   inrc_fund_code[7];
  STORE_CLASS TMCHAR   inrc_orgn_code[7];
  STORE_CLASS TMCHAR   inrc_acct_code[7];
  STORE_CLASS TMCHAR   inrc_prog_code[7];
  STORE_CLASS TMCHAR   inrc_actv_code[7];
  STORE_CLASS TMCHAR   inrc_locn_code[7];
  STORE_CLASS BANNUMSTR(inrc_dist_pct);
  STORE_CLASS BANNUMSTR(sum_inrc_dist_pct);

/*  FOBSYSC VARIABLES */

  STORE_CLASS TMCHAR   fobsysc_acct_code_coas_due_to[7];
  STORE_CLASS TMCHAR   fobsysc_acct_code_coas_due_frm[7];
  STORE_CLASS TMCHAR   fobsysc_consol_post_ind[2];
  STORE_CLASS TMCHAR   fobsysc_jv_dtag_feed_ind[2];
  STORE_CLASS TMCHAR   fobsysc_issu_dtag_feed_ind[2];
  STORE_CLASS TMCHAR   fobsysc_dcsr_dtag_feed_ind[2];
  STORE_CLASS BANNUMSTR(fobsysc_min_asset_cap_amt);

/* Release IM */

  STORE_CLASS TMCHAR   fobsysc_investment_sale_ind[2];
  STORE_CLASS TMCHAR   fobsysc_earning_receive_ind[2];

/* Release IM       */
/* FTVUVMS VARIABLE */

  STORE_CLASS BANNUMSTR(ftvuvms_unit_value_base_curr);

/* Release IM        */
/* FTVIVTP VARIABLES */

  STORE_CLASS TMCHAR   ftvivtp_ivtp_code[3];
  STORE_CLASS TMCHAR   ftvivtp_category[2];
  STORE_CLASS TMCHAR   ftvivtp_acct_code[7];
  STORE_CLASS TMCHAR   ftvivtp_acct_code_orig_gift[7];
  STORE_CLASS TMCHAR   ftvivtp_acct_code_subseq_gift[7];
  STORE_CLASS TMCHAR   ftvivtp_orgn_code_orig_gift[7];
  STORE_CLASS TMCHAR   ftvivtp_orgn_code_subseq_gift[7];
  STORE_CLASS TMCHAR   ftvivtp_prog_code_orig_gift[7];
  STORE_CLASS TMCHAR   ftvivtp_prog_code_subseq_gift[7];
  STORE_CLASS TMCHAR   ftvivtp_acct_code_payable[7];
  STORE_CLASS TMCHAR   ftvivtp_acct_code_sales_recv[7];
  STORE_CLASS TMCHAR   ftvivtp_acct_code_discount[7];
  STORE_CLASS TMCHAR   ftvivtp_acct_code_premium[7];


/* Release 2.0 */
/* New FTVIVTP VARS  */

  STORE_CLASS TMCHAR   ftvivtp_acct_code_income_recv[7];	
  STORE_CLASS TMCHAR   ftvivtp_acct_code_rg_proceed[7];	
  STORE_CLASS TMCHAR   ftvivtp_orgn_code_rg_proceed[7];	
  STORE_CLASS TMCHAR   ftvivtp_prog_code_rg_proceed[7];	
  STORE_CLASS TMCHAR   ftvivtp_acct_code_rg_basis[7];	
  STORE_CLASS TMCHAR   ftvivtp_orgn_code_rg_basis[7];	
  STORE_CLASS TMCHAR   ftvivtp_prog_code_rg_basis[7];	
  STORE_CLASS TMCHAR   ftvivtp_acct_code_rg_cost[7];	
  STORE_CLASS TMCHAR   ftvivtp_orgn_code_rg_cost[7];	
  STORE_CLASS TMCHAR   ftvivtp_prog_code_rg_cost[7];	
  STORE_CLASS TMCHAR   ftvivtp_acct_code_rl_proceed[7];	
  STORE_CLASS TMCHAR   ftvivtp_orgn_code_rl_proceed[7];	
  STORE_CLASS TMCHAR   ftvivtp_prog_code_rl_proceed[7];	
  STORE_CLASS TMCHAR   ftvivtp_acct_code_rl_basis[7];	
  STORE_CLASS TMCHAR   ftvivtp_orgn_code_rl_basis[7];	
  STORE_CLASS TMCHAR   ftvivtp_prog_code_rl_basis[7];	
  STORE_CLASS TMCHAR   ftvivtp_acct_code_rl_cost[7];	
  STORE_CLASS TMCHAR   ftvivtp_orgn_code_rl_cost[7];	
  STORE_CLASS TMCHAR   ftvivtp_prog_code_rl_cost[7];	
  STORE_CLASS TMCHAR   ftvivtp_acct_code_accrual[7];	
  STORE_CLASS TMCHAR   ftvivtp_orgn_code_accrual[7];	
  STORE_CLASS TMCHAR   ftvivtp_prog_code_accrual[7];	
  STORE_CLASS TMCHAR   ftvivtp_acct_code_amortize_inc[7];	
  STORE_CLASS TMCHAR   ftvivtp_orgn_code_amortize_inc[7];	
  STORE_CLASS TMCHAR   ftvivtp_prog_code_amortize_inc[7];	
  STORE_CLASS TMCHAR   ftvivtp_acct_code_amortize_exp[7];	
  STORE_CLASS TMCHAR   ftvivtp_orgn_code_amortize_exp[7];	
  STORE_CLASS TMCHAR   ftvivtp_prog_code_amortize_exp[7];	
  STORE_CLASS TMCHAR   ftvivtp_acct_code_inc_receipts[7];	
  STORE_CLASS TMCHAR   ftvivtp_orgn_code_inc_receipts[7];	
  STORE_CLASS TMCHAR   ftvivtp_prog_code_inc_receipts[7];	

/* Release IM     */
/* POOL VARIABLES */

  STORE_CLASS TMCHAR   pool_coas_code[2];
  STORE_CLASS TMCHAR   pool_fund_code_pool[7];
  STORE_CLASS TMCHAR   pool_coas_code_input[2];
  STORE_CLASS TMCHAR   pool_fund_code_input[7];
  STORE_CLASS TMCHAR  pool_trans_date[21];
  STORE_CLASS BANNUMSTR(pool_trans_amt);

/* The pool_fb_ind can be a +, -, or 0. if it is a +, an addition was */
/* made to the pool.                                                  */

  STORE_CLASS TMCHAR   pool_fb_ind[2];

/* Release IM */

  STORE_CLASS TMCHAR   im_control_ind[2];
  STORE_CLASS TMCHAR   cash_interfund_control[2];
  STORE_CLASS TMCHAR   cash_interfund_rec[2];
  STORE_CLASS BANNUMSTR(stk_cost_buy);
  STORE_CLASS BANNUMSTR(stk_num_of_buys);
  STORE_CLASS BANNUMSTR(stk_avg_cost);
  STORE_CLASS BANNUMSTR(sto_cost_buy);
  STORE_CLASS BANNUMSTR(sto_num_of_buys);
  STORE_CLASS BANNUMSTR(sto_avg_cost);
  STORE_CLASS BANNUMSTR(mkt_cost_buy);
  STORE_CLASS BANNUMSTR(mkt_num_of_buys);
  STORE_CLASS BANNUMSTR(mkt_avg_cost);
  STORE_CLASS BANNUMSTR(pty_cost_buy);
  STORE_CLASS BANNUMSTR(pty_num_of_buys);
  STORE_CLASS BANNUMSTR(pty_avg_cost);
  STORE_CLASS BANNUMSTR(cd_cost_buy);
  STORE_CLASS BANNUMSTR(cd_num_of_buys);
  STORE_CLASS BANNUMSTR(cd_avg_cost);
  STORE_CLASS BANNUMSTR(bnd_cost_buy);
  STORE_CLASS BANNUMSTR(bnd_num_of_buys);
  STORE_CLASS BANNUMSTR(bnd_avg_cost);
  STORE_CLASS TMCHAR   bnd_min_date_ind[2];
  STORE_CLASS TMCHAR  bnd_adjust_date[15];
  STORE_CLASS BANNUMSTR(bnd_interest_earned);
  STORE_CLASS BANNUMSTR(bnd_curr_carry_value);
  STORE_CLASS BANNUMSTR(bnd_aggr_pai_amt);
  STORE_CLASS BANNUMSTR(pfif_total_value);
  STORE_CLASS BANNUMSTR(pfif_num_of_units);
  STORE_CLASS BANNUMSTR(pfif_unit_value);
  STORE_CLASS BANNUMSTR(pfif_avg_cost);
  STORE_CLASS BANNUMSTR(pfif_avg_cost_hold);
  STORE_CLASS TMCHAR   im_rucl_code[5];
  STORE_CLASS TMCHAR   im_fund_code_ac[7];
  STORE_CLASS TMCHAR   im_coas_code_ac[2];
  STORE_CLASS TMCHAR   im_doc_num[9];
  STORE_CLASS TMCHAR   im_rsnc_code[3];
  STORE_CLASS BANNUMSTR(im_avg_cost_ac);
  STORE_CLASS TMCHAR   im_hold_rsnc_code[3];
  STORE_CLASS TMCHAR   im_hold_seq_code[3];
  STORE_CLASS TMCHAR   im_hold_doc_num[9];
  STORE_CLASS TMCHAR   im_hold_fund_pool[7];
  STORE_CLASS TMCHAR   im_hold_coas_pool[2];
  STORE_CLASS TMCHAR   fund_bal_pool_ind[2];

/* IM release 1.10 by vsoong 10/13/92                                */
/*                                                                   */
/* The variables for bond current carrying amount & interest eanred. */

  STORE_CLASS TMCHAR   calc_pool_switch[2];
  STORE_CLASS TMCHAR   calc_amort_method[2];
  STORE_CLASS BANNUMSTR(calc_nominal_rate);
  STORE_CLASS BANNUMSTR(calc_par_value);
  STORE_CLASS TMCHAR  calc_maturity_date[15];
  STORE_CLASS BANNUMSTR(calc_num_of_months);
  STORE_CLASS BANNUMSTR(calc_period_per_year);
  STORE_CLASS TMCHAR  calc_trans_date[15];
  STORE_CLASS TMCHAR  calc_settlement_date[15];
  STORE_CLASS BANNUMSTR(calc_num_of_bonds);
  STORE_CLASS BANNUMSTR(calc_amort_amt);
  STORE_CLASS BANNUMSTR(calc_carry_amt);
  STORE_CLASS TMCHAR   calc_int_month_start[4];
  STORE_CLASS TMCHAR   calc_int_month_end[4];
  STORE_CLASS TMCHAR   calc_int_day[3];
  STORE_CLASS TMCHAR   calc_int_year[5];
  STORE_CLASS BANNUMSTR(calc_aggr_d_p_rate);
  STORE_CLASS BANNUMSTR(calc_aggr_num_of_bonds);
  STORE_CLASS BANNUMSTR(calc_aggr_amort_amt);
  STORE_CLASS BANNUMSTR(calc_aggr_carry_amt);
  STORE_CLASS BANNUMSTR(calc_aggr_yield_rate);
  STORE_CLASS TMCHAR  calc_period_start_date[15];
  STORE_CLASS TMCHAR  calc_period_end_date[15];
  STORE_CLASS TMCHAR   calc_sign[2];
  STORE_CLASS TMCHAR   gen_doc_num_exists[2];

/*  REPORT VARIABLES */

  STORE_CLASS TMCHAR   rollback_doc[2];
  STORE_CLASS TMCHAR   ctrl_seq_num[3];
  STORE_CLASS TMCHAR  fobappd_rowid[21];
  STORE_CLASS TMCHAR  fgrbako_rowid[21];
  STORE_CLASS TMCHAR  fgbjvch_rowid[21];
  STORE_CLASS TMCHAR  fgbjvcd_rowid[21];
  STORE_CLASS TMCHAR  fgbench_rowid[21];
  STORE_CLASS TMCHAR  fgrgrnt_rowid[21];
  STORE_CLASS TMCHAR  fpbreqh_rowid[21];
  STORE_CLASS TMCHAR  fprreqa_rowid[21];
  STORE_CLASS TMCHAR  fpbpohd_rowid[21];
  STORE_CLASS TMCHAR  fprpodt_rowid[21];
  STORE_CLASS TMCHAR  fprpoda_rowid[21];
  STORE_CLASS TMCHAR  fprreqd_rowid[21];
  STORE_CLASS TMCHAR  ftvchrg_rowid[21];
  STORE_CLASS TMCHAR  ftvrqpo_rowid[21];
  STORE_CLASS TMCHAR  ftvbdpo_rowid[21];
  STORE_CLASS TMCHAR  fabinvh_rowid[21];
  STORE_CLASS TMCHAR  farinva_rowid[21];
  STORE_CLASS TMCHAR  fabchks_rowid[21];
  STORE_CLASS TMCHAR  fabchka_rowid[21];
  STORE_CLASS TMCHAR  fgbgenl_rowid[21];
  STORE_CLASS TMCHAR  fgbopal_rowid[21];
  STORE_CLASS TMCHAR  ftvactl_rowid[21];
  STORE_CLASS TMCHAR  ftvfsyr_rowid[21];
  STORE_CLASS TMCHAR  farintx_rowid[21];

/* Release IM */

  STORE_CLASS TMCHAR  fibstck_rowid[21];
  STORE_CLASS TMCHAR  fibstop_rowid[21];
  STORE_CLASS TMCHAR  fibbond_rowid[21];
  STORE_CLASS TMCHAR  fibmmkt_rowid[21];
  STORE_CLASS TMCHAR  fibcerd_rowid[21];
  STORE_CLASS TMCHAR  fibprty_rowid[21];
  STORE_CLASS TMCHAR  firstck_rowid[21];
  STORE_CLASS TMCHAR  firstop_rowid[21];
  STORE_CLASS TMCHAR  firbond_rowid[21];
  STORE_CLASS TMCHAR  firmmkt_rowid[21];
  STORE_CLASS TMCHAR  fircerd_rowid[21];
  STORE_CLASS TMCHAR  firprty_rowid[21];
  STORE_CLASS TMCHAR  firisum_rowid[21];
  STORE_CLASS TMCHAR  fibpool_rowid[21];
  STORE_CLASS TMCHAR   control_acct_ind[2];
  STORE_CLASS BANNUMSTR(rulp_exxx_count);
  STORE_CLASS TMCHAR   trnd_ins_ind[2];
  STORE_CLASS TMCHAR   ledger_ind[2];
  STORE_CLASS TMCHAR   field_code[3];
  STORE_CLASS TMCHAR   dr_cr_ind[2];
  STORE_CLASS TMCHAR   gl_dr_cr_ind[2];
  STORE_CLASS TMCHAR   opal_sign[2];
  STORE_CLASS TMCHAR   cy_py_control_ind[2];
  STORE_CLASS TMCHAR   cy_py_control_save[2];
  STORE_CLASS TMCHAR   cy_py_bud_control_ind[2];

/* Release 1.10 */

  STORE_CLASS TMCHAR   cmt_type_control_ind[2];
  STORE_CLASS TMCHAR   uncmt_type_control_ind[2];
  STORE_CLASS TMCHAR   bud_cmt_back_control_ind[2];
  STORE_CLASS TMCHAR   enc_cmt_back_control_ind[2];
  STORE_CLASS TMCHAR   yrlm_budcf[2];
  STORE_CLASS TMCHAR   adj_bo_pohd_code[9];
  STORE_CLASS TMCHAR   adj_bo_blanket_code[9];
  STORE_CLASS TMCHAR   adj_bo_blanket_ind[2];
  STORE_CLASS BANNUMSTR(adj_bo_item_num);
  STORE_CLASS BANNUMSTR(adj_bo_gross_amt);
  STORE_CLASS BANNUMSTR(adj_bo_inv_gross_amt);
  STORE_CLASS BANNUMSTR(adj_bo_sum_inv_amt);

/* Two new variables added for blanket order mods. */

  STORE_CLASS BANNUMSTR(adj_blao_sum_inv_amt);
  STORE_CLASS BANNUMSTR(adj_bo_prev_rem_bal);
  STORE_CLASS BANNUMSTR(adj_bo_temp_amt);
  STORE_CLASS BANNUMSTR(adj_bo_total_inv_amt);
  STORE_CLASS BANNUMSTR(adj_bo_rem_bal);
  STORE_CLASS BANNUMSTR(adj_bo_ext_amt);
  STORE_CLASS BANNUMSTR(adj_bo_fprblao_amt);
  STORE_CLASS TMCHAR   adj_bo_inv_code[9];
  STORE_CLASS BANNUMSTR(adj_bo_inv_item);
  STORE_CLASS TMCHAR   adj_bo_inv_po_code[9];
  STORE_CLASS BANNUMSTR(adj_bo_inv_po_item);
  STORE_CLASS TMCHAR   adj_bo_rem_bal_null[2];
  STORE_CLASS TMCHAR   adj_posted_ind[2];
  STORE_CLASS TMCHAR   adj_bo_inv_final_pmt[2];
  STORE_CLASS TMCHAR   adj_bo_inv_cr_memo_ind[2];
  STORE_CLASS TMCHAR   adj_bo_chks_doc[9];

/* Variables for the general ledger consolidated postings */

  STORE_CLASS TMCHAR  fgrgenc_rowid[21];
  STORE_CLASS TMCHAR   do_genc[2];
  STORE_CLASS TMCHAR  sdat_title[36];
  STORE_CLASS TMCHAR  gl_sum_eff_date[15];
  STORE_CLASS TMCHAR   gl_sum_doc_code[9];
  STORE_CLASS BANNUMSTR(gl_sum_doc_year);
  STORE_CLASS TMCHAR   gl_sum_rulp_code[5];
  STORE_CLASS TMCHAR   genc_rucl_code[5];
  STORE_CLASS TMCHAR   genc_coas_code[2];
  STORE_CLASS TMCHAR   genc_fsyr_code[3];
  STORE_CLASS TMCHAR   genc_fund_code[7];
  STORE_CLASS TMCHAR   genc_acct_code[7];
  STORE_CLASS TMCHAR   genc_period[3];
  STORE_CLASS TMCHAR   genc_field_code[3];
  STORE_CLASS BANNUMSTR(genc_dr_amt);
  STORE_CLASS BANNUMSTR(genc_cr_amt);
  STORE_CLASS BANNUMSTR(genc_trans_amt);
  STORE_CLASS TMCHAR   genc_dr_cr_ind[2];
  STORE_CLASS BANNUMSTR(genc_serial_num);
  STORE_CLASS BANNUMSTR(genc_seq_num);

/* Variables for the available balance checking process */

  STORE_CLASS TMCHAR   abal_err_msg[2];
  STORE_CLASS TMCHAR  abal_status[81];
  STORE_CLASS TMCHAR   abal_check[2];

 /* Release 2.0 Stores (Sri) */
  STORE_CLASS TMCHAR gl_acct_ind[2],
               is_it_stock_item[2];

 /* 2.0.4 (Sri/Don) */
  STORE_CLASS int is_discount;

  STORE_CLASS TMCHAR  fsbsysc_acct_code_trf_in[7];
  STORE_CLASS TMCHAR  fsbsysc_acct_code_trf_out[7];
  STORE_CLASS TMCHAR  rucl_str[5];
  STORE_CLASS TMCHAR  rucl_exists[2];
  STORE_CLASS TMCHAR  bo_exists[2];
  STORE_CLASS TMCHAR  currency_ind[2];
  STORE_CLASS TMCHAR  fpbreqh_single_acctg_ind[2];
  STORE_CLASS TMCHAR  fpbreqh_rqst_type_ind[2];    /* stores 2.0 */

  STORE_CLASS TMCHAR  fsbsysc_acct_code_val_clear[9];
  STORE_CLASS TMCHAR  dr_cr_ind_save[2];

  STORE_CLASS TMCHAR farinvc_comm_code[11];
  STORE_CLASS BANNUMSTR(farinvc_item);
                     STORE_CLASS BANNUMSTR(farinvc_appr_qty);
                     STORE_CLASS BANNUMSTR(ftvcomm_not_invoiced_qty);
                     STORE_CLASS BANNUMSTR(not_invoiced);
  STORE_CLASS int    not_cancelled,
                     DATA_FOUND;

  STORE_CLASS TMCHAR  fprpodt_comm_code[11];
  STORE_CLASS BANNUMSTR(fprpodt_item);
  STORE_CLASS BANNUMSTR(fprpodt_qty);
  STORE_CLASS BANNUMSTR(ftvcomm_onorder_qty);

  STORE_CLASS TMCHAR  fprreqd_comm_code[9];
  STORE_CLASS BANNUMSTR(fprreqd_item);
  STORE_CLASS BANNUMSTR(fprreqd_qty);
  STORE_CLASS BANNUMSTR(ftvcomm_reserved_qty);
  STORE_CLASS BANNUMSTR(ftvcomm_total_value_amt);

  STORE_CLASS  TMCHAR fprrcdt_rowid[21];
  STORE_CLASS  TMCHAR fpbrchd_rowid[21];
  STORE_CLASS  TMCHAR fsradjd_rowid[21];
  STORE_CLASS  TMCHAR fsbadjh_rowid[21];
  STORE_CLASS  TMCHAR ftvcomm_rowid[21];
  STORE_CLASS  TMCHAR fsbissh_rowid[21];
  STORE_CLASS  TMCHAR fsbtrah_rowid[21];
  STORE_CLASS  TMCHAR sp_comm_code[11];
  STORE_CLASS  TMCHAR  sp_ship_code[7];
  STORE_CLASS  TMCHAR sp_sub_locn[16];
  STORE_CLASS  TMCHAR  sp_fund_code_trf_in[7];
  STORE_CLASS  TMCHAR  sp_fund_code_trf_out[7];
  STORE_CLASS  TMCHAR  sp_acct_code_trf_in[7];
  STORE_CLASS  TMCHAR  sp_acct_code_trf_out[7];
  STORE_CLASS  TMCHAR  sp_convert_dr_cr_ind[2];
  STORE_CLASS  TMCHAR  prev_coas_code[2];
  STORE_CLASS  TMCHAR  fsbadjh_adj_type_ind[2];
  STORE_CLASS  TMCHAR  fsradjd_post_ind[2];
  STORE_CLASS  BANNUMSTR(fsradjd_orig_unit_cost);
  STORE_CLASS  BANNUMSTR(fsradjd_orig_stock_qty);
  STORE_CLASS  BANNUMSTR(fsradjd_adj_cnt_qty);
  STORE_CLASS  BANNUMSTR(fsradjd_unit_cost);
  STORE_CLASS  BANNUMSTR(fsradjd_adj_unit_cost);
  STORE_CLASS  BANNUMSTR(fsrvald_unit_price);
  STORE_CLASS  BANNUMSTR(fsrvald_adj_amt);
  STORE_CLASS  BANNUMSTR(fsrvald_qty);
  STORE_CLASS  BANNUMSTR(fsrvald_orig_stock_qty);

  STORE_CLASS  TMCHAR  fprrcdt_pohd_code[9];
  STORE_CLASS  TMCHAR fprrcdt_packing_slip[16];
  STORE_CLASS  TMCHAR  temp_fund_code_invtry[7];
  STORE_CLASS  TMCHAR  temp_acct_code_invtry[7];

  STORE_CLASS TMCHAR fprrcdt_comm_code[11];
  STORE_CLASS TMCHAR  fprrcdt_ship_code[7];
  STORE_CLASS TMCHAR fprrcdt_sub_locn[16];
  STORE_CLASS BANNUMSTR(fprrcdt_item);
  STORE_CLASS BANNUMSTR(fprrcdt_rcvd_qty);
  STORE_CLASS BANNUMSTR(fprrcdt_rejd_qty);
  STORE_CLASS BANNUMSTR(accepted_qty);
  STORE_CLASS TMCHAR fsradjd_comm_code[11];
  STORE_CLASS TMCHAR  fsradjd_ship_code[7];
  STORE_CLASS TMCHAR fsradjd_sub_locn[16];
  STORE_CLASS BANNUMSTR(fsrissd_exrt_amt);
  STORE_CLASS TMCHAR  hold_sp_encd_num[9];
  STORE_CLASS BANNUMSTR(hold_sp_encd_seq_num);
  STORE_CLASS TMCHAR  req_exists_ind[2];
  STORE_CLASS TMCHAR trans_desc[36];

  STORE_CLASS TMCHAR  sp_to_ship_code[7],
                     sp_from_ship_code[7];
  STORE_CLASS TMCHAR fsrtrad_comm_code[11];

  STORE_CLASS TMCHAR fsrtral_from_sub_locn[16],
                     fsrtral_to_sub_locn[16],
                     fsrtrad_packing_slip[16];

  STORE_CLASS BANNUMSTR(fsrtrad_rcdt_item);
                     STORE_CLASS BANNUMSTR(fsrtrad_item);
                     STORE_CLASS BANNUMSTR(temp_trans_amt);
                     STORE_CLASS BANNUMSTR(fsrtral_trans_qty);
                     STORE_CLASS BANNUMSTR(ftvstkl_stock_qty);
                     STORE_CLASS BANNUMSTR(unissued_qty);

  STORE_CLASS TMCHAR fsrtrad_rowid[21],
                     fsrtral_rowid[21],
                     ftvstkl_rowid[21];

  STORE_CLASS TMCHAR  fsrtrad_pohd_code[9],
                     fsbtrah_rchd_code[9];

  STORE_CLASS TMCHAR fsbissh_printed_date[15];
  STORE_CLASS TMCHAR fsrissa_rowid[21];
  STORE_CLASS TMCHAR fsrissd_rowid[21];
  STORE_CLASS TMCHAR fsrissl_rowid[21];

  STORE_CLASS TMCHAR  fsrissd_final_issue_ind[2],
                     sp_return_ind[2];

  STORE_CLASS BANNUMSTR(total_reqd_comm_final);
                     STORE_CLASS BANNUMSTR(total_issd_comm_final);
                     STORE_CLASS BANNUMSTR(fsrissd_item);
                     STORE_CLASS BANNUMSTR(fsrissd_issue_unit_cost);
                     STORE_CLASS BANNUMSTR(fsrissl_issue_qty);
  STORE_CLASS TMCHAR fsrissd_comm_code[11];
  STORE_CLASS TMCHAR  fsrissd_exrt_code[4];
  STORE_CLASS TMCHAR  fsrissl_ship_code[7];
  STORE_CLASS TMCHAR fsrissl_sub_locn[16];
  /* rel. 2.0.2 */
  STORE_CLASS TMCHAR  cy_po_exists[2];
  STORE_CLASS BANNUMSTR(encp_liq_amt_cy);
  STORE_CLASS TMCHAR  save_fsyr_code[3];
  STORE_CLASS TMCHAR  save_acct_code[7];
  /* end rel. 2.0.2 */
  /*Rel. 2.0.2 OSHE grant mods. */

  STORE_CLASS TMCHAR post_grnt_code[10];
  STORE_CLASS TMCHAR post_atyp_code[3];
  STORE_CLASS TMCHAR frrgrnl_rowid[21];
  STORE_CLASS TMCHAR temp_bud_ind[2],
                    adopt_bud_ind[2],
                    bud_adjt_ind[2],
                    ytd_actv_ind[2],
                    encumb_ind[2],
                    res_ind[2],
                    acctd_bud_ind[2];

/* Added for Rel. 3.1 Grants processing.     */
  STORE_CLASS TMCHAR  sysc_defer_grant_ind[2],
                     grant_rate_acct_exists[2],
                     grant_exists[2],
                     fgbtrnd_defer_grant_ind[2];
  STORE_CLASS TMCHAR  hold_invh_num[9];
  STORE_CLASS int sel_defer_grnt_ind(void);

/* Added for Rel. 2.0. Concurrent year processing.     */

  STORE_CLASS TMCHAR  encb_have_rolled[2],
                     cchk_py_closed[2];
  STORE_CLASS TMCHAR  cchk_fsyr_code[3];
  STORE_CLASS TMCHAR  cchk_fsyr_code_save[3];
  STORE_CLASS BANNUMSTR(cchk_consol_amt);
  STORE_CLASS TMCHAR  cchk_inva_rucl_code[5];
  STORE_CLASS TMCHAR  cnep_processed[2];
  STORE_CLASS TMCHAR  cnei_processed[2];
  STORE_CLASS TMCHAR  cnec_processed[2];
  STORE_CLASS int  icnei_processed;  /* 2.0.7 */
  STORE_CLASS int  rebate_process;  /* 2.0.7 */

  STORE_CLASS TMCHAR fgrgrnt_doc_num[16];
  STORE_CLASS int    grant_posting;     /* For grant reversals Defect 2837 */

  /* Added for EDI enhancement 4.0 */
  STORE_CLASS TMCHAR  sp_edi_ind[2];

  /* Added for EMS Project 4.0.1 */
  STORE_CLASS TMCHAR sp_gift_date[15];
  STORE_CLASS TMCHAR sp_emc_units[13];


  STORE_CLASS TMCHAR o030_o031_ind;
  STORE_CLASS TMCHAR g073_ind;
  STORE_CLASS TMCHAR fixed_asset_acct;
  STORE_CLASS TMCHAR doc_feed_ind;

  /* Shared indicator variables for SELECTs */

  STORE_CLASS short   Ind_01;
  STORE_CLASS short   Ind_02;
  STORE_CLASS short   Ind_03;
  STORE_CLASS short   Ind_04;
  STORE_CLASS short   Ind_05;
  STORE_CLASS short   Ind_06;
  STORE_CLASS short   Ind_07;
  STORE_CLASS short   Ind_08;
  STORE_CLASS short   Ind_09;
  STORE_CLASS short   Ind_10;
  STORE_CLASS short   Ind_11;
  STORE_CLASS short   Ind_12;
  STORE_CLASS short   Ind_13;
  STORE_CLASS short   Ind_14;
  STORE_CLASS short   Ind_15;
  STORE_CLASS short   Ind_16;
  STORE_CLASS short   Ind_17;
  STORE_CLASS short   Ind_18;
  STORE_CLASS short   Ind_19;
  STORE_CLASS short   Ind_20;
  STORE_CLASS short   Ind_21;
  STORE_CLASS short   Ind_22;
  STORE_CLASS short   Ind_23;
  STORE_CLASS short   Ind_24;
  STORE_CLASS short   Ind_25;
  STORE_CLASS short   Ind_26;
  STORE_CLASS short   Ind_27;
  STORE_CLASS short   Ind_28;
  STORE_CLASS short   Ind_29;
  STORE_CLASS short   Ind_30;
  STORE_CLASS short   Ind_31;
  STORE_CLASS short   Ind_32;
  STORE_CLASS short   Ind_33;
  STORE_CLASS short   Ind_34;
  STORE_CLASS short   Ind_35;
  STORE_CLASS short   Ind_36;
  STORE_CLASS short   Ind_37;
  STORE_CLASS short   Ind_38;
  STORE_CLASS short   Ind_39;
  STORE_CLASS short   Ind_40;
  STORE_CLASS short   Ind_41;
  STORE_CLASS short   Ind_42;
  STORE_CLASS short   Ind_43;
  STORE_CLASS short   Ind_44;
  STORE_CLASS short   Ind_45;
  STORE_CLASS short   Ind_46;
  STORE_CLASS short   Ind_47;
  STORE_CLASS short   Ind_48;
  STORE_CLASS short   Ind_49;
  STORE_CLASS short   Ind_50;
  STORE_CLASS short   Ind_51;
  STORE_CLASS short   Ind_52;
  STORE_CLASS short   Ind_53;
  STORE_CLASS short   Ind_54;
  STORE_CLASS short   Ind_55;
  STORE_CLASS short   Ind_56;
  STORE_CLASS short   Ind_57;
  STORE_CLASS short   Ind_58;
  STORE_CLASS short   Ind_59;
  STORE_CLASS short   Ind_60;
EXEC SQL END DECLARE SECTION;

/* Local prototypes */

STORE_CLASS int get_opp_sys(void);
STORE_CLASS int sel_doc_appd(int mode);
STORE_CLASS int sel_doc_appd_for_update(int mode);
STORE_CLASS int sel_budcf_yrlm(int mode);
STORE_CLASS int sel_null_bo_rem_balance(int mode);
STORE_CLASS int sel_podt_remain_direct(int mode);
STORE_CLASS int sel_podt_remain_indirect(int mode);
STORE_CLASS void upd_fprpodt_direct(void);
STORE_CLASS void upd_fprpodt_indirect(void);
STORE_CLASS int sel_po_for_inv(int mode);
STORE_CLASS int sel_podt_items(int mode);
STORE_CLASS int sel_inv_podt_items(int mode);
STORE_CLASS int sel_invc_items(int mode);
STORE_CLASS int sel_chks_invc_items(int mode);
STORE_CLASS int sel_inv_po_sum(int mode);
STORE_CLASS int sel_blao_sum_inv(int mode);
STORE_CLASS int sel_po_sum_amt_doc(int mode);
STORE_CLASS int sel_bo_item(int mode);
STORE_CLASS void upd_fprblao_direct_inv(void);
STORE_CLASS void upd_fprblao(void);
STORE_CLASS void upd_fprblao_indirect_inv(void);
STORE_CLASS void del_unchg_poda(void);
STORE_CLASS void del_unchg_podt(void);
STORE_CLASS void del_unchg_blao(void);
STORE_CLASS int update_ext_sel_podt(int mode);
STORE_CLASS void update_ext_podt1(void);
STORE_CLASS void update_ext_podt2(void);
STORE_CLASS void calc_delta_pohd(void);
STORE_CLASS int calc_delta_sel_podt(int mode);
STORE_CLASS void calc_delta_podt(void);
STORE_CLASS int calc_delta_sel_poda(int mode);
STORE_CLASS void calc_delta_poda(void);
STORE_CLASS int reset_rucl_sel_rucl(int mode);
STORE_CLASS void upd_podt_closed_partial(void);
STORE_CLASS int sel_final_pmt_invc(int mode);
STORE_CLASS int sel_total_liq_ind(int mode);
STORE_CLASS int sel_final_pmt_podt(int mode);
STORE_CLASS int sel_invc_final_ind(int mode);
STORE_CLASS int sel_final_pmt_comm_invc(int mode);
STORE_CLASS void reset_rucl_amt(void);
STORE_CLASS void reset_rucl_disc(void);
STORE_CLASS void reset_rucl_tax(void);
STORE_CLASS void reset_rucl_addl(void);
STORE_CLASS void update_null_pohd(void);
STORE_CLASS void update_null_can_pohd1(void);
STORE_CLASS void update_null_can_pohd2(void);
STORE_CLASS int update_null_s_updt_podt(int mode);
STORE_CLASS void update_null_updt_podt(void);
STORE_CLASS void update_null_can_podt1(void);
STORE_CLASS void update_null_can_podt2(void);
STORE_CLASS int update_null_s_ins_podt(int mode);
STORE_CLASS void update_null_ins_podt(void);
STORE_CLASS int update_null_s_updt_poda(int mode);
STORE_CLASS void update_null_updt_poda(void);
STORE_CLASS void update_null_updt_poda_pct(void);
STORE_CLASS void update_null_updt_poda_pct_doc(void);
STORE_CLASS void update_null_can_poda(void);
STORE_CLASS int update_null_s_ins_poda(int mode);
STORE_CLASS void update_null_ins_poda(void);
STORE_CLASS void update_text_del(void);
STORE_CLASS void update_text_ins(void);
STORE_CLASS void update_text_can_ins(void);
STORE_CLASS void update_tax_del(void);
STORE_CLASS void update_tax_ins(void);
STORE_CLASS void ins_farinva(void);    /* added for grant reversals */
STORE_CLASS void lock_appd(void);
STORE_CLASS void lock_bako(void);
STORE_CLASS void lock_ench(void);
STORE_CLASS void lock_encd(void);
STORE_CLASS void lock_encp(void);
STORE_CLASS void lock_reqh(void);
STORE_CLASS void lock_reqa(void);
STORE_CLASS void lock_pohd(void);
STORE_CLASS void lock_podt(void);
STORE_CLASS void lock_poda(void);
STORE_CLASS void lock_reqd(void);
STORE_CLASS void lock_text(void);
STORE_CLASS void lock_invh(void);
STORE_CLASS void lock_chks(void);
STORE_CLASS void lock_genl(void);
STORE_CLASS void lock_grnt(void);
STORE_CLASS void lock_jvcd(void);
STORE_CLASS void lock_jvch(void);
STORE_CLASS void lock_opal(void);
STORE_CLASS void lock_wo(void);
STORE_CLASS void lock_genc(void);
STORE_CLASS void lock_pool(void);
STORE_CLASS void lock_stk(void);
STORE_CLASS void lock_sto(void);
STORE_CLASS void lock_bnd(void);
STORE_CLASS void lock_mkt(void);
STORE_CLASS void lock_cd(void);
STORE_CLASS void lock_pty(void);
STORE_CLASS void lock_stcc(void);
STORE_CLASS void lock_stoc(void);
STORE_CLASS void lock_bonc(void);
STORE_CLASS void lock_mmkc(void);
STORE_CLASS void lock_cerc(void);
STORE_CLASS void lock_prtc(void);
STORE_CLASS void lock_seqn(void);
STORE_CLASS void lock_issh(void);        /* added for  stores */
STORE_CLASS void lock_trah(void);        /* added for  stores */
STORE_CLASS void lock_rchd(void);        /* added for  stores */
STORE_CLASS void lock_adjh(void);        /* added for  stores */
STORE_CLASS int sel_sysdate(void);
STORE_CLASS int sel_jvc_head(int mode);
STORE_CLASS int sel_jvc_acctg(int mode);
STORE_CLASS void insert_fobappd_check(void);
STORE_CLASS void ins_fobdinp(void);
STORE_CLASS void ins_stcc(void);
STORE_CLASS void ins_bonc(void);
STORE_CLASS int sel_enc_head(int mode);
STORE_CLASS int sel_enc_acctg(int mode);
STORE_CLASS int sel_sysdate(void);
STORE_CLASS int sel_jvc_head(int mode);
STORE_CLASS int sel_jvc_acctg(int mode);
STORE_CLASS void insert_fobappd_check(void);
STORE_CLASS void ins_fobdinp(void);
STORE_CLASS void ins_stcc(void);
STORE_CLASS void ins_bonc(void);
STORE_CLASS int sel_enc_head(int mode);
STORE_CLASS int sel_enc_acctg(int mode);
STORE_CLASS int sel_bnd_adjust_date(int mode);
STORE_CLASS int sel_bnd_min_date(int mode);
STORE_CLASS int sel_stk_acctg(int mode);
STORE_CLASS int sel_sto_acctg(int mode);
STORE_CLASS int sel_bnd_acctg(int mode);
STORE_CLASS int sel_mkt_acctg(int mode);
STORE_CLASS int sel_cd_acctg(int mode);
STORE_CLASS int sel_pty_acctg(int mode);
STORE_CLASS int sel_req_head(int mode);
STORE_CLASS int sel_wo_head(int mode);
STORE_CLASS int sel_reqh_upd_comp_appr(int mode);
STORE_CLASS int sel_reqh_upd_can(int mode);
STORE_CLASS void update_reqh_can(void);
STORE_CLASS int sel_wo_upd_comp_appr(int mode);
STORE_CLASS void update_enc_pend_amt(void);
STORE_CLASS void update_reqh_comp_appr(void);
STORE_CLASS void update_reqa_appr(void);
STORE_CLASS void update_wo_appr(void);
STORE_CLASS int sel_pohd_upd_comp_appr(int mode);
STORE_CLASS int sel_pohd_upd_can(int mode);
STORE_CLASS void update_pohd_comp_appr(void);
STORE_CLASS void update_pohd_can(void);
STORE_CLASS void update_poda_appr(void);
STORE_CLASS int sel_invh_upd_comp_appr(void);
STORE_CLASS int sel_invh_upd_can(void);
STORE_CLASS int sel_invh_upd_open_paid(int mode);
STORE_CLASS int sel_invh_upd_submission(int mode);
STORE_CLASS void update_invh_comp_appr(void);
STORE_CLASS void update_invh_can(void);
STORE_CLASS void update_inva_appr(void);
STORE_CLASS void update_invh_open_paid(void);
STORE_CLASS void update_invh_submission(void);
STORE_CLASS int sel_chkh_can(int mode);
STORE_CLASS void update_chkh_can(void);
STORE_CLASS void update_chka_can(void);
STORE_CLASS void update_invh_cancl_chk(void);
STORE_CLASS void update_inck_cancl_chk(void);
STORE_CLASS void update_inva_cancl_chk(void);
STORE_CLASS void update_invc_cancl_chk(void);
STORE_CLASS int sel_jvch_upd_comp_appr(int mode);
STORE_CLASS void update_jvch_comp_appr(void);
STORE_CLASS void update_jvcd_appr(void);
STORE_CLASS int sel_ench_upd_comp_appr(int mode);
STORE_CLASS void update_ench_comp_appr(void);
STORE_CLASS void update_encd_appr(void);
STORE_CLASS void del_blao_inv(void);
STORE_CLASS void del_blao_chk(void);
STORE_CLASS void del_blao_po(void);
STORE_CLASS int sel_req_acctg(int mode);
STORE_CLASS int sel_wo_acctg(int mode);
STORE_CLASS int sel_po_head(int mode);
STORE_CLASS int sel_po_acctg(int mode);
STORE_CLASS int sel_inv_head(int mode);
STORE_CLASS int sel_inv_acctg(int mode);
STORE_CLASS int sel_trans_vendor_name(int mode);
STORE_CLASS int sel_chk_acctg(int mode);
STORE_CLASS int sel_intx_non_vend_tax(int mode);
STORE_CLASS int get_chk_can_intx_rucl(int mode);
STORE_CLASS int get_rebate_intx_rucl(int mode);
STORE_CLASS int get_cancel_rebate_intx_rucl(int mode);  /* New for Rebates */
STORE_CLASS int get_intx_n_v_rucl(int mode);
STORE_CLASS int sel_intx_n_v_r_tax_chk(int mode);
STORE_CLASS int sel_intx_n_v_tax_chk(int mode);
STORE_CLASS int sel_inva_via_chk(int mode);
STORE_CLASS int sel_invh_acctg_ind_chk(void);       /* Rel. 2.0.2 */
STORE_CLASS void upd_farintx(void);
STORE_CLASS void upd_farintx_rebate(void);   /* GST enhancement 2.1.11 */
STORE_CLASS void upd_farinva(void);
STORE_CLASS void upd_farinvc(void);
STORE_CLASS int sel_vendor_pidm_name(int mode);
STORE_CLASS int sel_rqpo(int mode);
STORE_CLASS int sel_bdpo(int mode);
STORE_CLASS void upd_fprbidd(void);
STORE_CLASS void del_ftvbdpo(void);
STORE_CLASS int sel_rulp_posting(int mode);
STORE_CLASS int sel_curr_code(int mode);
STORE_CLASS int sel_ap_exch_acct(int mode);
STORE_CLASS int sel_rulp_exxx_count(int mode);
STORE_CLASS int read_fund(int mode);
STORE_CLASS int read_indc(int mode);
STORE_CLASS int read_inap(int mode);
STORE_CLASS int read_inrc(int mode);
STORE_CLASS int read_cost(int mode);
STORE_CLASS int read_csap(int mode);
STORE_CLASS int read_cscn(int mode);
STORE_CLASS int sel_oh_dr(int mode);
STORE_CLASS int sel_oh_cr(int mode);
STORE_CLASS int sel_match_dr(int mode);
STORE_CLASS int sel_match_fund_cr(int mode);
STORE_CLASS int sel_cost_sh_overhead(int mode);
STORE_CLASS int sel_total_rev_accr(int mode);
STORE_CLASS int calc_oh_debit(int mode);
STORE_CLASS int calc_ma_debit(int mode);
STORE_CLASS int calc_ma_credit(int mode);
STORE_CLASS int calc_oh_credit(int mode);
STORE_CLASS void ins_prjd(void);
STORE_CLASS void ins_grnt(void);
STORE_CLASS int sel_grnt(int mode);
STORE_CLASS void del_parm(void);
STORE_CLASS void del_grnt(void);
STORE_CLASS int sel_ctrl_acct(int mode);
STORE_CLASS int sel_acct_type(int mode);
STORE_CLASS int sel_acct_type_pred(int mode);
STORE_CLASS int sel_gl_sum_eff_date(int mode);
STORE_CLASS int sel_gl_sum_doc_code(void);
STORE_CLASS int sel_gl_sum_doc_year(void);
STORE_CLASS int sel_rucl_for_genc(int mode);
STORE_CLASS int sel_sdat_gl_sum(int mode);
STORE_CLASS int sel_sdat_gl_sum_title(int mode);
STORE_CLASS int sel_genc_post(int mode);
STORE_CLASS void ins_gl_via_genc(void);
STORE_CLASS int sel_genc(int mode);
STORE_CLASS void ins_genc(void);
STORE_CLASS void upd_genc_cr(void);
STORE_CLASS void upd_genc_dr(void);
STORE_CLASS void upd_gl_cr_via_genc(void);
STORE_CLASS void upd_gl_dr_via_genc(void);
STORE_CLASS void ins_trnd_via_genc(void);
STORE_CLASS void ins_trnh_via_genc(void);
STORE_CLASS int sel_bank(int mode);
STORE_CLASS int sel_bank_for_pool(int mode);
STORE_CLASS int sel_coas(int mode);
STORE_CLASS int sel_coas_budg_disp(int mode);
STORE_CLASS int sel_coas_cmt_type(int mode);
STORE_CLASS int get_cmt_invc_part_pmt(int mode);
STORE_CLASS int get_chk_invc_part_pmt(int mode);   /* Rel 2.0 */
STORE_CLASS int sel_curr_fsyr_code(int mode);
STORE_CLASS int sel_consol(void);
STORE_CLASS int sel_fsyr(int mode);
STORE_CLASS int sel_fsyr_chk(int mode);            /* rel 2.0 */
STORE_CLASS int sel_correct_fsyr_fspd(int mode);
STORE_CLASS int sel_ftyp_cmt_type(int mode);
STORE_CLASS int sel_ftyp_cmt_type_pred(int mode);
STORE_CLASS int sel_ftyp_budg_disp(int mode);
STORE_CLASS int sel_ftyp_budg_disp_pred(int mode);
STORE_CLASS int sel_pooled_funds_acct(int mode);
STORE_CLASS int sel_pooled_fund_bal(int mode);
STORE_CLASS int sel_pool_fund_ind(int mode);
STORE_CLASS int pfif_fund_history(int mode);
STORE_CLASS int cal_pfif_avg_cost(int mode);
STORE_CLASS int sel_round_pfif(int mode);
STORE_CLASS int sel_real_gain_loss(int mode);
STORE_CLASS int sel_rsnc_affect(int mode);
STORE_CLASS int sel_invest_type_accounts(int mode);
STORE_CLASS int sel_isum_post(int mode);
STORE_CLASS void ins_isum(void);
STORE_CLASS void upd_isum(void);
STORE_CLASS int sel_pool_post(int mode);
STORE_CLASS void ins_pool(void);
STORE_CLASS void upd_pool(void);
/* Release IM 2.0 RLO   */
STORE_CLASS int sel_calc_bond_master(int mode);
STORE_CLASS int sel_firbond_carry_value(int mode);
STORE_CLASS int sel_first_date(int mode,TMCHAR *date, TMCHAR *first_date);
STORE_CLASS int sel_months_between(int mode, TMCHAR *date1, TMCHAR *date2, TMCHAR *months);
STORE_CLASS double n_carry(double c_carry, double y_rate, double nom_int, int months);
STORE_CLASS double YTM(double i_rate, double par_val, double n_bonds, double disc_rate, double bond_years);
STORE_CLASS double eff_interest(double y_rate, double carrying_value);
STORE_CLASS double get_amort_amt(double eff_int, double nom_int);
STORE_CLASS int sel_firbond_trans(int mode);
/*  end IM 2.0 RLO   */
STORE_CLASS int sel_stk_avg_cost(int mode);
STORE_CLASS int sel_round_stk_ac(int mode);
STORE_CLASS int sel_sto_avg_cost(int mode);
STORE_CLASS int sel_round_sto_ac(int mode);
STORE_CLASS int sel_bnd_avg_cost(int mode);
STORE_CLASS int sel_round_bnd_ac(int mode);
STORE_CLASS int sel_mkt_avg_cost(int mode);
STORE_CLASS int sel_round_mkt_ac(int mode);
STORE_CLASS int sel_cd_avg_cost(int mode);
STORE_CLASS int sel_round_cd_ac(int mode);
STORE_CLASS int sel_pty_avg_cost(int mode);
STORE_CLASS int sel_round_pty_ac(int mode);
STORE_CLASS int sel_uvms_units(int mode);
STORE_CLASS int sel_stk_base(int mode);
STORE_CLASS void ins_stk_base(void);
STORE_CLASS void ins_stk_repeat(void);
STORE_CLASS int sel_sto_base(int mode);
STORE_CLASS void ins_sto_base(void);
STORE_CLASS void ins_sto_repeat(void);
STORE_CLASS int sel_bnd_base(int mode);
STORE_CLASS void ins_bnd_base(void);
STORE_CLASS void upd_bnd_aggr_amt(void);
STORE_CLASS void upd_bnd_base(void);
STORE_CLASS void ins_bnd_repeat(void);
STORE_CLASS int sel_mkt_base(int mode);
STORE_CLASS void ins_mkt_base(void);
STORE_CLASS void ins_mkt_repeat(void);
STORE_CLASS int sel_cd_base(int mode);
STORE_CLASS void ins_cd_base(void);
STORE_CLASS void ins_cd_repeat(void);
STORE_CLASS int sel_pty_base(int mode);
STORE_CLASS void ins_pty_base(void);
STORE_CLASS void ins_pty_repeat(void);
STORE_CLASS void upd_seqn_next_im(void);
STORE_CLASS int sel_seqn_doc_num(int mode);
STORE_CLASS int sel_seqn_num_stck(int mode);
STORE_CLASS int sel_seqn_num_stop(int mode);
STORE_CLASS int sel_seqn_num_bond(int mode);
STORE_CLASS int sel_seqn_num_mmkt(int mode);
STORE_CLASS int sel_seqn_num_cerd(int mode);
STORE_CLASS int sel_seqn_num_prty(int mode);
STORE_CLASS int sel_seqn_num_trnh(int mode);
STORE_CLASS int sel_sysc_sale_ind(int mode);
STORE_CLASS void ins_stk_collector(void);
STORE_CLASS void ins_sto_collector(void);
STORE_CLASS void ins_bnd_collector(void);
STORE_CLASS void ins_mkt_collector(void);
STORE_CLASS void ins_cd_collector(void);
STORE_CLASS void ins_pty_collector(void);
STORE_CLASS void del_stk_repeat(void);
STORE_CLASS void del_sto_repeat(void);
STORE_CLASS void del_bnd_repeat(void);
STORE_CLASS void del_mkt_repeat(void);
STORE_CLASS void del_cd_repeat(void);
STORE_CLASS void del_pty_repeat(void);
STORE_CLASS void del_firdsdt(void);
STORE_CLASS void del_firspnd(void);
STORE_CLASS int sel_sdat(int mode);
STORE_CLASS int sel_sdat_chka(int mode);
STORE_CLASS int sel_sysc(int mode);
STORE_CLASS int sel_gl_post_with_genc(int mode);
STORE_CLASS int sel_gl_post(int mode);
STORE_CLASS void ins_gl(void);
STORE_CLASS void upd_gl_cr(void);
STORE_CLASS void upd_gl_dr(void);
STORE_CLASS int sel_op_post(int mode);
STORE_CLASS int sel_encp_fsyr(int mode);
STORE_CLASS void ins_op(void);
STORE_CLASS void upd_op_adopt_bud(void);
STORE_CLASS void upd_op_bud_adjt(void);
STORE_CLASS void upd_op_ytd_actv(void);
STORE_CLASS void upd_op_encumb(void);
STORE_CLASS void upd_op_res(void);
STORE_CLASS void upd_op_acctd_bud(void);
STORE_CLASS void upd_op_temp_bud(void);
STORE_CLASS void ins_trnd(void);
STORE_CLASS void ins_trnh(void);
STORE_CLASS int exxx_sel_fgbencd_field_code(int mode);
STORE_CLASS int exxx_test_future(int mode);
STORE_CLASS int exxx_check_py(int mode);
STORE_CLASS int exxx_test_prior(int mode);
STORE_CLASS int sel_cmt_encp_bal(int mode);
STORE_CLASS int exxx_sel_encp_bal(int mode);
STORE_CLASS int exxx_sel_encp_post(int mode);
STORE_CLASS void exxx_ins_encp(void);
STORE_CLASS void exxx_upd_encp(void);
STORE_CLASS int abs_post_trans_amt(int mode);
STORE_CLASS void upd_encd_opal_field_code(void);
STORE_CLASS void exxx_upd_poda_close(void);
STORE_CLASS void exxx_upd_single_poda_close(void);
STORE_CLASS void exxx_upd_single_poda_open(void);
STORE_CLASS void exxx_upd_poda_reopen(void);
STORE_CLASS void exxx_upd_podt_reopen(void);
STORE_CLASS void exxx_upd_pohd_reopen(void);
STORE_CLASS void exxx_upd_reqd_reopen(void);
STORE_CLASS void exxx_delete_rqpo(void);
STORE_CLASS void exxx_delete_single_rqpo(void);
STORE_CLASS int exxx_sel_reqd_close_reopen(int mode);
STORE_CLASS int exxx_sel_poda_close_reopen(int mode);
STORE_CLASS void exxx_upd_encd_close(void);
STORE_CLASS void exxx_upd_encd_reopen(void);
STORE_CLASS void exxx_upd_ench_reopen(void);
STORE_CLASS int exxx_sel_encd_close_reopen(int mode);
STORE_CLASS int exxx_sel_close_ench_ind(int mode);
STORE_CLASS int exxx_sel_ench_close_reopen(int mode);
STORE_CLASS void exxx_upd_ench_close(void);
STORE_CLASS int exxx_sel_encd_cmt(int mode);
STORE_CLASS void exxx_upd_encd_cmt(void);
STORE_CLASS int exxx_get_cmt_type(int mode);
STORE_CLASS int exxx_sel_podt_close_reopen(int mode);
STORE_CLASS void exxx_upd_podt_close(void);
STORE_CLASS void exxx_upd_single_podt_close(void);
STORE_CLASS void exxx_upd_single_podt_open(void);
STORE_CLASS void exxx_upd_single_reqd_open(void);
STORE_CLASS int exxx_sel_pohd_close_reopen(int mode);
STORE_CLASS void exxx_upd_pohd_close(void);
STORE_CLASS int exxx_sel_ench(int mode);
STORE_CLASS void exxx_ins_ench(void);
STORE_CLASS void exxx_ins_encd(void);
STORE_CLASS int exxx_sel_encp_bal_all(int mode);
STORE_CLASS int exxx_sel_prev_fsyr(int mode);
STORE_CLASS int exxx_sel_next_fsyr(int mode);
STORE_CLASS int get_rev_enc_amt(int mode);
STORE_CLASS int get_chk_enc_amt(int mode);    /* REl. 2.0 */
STORE_CLASS int sel_encb_roll(void);           /* REl. 2.0 */
STORE_CLASS int exxx_get_liq_amount(int mode);
STORE_CLASS int exxx_get_liq_amount_disc(int mode);
STORE_CLASS int exxx_get_liq_amount_tax(int mode);
STORE_CLASS int exxx_get_liq_amount_addl(int mode);
STORE_CLASS int exxx_get_liq_amt_chk(int mode);
STORE_CLASS int exxx_get_liq_amt_chk_py(int mode);  /* rel 2.0  */
STORE_CLASS int exxx_get_liq_amt_e023(int mode);    /* rel 2.0  */
STORE_CLASS int exxx_get_liq_amt_disc_chk(int mode);
STORE_CLASS int exxx_get_liq_amt_tax_chk(int mode);
STORE_CLASS int exxx_get_liq_amt_addl_chk(int mode);
STORE_CLASS void del_appd(void);
STORE_CLASS void del_genc(void);
STORE_CLASS void del_jvch(void);
STORE_CLASS void del_jvcd(void);
STORE_CLASS void im_del_jvch(void);
STORE_CLASS void im_del_jvcd(void);
STORE_CLASS int sel_bako(int mode);
STORE_CLASS int select_fgrbako_failsafe(int mode);
STORE_CLASS void del_bako(void);
STORE_CLASS void commit_document(void);
STORE_CLASS void rollback_document(void);
STORE_CLASS void reset_doc(void);
STORE_CLASS void doc_body(void);
STORE_CLASS void delete_bako(void);
STORE_CLASS void do_bako_delete(void);
STORE_CLASS void doc_exec_jvc(void);
STORE_CLASS void doc_exec_enc(void);
STORE_CLASS void doc_exec_req(void);
STORE_CLASS void doc_exec_stk(void);
STORE_CLASS void doc_exec_sto(void);
STORE_CLASS void doc_exec_bnd(void);
STORE_CLASS void doc_exec_mkt(void);
STORE_CLASS void doc_exec_cd(void);
STORE_CLASS void doc_exec_pty(void);
STORE_CLASS void body_bdpo(void);
STORE_CLASS void doc_exec_po(void);
STORE_CLASS void doc_exec_inv(void);
STORE_CLASS void doc_exec_chk(void);
STORE_CLASS void doc_exec_wo(void);
STORE_CLASS void jvc_acctg_body(void);
STORE_CLASS void enc_acctg_body(void);
STORE_CLASS void req_acctg_body(void);
STORE_CLASS void req_liq_acctg_body(void);
STORE_CLASS void wo_acctg_body(void);
STORE_CLASS void stk_acctg_body(void);
STORE_CLASS void stk_get_avg_cost(void);
STORE_CLASS void sto_acctg_body(void);
STORE_CLASS void sto_get_avg_cost(void);
STORE_CLASS void bnd_acctg_body(void);
STORE_CLASS void bnd_get_avg_cost(void);
STORE_CLASS void determine_first_period(void);
STORE_CLASS void calc_bond(TMCHAR *carry_value, TMCHAR *amort_amt);  /* New */
STORE_CLASS void mkt_acctg_body(void);
STORE_CLASS void mkt_get_avg_cost(void);
STORE_CLASS void cd_acctg_body(void);
STORE_CLASS void cd_get_avg_cost(void);
STORE_CLASS void pty_acctg_body(void);
STORE_CLASS void pty_get_avg_cost(void);
STORE_CLASS void ins_pool_collector(void);
STORE_CLASS void set_collector_variable(void);
STORE_CLASS void ins_im_collector(void);
STORE_CLASS void generate_doc_num(void);
STORE_CLASS void po_acctg_body(void);
STORE_CLASS void po_acctg_gross(void);
STORE_CLASS void po_acctg_disc(void);
STORE_CLASS void po_acctg_tax(void);
STORE_CLASS void po_acctg_addl(void);
STORE_CLASS void po_acctg_consol_post(void);
STORE_CLASS void podt_items_reduce_bo(void);
STORE_CLASS void bo_item_change(void);
STORE_CLASS void invc_items_body(void);
STORE_CLASS void chks_invc_items_body(void);
STORE_CLASS void adjust_bo_balance(void);
STORE_CLASS void adjust_bo_bal_reverse(void);
STORE_CLASS void init_change_order(void);
STORE_CLASS void update_null_record(void);
STORE_CLASS void inv_acctg_body(void);
STORE_CLASS void inv_acctg_disc(void);
STORE_CLASS void inv_acctg_gross(void);
STORE_CLASS void inv_acctg_tax(void);
STORE_CLASS void inv_acctg_consol_post(void);
STORE_CLASS void intx_acctg_non_vend_tax(void);
STORE_CLASS void inv_acctg_addl(void);
STORE_CLASS void chk_acctg_head(void);
STORE_CLASS void chk_acctg_body(void);
STORE_CLASS void chk_acctg_foot(void);
STORE_CLASS void set_intx_pre(void);
STORE_CLASS void intx_round_head(void);
STORE_CLASS void intx_round_body(void);
STORE_CLASS void do_intx_round(void);
STORE_CLASS void intx_round_foot(void);
STORE_CLASS void intx_no_round_body(void);
STORE_CLASS void intx_acctg_n_v_tax_chk(void);
STORE_CLASS void acctg_body(void);
STORE_CLASS void grant_proc_body(void);
STORE_CLASS void posting_body(void);
STORE_CLASS void isum_ins_trans_amt(void);
STORE_CLASS void capitalization_posting(void);
STORE_CLASS void grant_body(void);
STORE_CLASS void sel_indc(void);
STORE_CLASS void readinapbody(void);
STORE_CLASS void sel_cost(void);
STORE_CLASS void readcsapbody(void);
STORE_CLASS void sel_inrc(void);
STORE_CLASS void sel_cscn_dr(void);
STORE_CLASS void madebitbody(void);
STORE_CLASS void sel_cscn(void);
STORE_CLASS void macreditbody(void);
STORE_CLASS void sel_inrc_cr(void);
STORE_CLASS void ohcreditbody(void);
STORE_CLASS void ohcredithead(void);
STORE_CLASS void print_error_line(void);
STORE_CLASS void gen_all_trans(void);
STORE_CLASS void genc_head(void);
STORE_CLASS void genc_body(void);
STORE_CLASS void post_genc_dr_amt(void);
STORE_CLASS void post_genc_cr_amt(void);
STORE_CLASS void exxx_post_genc(void);
STORE_CLASS void determine_acct_type(void);
STORE_CLASS void check_gl_keys(void);
STORE_CLASS void set_dr_cr(void);
STORE_CLASS void set_reverse_dr_cr(void);
STORE_CLASS void set_posting_codes(void);
STORE_CLASS void set_posting_override_codes_fcn(void);
STORE_CLASS void determine_cy_py_control(void);
STORE_CLASS void post_gl_dr_amt(void);
STORE_CLASS void post_gl_cr_amt(void);
STORE_CLASS void fund_bal_posting(void);
STORE_CLASS void fund_bal_posting_genc(void);
STORE_CLASS void exxx_check_source(void);
STORE_CLASS void exxx_get_field_code(void);
STORE_CLASS void exxx_test_foapal_match(void);
STORE_CLASS void exxx_replace_cifoapal(void);
STORE_CLASS void exxx_check_atyp(void);
STORE_CLASS void exxx_set_amt_p(void);
STORE_CLASS void exxx_post_op(void);
STORE_CLASS void exxx_post_gl(void);
STORE_CLASS void exxx_close_encd(void);
STORE_CLASS void exxx_reopen_encd(void);
STORE_CLASS void exxx_check_status(void);
STORE_CLASS void exxx_set_amt_t(void);
STORE_CLASS void exxx_swap_encumb_num(void);
STORE_CLASS void exxx_restore_encumb_num(void);
STORE_CLASS void exxx_post_orig_encp(void);
STORE_CLASS void exxx_post_gl_ctrl(void);
STORE_CLASS void exxx_post_adjt_encp(void);
STORE_CLASS void exxx_post_liq_encp(void);
STORE_CLASS void exxx_post_cmt_encd(void);
STORE_CLASS void exxx_post_all_encp(void);
STORE_CLASS void exxx_get_prev_fsyr(void);

/* New functions added for Stores req. closure fix        */
STORE_CLASS void exxx_close_po(void);
STORE_CLASS void exxx_close_req(void);
STORE_CLASS int exxx_sel_reqa_close_reopen(int mode);
STORE_CLASS int exxx_sel_reqh_close_reopen(int mode);
STORE_CLASS void exxx_upd_reqa_close(void);
STORE_CLASS void exxx_upd_reqd_close(void);
STORE_CLASS void exxx_upd_reqh_close(void);
STORE_CLASS void exxx_upd_single_reqa_close(void);
STORE_CLASS void exxx_upd_single_reqd_close(void);
STORE_CLASS void upd_reqd_closed_partial(void);
STORE_CLASS int exxx_sel_reqa_encumb_for_po(void);
STORE_CLASS int exxx_sel_po_source(void);
STORE_CLASS void determine_grant_hit(void);   /* Rel 2.0.2 */

/* New functions added to posting as IM mods. The source code for these   */
/* functions is stored after the posting body routine.                    */

/* Release 2.0 IM mods.   */

STORE_CLASS void i011_init(void);
STORE_CLASS void i012_init(void);
STORE_CLASS void i021_init(void);
STORE_CLASS void i022_init(void);
STORE_CLASS void i031_init(void);
STORE_CLASS void i032_init(void);
STORE_CLASS void i040_init(void);
STORE_CLASS void i050_init(void);
STORE_CLASS void i061_init(void);
STORE_CLASS void i062_init(void);
STORE_CLASS void i081_init(void);
STORE_CLASS void i091_init(void);
STORE_CLASS void i092_init(void);
STORE_CLASS void e031_postings(void);   /* stores mod */
STORE_CLASS void g105_postings(void);


/*  New process codes for Stores        */

STORE_CLASS void g061_postings(void);
STORE_CLASS void g062_postings(void);
STORE_CLASS void g063_postings(void);
STORE_CLASS void g064_postings(void);
STORE_CLASS void g065_postings(void);
STORE_CLASS void g066_postings(void);
STORE_CLASS void g067_postings(void);
STORE_CLASS void g068_postings(void);
STORE_CLASS void o060_postings(void);

/* new process codes for fixed assets */

STORE_CLASS void g070_postings(void);
STORE_CLASS void g071_postings(void);
STORE_CLASS void g072_postings(void);
STORE_CLASS void g073_postings(void);
STORE_CLASS void g074_postings(void);
STORE_CLASS void g075_postings(void);
STORE_CLASS void g076_postings(void);

/*  New functions For Release IM 2.0    */

STORE_CLASS void g131_postings(void);
STORE_CLASS void g135_postings(void);
STORE_CLASS void g136_postings(void);
STORE_CLASS void g137_postings(void);
STORE_CLASS void g138_postings(void);
STORE_CLASS void g139_postings(void);
STORE_CLASS void g143_postings(void);
STORE_CLASS void g146_postings(void);
STORE_CLASS void g147_postings(void);
STORE_CLASS void g148_postings(void);
STORE_CLASS void g149_postings(void);
STORE_CLASS void g157_postings(void);
STORE_CLASS void g180_postings(void);
STORE_CLASS void g181_postings(void);
STORE_CLASS void g182_postings(void);
STORE_CLASS void g183_postings(void);
STORE_CLASS void g184_postings(void);
STORE_CLASS void g185_postings(void);
STORE_CLASS void o103_postings(void);
STORE_CLASS void o108_postings(void);
STORE_CLASS void o111_postings(void);
STORE_CLASS void o112_postings(void);
STORE_CLASS void o180_postings(void);
STORE_CLASS void o181_postings(void);
STORE_CLASS void o182_postings(void);
STORE_CLASS void set_post_prem_vals(void);
STORE_CLASS void set_post_disc_vals(void);
STORE_CLASS void set_bnd_prem_values(void);
STORE_CLASS void set_bnd_disc_values(void);
STORE_CLASS int sel_sysc_acct_ind(int mode);
STORE_CLASS int sel_fbal_ftyp_ind(int mode);
STORE_CLASS int sel_fbal_ftyp_pred(int mode);
STORE_CLASS int sel_pty_dp_expense(int mode);
STORE_CLASS int sel_ftyp_fbal_acct(int mode);
STORE_CLASS int sel_ftyp_fbal_acct_pred(int mode);
STORE_CLASS int sel_fund_fbal_acct(int mode);
STORE_CLASS int sel_acct_fbal_acct(int mode);
STORE_CLASS int sel_acct_fbal_acct_null(int mode);
STORE_CLASS int sel_im_hist_cost_ind(int mode);
STORE_CLASS int sel_sys_defined_ind(int mode);
STORE_CLASS void bnd_amort_record(void);
STORE_CLASS void ins_bond_amort(void);
STORE_CLASS int get_fbal_account(int mode);
STORE_CLASS int sel_fund(int mode);
STORE_CLASS int sel_ftyp(int mode);
STORE_CLASS int sel_profit_center_ship(void);
STORE_CLASS int sel_ship_org_prog_code(void);

/* function prototypes added for Stores  */
STORE_CLASS int sel_sysc_trf_in_acct(void);   /*  to go in g063 or g064 */
STORE_CLASS int sel_sysc_trf_out_acct(void);  /*  for g063 or g064 */
STORE_CLASS int sel_podt_qty(int mode);       /* reset_po */
STORE_CLASS void upd_ftvcomm_podt(void);
STORE_CLASS void reset_po_co(void) ;
STORE_CLASS int sel_sysc_val_clear_acct(void);
STORE_CLASS int sel_fsrvald_adj_amt(void);    /* for G066 pcode for invoice */
STORE_CLASS int sel_sum_fsrvald(void);     /* not used now */
STORE_CLASS int sel_comm_list(int mode);
STORE_CLASS void upd_ftvcomm_not_invoiced_inv(void);
STORE_CLASS void reset_invoice(void);
STORE_CLASS int sel_fsrvald_adjt_inv(void);
STORE_CLASS void upd_ftvcomm_total_amt_inv(void);
STORE_CLASS int check_sdat_for_rucl(void);
STORE_CLASS void del_fsrvald_for_inv(void);
STORE_CLASS int sel_reqd_qty(int mode);
STORE_CLASS void upd_ftvcomm_reserved_req(void);
STORE_CLASS void reset_reqs(void);

/* Receiving document function prototypes */
STORE_CLASS void doc_exec_rcv(void);
STORE_CLASS int sel_rcv_head(int mode);
STORE_CLASS int sel_rcdt_detl_acctg(int mode);
STORE_CLASS int sel_rcv_vendor_from_po(void);
STORE_CLASS int sel_invm_coas(void);
STORE_CLASS int sel_fund_acct_invtry_invm(void);
STORE_CLASS int sel_fund_acct_invtry_ship(void);
STORE_CLASS int sel_fund_acct_invtry_sysc(void);
STORE_CLASS int get_fund_and_acct_code_invtry(void);
STORE_CLASS void rcv_detl_acctg_body(void);

/* function prototypes */
STORE_CLASS int sel_comm_list_recv(int mode);
STORE_CLASS void upd_ftvcomm_not_invoiced_rcv(void);
STORE_CLASS int sel_fsrvald_adjt_rcv(void);
STORE_CLASS void upd_ftvcomm_total_amt_rcv(void);
STORE_CLASS void upd_ftvcomm_onorder_rcv(void);
STORE_CLASS int sel_upd_ftvstkl_stock_rcv(void);
STORE_CLASS void upd_stkl_stock_rcv(void);
STORE_CLASS void del_fsrvald_for_rcv(void);
STORE_CLASS void reset_receiving(void);

/* Adjustment doc function prototypes */

STORE_CLASS void doc_exec_adj(void);
STORE_CLASS int sel_trans_desc(void);
STORE_CLASS int sel_adj_head(int mode);
STORE_CLASS int sel_adj_detl_acctg(int mode);
STORE_CLASS void ins_fsrvald_adj(void);
STORE_CLASS int sel_ftvcomm_for_update(void);
STORE_CLASS void upd_ftvcomm_adj(void);
STORE_CLASS int sel_upd_ftvstkl_adj(void);
STORE_CLASS void upd_ftvstkl_adjq(void);
STORE_CLASS void upd_ftvstkl_adjc(void);
STORE_CLASS void adj_detl_acctg_body(void);

/* function prototypes  for reset_doc_adj  Srivalli Pillutla 11/28/93 */
STORE_CLASS int sel_adj_list_reset(int mode);
STORE_CLASS void upd_stkl_status(void);
STORE_CLASS void reset_adjustments(void);

STORE_CLASS void doc_exec_iss(void);
STORE_CLASS void doc_exec_trn(void);
STORE_CLASS int sel_issh_upd_comp(int mode);
STORE_CLASS void update_issh_comp(void);
STORE_CLASS int sel_trah_upd_comp(int mode);
STORE_CLASS void update_trah_comp(void);
STORE_CLASS int sel_rchd_upd_comp(int mode);
STORE_CLASS void update_rchd_comp(void);
STORE_CLASS int sel_adjh_upd_comp(int mode);
STORE_CLASS void update_adjh_comp(void);
STORE_CLASS int sel_trn_head(void);
STORE_CLASS int sel_trn_detl_acctg(int mode);
STORE_CLASS int sel_trn_detl_loc_acctg(int mode);
STORE_CLASS int sel_stkl_trans_amt(void);
STORE_CLASS void trn_detl_acctg_body(void);
STORE_CLASS void trn_detl_loc_acctg_body(void);
STORE_CLASS int sel_fund_acct_trnf_invm(void);
STORE_CLASS void reset_transfers(void);
STORE_CLASS int sel_ftvstkl_trnf_out(void);
STORE_CLASS int sel_ftvstkl_trnf_in(void);
STORE_CLASS void upd_ftvstkl_trnf_out(void);
STORE_CLASS void upd_ftvstkl_trnf_in(void);
STORE_CLASS int sel_iss_head(void);
STORE_CLASS void iss_acctg_body(void);
STORE_CLASS void process_iss_acctg(void);
STORE_CLASS int sel_iss_acctg(int mode);
STORE_CLASS int sel_iss_detl_acctg(int mode);
STORE_CLASS int sel_iss_detl_loc_acctg(int mode);
STORE_CLASS void iss_detl_acctg_body(void);
STORE_CLASS void iss_detl_loc_acctg_body(void);
STORE_CLASS int sel_issd_final_ind(int mode);
STORE_CLASS int get_issue_fund_acct_invtry(void);
STORE_CLASS int sel_sum_issl_qty(void);
STORE_CLASS int sel_reset_issue(int mode);
STORE_CLASS void upd_ftvcomm_issl(void);
STORE_CLASS int sel_upd_ftvstkl_issl(void);
STORE_CLASS void upd_ftvstkl_issl(void);
STORE_CLASS int sel_fprreqd_qty(void);
STORE_CLASS void reset_issues(void);
STORE_CLASS int sel_final_pmt_issd(void);
STORE_CLASS int sel_final_pmt_reqd(void);
STORE_CLASS void check_and_do_rebate(void);
STORE_CLASS void check_and_do_cchk_rebate(void);
STORE_CLASS void upd_inv_via_can_chk(void);
STORE_CLASS int sel_sum_exrt_amt(void);  /* for issue regular accounting */
STORE_CLASS int sel_inv_detl_acctg(int mode);
STORE_CLASS void inv_detl_acctg_body(void);
STORE_CLASS void chk_detl_acctg_body(void);  /* rel. 2.0.7 defect# 3433 */
STORE_CLASS int sel_encp_liq_cy(void);   /* Rel. 2.0.2 */
STORE_CLASS int sel_encp_exist(void);    /* Rel. 2.0.2 */
STORE_CLASS void initialize_variables(void); /* 2.0.7 */
STORE_CLASS void post_amounts_to_ledger(void); /*2.0.7*/

/* fixed assets functions */

STORE_CLASS void invc_items_fa_process(void);  /* 2.1.11 */
STORE_CLASS void invc_items_cck_fa_process(void);  /* 2.1.11 */
STORE_CLASS void doc_exec_fixadj(void);
STORE_CLASS void reset_doc_fadj(void);

/* for GST enhancement */

STORE_CLASS void doc_exec_dcsr(void);

/* added for 2.1.11 */
STORE_CLASS void init_posting_amounts_to_zero(void);

/* For year 2000 enhancement */

STORE_CLASS int yearconv(TMCHAR *);
STORE_CLASS void two_to_four_char_year(TMCHAR[5],TMCHAR[3]);

/* For 3.1 release */

STORE_CLASS int encumb_have_rolled(TMCHAR chart[2], TMCHAR fiscal_year[3]);
STORE_CLASS int encumb_exists(TMCHAR encumbrance_number[9],BANNUMSTR(encumbrance_item),BANNUMSTR(encumbrance_seq),TMCHAR fiscal_year[3]);


/* for abal enhancement */

STORE_CLASS void abal_do_nsf_process(TMCHAR to_do_string[30]);

STORE_CLASS void abal_ins_fgrbako_fgbbavl(void);

STORE_CLASS void abal_delete_fgrbako(TMCHAR document_code[9],
                                     TMCHAR document_type[3],
                                     int   submission_numb,
                                     int   item_numb,
                                     int   sequence_numb,
                                     TMCHAR  reversal_indicator,
                                     int   serial_num);
STORE_CLASS void abal_get_nsf_message(TMCHAR document_code[9],
                                      TMCHAR document_type[3],
                                      int   submission_numb,
                                      int   item_numb,
                                      int   sequence_numb,
                                      TMCHAR  reversal_indicator,
                                      int   serial_num,
                                      TMCHAR chart[2],
                                      TMCHAR fiscal_year[3],
                                      TMCHAR fund_code[7],
                                      TMCHAR transaction_date[15],
                                      TMCHAR balance_message[81]);


STORE_CLASS void abal_insert_bako_bavl( TMCHAR   document_code[9] ,
                                   int     item_number ,
                                   int     sequence_number ,
                                   TMCHAR   document_type[3] ,
                                   int     submission_number,
                                   int     serial_number ,
                                   TMCHAR    reversal_ind ,
                                   int     rule_process_number,
                                   TMCHAR   chart_of_accounts[2] ,
                                   TMCHAR   fiscal_year[5],
                                   TMCHAR   bavl_fund_code[7] ,
                                   TMCHAR   bavl_organization[7] ,
                                   TMCHAR   bavl_account[7] ,
                                   TMCHAR   bavl_program[7] ,
                                   BANNUMSTR(adop_amount) ,
                                   BANNUMSTR(adjt_amount) ,
                                   BANNUMSTR(ytd_amount) ,
                                   BANNUMSTR(encumb_amount) ,
                                   BANNUMSTR(rsrv_amount) ,
                                   TMCHAR   fund_code[7] ,
                                   TMCHAR   organization[7] ,
                                   TMCHAR   account[7] ,
                                   TMCHAR   program[7] ,
                                   TMCHAR   posting_period[3] ,
                                   TMCHAR   posting_period_orig[3] ,
                                   TMCHAR   control_period_bvl ,
                                   TMCHAR    bavl_severity,
                                   TMCHAR    commit_ind );

STORE_CLASS void abal_get_bavl_foap(TMCHAR  chart_of_accounts[2],
                        TMCHAR  fund_code[7],
                        TMCHAR  organization[7],
                        TMCHAR  account[7],
                        TMCHAR  program[7],
                        TMCHAR transaction_date[15],
                        TMCHAR  bavl_fund[7],
                        TMCHAR  bavl_orgn[7],
                        TMCHAR  bavl_acct[7],
                        TMCHAR  bavl_prog[7],
                        TMCHAR  bavl_control_period[2],
                        TMCHAR  bavl_control_severity[2]);

STORE_CLASS void abal_get_fgbbavl_period(TMCHAR control_period[2],
                                         TMCHAR fgbbavl_period[3],
                                         TMCHAR transaction_period[3]);
STORE_CLASS void print_abal_message(void);

/* TO simulate the budget roll for documents after the budget roll has been run*/

STORE_CLASS  void check_budget_roll_roll_trans(void);

STORE_CLASS  void check_budg_parms_get_roll_amt(TMCHAR chart[2],
                                                TMCHAR fiscal_year[3],
                                                         TMCHAR fundcode[7],
                                                         TMCHAR transdate[15],
                                                         TMCHAR opal_field_code[3],
                                                         BANNUMSTR(roll_amount)
                                                        );
STORE_CLASS void grant_rate_acct_info_in_frvfund(void);
STORE_CLASS void select_grant_exists(void);

/* 4.0 Grant Billing Enhancement */
STORE_CLASS void doc_exec_gbill(void);


/*4.0 Encumbrance open close enhancement */
STORE_CLASS void doc_exec_eocd(void);
STORE_CLASS void do_eocd_doc_reset(void);
STORE_CLASS int get_reqh_single_acctg_ind(int mode);
STORE_CLASS int get_pohd_single_acctg_ind(int mode);


/* 4.0.1 ems */
STORE_CLASS void ins_fnbuntd(void);

/* 5.3.1 fixed assets enhancement */
STORE_CLASS void do_fixassets_tag_cap(void);
STORE_CLASS void sel_fobsysc_values(void);
STORE_CLASS TMCHAR  ruiv_installment_ind[2];

/* 5.3.1 printing release number for each posting sub-module */
STORE_CLASS void print_abal_rel(void);
STORE_CLASS void print_bill_rel(void);
STORE_CLASS void print_body_rel(void);
STORE_CLASS void print_eocd_rel(void);
STORE_CLASS void print_exxx_rel(void);
STORE_CLASS void print_fixa_rel(void);
STORE_CLASS void print_stor_rel(void);
STORE_CLASS void print_gran_rel(void);
STORE_CLASS void print_grnp_rel(void);
STORE_CLASS void print_pdoc_rel(void);
STORE_CLASS void print_invm_rel(void);
STORE_CLASS void print_release(TMCHAR[8], TMCHAR[15]);

/* added for API calls to replace calls to POSTORA */
STORE_CLASS void local_postora_api (TMCHAR table_name[50],
                                    TMCHAR context_name[50]);
STORE_CLASS TMCHAR sp_encb_origin[31];

/* .CR-000139298 */
STORE_CLASS BANNUMSTR(sp_trans_nonbase_amt);
STORE_CLASS TMCHAR req_liq_foreign_curr_ind[2];
