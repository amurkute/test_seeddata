/* AUDIT TRAIL:8.0 */
/* AUDIT TRAIL END */
#ifndef UOQJOBS_H
#define UOQJOBS_H
/******************************************************************************
*  UOQJOBS.H - Job Submission Functions                                       *
*  Note: Please see TEMPLATE.PC for a working example program that can be     *
*        modified easily to create new reports and processes.                 *
*******************************************************************************

Programs that use these functions can be started from the command line or 
submitted from BANNER using the form GJAPCTL.  This suite of functions is 
useful for interfacing with the Banner Job submission features.   It sets up
global variables that contain information necessary for report writing.  It
contains function calls to handle parameters easily:   retrieve parameters from
the job submission tables, alternately retrieve  parameters from the user, move
them into the collector table, and print them out on the control information
section at the end of the report.

Brief description of most important Job submission functions:

JSReportOpen() - Parses the command line parameters setting global flag vars.
   Builds the output file name. 
JSInitGlobals() - Sets the globals variables for printing the standard report
   header including: szJSSysDate, szJSSysTime, szJSRptUser, szJSInstitution and
   and szJSTitle.
JSGetOneUpNo() - Prompts the user for the Job submission one up number.  If the
   job is submitted from Form GJAPCTL, the one up number will be piped to the
   program.
JSReadMultiple() - Read the parm values from the table GJBPRUN.  Allocates 
   memory for the parm string and places the pointer in the array of string 
   pointers.
JSGetParmFromUser() - Prompt the user for the parm values.  Allocates memory
   for the parm string and places the pointer in the array of string pointers.
JSCopyParms() - Copies all parms for this job from GJBPRUN to GJBCOLR.  If a 
   parm does not have a value in the GJBPRUN table or the value of 
   GJBPRUN_VALUE is NULL table it will insert a row into the collector table 
   with '%' as the value of GJBCOLR_VALUE.
JSDelParms() - Deletes all parms for this job from GJBPRUN.
JSPurgeCollectorTable() - Deletes all parms for this job from the GJBCOLR table.
JSHeader() - Prints the standard report header for the report.  No page eject is
   performed.  It simply starts printing at column position 0 of the current 
   line.
JSPrintParm() - Prints the parm values separated by spaces.
JSJobAuditUpdateCompl()   - Updates the USBSUBM job submission audit table 
                            with the completion status, ending date, oracle
                            error, error line number, user id and activity 
                            date.
JSJobAuditSetErrLineNum() - Sets the sql error, and error line number at the 
                            point of error for later retrieval in 
                            JSJobAuditUpdateCompl().
*******************************************************************************/
/*******************************************************************************
* ### INIT   DATE   AUDIT TRAIL 2.0.3
* --- ---- -------- -----------------------------------------------------------
* 1.  EBR  05/01/95 Bug #4569 - Add changes to add missing functionality to
*                   USASUBM form.  Added new functions with name JSJobAudit...
*                   to insert/update USBSUBM rows with necessary information.
*                   Only public (extern) function prototypes were added here -
*                   these are called from dberror() and dbexit() functions
*                   in uoqorac.pc.
* 
*******************************************************************************/

/*-----------------------------------------------------------------------*/
/* Program Error macro - makes calling Program Error easier
/*-----------------------------------------------------------------------*/
#define PROG_ERROR(rc, msg) ProgramError(__FILE__, __LINE__, rc, msg)

#define MAX_TEMP_LEN      80  /* arbitrary value for local strings */

typedef enum JS_DATA_TYPE 
	{JS_ALPHA = ALPHA, JS_NUMERIC = NUM, JS_DATE, JS_TIME} JS_DATA_TYPE;

typedef enum JS_ONEUP_RESULT
   {JS_INVALID_ONEUP, JS_VALID_ONEUP, JS_GENERATED_ONEUP} JS_ONEUP_RESULT;

/*******************************************************************************
* The globals are set by JSReportOpen()                                        *
*******************************************************************************/
extern short int ff_flag;     /* user form feed instead of CRLF to get to tof */
extern short int eject_flag;  /* page eject at beginning of report            */
extern short int uc_flag;     /* all output in upper case                     */
extern short int rpf_flag;    
extern short int reverse_flag;/* reverse underline                            */
extern short int trace_flag;  /* print debugging messages                     */
extern short int sqltrace_flag;/* turn on sqltrace                            */

extern void ProgramError(char *pszSrcFile, long lLineNbr, long lRC, 
                         char *pszMsg); 

/*---------------------------------------------------------------------------*/
/* BEGIN JOB SUBMISSION SECTION                                              */
/*---------------------------------------------------------------------------*/

extern char      szJSSysDate     [12];   /* Report date                  */
extern char      szJSSysTime     [9];    /* Report time                  */
extern char      szJSRptUser     [31];   /* Report user                  */
extern char      szJSInstitution [41];   /* Utility's Name               */
extern char      szJSTitle       [51];   /* Report Title                 */

/******************************************************************************
* FUNCTION PROTOTYPES                                                         *
*******************************************************************************/
extern void JSReportOpen   (int argc, char *argv[], char *pszJobName, 
                          char *pszFile, char *pszUserPass, short sPageWidth);

extern int  JSSelectDate       (char *, char *, char *);
extern int  JSSelectInstitution(char *);
extern int  JSSelectTitle      (char *, char *);
extern void JSHeader           (char *,char *, char *, char *, char *, int);

extern int  JSValidateOneUpNo  (char *, long, short *);
extern int  JSGenOneUpNo       (long *);
extern void JSDelParms         (char *, long);

extern void JSPurgeCollectorTable (char *, long, char *);
extern void JSLoadCollectorTable(char *, 
                                 long lOneUpNo, 
                                  char *pszParmNo,
                                  const char *pszParmValue,
                                  char *pszRptDate);


extern short JSReadMultiple(char *szJobID, long lOneUpNo, char *szParmNbr, 
                           char *rpszParameter[], short sMaxCnt);
extern int  JSReadParmFromTbl(char *szJob, long lOneUpNo, 
                char *szParmNbr, char *szParameter);
extern int  JSReadLineCount(char *pszJob, long lOneUpNo, short *psLineCount);
extern void JSCopyParms(char *pszJob, long lOneUpNo, char *pszRptDate);
extern JS_ONEUP_RESULT JSGetOneUpNo(char *pszJob, long *plOneUp);
extern void JSCmdHelp(char *pszJobName);
extern void JSJobAuditUpdateCompl(int exit_status);
extern void JSJobAuditSetErrLineNum( long lParmSQLCode, long lParmLineNum );
                         
/******************************************************************************/
/* validation function should notify the user that data is in error and       */
/* return TRUE otherwise it should return FALSE                               */
/* is invalid                                                                 */
/******************************************************************************/
extern short JSGetParmFromUser(char *pszJob,
                              long lOneUpNo, 
										char *pszRptDate,
                              char *pszParmNo,
										char *rpszParmOut[],
										char *pszPromptString,
                              const char  *pszDefaultValue,
                              short sInputLen,
                              JS_DATA_TYPE eInputType,
                              int (*ValidationFunc)(char *, char *[]),
                              char  cRequiredIndicator,
                              short sMaxCnt);

extern void JSPrintParm(char *pszText, char *rpszParm[], short sPageWidth);
extern void JSInitGlobals(char *pszExecName, const char pszDefaultTitle[]);
extern JS_ONEUP_RESULT JSInitReport(int argc, 
                                    char *argv[], 
                                    char *pszExecName,
                                    char *pszDefaultReportTitle,
                                    short sPageWidth,
                                    long *plOneUpNo,
                                    char *pszFileName);

/*---------------------------------------------------------------------------*/
/* END job submission SECTION                                                */
/*---------------------------------------------------------------------------*/

/*---------------------------------------------------------------------------*/
/* BEGIN SLEEP/WAKE SECTION                                                  */
/*---------------------------------------------------------------------------
SLEEP WAKE - programs stop execution for a specified interval and restart 
execution.  They can be submitted from the command line or submitted from
BANNER using the form GJAPCTL.  The form GJASWPT is used to modify the execution
interval of the program (sleep interval) and to end the execution.

The following functions are useful in sleep/wake programs:

SWSleepWakeInit() - Puts a row into the GJRSWPT that contains the execution
   interval, the time of next execution and the running switch.  This row is
   used to communicate between the form GJASWPT and the program.  

SWBuildCommand() - Builds the print command to output the print file to the
   printer.

SWSleepWake() - reads the row in the GJRSWPT to check the continue running
   switch.  If the continue running switch is set to 'N' it will return
   FALSE and the program should interpret this as time to terminate.  If it
   is set to 'Y' this function will calculate the time it will wake up an
   write this out in the GJRSWPT row and will sleep for that amount of time.

SWSleepWakeDelete() - Deletes the row from the GJRSWPT table.

-----------------------------------------------------------------------------*/
extern void SWSleepWakeInit(char *pszJob, char *pszPrinter, 
                            long lCurrentInterval);
extern int SWBuildCommand(char *pszCommandOut, char *pszPrinter, char *pszFile);
extern int SWSleepWake(long *plCurrentIntv);
extern void SWSleepDelete(char *pszJob, char *pszPrinter);

/*---------------------------------------------------------------------------*/
/* END SLEEP/WAKE SECTION                                                    */
/*---------------------------------------------------------------------------*/

#endif

