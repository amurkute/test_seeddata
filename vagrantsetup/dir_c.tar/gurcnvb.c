/*TMCI18N BEGIN HEADER*/
#if !defined( tmBundle_EXISTS )
#include "tmcilib.h"
static struct TMBundle tmBundle = {"gurcnvb.c",NULL,NULL,NULL,NULL};
#define tmBundle_EXISTS
#endif
/*TMCI18N END HEADER*/

/* AUDIT_TRAIL_MSGKEY_UPDATE
-- PROJECT : MSGKEY
-- MODULE  : GURCNVB
-- SOURCE  : enUS
-- TARGET  : I18N
-- DATE    : Wed Nov 28 00:57:10 2012
-- MSGSIGN : #bd1a4a5459404c07
END AUDIT_TRAIL_MSGKEY_UPDATE */

/*============================================================================
AUDIT TRAIL: 8.0
1. New c lib to convert utf8 text files to std ascii.           PNN 04/01/2008

AUDIT TRAIL: 8.2.0.1
1. Defect 1-6T9UUY                                              LVH 08/04/2009
   Cloned gurcnva.c to create gurcnvb.c. The change is to call the new
   function gukcnva.f_translate instead of using gurcnvc.map.

AUDIT TRAIL: 8.3.0.1
1. Defect 1-ACOZ5E                                    LVH 01/15/2010
    Updates to ensure that all non-converted characters are converted
    to spaces to ensure that resulting file is 100% ascii even if a valid
    translation was not provided. Added POSTORA following END-EXEC;.

AUDIT TRAIL: 8.5
1.                                                    LVH 10/26/2011
    Increase max length from 1024 to 20000.

AUDIT TRAIL: 8.5.1
1.  Defect 1-12WJ0DF                                  EM 02/06/2012
    Added indicatior variable Ind_01 to function  convertFile. 
	
AUDIT TRAIL: 8.5.2.2
1.  Defect 1-19SW46L                                  EM 11/28/2012
    This patch is a pre-requisite for HR 8.8.1 and is a copy of 
	the 8.5.1 version. No other code changes have been made.	

AUDIT TRAIL END
===============================================================================*/
/* GURCNVB.C Copyright 2008-2012 Ellucian Company L.P. and its affiliates.     */
/*******************************************************************************/

#include "guastdf.h"

EXEC SQL BEGIN DECLARE SECTION;
int    mapCount              = 1;
int    convLen               = 0;
static TMCHAR mapStrNull[20] = {0};
static TMCHAR mapStr1[20]    = {0};
static TMCHAR mapStr2[20]    = {0};
static TMCHAR mapStr3[20]    = {0};
static TMCHAR mapStr4[20]    = {0};
static TMCHAR mapStr5[20]    = {0};
static TMCHAR mapStr6[20]    = {0};
static TMCHAR mapStr7[20]    = {0};
static TMCHAR mapStr8[20]    = {0};
static TMCHAR mapStr9[20]    = {0};
static TMCHAR mapStr10[20]   = {0};
static TMCHAR convLine[20000] = {0};
static TMCHAR notConv[20000]  = {0};
static TMCHAR oneLine[20000]  = {0};
static TMCHAR wrkLine[20000]  = {0};
static TMCHAR dupLine[20000]  = {0};
static TMCHAR convChr[10]    = {0};
static TMCHAR convAscii[10]  = {0};
EXEC SQL END DECLARE SECTION;

/* Local prototypes */
#define TRUE     1
#define FALSE    0
#define SAME     0
#define DIFF     1
#define MAX_READ 20000

static TMCHAR fNameIn[256]      = {0};
static TMCHAR fNameOut[256]     = {0};
static TMCHAR fNameTmp[256]     = {0};


static UFILE *fIn;
static UFILE *fOut;
static UFILE *openFile(TMCHAR *fname, TMCHAR *flag);

static void utf8_to_ascii(TMCHAR *fnameIn, TMCHAR *fNameOut);

static void printMap(void);
static void printUnconverted(TMCHAR nonPrt[20000]);
static void convertFile(void);
static void cleanupFiles(void);

/******************************************************************************/
static void utf8_to_ascii(TMCHAR *fileIn, TMCHAR *fileOut)
{
#ifdef SCT_DEBUG
  tmprintf(&tmBundle, _TMC("Executing utf8_to_ascii\n"));
  tmfflush(tmstdout);
#endif

  tmstrcpy(fNameIn, fileIn);
  tmstrcpy(fNameOut, fileOut);
  tmstrcpy(fNameTmp, fNameOut);

  if (tmstrcmp(fNameIn, fNameOut) == SAME)
    tmstrcat(fNameOut, _TMC("tmp"));

#ifdef SCT_DEBUG
  printMap();
#endif
  convertFile();
  cleanupFiles();

  tmprintf(&tmBundle, _TMC("File \"{0}\" converted successfully.\n"), fileIn);
}

/******************************************************************************/
static void printMap(void)
{

  tmprintf(&tmBundle, _TMC("List of mapping pairs\n"));
  while (1)
    {
      EXEC SQL EXECUTE
        DECLARE
        BEGIN
          :mapStr1  := nvl(gukcnva.f_conv_chars(:mapCount),' ');
          :mapCount := :mapCount + 1;
          :mapStr2  := nvl(gukcnva.f_conv_chars(:mapCount),' ');
          :mapCount := :mapCount + 1;
          :mapStr3  := nvl(gukcnva.f_conv_chars(:mapCount),' ');
          :mapCount := :mapCount + 1;
          :mapStr4  := nvl(gukcnva.f_conv_chars(:mapCount),' ');
          :mapCount := :mapCount + 1;
          :mapStr5  := nvl(gukcnva.f_conv_chars(:mapCount),' ');
          :mapCount := :mapCount + 1;
          :mapStr6  := nvl(gukcnva.f_conv_chars(:mapCount),' ');
          :mapCount := :mapCount + 1;
          :mapStr7  := nvl(gukcnva.f_conv_chars(:mapCount),' ');
          :mapCount := :mapCount + 1;
          :mapStr8  := nvl(gukcnva.f_conv_chars(:mapCount),' ');
          :mapCount := :mapCount + 1;
          :mapStr9  := nvl(gukcnva.f_conv_chars(:mapCount),' ');
          :mapCount := :mapCount + 1;
          :mapStr10 := nvl(gukcnva.f_conv_chars(:mapCount),' ');
        END;
      END-EXEC;
      POSTORA;
      tmprintf(&tmBundle, _TMC("{0}   {1}   {2}   {3}   {4}   {5}   {6}   {7}   {8}   {9}\n"),
                               mapStr1, mapStr2, mapStr3, mapStr4, mapStr5, mapStr6, mapStr7, mapStr8, mapStr9, mapStr10);
      if ( compare(mapStr10,_TMC(" "),EQS) )
      {
        if ( compare(mapStr1,_TMC(" "),EQS) )
          mapCount--;
        if ( compare(mapStr2,_TMC(" "),EQS) )
          mapCount--;
        if ( compare(mapStr3,_TMC(" "),EQS) )
          mapCount--;
        if ( compare(mapStr4,_TMC(" "),EQS) )
          mapCount--;
        if ( compare(mapStr5,_TMC(" "),EQS) )
          mapCount--;
        if ( compare(mapStr6,_TMC(" "),EQS) )
          mapCount--;
        if ( compare(mapStr7,_TMC(" "),EQS) )
          mapCount--;
        if ( compare(mapStr8,_TMC(" "),EQS) )
          mapCount--;
        if ( compare(mapStr9,_TMC(" "),EQS) )
          mapCount--;
        if ( compare(mapStr10,_TMC(" "),EQS) )
          mapCount--;
        break;
      }
      mapCount++;
    }

  tmprintf(&tmBundle, _TMC("{0,%d} mapping pairs found \n"), mapCount);

}
/******************************************************************************/
static void printUnconverted(TMCHAR nonPrt[20000])
{
    int     i                = 0;

    substr(dupLine,nonPrt,0,20000);
    EXEC SQL EXECUTE
      DECLARE
      BEGIN
        :notConv  := gukcnva.f_missing(:dupLine,'Y');
      END;
    END-EXEC;
    POSTORA;
    nonPrt = notConv;
    convLen = tmstrlen(nonPrt) - 1;

    for (i = 0; i < convLen; i++)
    {
      *convChr   =    '\0';
      substr(convChr,nonPrt,i,1);

      EXEC SQL
        SELECT ascii(:convChr)
        INTO :convAscii
        FROM DUAL;
      POSTORA;
      tmprintf(&tmBundle, _TMC("    ASCII conversion value for {0} is {1}\n"), convChr, convAscii);
    }
}

/******************************************************************************/
static void convertFile(void)
{
  TMCHAR           myNull[02]  ={0};
  TMCHAR *ptr              = NULL;
  short   Ind_01;

 *myNull =  '\0';
#ifdef SCT_DEBUG
  tmprintf(&tmBundle, _TMC("Executing convertFile\n"));
  tmfflush(tmstdout);
#endif

  fOut = openFile(fNameOut, _TMC("w"));

  fIn = openFile(fNameIn, _TMC("r"));
  while (tmfgets(oneLine, MAX_READ, fIn))
  {
    tmstrcpy(wrkLine,oneLine);
    EXEC SQL EXECUTE
      DECLARE
      BEGIN
        :convLine:Ind_01:= gukcnva.f_convert(:wrkLine);
        :notConv:Ind_01:= gukcnva.f_missing(:oneLine);
      END;
    END-EXEC;
    POSTORA;
/* Print out before and after if the lines are converted */
    if (tmstrcmp(wrkLine, convLine) != SAME)
    {
      tmprintf(&tmBundle, _TMC("Original : {0}"), wrkLine);
      tmprintf(&tmBundle, _TMC("Converted: {0}"), convLine);
    }
#ifdef SCT_DEBUG
    else
    {
        tmprintf(&tmBundle, _TMC("No Conversions made : {0}"), wrkLine);
    }
#endif
   ptr = notConv;
/* If there are characters that could not be converted, print them out */
    convLen = tmstrlen(notConv);
    if (convLen > 1)
    {
      if (tmstrcmp(wrkLine, convLine) == SAME)
      {
        tmprintf(&tmBundle, _TMC("No Conversions made : {0}"), wrkLine);
      }
      tmprintf(&tmBundle, _TMC("  Characters not converted: {0}"), notConv);
/* #ifdef SCT_DEBUG */
      printUnconverted(notConv);
/* #endif */
    }
/* Write out the converted line to the output file */
    tmfprintf(&tmBundle, fOut, _TMC("{0}"), convLine);

  }
}


/******************************************************************************/
static void cleanupFiles(void)
{
#ifdef SCT_DEBUG
  tmprintf(&tmBundle, _TMC("Executing cleanupFiles\n"));
  tmfflush(tmstdout);
#endif

  if (fOut)
    tmfclose(fOut);
  if (fIn)
    tmfclose(fIn);

  if (tmstrcmp(fNameIn, fNameTmp) == SAME)
  { /* if name of the in file is same as out file, then rename the file */
    remove(tmtochar8(fNameIn));
    rename(tmtochar8(fNameOut), tmtochar8(fNameIn));
  }
}

/******************************************************************************/
static UFILE *openFile(TMCHAR *fname, TMCHAR *flag)
{
  UFILE *f;

#ifdef SCT_DEBUG
  tmprintf(&tmBundle, _TMC("Executing openFile\n"));
  tmfflush(tmstdout);
#endif

  f = tmfopen(&tmBundle, fname, flag);
  if (!f)
  {
    if (tmstrcmp(flag, _TMC("w")) == SAME)
      tmprintf(&tmBundle, TM_NLS_Get("0000","%Error% - Unable to create file \"{0}\" for output.\n"), fname);
    else
      tmprintf(&tmBundle, TM_NLS_Get("0001","%Error% - Unable to open file \"{0}\".\n"), fname);

    exit2os(EXIT_FAILURE);
    return NULL;
  }

  return f;
}

