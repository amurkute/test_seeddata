/*UnicodeSedFixed*/
/*TMCI18N BEGIN HEADER*/
#if !defined( _TMBAPPAPFL_H_EXISTS )
/* No Initialisation Required */                                               
#include "tmcilib.h"
static struct TMBundle _TMBAPPAPFL_H = {"appapfl.h",NULL,NULL,NULL,NULL};
#define _TMBAPPAPFL_H_EXISTS
#endif
/*TMCI18N END HEADER*/

/* AUDIT_TRAIL_TM63
-- TranMan 6.3 
-- PROJECT : HEGDE_I18N
-- MODULE  : APPAPFL
-- SOURCE  : enUS
-- TARGET  : I18N
-- DATE    : Thu Nov 08 10:05:41 2007
END AUDIT_TRAIL_TM63 */
/*****************************************************************************/
/* APPAPFL.H Copyright (c) SCT Corporation 1996, 2003.  All rights reserved  */
/*****************************************************************************/

              /***************************************************/
              /*                                                 */
              /*       CONFIDENTIAL BUSINESS INFORMATION         */
              /*                                                 */
              /*      **********************************         */
              /*                                                 */
              /*  THIS PROGRAM IS PROPRIETARY INFORMATION OF     */
              /* SYSTEMS AND COMPUTER TECHNOLOGY CORPORATION     */
              /* AND IS NOT TO BE COPIED, REPRODUCED, LENT OR    */
              /* DISPOSED OF, NOR USED FOR ANY PURPOSE OTHER     */
              /* THAN THAT FOR WHICH IT IS SPECIFICALLY PROVIDED */
              /* WITHOUT THE WRITTEN PERMISSION OF SAID COMPANY  */
              /*                                                 */
              /***************************************************/

/************************************************************************/
/* APPAPFL.H                                                            */
/* AUDIT TRAIL: 3.0.2.1                                                 */
/* 1. LHS 06/17/1999                                                    */
/*    Header file for alumni extract.                                   */
/* AUDIT TRAIL: 3.1.1                                                   */
/* 1. SCG 10/07/1999                                                    */
/*    Change definition of filename variable from char to TMCHAR1[2]        */
/*    to prevent the padding of the file name with spaces when apppfl   */
/*    is run through job submission.                                    */
/* AUDIT TRAIL: 4.3                                                     */
/* 1. NGB 06/19/2000                                                    */
/*    Checked out for delivery with the Alumni 4.3 upgrade.             */
/* AUDIT TRAIL: 6.0							                            */
/* 1. ZYB 01/06/2003							                        */
/*    Udated extract process to use current Campus Pipeline DTD also    */
/*    added the ability to extract useres with a role of                */
/*    'DEVELOPMENTOFFICER'.                                             */
/*                                                                            */
/* AUDIT TRAIL : 8.0 (I18N)                                                   */
/*   1.  Internationalization Unicode Conversion                              */
/*                                                                            */
/* AUDIT TRAIL END                                                      */
/************************************************************************/

#ifndef _APPAPFL_C_
#define STORE_CLASS extern
#else
#define STORE_CLASS /* */
#endif

#define LENGTH 60
/*typedef TMCHAR TMCHAR0[1000][10000]; */          /* For the dynamic sql statement      */

/*Constant section for XML Keywords */
#define DTDHeader     TM_NLS_HGet( &_TMBAPPAPFL_H, "0000","<?xml version=\"1.0\"?>\n")
#define DTDName       TM_NLS_HGet( &_TMBAPPAPFL_H, "0001","<!DOCTYPE PIPELINE-USERS SYSTEM \"pipeline-user-2.dtd\">\n")
#define ObjectsStart  TM_NLS_HGet( &_TMBAPPAPFL_H, "0002","<PIPELINE-USERS>\n")
#define ObjectsEnd    TM_NLS_HGet( &_TMBAPPAPFL_H, "0003","</PIPELINE-USERS>\n")
#define UserTagStart  TM_NLS_HGet( &_TMBAPPAPFL_H, "0004"," <USER>\n")
#define UserTagEnd    TM_NLS_HGet( &_TMBAPPAPFL_H, "0005"," </USER>\n")
#define EndProperty   TM_NLS_HGet( &_TMBAPPAPFL_H, "0006","</PROPERTY>\n")
#define UserName      TM_NLS_HGet( &_TMBAPPAPFL_H, "0007","  <PROPERTY name=\"UserName\">")
#define FirstName     TM_NLS_HGet( &_TMBAPPAPFL_H, "0008","  <PROPERTY name=\"FirstName\">")
#define MiddleName    TM_NLS_HGet( &_TMBAPPAPFL_H, "0009","  <PROPERTY name=\"MiddleName\">")
#define LastName      TM_NLS_HGet( &_TMBAPPAPFL_H, "0010","  <PROPERTY name=\"LastName\">")
#define Credential    TM_NLS_HGet( &_TMBAPPAPFL_H, "0011","  <PROPERTY name=\"ClearText.Credential\">")
#define DisplayName   TM_NLS_HGet( &_TMBAPPAPFL_H, "0012","  <PROPERTY name=\"DisplayName\">")
#define Role          TM_NLS_HGet( &_TMBAPPAPFL_H, "0013","  <PROPERTY name=\"Role\">")
#define SCTID         TM_NLS_HGet( &_TMBAPPAPFL_H, "0014","  <PROPERTY name=\"SCT.ID\">")
#define SCTCredential TM_NLS_HGet( &_TMBAPPAPFL_H, "0015","  <PROPERTY name=\"ClearText.SCT.Credential\">")
#define Source        TM_NLS_HGet( &_TMBAPPAPFL_H, "0016","  <PROPERTY name=\"SourcedID.Source\">")
#define SourcedID     TM_NLS_HGet( &_TMBAPPAPFL_H, "0017","  <PROPERTY name=\"SourcedID.ID\">")
#define EmailID       TM_NLS_HGet( &_TMBAPPAPFL_H, "0018","  <PROPERTY name=\"EmailID\">")
#define PERMADDR      TM_NLS_HGet( &_TMBAPPAPFL_H, "0019","PERMADDR")
#define SCHADDR       TM_NLS_HGet( &_TMBAPPAPFL_H, "0020","SCHADDR")
#define RELEASE       _TMC("6.0")
#define ADVSELFSERV   _TMC(" SELECT TWTVMODU_CODE FROM TWTVMODU \
                        WHERE  TWTVMODU_CODE = 'ALU'")
                        
#define SELECT _TMC(" SELECT GOBTPAC_PIDM ")
#define FROM             _TMC(" FROM GOBTPAC ")
#define TWGRROLE         _TMC(", TWGRROLE ")
#define GLBEXTR          _TMC(", GLBEXTR ")
#define UNION _TMC(" UNION ")
#define ADVGOVEROLEWHERE _TMC(" WHERE   ((   :friend_ind = 'Y' \
                                   AND f_alumni_friend_ind(GOBTPAC_PIDM) = 'Y') \
                              OR  (    :alumni_ind = 'Y' \
                                   AND f_alumni_constituent_ind(GOBTPAC_PIDM) = 'Y')) \
                             AND GOBTPAC_EXTERNAL_USER IS NOT NULL ")
#define ADVSELFSERVWHERE _TMC(" WHERE GOBTPAC_PIDM = TWGRROLE_PIDM \
                             AND TWGRROLE_ROLE = 'DEVELOPMENTOFFICER' \
                             AND GOBTPAC_EXTERNAL_USER IS NOT NULL ")
#define POPSEL _TMC(" AND TO_NUMBER(GLBEXTR_KEY) = GOBTPAC_PIDM \
                 AND GLBEXTR_APPLICATION = UPPER(:ask_application_id) \
                 AND GLBEXTR_SELECTION = UPPER(:ask_selection_id) \
                 AND GLBEXTR_CREATOR_ID = UPPER(:ask_creator_id) \
                 AND GLBEXTR_USER_ID = UPPER(:ask_user_id) ")
#define ORDERBY _TMC(" ORDER BY GOBTPAC_PIDM ")

EXEC SQL BEGIN DECLARE SECTION;

STORE_CLASS TMCHAR ID[10];
STORE_CLASS TMCHAR  pin[7];
STORE_CLASS TMCHAR sessionid[31];
STORE_CLASS TMCHAR filename[21];
STORE_CLASS TMCHAR external_user[31];
STORE_CLASS TMCHAR select_statement1[10000]; /* The actual record statement       */
STORE_CLASS TMCHAR select_statement2[10000]; /* The actual record statement       */
STORE_CLASS short  Ind_01;
STORE_CLASS short  Ind_02;
STORE_CLASS short  Ind_03;
STORE_CLASS short  Ind_04;
STORE_CLASS short  Ind_05;
STORE_CLASS short  Ind_06;
STORE_CLASS short  Ind_07;
STORE_CLASS short  Ind_08;
STORE_CLASS short  Ind_09;
STORE_CLASS short  Ind_10;
STORE_CLASS short  Ind_11;
STORE_CLASS short  Ind_12;
STORE_CLASS short  Ind_13;
STORE_CLASS short  Ind_14;
STORE_CLASS short  Ind_15;
STORE_CLASS short  Ind_16;
STORE_CLASS TMCHAR  ask_application_id[31];
STORE_CLASS TMCHAR  ask_selection_id[31];
STORE_CLASS TMCHAR  ask_creator_id[31];
STORE_CLASS TMCHAR  ask_user_id[31];
STORE_CLASS TMCHAR   alumni_ind[4];
STORE_CLASS TMCHAR   developofficer_ind[4];
STORE_CLASS TMCHAR   friend_ind[4];

STORE_CLASS long   	alumni_cnt;
STORE_CLASS long   	friends_cnt;
STORE_CLASS long   	developofficer_cnt;
STORE_CLASS TMCHAR 	gtvsdax_ind[4];
STORE_CLASS long    pidm;
STORE_CLASS TMCHAR   pop_sel_ind[4];
STORE_CLASS long    sourced_id;
STORE_CLASS TMCHAR sch_name[200];
EXEC SQL END DECLARE SECTION;

UFILE    *myfp;
UFILE    *ofile;
UFILE    *schd_file_ptr;
FNSTRUC schd_file;
FNSTRUC outfile;
/* *************************************************************************** */
/*   Job Submission Parameters                                                 */
/* *************************************************************************** */
EXEC SQL BEGIN DECLARE SECTION;

#define oopenfile(u,c,v) _oopenfile(u,c,(TMCHAR **)v)
#define CHECKIO if (tmferror(ofile)) prtmsg(IOERROR,outfile.fname);

STORE_CLASS TMCHAR    abort_msg[81];
STORE_CLASS TMCHAR    ext[5];
STORE_CLASS TMCHAR    ofile_name[81];

EXEC SQL END DECLARE SECTION;

/* *************************************************************************** */
/*  Prototype section for functions                                            */
/* *************************************************************************** */
STORE_CLASS void getAdvancementUsers(void);

