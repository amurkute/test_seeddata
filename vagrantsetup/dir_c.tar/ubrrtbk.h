/* AUDIT TRAIL: 8.0 */
/* AUDIT TRAIL END */
#ifndef UBRRTBK_H
#define UBRRTBK_H

#ifndef  UOQCOM_H
   #include "uoqcom.h"
#endif

/*-- Column Defines  ---------------------------------------------------------*/
#define   COL1     0
#define   COL2    10
#define   COL3    41
#define   COL4    57
#define   COL5    69
#define   COL6    81
#define   COL7    93
#define   COL8   103
#define   COL9   113
          
#define EXEC_NAME            "UBRRTBK"
#define PAGE_WIDTH           131
#define DEFAULT_REPORT_TITLE "Rate Block Analysis Report"

#define MAX_PARMS        50

#define BASE_MIN_NONE     '0'
#define BASE_MIN_ONE      '1'
#define BASE_MIN_CON_SIZE '2'

#define PRIMARY_RATE_TXT "Primary Rate"
#define SUBORD_RATE_TXT  "Subordinate Rate"

/*---------------------------------------------------------------------------*/
/* enum declaration for record type for flat file save                       */
/*---------------------------------------------------------------------------*/
typedef enum
   {
   HEADER_REC,
   PRIMARY_REC,
   SUBORDINATE_REC,
   STEP_REC,
   TRAILER_REC
   } RECORD_TYPE;

/*---------------------------------------------------------------------------*/
/* structure definitions for rate link list                                  */
/*---------------------------------------------------------------------------*/
typedef struct REPORT *PREPORT;

typedef struct REPORT
   {
   double   dConsumption;
   long     lServicesCnt;
   double   dRevenue;
   } REPORT;

typedef struct STEP *PSTEP;

typedef struct STEP
   {
   double   dStepDelta;
   double   dConsumpLevel;
   double   dChargeDelta;
   double   dChargeAmt;
   REPORT   Report;
   } STEP;


typedef struct RATES *PRATES;

typedef struct RATES
   {
   char     szSRATCode          [5];
   char     szSCATCode          [5];
   char     szAsvcCode          [3];
   char     szEffectiveDate     [12];
   char     szNChgDate          [12];  /* next change date */
   char     szDesc              [36]; 
   char     cStepInd;        /* <M> rate per unit for each step accumulated   */
                             /* <F>lat - fixed dollar amount                  */
                             /* <R>amp - rate per unit of consumption         */
                             /* <S>tep - fixed amount per range of consumption*/
                             /* <T>    - fixed amount each step accumulated   */
   char     cRateBasis;       /* <C>onsumption */
                             /* <D>ollar      */
                             /* <U>nits       */
   char     cUnitCalcMethod;
   char     szUnitofMeasure     [ 5];
   char     cBaseType;      
   double   dBaseAmount;
   double   dBaseDelta;
   REPORT   BaseRpt;    
   char     cMinType;       
   double   dMinAmount;
   double   dMinDelta;     
   REPORT   MinRpt;    
   double   dConsumpDelta;
   double   dFlatConsump;
   double   dProBaseDays;
   double   dProMinDays;
   double   dProMaxDays;
   short    sJan;
   short    sFeb;
   short    sMar;
   short    sApr;
   short    sMay;
   short    sJun;
   short    sJul;
   short    sAug;
   short    sSep;
   short    sOct;
   short    sNov;
   short    sDec;
   LLIST    LLSubRate;              /* Subordinate rate Link list */
   LLIST    LLSteps;                /* Step Link List             */
   REPORT   Report; 
   } RATES;

typedef struct RATES_KEY
   {
   char szSRATCode      [6];
   char szSCATCode      [6];
   char szEffectiveDate [10];
   } RATES_KEY, *PRATES_KEY;

typedef struct RPT_TOTALS
   {
   double   dSubTMinConsump;
   double   dSubTConsump;
   long     lSubTMinCnt; 
   long     lSubTSvcsCnt;
   double   dSubTRevenue;
            
   double   dGrnTMinConsump;
   double   dGrnTConsump;
   long     lGrnTMinCnt;
   long     lGrnTSvcsCnt;
   double   dGrnTRevenue;
   } RPT_TOTALS, *PRPT_TOTALS;
/*---------------------------------------------------------------------------*/
extern char *rpszMaxLinesPerPage           [2];
      
extern char *rpszBillCycleRange            [MAX_PARMS +1];
extern char *rpszFromChargeDate            [2];
extern char *rpszToChargeDate              [2];
extern char *rpszASVCType                  [MAX_PARMS +1];
extern char *rpszRateCode                  [MAX_PARMS +1];
extern char *rpszSVCCategory               [MAX_PARMS +1];
extern char *rpszConsumpDelta              [MAX_PARMS +1];
extern char *rpszMinChargeDelta            [MAX_PARMS +1];
extern char *rpszBaseChargeDelta           [MAX_PARMS +1];
extern char *rpszRateStepDelta             [MAX_PARMS +1];
extern char *rpszAllSteps                  [2];
extern char *rpszRateChargeDelta           [MAX_PARMS +1];
extern char *rpszAllCharges                [2];
extern char *rpszFlatFileSave              [2];
extern char *rpszFieldDelim                [2];
extern char *rpszProRate                   [2];

extern char  szEXCmsg                      [132];

/*------------------------------------------------------------------------*/
 
 
/*---------------------------------------------------------------------------*/
extern void ReadOpenItems(PRATES *pPRatesArray, long lCnt);
 
/*---------------------------------------------------------------------------*/
#endif
