/* AUDIT TRAIL: 3.1.0.1                                                      */
/* 1. RRM 07/27/98                                                           */
/*    New module to handle SLEEP processing for Windows NT only.             */
/* AUDIT TRAIL : 8.0 (I18N) *//* AUDIT TRAIL END                              */
#include <Windows.h>
#include <Winbase.h>

void sleep(int secs)
{
	Sleep(secs*1000);
}
