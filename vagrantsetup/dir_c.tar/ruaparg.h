/*TMCI18N BEGIN HEADER*/
#if !defined( _TMBRUAPARG_H_EXISTS )
/* No Initialisation Required */
#include "tmcilib.h"
static struct TMBundle _TMBRUAPARG_H = {"ruaparg.h",NULL,NULL,NULL,NULL};
#define _TMBRUAPARG_H_EXISTS
#endif
/*TMCI18N END HEADER*/

/* AUDIT_TRAIL_MSGKEY_UPDATE
-- PROJECT : MSGKEY
-- MODULE  : RUAPARG
-- SOURCE  : enUS
-- TARGET  : I18N
-- DATE    : Mon Jul 27 23:12:46 2015
-- MSGSIGN : #0000000000000000
END AUDIT_TRAIL_MSGKEY_UPDATE */

/****************************************************************************/
/*                                                                          */
/* Copyright 2015 Ellucian Company L.P. and its affiliates.                 */
/*                                                                          */
/****************************************************************************/

/****************************************************************************/
/* AUDIT TRAIL: 8.23.1                                      INIT    DATE    */
/* 1. CR-000131094                                           JC  07/02/2015 */
/*    Initial version.                                                      */
/*    New library to conform with changes to Banner General 8.7.3 due to    */
/*    Defect 1-2D5A72.                                                      */
/*    The parsargs and progopen methods were extracted from the BFA Pro*C   */
/*    programs with non-standard login routines and should be referenced    */
/*    from this common object.                                              */
/*                                                                          */
/* AUDIT TRAIL END                                                          */
/****************************************************************************/

/*
   ruaparg.h should be included in all BFA Pro*C programs that uses 
   non-standard login routines.
*/

#ifndef _RUAPARG_H_
#define _RUAPARG_H_

/*****************************************************************************/
/*                                                                           */
/* INCLUDES AND DEFINES                                                      */
/*                                                                           */
/*****************************************************************************/
#include "guastdf.h"

/*****************************************************************************/
/*                                                                           */
/* VARIABLES                                                                 */
/*                                                                           */
/*****************************************************************************/

FNSTRUC rptfile;
FNSTRUC outfile;
TMCHAR  *ofile_name;
TMCHAR  one_up_no[27];
short   sqltrace_flag; /* switch to turn on the sql_trace option */

/*****************************************************************************/
/*                                                                           */
/* PROTOTYPES                                                                */
/*                                                                           */
/*****************************************************************************/

void parsargs(TMCHAR *userpass, int argc, TMCHAR *argv[]);
void progopen(TMCHAR *userpass, int argc, TMCHAR *argv[]);
void cmdhelp(void);
void cmdhelp2(void);

#endif
