#ifndef UBPBPFM_H
#define UBPBPFM_H

/****************************************************************************/
/* ## INIT    DATE   AUDIT TRAIL                                            */
/* -- ----  -------- ------------------------------------------------------ */
/*                   RELEASE:2.0.3-C   OUC/583                              */
/*  1 EBR   12/08/96 All definitions controlling content and formatting of  */
/*                   the bill print that cannot be specified in the bill    */
/*                   print formatter (e.g., usppsfm).                       */
/*  2 EBR   08/08/97 Defect #1781 - change control to not print number of   */
/*                   units on residential street light charges.             */
/*                                                                          */
/* AUDIT TRAIL: 8.0 */
/* AUDIT TRAIL END */
/****************************************************************************/

/****************************************************************************

 UBPBPFM.H - Definitions for bill record field numbers and formatting

*****************************************************************************/

#define FIELD_1_ACCOUNT_NUM              "8"
#define FIELD_1_SERVICE_ADDRESS          "10"
#define FIELD_1_SERVICE_ADDRESS_2        "11"
#define FIELD_1_CONSUMPTION_HISTORY      "12"
#define FIELD_1_MESSAGES                 "27"
#define FIELD_1_DEPOSIT_ON_HAND          "37"
#define FIELD_1_CHARGES                  "40"
#define FIELD_1_OBAG_SINGLE              "118"
#define FIELD_1_OBAG_MULTIPLE            "103"
#define FIELD_1_OBAG_SECT_1_SEPARATOR    "130"
#define FIELD_1_OBAG_SECT_1_LOGO         "131"
#define FIELD_1_OBAG_SECT_2_SEPARATOR    "132"
#define FIELD_1_OBAG_SECT_2_LOGO         "133"
#define FIELD_1_BUDGET_GRID              "134"
#define FIELD_1_DUE_DATE                 "135"
#define FIELD_1_TOTAL_CURRENT_CHARGES    "136"
#define FIELD_1_NOW_PAST_DUE             "137"
#define FIELD_1_PAST_DUE                 "138"
#define FIELD_1_TOTAL_AMOUNT_DUE         "139"
#define FIELD_1_SPECIAL_MESSAGES_1       "140"
#define FIELD_1_SPECIAL_MESSAGES_2       "141"
#define FIELD_1_WATERMARK_TEXT           "142"
#define FIELD_1_DUE_NOW_MSG              "146"
#define FIELD_1_STUB_PAST_DUE            "147"
#define FIELD_1_CURRENT_AMT_DUE          "148"
#define FIELD_1_STUB_DUE_DATE            "149"
#define FIELD_1_STUB_ACCOUNT_NUMBER      "150"
#define FIELD_1_BILL_PRINT_DATE          "151"
#define FIELD_1_SCANLINE                 "152"
#define FIELD_1_BARCODE                  "153"

#define END_OF_RECORD_TEXT               "UBPBILP1"

#define NUM_FIELDS_PER_PAGE              159
#define NUM_FIELDS_PER_CHARGE_LINE       3
#define NUM_OF_CHARGE_LINES              21
#define NUM_OF_AGENCY_1_LINES            5
#define NUM_OF_AGENCY_2_LINES            4

#define LAST_CHG_ADJ_DTL_LINE_0          30
#define LAST_CHG_ADJ_DTL_LINE_1          26
#define LAST_CHG_ADJ_DTL_LINE_2          21

#define LAST_CONSUMPTION_LINE            "26"
#define LAST_OUTSIDE_AGENCY_LINE         "129"

#define TOTAL_OUC_ADJUSTMENTS_LABEL      "     %s Adjustments"
#define TOTAL_NON_OUC_ADJUSTMENTS_LABEL  "%s Adjustments"

#define BUDGET_GRID_HEADER_1_FORMAT      "              Budget Information"
#define BUDGET_GRID_HEADER_2_FORMAT      "                     %s       Yr to Date"
#define BUDGET_GRID_DETAIL_1_FORMAT      "Current Charges  %13.13s    %13.13s"
#define BUDGET_GRID_DETAIL_2_FORMAT      "Budget Charges   %13.13s    %13.13s"
#define BUDGET_GRID_DETAIL_3_FORMAT      "Budget Variance  %13.13s    %13.13s"

#define RATE_CHANGE_LEGEND_FORMAT        "* = Rate Change"
#define RECALC_OF_EST_LEGEND_FORMAT      "R = Recalculation of estimations"

#define OBAG_SEPARATOR_IND_DATA          "Y"
#define SPECIAL_HANDLING_CODE_DATA       "S"

#define MULTIPLIER_FORMAT                "     Multiplier %-19.19s"
#define OBAG_SINGLE_GROUP_TOTAL_FORMAT   "Current %s Charges"
#define OBAG_MULTIPLE_GROUP_TOTAL_FORMAT "Current Charges"

#define CHG_ADJ_AMOUNT_FORMAT            "99,999,999.00MI"
#define BUDGET_AMOUNT_FORMAT             "99,999,999.99"

#define DUPLICATE_BILL_TEXT_FORMAT       "               * DUPLICATE BILL *"
#define CORRECTED_BILL_TEXT_FORMAT       "               * CORRECTED BILL *"
#define ADJUSTED_BILL_TEXT_FORMAT        "               * ADJUSTED  BILL *"
#define REPRINTED_BILL_TEXT_FORMAT       "               * REPRINT *"
#define COMM_SEC_LIGHT_TEXT_FORMAT       "%s - %ld Units"
/* #define RESID_SEC_LIGHT_TEXT_FORMAT      "%s - %ld Units"     Defect #1781 */
#define RESID_SEC_LIGHT_TEXT_FORMAT      "%s            "     /* Defect #1781 */
#define METER_INFO_TEXT_FORMAT           "Your %s Meter No. %s%s%s"
#define METER_INFO_EMP_IND_TEXT_FORMAT   "Employee"
#define CURRENT_READING_TEXT_FORMAT      "%5.5s%s Reading: %9.9s%s%s"
#define METER_INFO_NEW_METER_1_FORMAT    "%5.5s%s Reading: %9.9s New Meter"
#define ESTIMATED_TEXT_FORMAT            " Estimated"
#define CORRECTED_TEXT_FORMAT            " Corrected"
#define CONS_ADJ_HEADER_TEXT_FORMAT      "     Adjustment to period ending:"
#define CONS_ADJ_DETAIL_TEXT_FORMAT      "     %8.8s %-5.1lf %s %s %s%s%s"
#define CONS_HIST_HDR_TEXT_1_FORMAT      "CONSUMPTION"
#define CONS_HIST_HDR_TEXT_2_FORMAT      "HISTORY"
#define CONS_HIST_DTL_TEXT_NA_FORMAT     "%s: %8.8s %4.4s"
#define CONS_HIST_DTL_TEXT_PREV_FORMAT   "%s: %-8.3f %4.4s"
#define CONS_HIST_DTL_TEXT_CURR_FORMAT   "%s: %-8.3f %4.4s"
#define STEP_DETAIL_CHG_TEXT_FORMAT      "%-5.3f %4s @ %-10.10f"
#define DUE_NOW_MSG_TEXT_FORMAT          "* DUE NOW               *"
#define BALANCE_FORWARD_FORMAT           "Balance Forward"
#define START_PAGE_SEPARATOR_FORMAT      "***************  START OF %s %s  ***************"
#define END_PAGE_SEPARATOR_FORMAT        "****************  END OF %s %s  ****************"

#define DONT_PRINT_DATA                  0
#define PRINT_DATA                       1

#define USA_NATION_CODE                  "157"

#endif
