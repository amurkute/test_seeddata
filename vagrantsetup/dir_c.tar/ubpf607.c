/******************************************************************************/
/* UBPBPFM.PC - Bill Print Format Subroutines                                 */
/* Alexandria version.                                                        */
/* UBPBPFM.PC Copyright (c) SCT Corporation 1993.  All rights reserved.       */
/******************************************************************************/

/***************************************************/
/*                                                 */
/*       CONFIDENTIAL BUSINESS INFORMATION         */
/*                                                 */
/*      **********************************         */
/*                                                 */
/*  THIS PROGRAM IS PROPRIETARY INFORMATION OF     */
/* SYSTEMS AND COMPUTER TECHNOLOGY CORPORATION     */
/* AND IS NOT TO BE COPIED, REPRODUCED, LENT OR    */
/* DISPOSED OF, NOR USED FOR ANY PURPOSE OTHER     */
/* THAN THAT FOR WHICH IT IS SPECIFICALLY PROVIDED */
/* WITHOUT THE WRITTEN PERMISSION OF SAID COMPANY  */
/*                                                 */
/***************************************************/
/* UBPBPFM.PC                                                             */
/* Bill Print Format Subroutines                                          */
/*                                                                        */
/* This is the customer specific set of subroutines to be included in     */
/* program UBPBILP.PC.                                                    */
/* See that program's documentation for Tables, etc.                      */
/*                                                                        */
/* AUDIT TRAIL                                         INIT    DATE        */
/* -------------------------------------------------  ----  --------      */
/* Release: 1.1                                                           */
/* 1.  Broken out of UBPBILP.PC                       RMG   01-DEC-1993   */
/* 2.  Fixed problem with printing duplicate bills    EBR   27-APR-1994   */
/*     via UBADUPB for accts w/extended due dates.                        */
/*                                                                        */
/* AUDIT TRAIL: 8.0 */
/* AUDIT TRAIL END */
EXEC SQL BEGIN DECLARE SECTION;

/* Misc Application Variables */

  static CHAR2   chk_digit="";
  static CHAR33  ocr_weights="";
  static NUMSTR  accumulated_tax="";
  static CHAR81  temp_text="";

EXEC SQL END DECLARE SECTION;

static void installation_init(void);
static void installation_body_init(void);
static void line_5_7(void);
static void line_05_30_change_out(void);
static void line_05_30_text(void);
static void insert_blank_line(void);
static void insert_blank_line_2(void);
static void line_31_multi(void);
static void line_47_multi(void);
static void update_bunch_code(void);
static void insert_multiple_pages(void);
static void print_address(void);
static void print_budget_footnote(void);
static void print_budget_line(void);
static void print_line_01(void);
static void print_line_03(void);
static void print_line_04(void);
static void print_line_5_7(void);
static void print_line_14(void);
static void print_line_25(void);
static void print_line_36(void);
static void print_line_37(void);
static void print_line_39(void);
static void print_line_40(void);
static void print_line_41(void);
static void ocra_off(void);
static void print_detail_line(void);
static void print_detail_line_2(void);
static void print_detail_line_change_out_2(void);
static void print_detail_line_adjustments(void);
static void print_line_05_30_text(void);
static void print_blank_line(void);
static void print_unprinted_bill(void);
static void print_printed_bill(void);
static void uabopen_head(void);
static void uabopen_body(void);
static void uabopen_foot(void);
static void adjustment_head(void);
static void adjustment_body(void);
static void adjustment_foot(void);
static void print_barcode_zip(void);
static void print_draft_next_month_msg(void);
static void print_draft_msg(void);
static void print_line_08_dupl(void);
static void print_line_09_draft(void);
static void print_rdup(void);
static void print_line_09_no_pay(void);
static void print_please_pay_msg(void);
static void print_line_09_please_pay(void);


  /****************************************************************************/
  /****************************************************************************/
  /*--------------------------------------------------------------------------*/
  /* Installation Initializations                                             */
  /*--------------------------------------------------------------------------*/
  /****************************************************************************/
  /****************************************************************************/

static void installation_init(void)
{
  /*  Line number that address lines should follow on page  */
  /*  To print address at very top, set to "0".             */
  strcpy(address_after_line,"25");
  strcpy(ocr_weights,"71371371371371371371371037137130");
}

static void installation_body_init(void)
{
  return;
}

  /****************************************************************************/
  /****************************************************************************/
  /*--------------------------------------------------------------------------*/
  /*  print_unprinted_bill and print_printed_bill, top level control for      */
  /*  format modules.  Called from BODY in ubpbilp.pc                         */
  /*--------------------------------------------------------------------------*/
  /****************************************************************************/
  /****************************************************************************/

/* ************************************************************************** */
/* print bills that have never been printed before (printed_inds = 'N')       */
/* ************************************************************************** */

static void print_unprinted_bill(void)
{

/* select the next bhst_tran_num from the sequence */

  select_ubsbhst(FIRST_ROW);

  strcpy(amount_due,"0");
  strcpy(adjustments,"0");
  strcpy(accumulated_tax,"0");

  strcpy(line_05_30_lineno,"10");

/* prev balance */

  tonum(prev_bal,null);
  select_prev_bal(FIRST_ROW);
  if ( !*prev_bal )
    strcpy(prev_bal,"0");
  else
    add(amount_due,amount_due,prev_bal);
  strcpy(text,"PREVIOUS BALAN");
  strcpy(amount,prev_bal);
  strcpy(prev_bal,ubbbhst_prev_bal);
  prtnum(ubbbhst_prev_bal,"99,999,999.99");
  prtnum(prev_bal,"99,999,999.99");
  if (!compare(amount,"0",EQS))
    print_line_05_30_text();

/* adjustments            */
/*                        */
/*    .EQUAL adj_ind null */

    report(select_adjs_unprinted,adjustment_body,adjustment_head,adjustment_foot);

    add(amount_due,amount_due,adjustments);

/* payments */

    tonum(payments,null);
    select_payments_unbilled(FIRST_ROW);
    if ( !*payments )
      strcpy(payments,"0");
    else
      subtract(amount_due,amount_due,payments);

/*    .SET text "Less Payments:" */

    strcpy(amount,payments);
/*    strcpy(payments,ubbbhst_payments);   to correct update of ubbbhst */

/* get balance of account */
/* At this point, as we are processing each open item, we do not yet know
   what the final amount due will be.  So we go get it and store it in
   amount_due_balance.  This field differs from amount_due, which will
   eventually be the same amount but is just being computed as we go along
   at this point in the logic.                                             */

    select_payments_zero_bill(FIRST_ROW);
    uabopen_bill_balance(FIRST_ROW);
    subtract(amount_due_balance,bill_balance,payments_zero_bill);

/*  Commented out 1/25/94, RMG - test will be done right before UBRRECP
    insert anyhow, and some updates within UABOPEN get skipped if done here.

    if ((compare(amount_due_balance,"0",EQ))
      && (print_zero_balance_bills_var[0]=='N'))
        return;
*/

/* compute round up if necessary */

    if (ucracct_rdup_ind[0]=='Y' && *uobsysc_srat_code_rdup)
      insert_roundup();

/* open item charges */
    report(uabopen_selmacro_unprinted,uabopen_body,uabopen_head,uabopen_foot);

    print_line_25();
    subtract(balance_forward,prev_bal,payments);

/* amount due                                 */
/*                                            */
/* turn on the OCR-A scan line and print data */

    print_line_41();

/* turn off the OCR-A scan line */

/*AP    ocra_off();     */

    if ( compare(amount_due,"0",LT) ) {  /*  AP  */
      if ( compare(amount_due,"0",LT) ) {
        strcpy(text,"Credit Balance ");
        strcpy(credit_bill_ind,"Y");
      }
      else {
        strcpy(text,"Total Due ");
        strcpy(credit_bill_ind,null);
      }
      strcpy(amount,amount_due);
  /*  print_line_05_30_text();
      print_blank_line();          AP 10-08-93 */
      strcpy(text,null);
    }

/* if we had a budgeted service, print footnote explaining */
/* '*' beside charges                                      */

    print_budget_footnote();

    bank_drafts();

    if (*uobsysc_srat_code_rdup)
      check_rdup_msg();

    if (ubtibil_type_ind[0] == 'D')
      print_line_08_dupl();

    if (ucbmbil_sub_pymt_ind[0]=='N')
      print_line_09_no_pay();

    print_line_01();
    print_line_03();
    print_line_04();
    print_line_14();
    print_line_36();
    print_line_37();
    print_line_39();
    print_line_40();

/* print the system-wide, customer-specific, and/or account specific */
/* bill message                                                      */

    print_line_5_7();

/* if we have multi-page bills, duplicate lines 1, 3, 50, 51,and 52   */
/* on all pages of the bill.  Also print the page number on all pages */

    if ( *multi_page_ind ) {
      count_pages();
      insert_multiple_pages();
    }

}                                        /* end print_unprinted_bill */

/* ************************************************************************** */
/* print bills that have been printed before (printed_inds = 'Y')             */
/* ************************************************************************** */

static void print_printed_bill(void)
{

/* get the due date from one of the open items for this */
/* billing                                              */

  /* printf("\nDUE_DATE1 = %s\n",uabopen_due_date);      */
  /* printf("\NBHST_TRAN_NUM = %s\n",ubbbhst_tran_num);  */
  select_due_date_printed(FIRST_ROW);
  /* printf("\nDUE_DATE2 = %s\n",uabopen_due_date);      */
  strcpy(amount_due,"0");
  strcpy(adjustments,"0");
  strcpy(line_05_30_lineno,"10");

/* prev balance */

  strcpy(text,"PREVIOUS BALAN");
  strcpy(amount,ubbbhst_prev_bal);
  strcpy(prev_bal,ubbbhst_prev_bal);
  if (!compare(amount,"0",EQS))
    print_line_05_30_text();

/* payments */

  strcpy(text,"Less Payments:");
  strcpy(amount,ubbbhst_payments);
  strcpy(payments,ubbbhst_prev_bal);
  print_line_25();

/* open item charges */

  report(uabopen_selmacro_printed,uabopen_body,uabopen_head,uabopen_foot);

/* adjustments */

  if ( compare(ubbbhst_adjustments,"0",NE) )
    strcpy(amount,ubbbhst_adjustments);

/* amount due */

    if ( compare(ubbbhst_ending_bal,"0",LT) ) {
      strcpy(text,"Credit Balance:");
      strcpy(credit_bill_ind,"Y");
    }
    else {
      strcpy(text,"Amount Due:");
      strcpy(credit_bill_ind,null);
    }
    strcpy(amount,ubbbhst_ending_bal);
    strcpy(amount_due,ubbbhst_ending_bal);
    subtract(balance_forward,prev_bal,payments);

/* amount due                                 */
/*                                            */
/* turn on the OCR-A scan line and print data */

    print_line_41();

/* turn off the OCR-A scan line */

/*AP    ocra_off();   */

    if ( compare(amount_due,"0",LT) ) {   /*  AP  */
      if ( compare(amount_due,"0",LT) ) {
        strcpy(text,"Credit Balance ");
        strcpy(credit_bill_ind,"Y");
      }
      else {
        strcpy(text,"Total Due ");
        strcpy(credit_bill_ind,null);
      }
      strcpy(amount,amount_due);
  /*  print_line_05_30_text();
      print_blank_line();          AP 10-08-93  */
      strcpy(text,null);
    }

/* if we had a budgeted service, print footnote explaining */
/* '*' beside charges                                      */

    print_budget_footnote();

    bank_drafts();

    if (*uobsysc_srat_code_rdup)
      check_rdup_msg();

    if (ubtibil_type_ind[0] == 'D')
      print_line_08_dupl();

    if (ucbmbil_sub_pymt_ind[0]=='N')
      print_line_09_no_pay();

    print_line_01();
    print_line_03();
    print_line_04();

/* print the system-wide, customer-specific, and/or account specific */
/* bill message                                                      */

    print_line_5_7();
    print_line_14();
    print_line_36();
    print_line_37();
    print_line_39();
    print_line_40();

/* if we have multi-page bills, duplicate lines 1, 3, 50, 51,and 52   */
/* on all pages of the bill.  Also print the page number on all pages */

    if ( *multi_page_ind ) {
      count_pages();
      insert_multiple_pages();
    }

}                                        /* end print_printed_bill */

  /****************************************************************************/
  /****************************************************************************/
  /*--------------------------------------------------------------------------*/
  /*   uabopen head and body.  Called from print_printed_bill,                */
  /*   print_unprinted_bill for each open item to print in center of page.    */
  /*--------------------------------------------------------------------------*/
  /****************************************************************************/
  /****************************************************************************/

/* ************************************************************************** */
/* uabopen head                                                               */
/* ************************************************************************** */

static void uabopen_head(void)
{
  select_serv_info(FIRST_ROW);
  test_for_budget();
  strcpy(break_serv_num,uabopen_serv_num);
  strcpy(total_budget_amount,"0");
  uabopen_body();
}                                        /* end uabopen_head */

/* *********************************************************************** */
/* uabopen body                                                            */
/* *********************************************************************** */

static void uabopen_body(void)
{

/* check for service break */

  if ( compare(break_serv_num,uabopen_serv_num,NE) ) {
    /* if this was a budgeted_service */
    if ( *budgeted_service_ind )
      print_budget_line();
    test_for_budget();
    select_serv_info(FIRST_ROW);
    strcpy(break_serv_num,uabopen_serv_num);
  }

/* clear detail line fields */

    strcpy(ubbchst_billed_consump,"        ");
    strcpy(present_reading,"         ");
    strcpy(prev_reading,"         ");
    strcpy(urrshis_multiplier,"         ");
    strcpy(urrshis_high_low_excp," ");

    if (*uabopen_chrg_calc_num && *non_metered_ind) {
      /* select the non-metered info if we have the primary rate */
      select_dos_flat(FIRST_ROW);
      select_present_date_flat(FIRST_ROW);
      select_previous_date_flat(FIRST_ROW);
      /* print the open item detail */
      print_detail_line_2();
    }
    else {
      if (*uabopen_chrg_calc_num) {
        /* select the metered info if we have the primary rate */
        select_previous_reading(FIRST_ROW);
        select_change_out_reading(FIRST_ROW);
        select_dos(FIRST_ROW);
        if (change_out_ind[0]=='Y') {
          subtract(change_out_cons,change_out_reading,prev_reading_2);
          print_detail_line_change_out_2();
          strcpy(change_out_ind,"N");
          select_present_reading(FIRST_ROW);
          sel_previous_reading_new_meter(FIRST_ROW);
          /* print the open item detail */
          print_detail_line();
        }
        select_previous_reading(FIRST_ROW);
        select_present_reading(FIRST_ROW);
        select_dos(FIRST_ROW);
        select_cons_history(FIRST_ROW);
        /* print the open item detail */
        print_detail_line_2();
      }
      else {
        select_previous_reading(FIRST_ROW);
        select_present_reading(FIRST_ROW);
        select_dos(FIRST_ROW);
        select_cons_history(FIRST_ROW);
        /* print the open item detail */
        print_detail_line_2();
      }
    }

/* total the adjustments for the open item we are currently processing. */

    tonum(uabadje_budget_variance,null);
    tonum(uabadje_billed_chg,null);
    strcpy(adj_ind,null);
    select_adjs_printed(FIRST_ROW);

/* total the charges */

    if ( *budgeted_service_ind && compare(budgeted_service_ind,"C",NES) ) {
      /* we have a budgeted service, add the budget charges to the */
      /* charges total and insert the budget charge line           */
      strcpy(budget_footnote,"Y");
      if ( *uabadje_budget_variance )
        add(uabopen_budget_variance,uabopen_budget_variance,uabadje_budget_variance);
      if ( *uabadje_billed_chg )
        add(uabopen_billed_chg,uabopen_billed_chg,uabadje_billed_chg);
      subtract(budget_amount,uabopen_billed_chg,uabopen_budget_variance);
      add(charges,charges,budget_amount);
      add(total_budget_amount,total_budget_amount,budget_amount);
    }
    else {
      add(charges,charges,uabopen_billed_chg);
      if (compare(uabopen_tax_ind,"Y",EQS) || compare(uabopen_tax_ind,"T",EQS))
         add(accumulated_tax,accumulated_tax,uabopen_billed_chg);
    }

/* ********************************************************************* */
/* update routines - do not execute if in reprint mode                   */
/*   or, in sleep-wake, update-ind is off                                */
/* ********************************************************************* */

    if ( *reprint_date_var ||
      (*sleep_wake_ind && ubtibil_calc_update_ind[0] != 'Y') )
        return;

/* If the account has a payment arrangement, check the open item        */
/* and determine if it needs to be updated into uarpyar.  It needs to   */
/* be updated/inserted when:                                            */
/*  1) A debit open item is found with no due date (31-dec-2099) and    */
/*     has not been printed on a bill                                   */
/*  2) A debit adjustment is found that has not been printed on a bill. */

    if ( *ucracct_pmnt_arr ) {
      /* we have a payment arrangement, total the debit adjs for this */
      /* open item                                                    */
      strcpy(adj_ind,null);
      select_adjs_pay_arrng(FIRST_ROW);
      if ( *adj_ind )
        add(debit_adjs,debit_adjs,uabadje_balance);
        /* check to see if the open item has a due date and a debit amount */
      if ( compare(uabopen_due_date,"31-DEC-2099",EQS) &&
        compare(uabopen_billed_chg,"0",GT) ) {
          /* we have a positive charge, update/insert a row to uarpyar */
          strcpy(amount,uabopen_billed_chg);
          update_insert_pmnt_arrng();
      }
    }

/* update the printed indicator, printed date, and due date in uabopen */

    update_uabopen();

/* ********************************************************************* */
/* end update routines                                                   */
/* ********************************************************************* */

}                                        /* end uabopen_body */

/* ************************************************************************** */
/* uabopen foot                                                               */
/* ************************************************************************** */

static void uabopen_foot(void)
{
  /* if this was a budgeted_service */
  if ( *budgeted_service_ind )
    print_budget_line();
  /*    .print_blank_line */
  add(amount_due,amount_due,charges);
}                                        /* end uabopen_foot */

  /****************************************************************************/
  /****************************************************************************/
  /*--------------------------------------------------------------------------*/
  /*   adjustment head, body, and foot.  Called from print_unprinted_bill.    */
  /*--------------------------------------------------------------------------*/
  /****************************************************************************/
  /****************************************************************************/

/* ************************************************************************** */
/*   a d j u s t m e n t   h e a d                                            */
/* ************************************************************************** */

static void adjustment_head(void)
{
  adjustment_body();
}

/* ************************************************************************** */
/*   a d j u s t m e n t   b o d y                                            */
/* ************************************************************************** */

static void adjustment_body(void)
{
  print_detail_line_adjustments();
  add(adjustments,adjustments,uabadje_balance);
  /* ********************************************************************** */
  /* update the printed indicator and printed date in uabadje               */
  /* if in sleep-wake mode and update-ind is off, skip updates              */
  /* ********************************************************************** */
  if (*sleep_wake_ind && ubtibil_calc_update_ind[0] != 'Y')
    return;
  update_uabadje();
}

/* ************************************************************************** */
/*   a d j u s t m e n t   f o o t                                            */
/* ************************************************************************** */

static void adjustment_foot(void)
{
  add(adjustments,adjustments,uabadje_balance);
  strcpy(amount,adjustments);
  strcpy(text,"Total Adjustments");
  print_line_05_30_text();
  print_blank_line();
}

  /****************************************************************************/
  /****************************************************************************/
  /*--------------------------------------------------------------------------*/
  /*           Report line creation                                           */
  /*--------------------------------------------------------------------------*/
  /****************************************************************************/
  /****************************************************************************/

/* ******************************************************************* */
/* change out lines                                                    */
/* ******************************************************************* */

static void line_05_30_change_out(void)
{
  EXEC SQL
   INSERT INTO uimsmgr.ubrbill
        (
        ubrbill_bill_num,
        ubrbill_page_num,
        ubrbill_line_num,
        ubrbill_sess_id,
        ubrbill_text
        )
    SELECT
          TO_NUMBER(:billno),
          TO_NUMBER(:line_05_30_pageno),
          TO_NUMBER(:line_05_30_lineno),
          :session_id,
          decode(TO_NUMBER(:uabopen_chrg_calc_num),
                 null,rpad(utrsrat_bill_print_desc,14),
                 decode(:non_metered_ind,
                 null,rpad(:change_out_reading,9) ||
                 :change_out_date,
                 '              '))                                ||
          lpad(nvl(to_char(TO_NUMBER(:change_out_dos)),'   '),3)   ||
          lpad(nvl(to_char(TO_NUMBER(:change_out_cons)),'        '),8)  ||
          lpad(nvl(:ucrserv_styp_code,'    '),4)
    FROM uimsmgr.utrsrat
    WHERE utrsrat_srat_code = :uabopen_srat_code
      AND utrsrat_scat_code = :uabopen_scat_code;
  POSTORA;
}                                        /* end line_05_30_change_out */

/* ******************************************************************* */
/* print a text line                                                   */
/* ******************************************************************* */

static void line_05_30_text(void)
{
  EXEC SQL
   INSERT INTO uimsmgr.ubrbill
        (
        ubrbill_bill_num,
        ubrbill_page_num,
        ubrbill_line_num,
        ubrbill_sess_id,
        ubrbill_text
        )
   VALUES
        (
        TO_NUMBER(:billno),
        TO_NUMBER(:line_05_30_pageno),
        TO_NUMBER(:line_05_30_lineno),
        :session_id,
        rpad(:text,28)  ||
        ' '             ||
        decode(substr(:amount_due,1,1),
        '-',
        nvl(lpad(to_char(ABS(TO_NUMBER(:amount)),'9999.99'),8),0)    ||
        'CR ',
        nvl(lpad(to_char(TO_NUMBER(:amount),'9999.99'),8),0)
        )
        );
  POSTORA;
}                                        /* end line_05_30_text */

/* ******************************************************************* */
/* print a blank text line                                             */
/* ******************************************************************* */

static void insert_blank_line(void)
{
  EXEC SQL
   INSERT INTO uimsmgr.ubrbill
        (
        ubrbill_bill_num,
        ubrbill_page_num,
        ubrbill_line_num,
        ubrbill_sess_id,
        ubrbill_text
        )
   VALUES
        (
        TO_NUMBER(:billno),
        TO_NUMBER(:line_05_30_pageno),
        TO_NUMBER(:line_05_30_lineno),
        :session_id,
        '          '
        );
  POSTORA;
}                                        /* end insert_blank_line */

/* ******************************************************************* */
/* print a blank text line                                             */
/* ******************************************************************* */

static void insert_blank_line_2(void)
{
  EXEC SQL
   INSERT INTO uimsmgr.ubrbill
        (
        ubrbill_bill_num,
        ubrbill_page_num,
        ubrbill_line_num,
        ubrbill_sess_id,
        ubrbill_text
        )
   VALUES
        (
        TO_NUMBER(:billno),
        TO_NUMBER(:pageno),
        TO_NUMBER(:lineno),
        :session_id,
        '          '
        );
  POSTORA;
}                                        /* end insert_blank_line_2 */

/* ******************************************************************* */
/* if multi-page print continued on next page message for line 05-30   */
/* overflow                                                            */
/* ******************************************************************* */

static void line_31_multi(void)
{
  EXEC SQL
   INSERT INTO uimsmgr.ubrbill
        (
        ubrbill_bill_num,
        ubrbill_page_num,
        ubrbill_line_num,
        ubrbill_sess_id,
        ubrbill_text
        )
   VALUES
        (
        TO_NUMBER(:billno),
        TO_NUMBER(:line_05_30_pageno),
        42,
        :session_id,
'                                                         Continued on Next Page'
        );
  POSTORA;
}                                        /* end line_31_multi */

/* ******************************************************************* */
/* if multi-page print page number on the bill                         */
/* overflow                                                            */
/* ******************************************************************* */

static void line_47_multi(void)
{
  EXEC SQL
   INSERT INTO uimsmgr.ubrbill
        (
        ubrbill_bill_num,
        ubrbill_page_num,
        ubrbill_line_num,
        ubrbill_sess_id,
        ubrbill_text
        )
   VALUES
        (
        TO_NUMBER(:billno),
        TO_NUMBER(:pageno),
        43,
        :session_id,
        '                                                                    '
        ||
        'Page ' ||
        to_char(TO_NUMBER(:pageno)) ||
        ' of '  ||
        to_char(TO_NUMBER(:page_count))
        );
  POSTORA;
}                                        /* end line_47_multi */

/* ************************************************************************** */
/* override the bunch code in the bill print collector table because          */
/* the user choice to bunch finals, credits, and/or inactives or              */
/* we have a multi-page bill                                                  */
/* Alexandria version: just return.                                           */
/* ************************************************************************** */

static void update_bunch_code(void)
{
  return;
}                                        /* end update_bunch_code */

/* ************************************************************************** */
/* if we have a multiple page bill, duplicate the below lines on all          */
/* pages of the bill                                                          */
/* ************************************************************************** */

static void insert_multiple_pages(void)
{
  line_47_multi();
  while(1) {
    add(pageno,pageno,"1");
    if ( compare(pageno,page_count,GT) )
      return;
    print_line_01();
    print_line_03();
    print_line_04();
    print_line_14();
    print_line_25();
    print_line_36();
    print_line_37();
    print_line_39();
    print_line_40();
    print_line_41();
    line_47_multi();
  }
}                                        /* end insert_multiple_pages */

/* ************************************************************************** */
/* print the address lines                                                    */
/* ************************************************************************** */

static void print_address(void)
{

  print_barcode_zip();

/* clear the address lines */

  strcpy(address_line1_text,null);
  strcpy(address_line2_text,null);
  strcpy(address_line3_text,null);
  strcpy(address_line4_text,null);
  strcpy(address_line5_text,null);
  strcpy(address_line6_text,null);

/* load the address fields */

  EXEC SQL
   SELECT   '                      '               ||
            '                      '               ||
                      rpad(substr(:ubrrecp_print_name,1,40),40)
     into :address_line1_text:Ind_01
     FROM  sys.dual;
  POSTORA;
  if ( NO_ROWS_FOUND ) {
    *address_line1_text='\0';
  }

  if ( *ubrrecp_street_line1 ) {
    EXEC SQL
     SELECT       '                      '               ||
                  '                      '               ||
                             rpad(:ubrrecp_street_line1,15) ||
                  ' ' ||
                  rpad(:ubrrecp_street_line2,15) ||
                  ' ' ||
                  rpad(:ubrrecp_street_line3,15)
     into :address_line2_text:Ind_01
     FROM sys.dual;
    POSTORA;                      
    if ( NO_ROWS_FOUND ) {
      *address_line2_text='\0';
    }
  }

  if ( *ubrrecp_street_name ) {
    EXEC SQL
     SELECT       '                      '               ||
                  '                      '               ||
                             rpad(substr(:ubrrecp_street_address,1,40),40)
     into :address_line3_text:Ind_01
     FROM sys.dual;
    POSTORA;
    if ( NO_ROWS_FOUND ) {
      *address_line3_text='\0';
    }
  }

  if ( *ubrrecp_street_line2 ) {
    EXEC SQL
     SELECT       '                      '               ||
                  '                      '               ||
                       rpad(:ubrrecp_street_line2,40)
     into :address_line4_text:Ind_01
     FROM sys.dual;
    POSTORA;
    if ( NO_ROWS_FOUND ) {
      *address_line4_text='\0';
    }
  }        

  if ( *ubrrecp_street_line3 ) {
    EXEC SQL
     SELECT       '                      '               ||
                  '                      '               ||
                     rpad(:ubrrecp_street_line3,40)
     into :address_line5_text:Ind_01
     FROM sys.dual;
    POSTORA;
    if ( NO_ROWS_FOUND ) {
      *address_line5_text='\0';
    }
  }        

  EXEC SQL
   SELECT       '                      '               ||
                '                      '               ||
                :ubrrecp_city           ||
                ' '                     ||
                :ubrrecp_stat_code      ||
                ' '                     ||
                :ubrrecp_zip_1_5        ||
                decode(:ubrrecp_zip_7_10,
                        null,'',
                        '-' || :ubrrecp_zip_7_10)
   into :address_line6_text:Ind_01
   FROM sys.dual;
  POSTORA;
  if ( NO_ROWS_FOUND ) {
    *address_line6_text='\0';
  }

/* print the address lines                       */
/*                                               */
/* customer name and cycle code - address line 1 */
/*                                               */
/*    #S 3                                       */

    newline();
    setmode(M_COLLIT);
    prtstr(address_line1_text);
    setmode(M_NORMAL);
    newline();
    add(prev_line_num,prev_line_num,"1");

/* attention line - address line 2 */

    if ( *address_line2_text ) {
      setmode(M_COLLIT);
      prtstr(address_line2_text);
      setmode(M_NORMAL);
      newline();
      add(prev_line_num,prev_line_num,"1");
    }

/* street number, street name, etc - address line 3 */

    if ( *address_line3_text ) {
      setmode(M_COLLIT);
      prtstr(address_line3_text);
      setmode(M_NORMAL);
      newline();
      add(prev_line_num,prev_line_num,"1");
    }

/* city, state and zip line - address line 6 */

    if ( *address_line6_text ) {
      setmode(M_COLLIT);
      prtstr(address_line6_text);
      setmode(M_NORMAL);
      newline();
      add(prev_line_num,prev_line_num,"1");
    }

}                                        /* end print_address */

/* ************************************************************************** */
/* print the barcode zip line                                                 */
/* ************************************************************************** */

static void print_barcode_zip(void)
{

  /* set ocr barcode and print */

  int j,
      process_code=0;   /* 0=do not print,
                           1=print 5-digit zip,
                           2=print 9-digit zip with default '99' delivery point,
                           3=print 9-digit zip with delivery point  */

  if (first_time_barcode == 1) {
    barcode_return = get_barcode_escapes();
    first_time_barcode = 0;
  }

  if (barcode_return > 0)
    return;

  for (j=0; j<5; j++) {
    if (!isdigit(ubrrecp_zip_1_5[j]))
      return;
  }
  process_code = 1;
  for (j=0; j<4; j++) {
    if (!isdigit(ubrrecp_zip_7_10[j]))
      break;
  }
  if (j==4) {
    process_code = 2;
    for (j=0; j<2; j++) {
      if (!isdigit(ubrrecp_delivery_point[j]))
        break;
    }
    if (j==2)
      process_code = 3;
  }

  if (process_code == 1) {
    EXEC SQL
      SELECT
        '          ' ||
        :baron_esc_parsed ||
        :ubrrecp_zip_1_5 ||
        :baroff_esc_parsed
      into :barcode_line_text
      from SYS.DUAL;
    POSTORA;
    if (NO_ROWS_FOUND)
      *barcode_line_text = '\0';
  }
  else {
    if (process_code == 2)
      strcpy(ubrrecp_delivery_point,"99");
    EXEC SQL
      SELECT
        '          ' ||
        :baron_esc_parsed ||
        :ubrrecp_zip_1_5 ||
        :ubrrecp_zip_7_10 ||
        :ubrrecp_delivery_point ||
        :baroff_esc_parsed
      into :barcode_line_text
      from SYS.DUAL;
    POSTORA;
    if (NO_ROWS_FOUND)
      *barcode_line_text = '\0';
  }

  newline();
  setmode(M_COLLIT);
  prtstr(barcode_line_text);
  setmode(M_NORMAL);
  newline();
  add(prev_line_num,prev_line_num,"1");

}                                        /* end print_barcode_zip */

/* ************************************************************************* */
/* if we had a budgeted service, print the footnote at the bottom            */
/* of the open item detail section                                           */
/* ************************************************************************* */

static void print_budget_footnote(void)
{
  if ( *budget_footnote ) {
    add(line_05_30_lineno,line_05_30_lineno,"1");
    strcpy(text,
      "'*'=Actual Charges For Budgeted Service Not Included in Amount Due");
    tonum(amount,null);
    print_line_05_30_text();
  }

}                                        /* end print_budget_footnote */

/* ************************************************************************** */
/* print budget line                                                          */
/* ************************************************************************** */

static void print_budget_line(void)
{
  select_budget_totals(FIRST_ROW);
  subtract(ytd_budget_charges,ytd_actual_charges,ytd_budget_variance);
  EXEC SQL
   SELECT 'YTD Actual: '                                        ||
          rpad(to_char(TO_NUMBER(:ytd_actual_charges),'9999999.99'),11)    ||
        '  YTD Budget: '                                        ||
          rpad(to_char(TO_NUMBER(:ytd_budget_charges),'9999999.99'),11)    ||
        decode(:budgeted_service_ind,
                'Y', '     Budget Amount:',
                'C', ' Settlement Amount:',
                     '                   ')
     into :text:Ind_01
     FROM sys.dual;
  POSTORA;
  if ( NO_ROWS_FOUND ) {
    *text='\0';
  }
  if ( compare(budgeted_service_ind,"Y",NES) ) {
    strcpy(amount,ytd_budget_variance);
    add(charges,charges,ytd_budget_variance);
    if (!*sleep_wake_ind ||
      (*sleep_wake_ind && ubtibil_calc_update_ind[0] == 'Y'))
        update_uarbudg();
  }
  else
    strcpy(amount,total_budget_amount);
  print_line_05_30_text();
  strcpy(total_budget_amount,"0");
}                                        /* end print_budget_line */

/* ************************************************************************** */
/* insert line 01-06 into ubrbill collector table                             */
/* ************************************************************************** */

static void print_line_01(void)
{

/* load the bill into the ubrbill-bill collector */
/*                                               */
/* page number                                   */

  strcpy(lineno,"1");
  EXEC SQL
   INSERT INTO uimsmgr.ubrbill
        (
        ubrbill_bill_num,
        ubrbill_page_num,
        ubrbill_line_num,
        ubrbill_sess_id,
        ubrbill_text
        )
   VALUES
        (
        TO_NUMBER(:billno),
        TO_NUMBER(:pageno),
        TO_NUMBER(:lineno),
        :session_id,
        '  PAGE ' ||  lpad(to_char(TO_NUMBER(:pageno)),4)
        );
  POSTORA;
}                                                /* end print_line_01 */

static void print_line_03(void)
{

/* load the bill into the ubrbill-bill collector */
/*                                               */
/* Premises Address - line 3                     */

  strcpy(lineno,"3");
  EXEC SQL
   INSERT INTO uimsmgr.ubrbill
        (
        ubrbill_bill_num,
        ubrbill_page_num,
        ubrbill_line_num,
        ubrbill_sess_id,
        ubrbill_text
        )
    SELECT
          TO_NUMBER(:billno),
          TO_NUMBER(:pageno),
          TO_NUMBER(:lineno),
          :session_id,
          '  ' ||
          rpad(substr (
            decode (ucbprem_street_number,'','',ucbprem_street_number||' ')||
            decode (ucbprem_pdir_code_pre,'','',ucbprem_pdir_code_pre||' ')||
            decode (ucbprem_street_name,'','',  ucbprem_street_name  ||' ')||
            decode (ucbprem_ssfx_code,'','',ucbprem_ssfx_code        ||' ')||
                  ucbprem_pdir_code_post,1,38),38)
    FROM uimsmgr.ucbprem
    WHERE ucbprem_code = :ucracct_prem_code;
  POSTORA;
}                                                /* end print_line_03 */

static void print_line_04(void)
{

/* load the bill into the ubrbill-bill collector */
/*                                               */
/* Premises Address - address_line 6             */

  strcpy(lineno,"4");
  EXEC SQL
   INSERT INTO uimsmgr.ubrbill
        (
        ubrbill_bill_num,
        ubrbill_page_num,
        ubrbill_line_num,
        ubrbill_sess_id,
        ubrbill_text
        )
   SELECT
        TO_NUMBER(:billno),
        TO_NUMBER(:pageno),
        TO_NUMBER(:lineno),
        :session_id,
        '  ' ||
            decode (ucbprem_city,'','',ucbprem_city||' ')||
            decode (ucbprem_stat_code_addr,'','',ucbprem_stat_code_addr||' ')||
            decode (ucbprem_zipc_code,'','',ucbprem_zipc_code        ||' ')
   FROM uimsmgr.ucbprem
   WHERE ucbprem_code = :ucracct_prem_code;
 POSTORA;
}                                                /* end print_line_04 */

/* ************************************************************************** */
/* insert line 14 into ubrbill collector table                                */
/* ************************************************************************** */

static void print_line_14(void)
{

/* late date       */

  strcpy(lineno,"14");
  EXEC SQL
      SELECT ubrbill_text INTO :temp_text
      FROM uimsmgr.ubrbill
      WHERE
         ubrbill_bill_num = TO_NUMBER(:billno)
     AND ubrbill_page_num = TO_NUMBER(:pageno)
     AND ubrbill_line_num = TO_NUMBER(:lineno)
     AND ubrbill_sess_id  = :session_id;
  POSTORA;
  EXEC SQL
     DELETE FROM uimsmgr.ubrbill
     WHERE
         ubrbill_bill_num = TO_NUMBER(:billno)
     AND ubrbill_page_num = TO_NUMBER(:pageno)
     AND ubrbill_line_num = TO_NUMBER(:lineno)
     AND ubrbill_sess_id  = :session_id;
  POSTORA;
  EXEC SQL
   INSERT INTO uimsmgr.ubrbill
        (
        ubrbill_bill_num,
        ubrbill_page_num,
        ubrbill_line_num,
        ubrbill_sess_id,
        ubrbill_text
        )
    VALUES
        (
          TO_NUMBER(:billno),
          TO_NUMBER(:pageno),
          TO_NUMBER(:lineno),
          :session_id,
        rpad(nvl(:temp_text,' '),40)         ||
        decode(:ucbmbil_sub_pymt_ind,
               'N','                 ',
               lpad(to_char(TO_DATE(
                    decode(:reprint_date_var,
                           null, decode(:deferred_due_date,
                                        null,:due_date,
                                        :deferred_due_date),
                           :uabopen_due_date),
                    'DD-MON-YYYY'),'fmMM/DD/YY'),17))
       );
  POSTORA;
  strcpy(temp_text,null);
}                                        /* end print_line_14 */

/* ************************************************************************** */
/* insert line 41 OCR-A scan line into ubrbill collector table                */
/* ************************************************************************** */

static void print_line_41(void)
{

  /* set ocr scan line and print */

  register int     ocr_sub;         /* Actual position within the string  */
           int     ocr_mod;         /* modulus to be used                 */
           int     ocr_start;       /* index of the start of the ocr      */
  register int     ocr_total;       /* computed sum                       */

  if (first_time_scan == 1) {
    get_scan_escapes();
    first_time_scan = 0;
  }

  strcpy(lineno,"41");

  EXEC SQL
     SELECT      '                                        ' ||
                 lpad(lpad(to_char(TO_NUMBER(:ucracct_cust_code)),9,'0'),15) ||
                 lpad(:ucracct_prem_code,7,'0')                             ||

                 decode(substr(:amount_due,1,1),
                 '-',
                 to_char(TO_NUMBER(nvl( (100 * :amount_due),0)),'0999999MI')  ||
                 to_char(TO_NUMBER(nvl( (100 * :amount_due),0)),'0999999MI'),
                 to_char(TO_NUMBER(nvl( (100 * :amount_due),0)),'0999999MI')  ||
                 to_char(nvl(
                   (110 * (TO_NUMBER(:amount_due) - TO_NUMBER(:accumulated_tax))
                        + TO_NUMBER(:accumulated_tax)),0),'0999999MI')
                 )
     INTO :ubrbill_text
     FROM sys.dual;
  POSTORA;

  ocr_mod     =   10;
  ocr_total   =    0;
  ocr_start   =   46;
  strcpy(chk_digit,null);

  for (ocr_sub = ocr_start; ocr_sub <= 77; ocr_sub++)
     ocr_total += ( ubrbill_text [ocr_sub] - '0' ) *
                  ( ocr_weights [ocr_sub - ocr_start] - '0' );

  chk_digit[0] = ( ( ocr_total % ocr_mod ) + '0') ;

  EXEC SQL
   INSERT INTO uimsmgr.ubrbill
        (
        ubrbill_bill_num,
        ubrbill_page_num,
        ubrbill_line_num,
        ubrbill_sess_id,
        ubrbill_text
        )
    VALUES
        (
          TO_NUMBER(:billno),
          TO_NUMBER(:pageno),
          TO_NUMBER(:lineno),
          :session_id,
          :ubrbill_text   || :chk_digit
        );
  POSTORA;

  /*  If OCR is ever to be used, insert field :scanon_esc_parsed into above
      line.  */

}                                        /* end print_line_41 */

/* ************************************************************************** */
/* turn OCR-A scan line off                                                   */
/* ************************************************************************** */

static void ocra_off(void)
{
            
/* turn ocr-a scan off */

  strcpy(lineno,"42");
  EXEC SQL
   INSERT INTO uimsmgr.ubrbill
        (
        ubrbill_bill_num,
        ubrbill_page_num,
        ubrbill_line_num,
        ubrbill_sess_id,
        ubrbill_text
        )
    VALUES
        (
          TO_NUMBER(:billno),
          TO_NUMBER(:pageno),
          TO_NUMBER(:lineno),
          :session_id,
          ''
         );
  POSTORA;

  /*  If OCR is ever to be used, insert field :scanoff_esc_parsed into above
      line.  */

}                                        /* end ocra_off */

/* ************************************************************************** */
/* insert line 25 into ubrbill collector table                                */
/* ************************************************************************** */
/* customer, premises                                                         */
               
static void print_line_25(void)
{

  strcpy(lineno,"25");
  EXEC SQL
   INSERT INTO uimsmgr.ubrbill
        (
        ubrbill_bill_num,
        ubrbill_page_num,
        ubrbill_line_num,
        ubrbill_sess_id,
        ubrbill_text
        )
    VALUES
        (
          TO_NUMBER(:billno),
          TO_NUMBER(:pageno),
          TO_NUMBER(:lineno),
          :session_id,
          '                               '        ||
          '                               '        ||
          lpad(to_char(TO_NUMBER(:ucracct_cust_code)),9)    ||
          '-'                                      ||
          rpad(:ucracct_prem_code,7)
         );
  POSTORA;
}                                        /* end print_line_25 */

static void print_line_36(void)
{

/* load the bill into the ubrbill-bill collector */
/*                                               */
/* page number                                   */

  strcpy(lineno,"36");
  EXEC SQL
   INSERT INTO uimsmgr.ubrbill
        (
        ubrbill_bill_num,
        ubrbill_page_num,
        ubrbill_line_num,
        ubrbill_sess_id,
        ubrbill_text
        )
   VALUES
        (
        TO_NUMBER(:billno),
        TO_NUMBER(:pageno),
        TO_NUMBER(:lineno),
        :session_id,
        '                                      '||
        lpad(to_char(TO_NUMBER(:ucracct_cust_code)),9)   ||
        '          '                            ||
        decode(:ucbmbil_sub_pymt_ind,
               'N',' ',
               to_char(TO_DATE(
                 decode(:reprint_date_var,
                         null, decode(:deferred_due_date,
                                      null,:due_date,
                                      :deferred_due_date),
                        :uabopen_due_date),
                 'DD-MON-YYYY'),'fmMM/DD/YY'))
        );
  POSTORA;
}                                                /* end print_line_36 */

static void print_line_37(void)
{

/* load the bill into the ubrbill-bill collector */
/*                                               */
/* Prem_Code - Late Amount Due - Amount Due      */

  strcpy(lineno,"37");
  EXEC SQL
   INSERT INTO uimsmgr.ubrbill
        (
        ubrbill_bill_num,
        ubrbill_page_num,
        ubrbill_line_num,
        ubrbill_sess_id,
        ubrbill_text
        )
   VALUES
        (
        TO_NUMBER(:billno),
        TO_NUMBER(:pageno),
        TO_NUMBER(:lineno),
        :session_id,
        '                        '              ||
        '                '                      ||
        lpad(:ucracct_prem_code,7)              ||
        '       '                               ||
        decode(substr(:amount_due,1,1),
        '-',
        nvl(lpad(to_char(ABS(TO_NUMBER(:amount_due)),'999,999.99'),11),0)    ||
        'CR '                                                                ||
        nvl(lpad(to_char(ABS(TO_NUMBER(:amount_due)),'999,999.99'),11),0)    ||
        'CR',
        nvl(lpad(to_char(
                 (1.1 * (TO_NUMBER(:amount_due) - TO_NUMBER(:accumulated_tax))
                     + TO_NUMBER(:accumulated_tax)),
                       '999,999.99'),11),0)                                  ||
        '   '                                                                ||
        nvl(lpad(to_char(TO_NUMBER(:amount_due),'999,999.99'),11),0)
        )
        );
  POSTORA;
}                                                /* end print_line_37 */

static void print_line_39(void)
{

/* load the bill into the ubrbill-bill collector */
/*                                               */
/* Cust_Code - Late Date                         */

  strcpy(lineno,"39");
  EXEC SQL
   INSERT INTO uimsmgr.ubrbill
        (
        ubrbill_bill_num,
        ubrbill_page_num,
        ubrbill_line_num,
        ubrbill_sess_id,
        ubrbill_text
        )
   VALUES
        (
        TO_NUMBER(:billno),
        TO_NUMBER(:pageno),
        TO_NUMBER(:lineno),
        :session_id,
        lpad(to_char(TO_NUMBER(:ucracct_cust_code)),9)      ||
        '     '                                    ||
        decode(:ucbmbil_sub_pymt_ind,
               'N',' ',
               to_char(TO_DATE(
                 decode(:reprint_date_var,
                        null, decode(:deferred_due_date,
                                     null,:due_date,
                                     :deferred_due_date),
                        :uabopen_due_date),
                 'DD-MON-YYYY'),'fmMM/DD/YY'))
        );
  POSTORA;
}                                                /* end print_line_39 */

static void print_line_40(void)
{

/* load the bill into the ubrbill-bill collector */
/*                                               */
/* Prem_Code - Late Amount Due - Amount Due      */

  strcpy(lineno,"40");
  EXEC SQL
   INSERT INTO uimsmgr.ubrbill
        (
        ubrbill_bill_num,
        ubrbill_page_num,
        ubrbill_line_num,
        ubrbill_sess_id,
        ubrbill_text
        )
   VALUES
        (
        TO_NUMBER(:billno),
        TO_NUMBER(:pageno),
        TO_NUMBER(:lineno),
        :session_id,
        '  '                                    ||
        lpad(:ucracct_prem_code,7)              ||
        '  '                                    ||
        decode(substr(:amount_due,1,1),
        '-',
        nvl(lpad(to_char(ABS(TO_NUMBER(:amount_due)),'999,999.99'),11),0)    ||
        'CR '                                                                ||
        nvl(lpad(to_char(ABS(TO_NUMBER(:amount_due)),'999,999.99'),11),0)    ||
        'CR',
        '   '                                                                ||
        nvl(lpad(to_char(
                 (1.1 * (TO_NUMBER(:amount_due) - TO_NUMBER(:accumulated_tax))
                     + TO_NUMBER(:accumulated_tax)),
                       '999,999.99'),11),0)                                  ||
        nvl(lpad(to_char(TO_NUMBER(:amount_due),'999,999.99'),11),0)
        )
        );
  POSTORA;
}                                                /* end print_line_40 */

/* ************************************************************************** */
/* insert line 08 duplicate bill msg into ubrbill collector table             */
/* ************************************************************************** */

static void print_line_08_dupl(void)
{

/* duplicate bill message */

  strcpy(lineno,"8");

  EXEC SQL
   INSERT INTO uimsmgr.ubrbill
        (
        ubrbill_bill_num,
        ubrbill_page_num,
        ubrbill_line_num,
        ubrbill_sess_id,
        ubrbill_text
        )
    VALUES
        (
         TO_NUMBER(:billno),
         TO_NUMBER(:pageno),
         TO_NUMBER(:lineno),
         :session_id,
         'DUPLICATE BILL'
         );
  POSTORA;                   
}                                        /* end print_line_08_dupl */

/* ************************************************************************** */
/* insert line 09 draft msg into ubrbill collector table                     */
/* ************************************************************************** */

static void print_line_09_draft(void)
{

/* bank draft message */
/* This uses line 9, also used by print_line_09_no_pay; bank drafting and
   master bills are mutually exclusive, so a conflict should not occur.  */

  strcpy(lineno,"9");

  EXEC SQL
   INSERT INTO uimsmgr.ubrbill
        (
        ubrbill_bill_num,
        ubrbill_page_num,
        ubrbill_line_num,
        ubrbill_sess_id,
        ubrbill_text
        )
    VALUES
        (                
          TO_NUMBER(:billno),
          TO_NUMBER(:pageno),
          TO_NUMBER(:lineno),
          :session_id,
          'DO NOT PAY - account is being drafted for the amount owed.'
          );
  POSTORA;
}                                        /* end print_line_09_draft */

/* ************************************************************************** */
/* insert line 09 please pay msg into ubrbill collector table                 */
/* ************************************************************************** */

static void print_please_pay_msg(void)
{
  print_line_09_please_pay();
}

static void print_line_09_please_pay(void)
{

/* bank draft message */
/* This uses line 9, also used by print_line_09_no_pay; bank drafting and
   master bills are mutually exclusive, so a conflict should not occur.  */

  strcpy(lineno,"9");

  EXEC SQL
   INSERT INTO uimsmgr.ubrbill
        (
        ubrbill_bill_num,
        ubrbill_page_num,
        ubrbill_line_num,
        ubrbill_sess_id,
        ubrbill_text
        )
    VALUES
        (
          TO_NUMBER(:billno),
          TO_NUMBER(:pageno),
          TO_NUMBER(:lineno),
          :session_id,
          'PLEASE PAY - amount is NOT being drafted.'
          );
  POSTORA;        
}                                        /* end print_line_09_please_pay */

/* ************************************************************************** */
/* insert line 09 no pay msg into ubrbill collector table                     */
/* ************************************************************************** */

static void print_line_09_no_pay(void)
{

/* no payment - master bills message */
/* This uses line 9, also used by print_line_09_draft; bank drafting and
   master bills are mutually exclusive, so a conflict should not occur.  */

  strcpy(lineno,"9");

  EXEC SQL
   INSERT INTO uimsmgr.ubrbill
        (
        ubrbill_bill_num,
        ubrbill_page_num,                                    
        ubrbill_line_num,
        ubrbill_sess_id,
        ubrbill_text
        )
    VALUES
        (
          TO_NUMBER(:billno),
          TO_NUMBER(:pageno),
          TO_NUMBER(:lineno),
          :session_id,
          'Do not pay - summary only.'
          );
  POSTORA;
}                                        /* end print_line_09_no_pay */

/* ************************************************************************** */
/* print detail lines (meter readings, consumption, etc)                      */
/* ************************************************************************** */

static void print_detail_line(void)
{
  if ( compare(line_05_30_lineno,"25",GE) ) {
    line_31_multi();
    strcpy(multi_page_ind,"Y");
    strcpy(line_05_30_lineno,"10");
    add(line_05_30_pageno,line_05_30_pageno,"1");
  }
  EXEC SQL
   INSERT INTO uimsmgr.ubrbill
        (
        ubrbill_bill_num,
        ubrbill_page_num,
        ubrbill_line_num,
        ubrbill_sess_id,
        ubrbill_text
        )
    SELECT
          TO_NUMBER(:billno),
          TO_NUMBER(:line_05_30_pageno),
          TO_NUMBER(:line_05_30_lineno),
          :session_id,
          decode(:uabopen_chrg_calc_num,
                 null,nvl(rpad(utrsrat_bill_print_desc,14),'              '),
             decode(:non_metered_ind,
                 null,rpad(:present_reading,9) ||  :present_date,
                 nvl(rpad(utrsrat_bill_print_desc,14),'              ')))   ||
          lpad(nvl(to_char(TO_NUMBER(:urrshis_dos)),'   '),3)               ||
          lpad(nvl(to_char(TO_NUMBER(:urrshis_consumption)),'        '),8)  ||
          lpad(nvl(:ucrserv_styp_code,'    '),4)                            ||
    decode(substr(:uabopen_billed_chg,1,1),
    '-',
    nvl(lpad(to_char(ABS(TO_NUMBER(:uabopen_billed_chg)),'9999.99'),8),0)    ||
    'CR',
    nvl(lpad(to_char(TO_NUMBER(:uabopen_billed_chg),'9999.99'),8),0)
    )
    FROM uimsmgr.utrsrat
    WHERE utrsrat_srat_code = :uabopen_srat_code
      AND utrsrat_scat_code = :uabopen_scat_code;
  POSTORA;
  add(line_05_30_lineno,line_05_30_lineno,"1");
}                                        /* end print_detail_line */

/* ************************************************************************** */
/* print detail lines (meter readings, consumption, etc)                      */
/* ************************************************************************** */

static void print_detail_line_2(void)
{
  if ( compare(line_05_30_lineno,"25",GE) ) {
    line_31_multi();
    strcpy(multi_page_ind,"Y");
    strcpy(line_05_30_lineno,"10");
    add(line_05_30_pageno,line_05_30_pageno,"1");
  }
  EXEC SQL
   INSERT INTO uimsmgr.ubrbill
        (
        ubrbill_bill_num,
        ubrbill_page_num,
        ubrbill_line_num,
        ubrbill_sess_id,
        ubrbill_text
        )
    SELECT
          TO_NUMBER(:billno),
          TO_NUMBER(:line_05_30_pageno),
          TO_NUMBER(:line_05_30_lineno),
          :session_id,
          decode(:uabopen_chrg_calc_num,
                 null,nvl(rpad(utrsrat_bill_print_desc,14),'              '),
             decode(:non_metered_ind,
                 null,rpad(:present_reading,9) ||  :present_date,
                 nvl(rpad(utrsrat_bill_print_desc,14),'              ')))   ||
       lpad(nvl(to_char(TO_NUMBER(:urrshis_dos)),'   '),3)                  ||
          lpad(nvl(to_char(TO_NUMBER(:urrshis_consumption)),'        '),8)  ||
          lpad(nvl(:ucrserv_styp_code,'    '),4)                            ||
    decode(substr(:uabopen_billed_chg,1,1),
    '-',
    nvl(lpad(to_char(ABS(TO_NUMBER(:uabopen_billed_chg)),'9999.99'),8),0)    ||
    'CR',
    nvl(lpad(to_char(TO_NUMBER(:uabopen_billed_chg),'9999.99'),8),0)
    )
    FROM uimsmgr.utrsrat
    WHERE utrsrat_srat_code = :uabopen_srat_code
      AND utrsrat_scat_code = :uabopen_scat_code;
  POSTORA;
  add(line_05_30_lineno,line_05_30_lineno,"1");
}                                        /* end print_detail_line */

/* ************************************************************************** */
/* print detail lines (meter readings, consumption, etc) for change out       */
/* ************************************************************************** */

static void print_detail_line_change_out_2(void)
{
  if ( compare(line_05_30_lineno,"25",GE) ) {
    strcpy(multi_page_ind,"Y");
    strcpy(line_05_30_lineno,"10");
    add(line_05_30_pageno,line_05_30_pageno,"1");
  }
  EXEC SQL
   INSERT INTO uimsmgr.ubrbill
        (
        ubrbill_bill_num,
        ubrbill_page_num,
        ubrbill_line_num,
        ubrbill_sess_id,
        ubrbill_text
        )
    SELECT
          TO_NUMBER(:billno),
          TO_NUMBER(:line_05_30_pageno),
          TO_NUMBER(:line_05_30_lineno),
          :session_id,
          decode(TO_NUMBER(:uabopen_chrg_calc_num),
                 null,rpad (utrsrat_bill_print_desc,14),
                 decode(:non_metered_ind,
                 null,rpad(:change_out_reading,9) ||
                 :change_out_date,
                 '              '))                                ||
          lpad(nvl(to_char(TO_NUMBER(:change_out_dos)),'   '),3)   ||
          lpad(nvl(to_char(TO_NUMBER(:change_out_cons)),'        '),8)  ||
          lpad(nvl(:ucrserv_styp_code,'    '),4)
    FROM uimsmgr.utrsrat
    WHERE utrsrat_srat_code = :uabopen_srat_code
      AND utrsrat_scat_code = :uabopen_scat_code;
  POSTORA;
  add(line_05_30_lineno,line_05_30_lineno,"1");
}                                       /* end print_detail_line_change_out_2 */

/* ************************************************************************** */
/* print detail lines adjustments                                             */
/* ************************************************************************** */

static void print_detail_line_adjustments(void)
{
  if ( compare(line_05_30_lineno,"25",GE) ) {
    line_31_multi();
    strcpy(multi_page_ind,"Y");
    strcpy(line_05_30_lineno,"10");
    add(line_05_30_pageno,line_05_30_pageno,"1");
  }
  EXEC SQL
   INSERT INTO uimsmgr.ubrbill
        (
        ubrbill_bill_num,
        ubrbill_page_num,
        ubrbill_line_num,
        ubrbill_sess_id,
        ubrbill_text
        )
   SELECT TO_NUMBER(:billno),
          TO_NUMBER(:line_05_30_pageno),
          TO_NUMBER(:line_05_30_lineno),
          :session_id,
          decode(utradjm_desc,null,'              ',
               rpad(utradjm_desc,14)) ||
          lpad(to_char(TO_NUMBER(:uabadje_balance),'9999.99'),23)
     FROM uimsmgr.utradjm
    WHERE utradjm_code = :uabadje_adjm_code;
  POSTORA;
  add(line_05_30_lineno,line_05_30_lineno,"1");
}                                        /* end print_detail_line_adjustments */

/* ************************************************************************** */
/* print lines 05 thru 30 - text and dollar amount                            */
/* ************************************************************************** */

static void print_line_05_30_text(void)
{
  if ( compare(line_05_30_lineno,"25",GE) ) {
    line_31_multi();
    strcpy(multi_page_ind,"Y");
    strcpy(line_05_30_lineno,"10");
    add(line_05_30_pageno,line_05_30_pageno,"1");
  }
  line_05_30_text();
  add(line_05_30_lineno,line_05_30_lineno,"1");
}                                        /* end print_line_05_30_text */

/* ************************************************************************** */
/* print bank draft messages                                                  */
/* ************************************************************************** */

static void print_draft_next_month_msg(void)
{
  if ( compare(line_05_30_lineno,"25",GE) ) {
    line_31_multi();
    strcpy(multi_page_ind,"Y");
    strcpy(line_05_30_lineno,"10");
    add(line_05_30_pageno,line_05_30_pageno,"1");
  }
  EXEC SQL
   INSERT INTO uimsmgr.ubrbill
        (
        ubrbill_bill_num,
        ubrbill_page_num,
        ubrbill_line_num,
        ubrbill_sess_id,
        ubrbill_text
        )
    VALUES
        (
         TO_NUMBER(:billno),
         TO_NUMBER(:line_05_30_pageno),
         TO_NUMBER(:line_05_30_lineno),
         :session_id,
         'Automatic account drafting will begin next month'
        );                      
  POSTORA;
  add(line_05_30_lineno,line_05_30_lineno,"1");
}                                        /* end print_draft_next_month_msg */

static void print_draft_msg(void)
{

  print_line_09_draft();

  if ( compare(line_05_30_lineno,"25",GE) ) {
    line_31_multi();
    strcpy(multi_page_ind,"Y");
    strcpy(line_05_30_lineno,"10");
    add(line_05_30_pageno,line_05_30_pageno,"1");
  }
  EXEC SQL
   INSERT INTO uimsmgr.ubrbill
        (
        ubrbill_bill_num,
        ubrbill_page_num,
        ubrbill_line_num,
        ubrbill_sess_id,
        ubrbill_text
        )
    VALUES
        (
         TO_NUMBER(:billno),
         TO_NUMBER(:line_05_30_pageno),
         TO_NUMBER(:line_05_30_lineno),
         :session_id,
         'Amount will be drafted on / around ' ||
         DECODE(:reprint_date_var,
                NULL, DECODE(:deferred_due_date,
                             NULL,TO_CHAR(TO_DATE(:due_date,'DD-MON-YYYY')
                                          - to_number(:uobsysc_days_draft),
                                          'DD-MON-YYYY'),
                             TO_CHAR(TO_DATE(:deferred_due_date,'DD-MON-YYYY')
                                     - to_number(:uobsysc_days_draft),
                                     'DD-MON-YYYY')),
                TO_CHAR(TO_DATE(:uabopen_due_date,'DD-MON-YYYY')
                        - to_number(:uobsysc_days_draft),
                        'DD-MON-YYYY'))
        );
  POSTORA;
  add(line_05_30_lineno,line_05_30_lineno,"1");
}                                        /* end print_draft_msg */

/* ************************************************************************** */
/* print roundup total for a year                                             */
/* ************************************************************************** */

static void print_rdup(void)
{
  if ( compare(line_05_30_lineno,"25",GE) ) {
    line_31_multi();
    strcpy(multi_page_ind,"Y"); 
    strcpy(line_05_30_lineno,"10");
    add(line_05_30_pageno,line_05_30_pageno,"1");
  }
  EXEC SQL
   INSERT INTO uimsmgr.ubrbill
        (
        ubrbill_bill_num,
        ubrbill_page_num,
        ubrbill_line_num,
        ubrbill_sess_id,
        ubrbill_text
        )
    VALUES
        (
         TO_NUMBER(:billno),
         TO_NUMBER(:line_05_30_pageno),
         TO_NUMBER(:line_05_30_lineno),
         :session_id,
         'Total Round Up Contributions for ' ||
         :year_vbg ||
         ' year: ' ||
         TO_CHAR(TO_NUMBER(:total_roundup),'999,999.99') ||
         '   Total Paid: ' ||
         TO_CHAR(TO_NUMBER(:total_roundup_paid),'999,999.99')
        );
  POSTORA;
  add(line_05_30_lineno,line_05_30_lineno,"1");
}                                        /* end print_rdup */


/* ************************************************************************** */
/* print a blank line                                                         */
/* ************************************************************************** */

static void print_blank_line(void)
{
  if ( compare(line_05_30_lineno,"25",GE) ) {
    line_31_multi();
    strcpy(multi_page_ind,"Y");
    strcpy(line_05_30_lineno,"10");
    add(line_05_30_pageno,line_05_30_pageno,"1");
  }
  insert_blank_line();
  add(line_05_30_lineno,line_05_30_lineno,"1");
}

/* ******************************************************************* */
/* insert line 5, 6, 7 into ubrbill collector table                    */
/* system-wide, customer-specific, or account-specific bill message    */
/* ******************************************************************* */


static void print_line_5_7(void)
{

  strcpy(lineno,"5");

/* insert system bill message */

  if ( *bill_message_code && compare(system_bmsg_option,"A",NES) ) {
    /*  .SET lineno 5 */
    strcpy(bmsg_code,bill_message_code);
    line_5_7();
    add(lineno,lineno,"1");
    insert_blank_line_2();
    add(lineno,lineno,"1");
  }

/* insert customer-specific message */

  if ( *ucbcust_bmsg_code ) {
    /*    .SET lineno 6 */
    strcpy(bmsg_code,ucbcust_bmsg_code);
    line_5_7();
    add(lineno,lineno,"1");
    insert_blank_line_2();
    add(lineno,lineno,"1");
  }

/* insert account-specific message */

  if ( *ucracct_bmsg_code && compare(system_bmsg_option,"S",NES) ) {
    /*    .SET lineno 7 */
    strcpy(bmsg_code,ucracct_bmsg_code);
    line_5_7();
    add(lineno,lineno,"1");
    insert_blank_line_2();
    add(lineno,lineno,"1");
  }

}                                        /* end print_line_5_7 */

static void line_5_7(void)
{
  EXEC SQL
   INSERT INTO uimsmgr.ubrbill
        (
        ubrbill_bill_num,
        ubrbill_page_num,
        ubrbill_line_num,
        ubrbill_sess_id,
        ubrbill_text
        )
   SELECT
          TO_NUMBER(:billno),
          TO_NUMBER(:pageno),
          TO_NUMBER(:lineno),
          :session_id,
          '          ' ||
          utvbmsg_message_text
     FROM uimsmgr.utvbmsg
    WHERE utvbmsg_code = :bmsg_code;
  POSTORA;
}                                        /* end line_5_7 */
