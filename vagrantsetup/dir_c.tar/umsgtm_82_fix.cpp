/* AUDIT TRAIL: 8.0                                                         */
/* TAM 10/08/2007                                                           */
/* 1. Internationalization unicode conversion                               */
/* AUDIT TRAIL: 8.1.0.1                                                     */
/* TAM 03/10/2009                                                           */
/* 1. Corrected nested comment. It was causing a compile warning on VMS.    */
/* TAM 04/02/2009                                                           */
/* 1. Added VMS specific override code via #if #else directives.            */
/*                                                                          */
/* 8.2 Paper Fix Version of tmcilib.cpp                                     */
/*       includes fixes for defect 1-40WK37 and 1-4EEY5P                    */
/*                                                                          */
/* AUDIT TRAIL END                                                          */
/*
*******************************************************************************
*
*   Copyright (C) 2001, International Business Machines
*   Corporation and others.  All Rights Reserved.
*
*******************************************************************************
*   file name:  umsgtm.cpp, based on ICU 3.6 umsg.cpp
*   encoding:   US-ASCII
*   tab size:   8 (not used)
*   indentation:4
*
*   Compatible with ICU 3.6
*/

#include "unicode/umsg.h"
#include "unicode/ustring.h"
#include "unicode/fmtable.h"
#include "cpputils.h"
#include "uassert.h"
#include "unicode/msgfmt.h"
#include "unicode/unistr.h"

#include "umsgtm.h"
#include "msgfmttm.h"

U_NAMESPACE_USE

// locale aware version needed here, after ICU removed it
int32_t
u_vsnprintf_loc_u(UChar *buffer,
				  int32_t         count,
				  const char      *locale,
				  const UChar     *patternSpecification,
				  va_list         ap) 
{
	int32_t numchars;
	UFILE* fl=u_fstropen(buffer,count,locale);
	numchars=u_vfprintf_u(fl,patternSpecification,ap);
	u_fclose(fl);
	return numchars;
}


//forward declaration
U_CAPI UMessageFormat* U_EXPORT2
tmumsg_open(const UChar     *pattern,
            int32_t         patternLength,
            const  char     *locale,
            UParseError     *parseError,
            UErrorCode      *status);

U_CAPI void U_EXPORT2
tmumsg_close(UMessageFormat* format);

//implementation of TM variants

U_CAPI int32_t U_EXPORT2
tmu_vformatMessage( const char  *locale,
                    const TMCHAR *pattern,
                    int32_t     patternLength,
                    TMCHAR      *result,
                    int32_t     resultLength,
                    va_list     ap,
                    UErrorCode  *status)

{
    //argument checking defered to subsequent method calls
#ifdef _TMUNICODE
    UMessageFormat *fmt = tmumsg_open(pattern,patternLength,locale,NULL,status);
    int32_t retVal = tmumsg_vformat(fmt,result,resultLength,ap,status);
    tmumsg_close(fmt);
#else
    UChar* upat;
    if (patternLength==-1)
        patternLength=strlen(pattern);
    upat=(UChar*) malloc(sizeof(UChar)*(patternLength+1));
    u_uastrcpy( upat,pattern);
    UMessageFormat *fmt = tmumsg_open(upat,patternLength,locale,NULL,status);
    int32_t retVal = tmumsg_vformat(fmt,result,resultLength,ap,status);
    tmumsg_close(fmt);
    if (upat)
        free(upat);
#endif

    return retVal;
}


U_CAPI UMessageFormat* U_EXPORT2
tmumsg_open(const UChar     *pattern,
            int32_t         patternLength,
            const  char     *locale,
            UParseError     *parseError,
            UErrorCode      *status)
{
    //check arguments
    if(status==NULL || U_FAILURE(*status))
    {
      return 0;
    }
    if(pattern==NULL||patternLength<-1){
        *status=U_ILLEGAL_ARGUMENT_ERROR;
        return 0;
    }
    UParseError tErr;

    if(!parseError)
    {
        parseError = &tErr;
    }

    UMessageFormat* retVal = 0;

    int32_t len = (patternLength == -1 ? u_strlen(pattern) : patternLength);

	// This is not commented in ICU3.6
    //UnicodeString patString((patternLength == -1 ? TRUE:FALSE), pattern,len);

    retVal = (UMessageFormat*) new MessageFormatTM(pattern,Locale(locale),*parseError,*status);
    if(retVal == 0) {
        *status = U_MEMORY_ALLOCATION_ERROR;
        return 0;
    }
    return retVal;
}

U_CAPI void U_EXPORT2
tmumsg_close(UMessageFormat* format)
{
    //check arguments
    if(format==NULL){
        return;
    }
    delete (MessageFormatTM*) format;
}

//no equivalent needed for umsg_clone
//no equivalent needed for umsg_setLocale
//no equivalent needed for umsg_getLocale
//no equivalent needed for umsg_applyPattern
//no equivalent needed for umsg_toPattern
//no equivalent needed for umsg_format

/*
Helper function fixArgPtr for tmumsg_vformat 
adjust the argument ptr according to the ansi pattern in pat
input	pat: single printf specifier starting with % and ending with the type specifier
result	aptr points to the next argument

*/

/* cannot use a va_list * in RedHat AS 4, update 4 64-bit gcc 3.4.6-3 
   move fixArgPtr code into main  loop tmumsg_vformat for argument retrieval
*/


#ifdef OPSYS_VMS
// modified copy from umsg.cpp
U_NAMESPACE_BEGIN
/**
 * This class isolates our access to private internal methods of
 * MessageFormat.  It is never instantiated; it exists only for C++
 * access management.
 */
class MessageFormatAdapter {
public:
    static const Formattable::Type* getArgTypeListTM(const MessageFormat& m,
                                                   int32_t& count);
};
const Formattable::Type*
MessageFormatAdapter::getArgTypeListTM(const MessageFormat& m,
                                     int32_t& count) {
    return m.getArgTypeList(count);
}
U_NAMESPACE_END
#else
// literal copy from umsg.cpp
U_NAMESPACE_BEGIN
/**
 * This class isolates our access to private internal methods of
 * MessageFormat.  It is never instantiated; it exists only for C++
 * access management.
 */
class MessageFormatAdapter {
public:
    static const Formattable::Type* getArgTypeList(const MessageFormat& m,
                                                   int32_t& count);
};
const Formattable::Type*
MessageFormatAdapter::getArgTypeList(const MessageFormat& m,
                                     int32_t& count) {
    return m.getArgTypeList(count);
}
U_NAMESPACE_END
#endif


//modified copy from umsg.cpp
U_CAPI int32_t U_EXPORT2
tmumsg_vformat( UMessageFormat *fmt,
                TMCHAR         *result,
                int32_t        resultLength,
                va_list        ap,
                UErrorCode     *status)
{
    UChar uargbuff[2048]; //HVT: a buffer to store a formatted argument
    if(status==0 || U_FAILURE(*status))
    {
      return -1;
    }
    if(fmt==NULL||resultLength<0 || (resultLength>0 && result==0)) {
        *status=U_ILLEGAL_ARGUMENT_ERROR;
        return -1;
    }

    int32_t count =0;
#ifdef OPSYS_VMS
    const Formattable::Type* argTypes =
        MessageFormatAdapter::getArgTypeListTM(*(MessageFormatTM*)fmt, count);
#else
    const Formattable::Type* argTypes =
        MessageFormatAdapter::getArgTypeList(*(MessageFormatTM*)fmt, count);
#endif
    // Allocate at least one element.  Allocating an array of length
    // zero causes problems on some platforms (e.g. Win32).
    Formattable* args = new Formattable[count ? count : 1];

    // iterate through the vararg list, and get the arguments out
    for(int32_t i = 0; i < count; ++i) {
        TMCHAR *stringVal;
        double tDouble=0;
        int32_t tInt =0;
        int64_t tInt64 = 0;
        UDate tempDate = 0;
        switch(argTypes[i]) {
        case Formattable::kDate:
            tempDate = va_arg(ap, UDate);
            args[i].setDate(tempDate);
            break;

        case Formattable::kDouble:
            tDouble =va_arg(ap, double);
            args[i].setDouble(tDouble);
            break;

        case Formattable::kLong:
            tInt = va_arg(ap, int32_t);
            args[i].setLong(tInt);
            break;

        case Formattable::kInt64:
            tInt64 = va_arg(ap, int64_t);
            args[i].setInt64(tInt64);
            break;
         
        case Formattable::kString:
            // For some reason, a temporary is needed
            stringVal = va_arg(ap, TMCHAR*);
            if(stringVal){
                args[i].setString(stringVal);
            }else{
                *status=U_ILLEGAL_ARGUMENT_ERROR;
            }
            break;
            
        case Formattable::kObject:
            // This will never happen because MessageFormat doesn't
            // support kObject.  When MessageFormat is changed to
            // understand MeasureFormats, modify this code to do the
            // right thing. [alan]
            U_ASSERT(FALSE);
            break;
            
        // better not happen!
		case Formattable::kArray:
			U_ASSERT(FALSE);
			break;
		case FormattableTM::kAnsiPattern: //HVT added this to add ansi pattern support
			{
				int ch;
				const TMCHAR *pat=((MessageFormatTM*)fmt)->getAnsiPattern(i)->getTerminatedBuffer();
				u_vsnprintf_loc_u(
					uargbuff,
					sizeof(uargbuff)/sizeof(uargbuff[0])-1,
					((MessageFormatTM*)fmt)->getLocale().getName(),
					pat,
					ap
					);
				args[i].setString(uargbuff);

/* 
   SCB8.0 Next section (fixArgPtr) causes segmentation errors and garbage to be printed in some environments
   Issue is known to occur with Red Hat 64.
   Without this section MS Visual C++ generated executable coredump.
   It will be executed by default to make it compatible with previous releases.
   To disable section define _NOFIXARGPTR
*/
#if !defined(_NOFIXARGPTR) 
				for (ch=0; pat[ch]!=0;ch++){
					if (pat[ch]=='*')
						va_arg(ap, int);
				}
				switch(pat[ch-1]) {
				case 'c':
				case 'C': // ICU UChar
				case 'd':
				case 'i':
				case 'o':
				case 'x':
				case 'X':
				case 'u':
					va_arg(ap, int);
					break;
				case 's':
				//case 'U': // old u_printf 
				case 'S':
					va_arg(ap, UChar*);
					break;
				case 'p':
					va_arg(ap, void*);
					break;
				case 'f':
				case 'e':
				case 'E':
				case 'g':
				case 'G':
					va_arg(ap, double);
					break;
				default:
					break;
				}
#endif
			}
			// End copy code
			break;
		}
    }
    UnicodeString resultStr;
    FieldPosition fieldPosition(0);

    /* format the message */
    ((const MessageFormatTM*)fmt)->format(args,count,resultStr,fieldPosition,*status);
    
    //delete added, was in ICU3.6
    delete[] args;

    if(U_FAILURE(*status)){
        return -1;
    }
#ifdef _TMUNICODE
    return resultStr.extract(result, resultLength, *status);
#else
	//return result in system default codepage
	return resultStr.extract(0,resultLength,result, resultLength);
#endif

}
