/*TMCI18N BEGIN HEADER*/
#if !defined( _TMBGUAERROR_H_EXISTS )
/* No Initialisation Required */                                               
#include "tmcilib.h"
static struct TMBundle _TMBGUAERROR_H = {"guaerror.h",NULL,NULL,NULL,NULL};
#define _TMBGUAERROR_H_EXISTS
#endif
/*TMCI18N END HEADER*/

/* AUDIT_TRAIL_MSGKEY_UPDATE
-- PROJECT : MSGKEY
-- MODULE  : GUAERROR
-- SOURCE  : enUS
-- TARGET  : I18N
-- DATE    : Fri Mar 20 13:22:57 2015
-- MSGSIGN : #a7e1fc0a46e3013f
END AUDIT_TRAIL_MSGKEY_UPDATE */

/* AUDIT_TRAIL_SCB
-- Solution Centre Baseline 
-- PROJECT : BAN74c
-- MODULE  : GUAERROR
-- SOURCE  : enUS
-- TARGET  : I18N
-- DATE    : Mon Mar 19 12:47:05 2007
END AUDIT_TRAIL_SCB */
/* Object: guaerror.h
   Author: John Morgan
 Mod Date: 12/5/94
  Release: General 2.1
*/

/***************************************************/
/*                                                 */
/*       CONFIDENTIAL BUSINESS INFORMATION         */
/*                                                 */
/*      **********************************         */
/*                                                 */
/*  THIS PROGRAM IS PROPRIETARY INFORMATION OF     */
/* SYSTEMS AND COMPUTER TECHNOLOGY CORPORATION     */
/* AND IS NOT TO BE COPIED, REPRODUCED, LENT OR    */
/* DISPOSED OF, NOR USED FOR ANY PURPOSE OTHER     */
/* THAN THAT FOR WHICH IT IS SPECIFICALLY PROVIDED */
/* WITHOUT THE WRITTEN PERMISSION OF SAID COMPANY  */
/*                                                 */
/***************************************************/

/* AUDIT TRAIL: 2.1                                INIT      DATE           */
/*                                                                          */
/* 1. Changed ERR messages to ERM since ERR is      JWM    11/21/94         */
/*    a reserved word under DG AOS.                                         */
/* 2. Moved a couple of messages to the generic     JWM    12/05/94         */
/*    section in preparation for guasrpk.c.                                 */
/* 3. Made LONGTOK a warning instead of an error.   JWM    12/06/94         */
/*                                                                          */
/* AUDIT TRAIL: 2.1.5                              INIT      DATE           */
/*                                                                          */
/* 1. New ORACLE error message handling.            JWM    08/16/95         */
/* 2. New message for chkcflag/setcflag.            JWM    08/17/95         */
/*                                                                          */
/* AUDIT TRAIL: 8.0                                                         */
/* TAM 10/08/2007                                                           */
/* 1. Internationalization unicode conversion                               */
/*                                                                          */
/* AUDIT TRAIL: 8.8                                                         */
/* 1. CR-000125282                                                          */
/*    JDC 03/20/2015                                                        */
/*    Ran re-key to ensure G$_NLS calls were properly coded                 */
/* AUDIT TRAIL END                                                          */

/* This header file is included once in by any compilation unit which needs
   to call the prtmsg function in guastdf.c, in order to create an
   enumeration list of error codes and a separate enumeration of message
   types.  In order to create the actual array of structures, called msg,
   which contains pointers to error message formats and other information
   about each message, guastdf.c includes this file twice.  This method
   greatly simplifies modifying the error table.
*/

#ifndef _GUAERROR_H_

/* Message types */

enum {MSG,   /* informational messages */
      WRN,   /* warning messages - no exit from program */
      ERM};  /* error messages */

/* format: DTAB(code,code_string,type,string)

   where
      code        - 7-char mnemonic for the message
      code_string - string version of code - this wouldn't be necessary
                    if VAX C supported the expansion of # in a macro
      type        - message type (from enumeration above)
      string      - valid printf style format of the message
*/

#define DTAB(c1,c2,t,s) c1,

enum {

#else
#define DTAB(c1,c2,t,s) {c2,t,s},

static struct {TMCHAR *code;
               int type;
               TMCHAR *text;} msg[]={

#endif

/* generic messages */

DTAB(PRGOPEN,NULL,0,NULL)    /* used to reset flags */
DTAB(PRGCLOS,NULL,0,NULL)    /* used to signal that program is closing */
DTAB(CMPNORM,_TMC("CMPNORM"),MSG,TM_NLS_HGet( &_TMBGUAERROR_H, "0000","{0} completed successfully"))
DTAB(CMPWARN,_TMC("CMPWARN"),MSG,TM_NLS_HGet( &_TMBGUAERROR_H, "0001","{0} completed with warning(s)"))
DTAB(CMPERRO,_TMC("CMPERRO"),MSG,TM_NLS_HGet( &_TMBGUAERROR_H, "0002","{0} terminated with error"))
DTAB(LINSOUT,_TMC("LINSOUT"),MSG,TM_NLS_HGet( &_TMBGUAERROR_H, "0003","{0,%lu} lines written to {1}"))
DTAB(IOERROR,_TMC("IOERROR"),ERM,TM_NLS_HGet( &_TMBGUAERROR_H, "0004","I/O error on file {0}"))

/* messages used by functions in guarpfe.h */

DTAB(LONGLIT,_TMC("LONGLIT"),WRN,TM_NLS_HGet( &_TMBGUAERROR_H, "0005","Column literal width ({0,number,integer}) exceeds column width ({1,number,integer})"))
DTAB(MULTTAB,_TMC("MULTTAB"),WRN,TM_NLS_HGet( &_TMBGUAERROR_H, "0006","Table {0,number,integer} is multiply defined"))
DTAB(LONGTOK,_TMC("LONGTOK"),WRN,TM_NLS_HGet( &_TMBGUAERROR_H, "0007","Token \"{0}\" exceeds containing column width ({1,number,integer})"))
DTAB(BADTABN,_TMC("BADTABN"),ERM,TM_NLS_HGet( &_TMBGUAERROR_H, "0008","Invalid table number ({0,number,integer})"))
DTAB(BADCEND,_TMC("BADCEND"),ERM,TM_NLS_HGet( &_TMBGUAERROR_H, "0009","Column end ({0,number,integer}) exceeds maximum position of 255"))
DTAB(BADCSKA,_TMC("BADCSKA"),ERM,TM_NLS_HGet( &_TMBGUAERROR_H, "0010","Illegal argument to colskip function"))
DTAB(BADCDEF,_TMC("BADCDEF"),ERM,TM_NLS_HGet( &_TMBGUAERROR_H, "0011","Bad column definition in table {0,number,integer}"))
DTAB(BADFLAG,_TMC("BADFLAG"),ERM,TM_NLS_HGet( &_TMBGUAERROR_H, "0012","Illegal argument to {0} function"))
DTAB(BADINDA,_TMC("BADINDA"),ERM,TM_NLS_HGet( &_TMBGUAERROR_H, "0013","Illegal argument to indent function"))
DTAB(BADJUSA,_TMC("BADJUSA"),ERM,TM_NLS_HGet( &_TMBGUAERROR_H, "0014","Illegal argument to justify function"))
DTAB(BADPGFA,_TMC("BADPGFA"),ERM,TM_NLS_HGet( &_TMBGUAERROR_H, "0015","Illegal argument to pgformat function"))
DTAB(BADPGNA,_TMC("BADPGNA"),ERM,TM_NLS_HGet( &_TMBGUAERROR_H, "0016","Illegal argument to pgnum function"))
DTAB(BADPGNP,_TMC("BADPGNP"),ERM,TM_NLS_HGet( &_TMBGUAERROR_H, "0017","Illegal page number position: must be in range 1 to 250"))
DTAB(BADPGNT,_TMC("BADPGNT"),ERM,TM_NLS_HGet( &_TMBGUAERROR_H, "0018","Illegal page number type: must be in range 1 to 4"))
DTAB(BADSETA,_TMC("BADSETA"),ERM,TM_NLS_HGet( &_TMBGUAERROR_H, "0019","Illegal argument to setmode function"))
DTAB(BADSKPA,_TMC("BADSKPA"),ERM,TM_NLS_HGet( &_TMBGUAERROR_H, "0020","Illegal argument to skipline function"))
DTAB(BADTABA,_TMC("BADTABA"),ERM,TM_NLS_HGet( &_TMBGUAERROR_H, "0021","Illegal argument to table function"))
DTAB(BADTTLW,_TMC("BADTTLW"),ERM,_TMC("\"{0,number,integer}\" is an illegal title width"))
DTAB(EXTRATE,_TMC("EXTRATE"),ERM,TM_NLS_HGet( &_TMBGUAERROR_H, "0022","Unmatched call to table(T_END)"))
DTAB(LONGCEN,_TMC("LONGCEN"),ERM,TM_NLS_HGet( &_TMBGUAERROR_H, "0023","Centered text too long for column width ({0,number,integer})"))
DTAB(LONGHDR,_TMC("LONGHDR"),ERM,TM_NLS_HGet( &_TMBGUAERROR_H, "0024","Page header longer than page length"))
DTAB(LONGIND,_TMC("LONGIND"),ERM,TM_NLS_HGet( &_TMBGUAERROR_H, "0025","Indent value ({0,number,integer}) exceeds column width"))
DTAB(LONGPAR,_TMC("LONGPAR"),ERM,TM_NLS_HGet( &_TMBGUAERROR_H, "0026","Column width ({0,number,integer}) too small for paragraph indent"))
DTAB(LONGTAB,_TMC("LONGTAB"),ERM,TM_NLS_HGet( &_TMBGUAERROR_H, "0027","Table width exceeds containing column width"))
DTAB(LONGTTL,_TMC("LONGTTL"),ERM,TM_NLS_HGet( &_TMBGUAERROR_H, "0028","Title is longer than specified width"))
DTAB(NOCLTRM,_TMC("NOCLTRM"),ERM,TM_NLS_HGet( &_TMBGUAERROR_H, "0029","Missing termination for column literal mode"))
DTAB(NOCOLMS,_TMC("NOCOLMS"),ERM,TM_NLS_HGet( &_TMBGUAERROR_H, "0030","Table must contain at least one column"))
DTAB(NOLTTRM,_TMC("NOLTTRM"),ERM,TM_NLS_HGet( &_TMBGUAERROR_H, "0031","Missing termination for literal mode"))
DTAB(NOMEMOR,_TMC("NOMEMOR"),ERM,TM_NLS_HGet( &_TMBGUAERROR_H, "0032","Memory exhausted -- needed {0,%u} bytes"))
DTAB(NONLITC,_TMC("NONLITC"),ERM,TM_NLS_HGet( &_TMBGUAERROR_H, "0033","\"{0}\" not valid while in literal mode"))
DTAB(NONLITS,_TMC("NONLITS"),ERM,TM_NLS_HGet( &_TMBGUAERROR_H, "0034","Only setmode(M_NORMAL) valid while in literal mode"))
DTAB(UNDFTAB,_TMC("UNDFTAB"),ERM,TM_NLS_HGet( &_TMBGUAERROR_H, "0035","Unable to begin table {0,number,integer} - table is undefined"))

/* messages used by functions in guastdf.h  */

DTAB(LONGINP,_TMC("LONGINP"),MSG,TM_NLS_HGet( &_TMBGUAERROR_H, "0036","Input longer than receiving field - reenter"))
DTAB(BADNUMB,_TMC("BADNUMB"),MSG,TM_NLS_HGet( &_TMBGUAERROR_H, "0037","Invalid number - reenter"))
DTAB(BADDECN,_TMC("BADDECN"),ERM,TM_NLS_HGet( &_TMBGUAERROR_H, "0038","Invalid argument '{0,number,integer}' to round function"))
DTAB(OVERFLW,_TMC("OVERFLW"),ERM,TM_NLS_HGet( &_TMBGUAERROR_H, "0039","Arithmetic overflow"))
DTAB(ZERODIV,_TMC("ZERODIV"),ERM,TM_NLS_HGet( &_TMBGUAERROR_H, "0040","Division by zero"))

/* messages used by functions in guaorac.c */

DTAB(CONNECT,_TMC("CONNECT"),MSG,TM_NLS_HGet( &_TMBGUAERROR_H, "0041","Connected."))
DTAB(NOLOGIN,_TMC("NOLOGIN"),ERM,TM_NLS_HGet( &_TMBGUAERROR_H, "0042","Unable to CONNECT to ORACLE after {0,number,integer} attempts"))
DTAB(ERRSTMT,_TMC("ERRSTMT"),WRN,TM_NLS_HGet( &_TMBGUAERROR_H, "0043","Following statement was last statement parsed:\n    {0}"))
DTAB(ORACERR,_TMC("ORACERR"),WRN,TM_NLS_HGet( &_TMBGUAERROR_H, "0044","Error occurred in file \"{0}\" at line {1,%ld}"))

/* messages used by guaprpf.c (standalone RPF emulator */

DTAB(RPFNIMP,_TMC("RPFNIMP"),ERM,TM_NLS_HGet( &_TMBGUAERROR_H, "0045","{0,%ld}: RPF command '{1}' not implemented"))
DTAB(MISSARG,_TMC("MISSARG"),ERM,TM_NLS_HGet( &_TMBGUAERROR_H, "0046","{0,%ld}: Required argument to RPF command '#{1}' not found"))
DTAB(MISTERM,_TMC("MISTERM"),ERM,TM_NLS_HGet( &_TMBGUAERROR_H, "0047","{0,%ld}: RPF command '{1}' not terminated"))
DTAB(NONPOSI,_TMC("NONPOSI"),ERM,TM_NLS_HGet( &_TMBGUAERROR_H, "0048","{0,%ld}: RPF argument '{1}' is not a positive integer"))
#undef DTAB

#ifndef _GUAERROR_H_
END_ERROR_TAB};
#define _GUAERROR_H_
#else
{NULL,0,NULL}};
#endif
