/*UnicodeSedFixed*/
/*TMCI18N BEGIN HEADER*/
#if !defined( tmBundle_EXISTS )
/* No Initialisation Required */                                               
#include "tmcilib.h"
static struct TMBundle tmBundle = {"guaslp2.c",NULL,NULL,NULL,NULL};
#define tmBundle_EXISTS
#endif
/*TMCI18N END HEADER*/

/* AUDIT_TRAIL_TM63
-- TranMan 6.3 
-- PROJECT : HEGDE_I18N
-- MODULE  : GUASLP2
-- SOURCE  : enUS
-- TARGET  : I18N
-- DATE    : Mon Nov 05 11:28:14 2007
END AUDIT_TRAIL_TM63 */

/* audit trail: 2.0                                  INIT   DATE */
/* 1. Create copylib for sleep/wake processes        SRS  06/23/93 */
/* audit trail: 2.1                                  INIT   DATE */
/* 1. Cast the strlen to int in buildcom.             TM   09/22/93 */
/* 2. Changed initsleep: Old logic was to search     SRS  10/12/94 */
/* was to search for a "running" row for a process/printer combination. */
/* Unfortuantely, that condition was also used to determine whether a new */
/* row should be inserted for that process/printer. New logic searchs for */
/* a row for that process/printer, return a 1 if it was found and was */
/* currently executingj.  Only if a row was not found will one be inserted, */
/* otherwise update the existing row. */
/* 3. Changed all functions using session id to retrieve SRS 02/09/95 */
/*    session id at the start.  */
/* audit trail: 5.2                                                         */
/* 1. Defect #32189                                  XL  04/12/01           */
/*  Title.....clean the lint errors                                         */
/*  Solutions.change the declaration of kount from int to long,             */
/*            take out int cast before function strlen.                     */
/*            ignore the warning                                            */
/*            "prototype for function sleep is not in scopt"                */
/*            we can use                                                    */ 
/*            extern unsigned int sleep(unsigned int);                      */
/*            to remove warning, but changing the prototype only works in   */
/*            UNIX. It will fail in NT.                                     */ 
/*                                                                          */
/* audit trail: 8.0                                                         */
/* audit trail end                                                          */

#ifndef NO_SLEEP_SW

/* sleep prototypes */

static void buildcom(TMCHAR *st);
static void resetsleep(int status);
static int initsleep();
static int sleepwake();

/* build print command and include file */

static void buildcom(TMCHAR *st)
{
 int kount;
 /* defect 32189
 int kount2;
 */
 long int kount2;
 static TMCHAR oldprintcom[260]={0}/*TMCI18N CHANGED FROM ""*/;
 TMCHAR builtcom[260];

/* find the printer command string */

 if ( tmstrlen(oldprintcom) == 0 )
  {
   exec sql select gtvprnt_printer_command
	    into :printcom
	    from general.gtvprnt
	    where gtvprnt_code=:printer;
   POSTORA;
   tmstrcpy(oldprintcom,printcom);
  }
 else
  {
   tmstrcpy(printcom,oldprintcom);
  }

/* replace @ with filename */

/* 2.1 # 1 */
/* defect 32189
 for (kount=0,kount2=0;kount<(int)strlen(printcom);kount++)
*/
 for (kount=0,kount2=0;kount<tmstrlen(printcom);kount++)
  {
   if (st[kount] == '@')
    {
     tmstrcat(builtcom,outputfile);
     kount2=tmstrlen(builtcom);
     builtcom[kount2]='\0';
    }
   else
    {
     builtcom[kount2]=printcom[kount];
     builtcom[kount2+1]='\0';
     kount2+=1;
    }
  }
  tmstrcpy(st,builtcom);
}

/* set the continue and abnormal indicators when the process ends */

static void resetsleep(int status)
{
 status=status;
 if ( compare(abnormalexit,_TMC("Y"),EQS) )
  {
   exec sql rollback work;
   POSTORA;
  }
 exec sql select userenv('sessionid')
	      into :session_id
              from sys.dual;
 POSTORA;
 exec sql update general.gjrswpt set gjrswpt_continue_ind='N',
	  gjrswpt_next_execution=null,
          gjrswpt_activity_date=sysdate,gjrswpt_error_ind=:abnormalexit
          where gjrswpt_session_id=:session_id;
 POSTORA;
 exec sql commit work release;
 POSTORA;

}


static int initsleep()
{

/* does process already have a row; if so is it already running?
                          runsw=0, not running
                          runsw=1, running
			  runsw=3, no row exists
			  runsw=4, no printer command string found
*/

 exec sql select userenv('sessionid')
          into :session_id
          from sys.dual;
 POSTORA;
 exec sql select gtvprnt_printer_command
	    into :printcom
            from general.gtvprnt
           where gtvprnt_code=:printer;
 POSTORA;
 if ( (sqlca.sqlcode == 1403) || (tmstrlen(printcom) == 0) )
  {
   runsw=4;
   return(4);
  }

 exec sql select decode(gjrswpt_continue_ind,'Y',1,'N',0,2),
	  decode(gjrswpt_next_execution,null,'0','1')
	  into :runsw,:nextsw from general.gjrswpt
          where gjrswpt_process=:rptname
          and gjrswpt_printer=:printer;
 POSTORA;

/* see if row does not exist */

 if (sqlca.sqlcode == 1403)
  {
   runsw=3;
  }
 if (runsw == 1)
  {
   return(1);
  }

/* if the row does not exist, insert one.  Otherwise, update the row. */

 if (runsw == 3)
  {
   exec sql insert into general.gjrswpt(gjrswpt_process, gjrswpt_printer,
	    gjrswpt_current_interval, gjrswpt_next_interval,
	    gjrswpt_interval_count, gjrswpt_last_execution,
            gjrswpt_cumulative_count, gjrswpt_continue_ind,
            gjrswpt_error_ind,gjrswpt_session_id,
	    gjrswpt_next_execution, gjrswpt_activity_date)
	    values(:rptname,:printer,:current_interval,
	    :next_interval,0,sysdate,0,'Y','N',:session_id,
	    null,sysdate );
   POSTORA;
  }
 else
  {
   exec sql update general.gjrswpt set
	    gjrswpt_current_interval=:current_interval,
	    gjrswpt_next_interval=:next_interval,
	    gjrswpt_interval_count=0, gjrswpt_cumulative_count=0,
	    gjrswpt_continue_ind='Y',
            gjrswpt_error_ind='N',gjrswpt_session_id=:session_id,
	    gjrswpt_last_execution=sysdate,
	    gjrswpt_next_execution=null,
	    gjrswpt_activity_date=sysdate
            where gjrswpt_process=:rptname
            and gjrswpt_printer=:printer;
   POSTORA;
  }

 exec sql commit work;
 POSTORA;

 return(0);
}

static int sleepwake()
{

 exec sql select userenv('sessionid')
          into :session_id
          from sys.dual;
 POSTORA;

/* see if the process should sleep; if so, how long to sleep. */

 exec sql select gjrswpt_next_interval,
	  decode(gjrswpt_continue_ind,'Y',1,'N',0,0)
	  into :next_interval,:runsw
          from general.gjrswpt
          where gjrswpt_session_id=:session_id;
 POSTORA;

/* see if row does not exist */

 if (sqlca.sqlcode == 1403)
  {
   return(1);
  }

/* reset the interval if necessary */

 if (next_interval != current_interval && runsw == 1)
  {
   current_interval=next_interval;
   exec sql update general.gjrswpt set
	    gjrswpt_current_interval=:current_interval,
	    gjrswpt_activity_date=sysdate
            where gjrswpt_session_id=:session_id;
   POSTORA;
   exec sql commit work;
   POSTORA;
  }

/* sleep and return 0, or simply return a 1 */

 if (runsw == 1)
  {
   exec sql update general.gjrswpt set
	    gjrswpt_next_execution=(sysdate + (:current_interval/24/60/60)),
	    gjrswpt_activity_date=sysdate
            where gjrswpt_session_id=:session_id;
   POSTORA;
   exec sql commit work;
   POSTORA;

   sleep(current_interval);
   exec sql update general.gjrswpt set
	    gjrswpt_next_execution=null,
	    gjrswpt_activity_date=sysdate
            where gjrswpt_session_id=:session_id;
   POSTORA;
   exec sql commit work;
   POSTORA;
   return(0);
  }
 else
  {
   return(1);
  }

}
#endif
