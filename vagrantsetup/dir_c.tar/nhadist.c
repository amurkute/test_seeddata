/*TMCI18N BEGIN HEADER*/
#if !defined( _TMBNHADIST_C_EXISTS )
/* No Initialisation Required */                                               
#include "tmcilib.h"
static struct TMBundle _TMBNHADIST_C = {"nhadist.c",NULL,NULL,NULL,NULL};
#define _TMBNHADIST_C_EXISTS
#endif
#define tmBundle _TMBNHADIST_C
/*TMCI18N END HEADER*/

/* AUDIT_TRAIL_MSGKEY_UPDATE
-- PROJECT : MSGKEY
-- MODULE  : NHADIST
-- SOURCE  : enUS
-- TARGET  : I18N
-- DATE    : Fri Mar 20 13:22:54 2015
-- MSGSIGN : #b5c685a9bdf6a1c4
END AUDIT_TRAIL_MSGKEY_UPDATE */

/* AUDIT_TRAIL_TM63
-- TranMan 6.3 
-- PROJECT : PVV_TEST
-- MODULE  : NHADIST
-- SOURCE  : enUS
-- TARGET  : I18N
-- DATE    : Tue Nov 06 06:31:50 2007
END AUDIT_TRAIL_TM63 */
/* Copyright 2015 Ellucian Company L.P. and its affiliates.                 */
/* nhadist.c Include File for Salary Distribution Reports                   */

/*  AUDIT TRAIL:  2.0.10                                                    */
/*                                                                          */
/*  1. Initial Coding                                     KM   11-11-94     */
/*  ---------------------------------------------------  ----  --------     */
/* AUDIT TRAIL: 2.1.5 Supplemental                            CFIX  09/09/95  */
/* 1. Program modified by cfix.c to remedy mostly Pro*C related problems:     */
/*    split SQL concatenations joined, colons added to FETCH targets,         */
/*    file extensions added to SQL INCLUDEs, 'static' modifier removed from   */
/*    indicator variables, new logic to hadle CLOSE_CURSOR was added to SQL   */
/*    function wrappers, and object owner references were removed as part of  */
/*    BANNER2.1.  (Not all changes necessarily apply.)                        */
/*   AUDIT TRAIL: 3.1                                      GK   02-19-98
   1. Year2000 Compliance 
      Technical Modification - Removed Add_19, Add_20 routines. 
      Added dateconv(parm_date) to convert DD-MON-YY to DD-MON-YYYY
      date format.                                                           
   AUDIT TRAIL: 6.1
   1. Defect# 85295                                     MT 12/24/2003
      Problem : Report abort with the Oracle error message.
      Functional Impact: Parameters are now accepted only when they are in
              valid format. Otherwise process prints an error message in the 
              log file.
      Technical Fix : Modified retr_home_parms and retr_coas_parms_body 
    AUDIT TRAIL: 7.0
    1. Changes Migrated to Release 7.0           MT 03/15/2004
       Defect# 85295  Release 6.1
    AUDIT TRAIL: 8.0
    1. Enhancement to Grants Management Multi Year Encumbrance  LA 09/20/2007
       Added the validation to following Grant parameters:
          par_grnt_option
          par_grnt_form
          par_grnt_to
          par_grnt
       Added the logic to following procedures:
          ins_par_grnt_code(void)
          ins_grnt_option(void)
          ins_grnt_range(void)
          ins_grnt_code(void)
          ins_grnt_s(void)
    AUDIT TRAIL: 8.8
    1. CR-000125282
       JDC 03/20/2015
       Ran re-key to ensure G$_NLS calls were properly coded
 AUDIT TRAIL END */

static void get_parameters(void)
{

	tmprintf(&tmBundle, _TMC("* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *\n"));
	tmprintf(&tmBundle, _TMC(" \n"));
	tmprintf(&tmBundle, TM_NLS_Get("0000","Parameters for the {0} ({1}) \n "),title_var,rptname );
	tmprintf(&tmBundle, _TMC(" \n"));
	tmprintf(&tmBundle, _TMC("* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *\n"));

	tmprintf(&tmBundle, _TMC(" \n"));
input(par_one_up_no,TM_NLS_Get("0001"," Enter Parameter Sequence Number --------> "),26,NUM);
	if ( !*par_one_up_no ) goto gen_one_up_no_lbl;
	tmstrcpy(valid_ind,_TMC("N"));
        tmstrcpy(reenter_parm,_TMC("N"));
	validate_one_up_no(FIRST_ROW);
	if ( compare(valid_ind,_TMC("Y"),EQS) ) goto retrieve_parms_lbl;
	goto no_parms;
retrieve_parms_lbl:
	del_colr();
	retrieve_parms(); 
        return;

gen_one_up_no_lbl:
	gen_one_up_no(FIRST_ROW);

   
begin_parameters:
        tmstrcpy(par_from,_TMC("O"));
	tmstrcpy(parm_ind,_TMC("N"));
	del_colr();
	tmprintf(&tmBundle, _TMC(" \n"));
if (compare(rptname,_TMC("NHRDIST"),EQS))
{ 
get_report_type:
input(par_report_type,TM_NLS_Get("0002"," Select Report type  (D)etail, (S)ummary --Default D ------> "),1,ALPHA);
	if ( !*par_report_type) 
              tmstrcpy(par_report_type,_TMC("D"));
        str2uc(par_report_type);
	if (inlist(par_report_type,ALPHA,_TMC("D"),_TMC("S"),NULL) ) goto get_sort;
	else goto get_report_type;
}
get_sort:
	tmprintf(&tmBundle, _TMC(" \n"));
	tmprintf(&tmBundle, TM_NLS_Get("0003"," Select Sort Option                        \n"));
	tmprintf(&tmBundle, _TMC(" \n"));
	tmprintf(&tmBundle, TM_NLS_Get("0004","  Sort By Home Organization ------------------------>   H\n"));
	tmprintf(&tmBundle, _TMC(" \n"));
	tmprintf(&tmBundle, TM_NLS_Get("0005","  Sort By FOAPAL Distribution Organization --------->   D\n"));
	tmprintf(&tmBundle, _TMC(" \n"));
	tmprintf(&tmBundle, TM_NLS_Get("0006","  Default : D\n"));
	tmprintf(&tmBundle, _TMC(" \n"));

input(par_sort_option,TM_NLS_Get("0007"," Sort Option (H,D)  ---------> "),1,ALPHA);
	tmprintf(&tmBundle, _TMC(" \n"));
	if ( !*par_sort_option ) tmstrcpy(par_sort_option,_TMC("D"));
        str2uc(par_sort_option);
	if ( inlist(par_sort_option,ALPHA,_TMC("H"),_TMC("D"),NULL) ) goto get_begin_date;
	else goto get_sort;

get_begin_date:

    tmprintf(&tmBundle, _TMC(" \n"));
input(par_begin_date,TM_NLS_Get("0008"," Begin Date ---(DD-MON-YYYY)---> "),11,ALPHA);
    tmprintf(&tmBundle, _TMC(" \n"));

    if ( !*par_begin_date ) goto missing_parm;

    tmprintf(&tmBundle, _TMC(" \n"));
input(par_end_date,TM_NLS_Get("0009"," End Date ----(DD-MON-YYYY)------> "),11,ALPHA);
    tmprintf(&tmBundle, _TMC(" \n"));

    if ( !*par_end_date ) goto missing_parm;

  get_pict_code:
    tmstrcpy(parm_ind,_TMC("N"));
    tmstrcpy(all_pict,_TMC("N"));

    tmprintf(&tmBundle, TM_NLS_Get("0010","  (Just Hit Enter for All Pay IDs)  \n"));
    tmprintf(&tmBundle, TM_NLS_Get("0011","  (Can Use % as wildcard character)  \n"));
  ask_pict_code:
input(par_pict,TM_NLS_Get("0012"," Pay ID Code --------------(XX)-----> "),2,ALPHA);
    tmprintf(&tmBundle, _TMC(" \n"));
   

   if ((!*par_pict) && (compare(parm_ind,_TMC("N"),EQS)))
     {
           tmstrcpy(all_pict,_TMC("Y"));
           goto get_hier;
	 }

    tmstrcpy(parm_ind,_TMC("Y"));
    if ( !*par_pict ) goto get_hier;
    ins_pict_code();
    goto ask_pict_code;
 
 
get_hier:
	tmprintf(&tmBundle, _TMC(" \n"));
	tmprintf(&tmBundle, TM_NLS_Get("0013"," Select Hierarchy Option                   \n"));
	tmprintf(&tmBundle, _TMC(" \n"));
	tmprintf(&tmBundle, TM_NLS_Get("0014","  FOAP As Exists ---------------------------->   E\n"));
	tmprintf(&tmBundle, _TMC(" \n"));
	tmprintf(&tmBundle, TM_NLS_Get("0015","  Roll Upto Specific FOAP Fields ------------>   F\n"));
	tmprintf(&tmBundle, _TMC(" \n"));
	tmprintf(&tmBundle, TM_NLS_Get("0016","  Roll Upto Specific FOAP Levels ------------>   L\n"));
	tmprintf(&tmBundle, _TMC(" \n"));

	tmprintf(&tmBundle, TM_NLS_Get("0017","  Default : E\n"));
	tmprintf(&tmBundle, _TMC(" \n"));

input(par_hier,TM_NLS_Get("0018"," Hierarchy (E,F,L)  ---------> "),1,ALPHA);
	tmprintf(&tmBundle, _TMC(" \n"));
	if ( !*par_hier ) tmstrcpy(par_hier,_TMC("E"));
        str2uc(par_hier);
	if ( inlist(par_hier,ALPHA,_TMC("E"),_TMC("F"),_TMC("L"),NULL) ) goto get_levels;
	else goto get_hier;

get_levels:
     if (compare(par_hier,_TMC("L"),EQS))
 {
get_fund_level:
tmprintf(&tmBundle, TM_NLS_Get("0019","\n  Level Parameters - E refers to as (E)xists \n "));
input(par_fund_level,TM_NLS_Get("0020"," Roll To Fund Level (E,1,2,3,4,5)----Default 1---> "),1,ALPHA);
	tmprintf(&tmBundle, _TMC(" \n"));
	if ( !*par_fund_level ) tmstrcpy(par_fund_level,_TMC("1"));
        str2uc(par_fund_level);
	if ( inlist(par_fund_level,ALPHA,_TMC("E"),_TMC("1"),_TMC("2"),_TMC("3"),_TMC("4"),_TMC("5"),NULL) ) goto get_orgn_level;
	else goto get_fund_level;

get_orgn_level:
input(par_orgn_level,TM_NLS_Get("0021"," Roll To Orgn Level (E,1,2,3,4,5,6,7,8)----Default 1---> "),1,ALPHA);
	tmprintf(&tmBundle, _TMC(" \n"));
	if ( !*par_orgn_level ) tmstrcpy(par_orgn_level,_TMC("1"));
        str2uc(par_orgn_level);
	if ( inlist(par_orgn_level,ALPHA,_TMC("E"),_TMC("1"),_TMC("2"),_TMC("3"),_TMC("4"),_TMC("5"),_TMC("6"),_TMC("7"),_TMC("8"),NULL) ) goto get_acct_level;
	else goto get_orgn_level;

get_acct_level:
input(par_acct_level,TM_NLS_Get("0022"," Roll To Acct Level (E,1,2,3,4,5)----Default 1---> "),1,ALPHA);
	tmprintf(&tmBundle, _TMC(" \n"));
	if ( !*par_acct_level ) tmstrcpy(par_acct_level,_TMC("1"));
        str2uc(par_acct_level);
	if ( inlist(par_acct_level,ALPHA,_TMC("E"),_TMC("1"),_TMC("2"),_TMC("3"),_TMC("4"),_TMC("5"),NULL) ) goto get_prog_level;
	else goto get_acct_level;

get_prog_level:
input(par_prog_level,TM_NLS_Get("0023"," Roll To Prog Level (E,1,2,3,4,5)----Default 1---> "),1,ALPHA);
	tmprintf(&tmBundle, _TMC(" \n"));
	if ( !*par_prog_level ) tmstrcpy(par_prog_level,_TMC("1"));
        str2uc(par_prog_level);
if (inlist(par_prog_level,ALPHA,_TMC("E"),_TMC("1"),_TMC("2"),_TMC("3"),_TMC("4"),_TMC("5"),NULL) ) goto get_coas_code;
	else goto get_prog_level;

}

get_coas_code:
   validate_dates();
if (compare(are_parameters_valid,TM_NLS_Get("0024","NO"),EQS)) goto end_parameters;

g_coas:
if (compare(par_sort_option,_TMC("H"),EQS)) 
  {
    input(par_home_coas,TM_NLS_Get("0025"," Home Orgn Chart Of Accounts ----(X)--> "),1,ALPHA);
   str2uc(par_home_coas);
 if (*par_home_coas) get_home_orgn();
if (compare(are_parameters_valid,TM_NLS_Get("0026","NO"),EQS)) goto end_parameters ;
  }

    input(par_coas,TM_NLS_Get("0027"," Chart Of Accounts ----(X)--> "),1,ALPHA);
   if (!*par_coas) goto missing_parm;
   str2uc(par_coas);
   ins_coas_code();
 do
	 {



if (compare(par_sort_option,_TMC("H"),EQS))
  if (!*par_home_coas) get_home_orgn();

if (compare(are_parameters_valid,TM_NLS_Get("0028","NO"),EQS)) goto end_parameters ;


chk_hier:
if (compare(par_hier,_TMC("L"),EQS)) goto more_coas;

  if (compare(par_hier,_TMC("F"),EQS))
    {

input(par_grnt,TM_NLS_Get("0029"," Specific Grant to Roll to (XXXXX), Optional---> "),9,ALPHA);
  tmprintf(&tmBundle, _TMC(" \n"));
 str2uc(par_grnt);
 ins_grnt_s();
     	
input(par_fund,TM_NLS_Get("0030"," Specific Fund to Roll to (XXXXX), Optional---> "),6,ALPHA);
  tmprintf(&tmBundle, _TMC(" \n"));
 str2uc(par_fund);
 ins_fund_s();
 
input(par_orgn,TM_NLS_Get("0031"," Specific Orgn to Roll to (XXXXX), Optional---> "),6,ALPHA);
  tmprintf(&tmBundle, _TMC(" \n"));
 str2uc(par_orgn);
 ins_orgn_s();
input(par_acct,TM_NLS_Get("0032"," Specific Acct to Roll to (XXXXX), Optional---> "),6,ALPHA);
  tmprintf(&tmBundle, _TMC(" \n"));
 str2uc(par_acct);
 ins_acct_s();

input(par_prog,TM_NLS_Get("0033"," Specific Prog to Roll to (XXXXX), Optional---> "),6,ALPHA);
  tmprintf(&tmBundle, _TMC(" \n"));
 str2uc(par_prog);
 ins_prog_s();
   
}

if (compare(par_hier,_TMC("E"),EQS))
  {

get_grnt_option:
   if (compare(rptname,_TMC("NHRDIST"),EQS))
   {
	tmprintf(&tmBundle, _TMC(" \n"));
	tmprintf(&tmBundle, TM_NLS_Get("0034"," Grant Options                        \n"));
	tmprintf(&tmBundle, _TMC(" \n"));
	tmprintf(&tmBundle, TM_NLS_Get("0035","  All Grant --------------------------------->   A\n"));
	tmprintf(&tmBundle, _TMC(" \n"));
	tmprintf(&tmBundle, TM_NLS_Get("0036","  Range of Grant ---------------------------->   R\n"));
	tmprintf(&tmBundle, _TMC(" \n"));
	tmprintf(&tmBundle, TM_NLS_Get("0037","  Wildcard Grant ---------------------------->   W\n"));
	tmprintf(&tmBundle, _TMC(" \n"));
	tmprintf(&tmBundle, TM_NLS_Get("0038","  Specific Grant ---------------------------->   S\n"));
	tmprintf(&tmBundle, _TMC(" \n"));

	tmprintf(&tmBundle, TM_NLS_Get("0039","  Default : A\n"));
	tmprintf(&tmBundle, _TMC(" \n"));

  input(par_grnt_option,TM_NLS_Get("0040"," Grant Options -----(A,R,W,S)---------> "),1,ALPHA);
	tmprintf(&tmBundle, _TMC(" \n"));
	if ( !*par_grnt_option ) tmstrcpy(par_grnt_option,_TMC("A"));
        str2uc(par_grnt_option);
  if ( inlist(par_grnt_option,ALPHA,_TMC("A"),_TMC("R"),_TMC("S"),_TMC("W"),NULL) ) goto get_grnt;
	else goto get_grnt_option;

  get_grnt:

  ins_grnt_option();

  if (compare(par_grnt_option,_TMC("R"),EQS))
  {
   input(par_grnt_from,TM_NLS_Get("0041"," From Grant -----------(XXXXXX)-------> "),9,ALPHA);
	 tmprintf(&tmBundle, _TMC(" \n"));
	 if ( !*par_grnt_from ) goto missing_parm;
     input(par_grnt_to,TM_NLS_Get("0042"," To Grant   -----------(XXXXXX)-------> "),9,ALPHA);
	 tmprintf(&tmBundle, _TMC(" \n"));
	 if ( !*par_grnt_to ) goto missing_parm;
     ins_grnt_range();
   ins_coas_parm(par_grnt_from_no,par_grnt_from);
   ins_coas_parm(par_grnt_to_no,par_grnt_to);
  }
  if (compare(par_grnt_option,_TMC("W"),EQS))
  {
    tmstrcpy(parm_ind,_TMC("N"));
    tmprintf(&tmBundle, TM_NLS_Get("0043","  (Can Use % as wildcard character)  \n"));
    ask_grnt:
    input(par_grnt,TM_NLS_Get("0044"," Grant ---------------------(XXXXXX)-> "),9,ALPHA);
    tmprintf(&tmBundle, _TMC(" \n"));
    tmstrcpy(parm_ind,_TMC("Y"));
    if ( !*par_grnt ) goto get_fund_option;
     ins_grnt_code();
    goto ask_grnt;
  }
  if (compare(par_grnt_option,_TMC("S"),EQS))
  {
    tmstrcpy(parm_ind,_TMC("N"));
    ask_grnt_s:
    input(par_grnt,TM_NLS_Get("0045"," Grant ---------------------(XXXXXX)-> "),9,ALPHA);
    tmprintf(&tmBundle, _TMC(" \n"));
   
    tmstrcpy(parm_ind,_TMC("Y"));
    if ( !*par_grnt ) goto get_fund_option;
    ins_grnt_s();
    goto ask_grnt_s;
  }
 }

get_fund_option:
	tmprintf(&tmBundle, _TMC(" \n"));
	tmprintf(&tmBundle, TM_NLS_Get("0046"," Fund Options                        \n"));
	tmprintf(&tmBundle, _TMC(" \n"));
	tmprintf(&tmBundle, TM_NLS_Get("0047","  All Funds --------------------------------->   A\n"));
	tmprintf(&tmBundle, _TMC(" \n"));
	tmprintf(&tmBundle, TM_NLS_Get("0048","  Range of Funds ---------------------------->   R\n"));
	tmprintf(&tmBundle, _TMC(" \n"));
	tmprintf(&tmBundle, TM_NLS_Get("0049","  Wildcard Funds ---------------------------->   W\n"));
	tmprintf(&tmBundle, _TMC(" \n"));
	tmprintf(&tmBundle, TM_NLS_Get("0050","  Specific Fund ----------------------------->   S\n"));
	tmprintf(&tmBundle, _TMC(" \n"));

	tmprintf(&tmBundle, TM_NLS_Get("0051","  Default : A\n"));
	tmprintf(&tmBundle, _TMC(" \n"));

input(par_fund_option,TM_NLS_Get("0052"," Fund Options -----(A,R,W,S)---------> "),1,ALPHA);
	tmprintf(&tmBundle, _TMC(" \n"));
	if ( !*par_fund_option ) tmstrcpy(par_fund_option,_TMC("A"));
        str2uc(par_fund_option);
 if ( inlist(par_fund_option,ALPHA,_TMC("A"),_TMC("R"),_TMC("S"),_TMC("W"),NULL) ) goto get_fund;
	else goto get_fund_option;

  get_fund:

 ins_fund_option();

if (compare(par_fund_option,_TMC("R"),EQS))
  {
input(par_fund_from,TM_NLS_Get("0053"," From Fund -----------(XXXXXX)-------> "),6,ALPHA);
	tmprintf(&tmBundle, _TMC(" \n"));
	if ( !*par_fund_from ) goto missing_parm;
input(par_fund_to,  TM_NLS_Get("0054"," To Fund   -----------(XXXXXX)-------> "),6,ALPHA);
	tmprintf(&tmBundle, _TMC(" \n"));
	if ( !*par_fund_to ) goto missing_parm;
ins_fund_range();
 ins_coas_parm(par_fund_from_no,par_fund_from);
 ins_coas_parm(par_fund_to_no,par_fund_to);
}
if (compare(par_fund_option,_TMC("W"),EQS))
  {
    tmstrcpy(parm_ind,_TMC("N"));

    tmprintf(&tmBundle, TM_NLS_Get("0055","  (Can Use % as wildcard character)  \n"));
  ask_fund:
    input(par_fund,TM_NLS_Get("0056"," Fund ---------------------(XXXXXX)-> "),6,ALPHA);
    tmprintf(&tmBundle, _TMC(" \n"));
   
    tmstrcpy(parm_ind,_TMC("Y"));
    if ( !*par_fund ) goto get_orgn_option;
    ins_fund_code();
    goto ask_fund;
  }
if (compare(par_fund_option,_TMC("S"),EQS))
  {
    tmstrcpy(parm_ind,_TMC("N"));

  ask_fund_s:
    input(par_fund,TM_NLS_Get("0057"," Fund ---------------------(XXXXXX)-> "),6,ALPHA);
    tmprintf(&tmBundle, _TMC(" \n"));
   
    tmstrcpy(parm_ind,_TMC("Y"));
    if ( !*par_fund ) goto get_orgn_option;
    ins_fund_s();
    goto ask_fund_s;
  }
 

get_orgn_option:
	tmprintf(&tmBundle, _TMC(" \n"));
	tmprintf(&tmBundle, TM_NLS_Get("0058"," Orgn Options                        \n"));
	tmprintf(&tmBundle, _TMC(" \n"));
	tmprintf(&tmBundle, TM_NLS_Get("0059","  All Orgns --------------------------------->   A\n"));
	tmprintf(&tmBundle, _TMC(" \n"));
	tmprintf(&tmBundle, TM_NLS_Get("0060","  Range of Orgns ---------------------------->   R\n"));
	tmprintf(&tmBundle, _TMC(" \n"));
	tmprintf(&tmBundle, TM_NLS_Get("0061","  Wildcard Orgns ---------------------------->   W\n"));
	tmprintf(&tmBundle, _TMC(" \n"));
	tmprintf(&tmBundle, TM_NLS_Get("0062","  Specific Orgn ----------------------------->   S\n"));
	tmprintf(&tmBundle, _TMC(" \n"));

	tmprintf(&tmBundle, TM_NLS_Get("0063","  Default : A\n"));
	tmprintf(&tmBundle, _TMC(" \n"));

input(par_orgn_option,TM_NLS_Get("0064"," Orgn Options -----(A,R,W,S)---------> "),1,ALPHA);
	tmprintf(&tmBundle, _TMC(" \n"));
	if ( !*par_orgn_option ) tmstrcpy(par_orgn_option,_TMC("A"));
        str2uc(par_orgn_option);
	if ( inlist(par_orgn_option,ALPHA,_TMC("A"),_TMC("R"),_TMC("S"),_TMC("W"),NULL) ) goto get_orgn;
	else goto get_orgn_option;

  get_orgn:

 ins_orgn_option();

if (compare(par_orgn_option,_TMC("R"),EQS))
  {
input(par_orgn_from,TM_NLS_Get("0065"," From Orgn -----------(XXXXXX)-------> "),6,ALPHA);
	tmprintf(&tmBundle, _TMC(" \n"));
	if ( !*par_orgn_from ) goto missing_parm;
input(par_orgn_to,TM_NLS_Get("0066"," To Orgn   -----------(XXXXXX)-------> "),6,ALPHA);
	tmprintf(&tmBundle, _TMC(" \n"));
	if ( !*par_orgn_to ) goto missing_parm;
ins_orgn_range();
 ins_coas_parm(par_orgn_from_no,par_orgn_from);
 ins_coas_parm(par_orgn_to_no,par_orgn_to);

}
if (compare(par_orgn_option,_TMC("W"),EQS))
  {
    tmstrcpy(parm_ind,_TMC("N"));

    tmprintf(&tmBundle, TM_NLS_Get("0067","  (Can Use % as wildcard character)  \n"));
  ask_orgn:
    input(par_orgn,TM_NLS_Get("0068"," Orgn ---------------------(XXXXXX)-> "),6,ALPHA);
    tmprintf(&tmBundle, _TMC(" \n"));
   
    tmstrcpy(parm_ind,_TMC("Y"));
    if ( !*par_orgn ) goto get_acct_option;
    ins_orgn_code();
    goto ask_orgn;
  }
if (compare(par_orgn_option,_TMC("S"),EQS))
  {
    tmstrcpy(parm_ind,_TMC("N"));

  ask_orgn_s:
    input(par_orgn,TM_NLS_Get("0069"," Orgn ---------------------(XXXXXX)-> "),6,ALPHA);
    tmprintf(&tmBundle, _TMC(" \n"));
   
    tmstrcpy(parm_ind,_TMC("Y"));
    if ( !*par_orgn ) goto get_acct_option;
    ins_orgn_s();
    goto ask_orgn_s;
  }


get_acct_option:
	tmprintf(&tmBundle, _TMC(" \n"));
	tmprintf(&tmBundle, TM_NLS_Get("0070"," Acct Options                        \n"));
	tmprintf(&tmBundle, _TMC(" \n"));
	tmprintf(&tmBundle, TM_NLS_Get("0071","  All Accts --------------------------------->   A\n"));
	tmprintf(&tmBundle, _TMC(" \n"));
	tmprintf(&tmBundle, TM_NLS_Get("0072","  Range of Accts ---------------------------->   R\n"));
	tmprintf(&tmBundle, _TMC(" \n"));
	tmprintf(&tmBundle, TM_NLS_Get("0073","  Wildcard Accts ---------------------------->   W\n"));
	tmprintf(&tmBundle, _TMC(" \n"));
	tmprintf(&tmBundle, TM_NLS_Get("0074","  Specific Acct ----------------------------->   S\n"));
	tmprintf(&tmBundle, _TMC(" \n"));

	tmprintf(&tmBundle, TM_NLS_Get("0075","  Default : A\n"));
	tmprintf(&tmBundle, _TMC(" \n"));

input(par_acct_option,TM_NLS_Get("0076"," Acct Options -----(A,R,W,S)---------> "),1,ALPHA);
	tmprintf(&tmBundle, _TMC(" \n"));
	if ( !*par_acct_option ) tmstrcpy(par_acct_option,_TMC("A"));
        str2uc(par_acct_option);
	if ( inlist(par_acct_option,ALPHA,_TMC("A"),_TMC("R"),_TMC("S"),_TMC("W"),NULL) ) goto get_acct;
	else goto get_acct_option;

  get_acct:

 ins_acct_option();

if (compare(par_acct_option,_TMC("R"),EQS))
  {
input(par_acct_from,TM_NLS_Get("0077"," From Acct -----------(XXXXXX)-------> "),6,ALPHA);
	tmprintf(&tmBundle, _TMC(" \n"));
	if ( !*par_acct_from ) goto missing_parm;
input(par_acct_to,TM_NLS_Get("0078"," To Acct   -----------(XXXXXX)-------> "),6,ALPHA);
	tmprintf(&tmBundle, _TMC(" \n"));
	if ( !*par_acct_to ) goto missing_parm;
ins_acct_range();
 ins_coas_parm(par_acct_from_no,par_acct_from);
 ins_coas_parm(par_acct_to_no,par_acct_to);

}
if (compare(par_acct_option,_TMC("W"),EQS))
  {
    tmstrcpy(parm_ind,_TMC("N"));

    tmprintf(&tmBundle, TM_NLS_Get("0079","  (Can Use % as wildcard character)  \n"));
  ask_acct:
    input(par_acct,TM_NLS_Get("0080"," Acct ---------------------(XXXXXX)-> "),6,ALPHA);
    tmprintf(&tmBundle, _TMC(" \n"));
   
    tmstrcpy(parm_ind,_TMC("Y"));
    if ( !*par_acct ) goto get_prog_option;
    ins_acct_code();
    goto ask_acct;
  }
if (compare(par_acct_option,_TMC("S"),EQS))
  {
    tmstrcpy(parm_ind,_TMC("N"));

  ask_acct_s:
    input(par_acct,TM_NLS_Get("0081"," Acct ---------------------(XXXXXX)-> "),6,ALPHA);
    tmprintf(&tmBundle, _TMC(" \n"));
   
    tmstrcpy(parm_ind,_TMC("Y"));
    if ( !*par_acct ) goto get_prog_option;
    ins_acct_code();
    goto ask_acct_s;
  }



get_prog_option:
	tmprintf(&tmBundle, _TMC(" \n"));
	tmprintf(&tmBundle, TM_NLS_Get("0082"," Prog Options                        \n"));
	tmprintf(&tmBundle, _TMC(" \n"));
	tmprintf(&tmBundle, TM_NLS_Get("0083","  All Progs --------------------------------->   A\n"));
	tmprintf(&tmBundle, _TMC(" \n"));
	tmprintf(&tmBundle, TM_NLS_Get("0084","  Range of Progs ---------------------------->   R\n"));
	tmprintf(&tmBundle, _TMC(" \n"));
	tmprintf(&tmBundle, TM_NLS_Get("0085","  Wildcard Progs ---------------------------->   W\n"));
	tmprintf(&tmBundle, _TMC(" \n"));
	tmprintf(&tmBundle, TM_NLS_Get("0086","  Specific Prog ----------------------------->   S\n"));
	tmprintf(&tmBundle, _TMC(" \n"));

	tmprintf(&tmBundle, TM_NLS_Get("0087","  Default : A\n"));
	tmprintf(&tmBundle, _TMC(" \n"));

input(par_prog_option,TM_NLS_Get("0088"," Prog Options -----(A,R,S,W)---------> "),1,ALPHA);
	tmprintf(&tmBundle, _TMC(" \n"));
	if ( !*par_prog_option ) tmstrcpy(par_prog_option,_TMC("A"));
        str2uc(par_prog_option);
	if ( inlist(par_prog_option,ALPHA,_TMC("A"),_TMC("R"),_TMC("S"),_TMC("W"),NULL) ) goto get_prog;
	else goto get_prog_option;

  get_prog:

 ins_prog_option();

if (compare(par_prog_option,_TMC("R"),EQS))
  {
input(par_prog_from,TM_NLS_Get("0089"," From Prog -----------(XXXXXX)-------> "),6,ALPHA);
	tmprintf(&tmBundle, _TMC(" \n"));
	if ( !*par_prog_from ) goto missing_parm;
input(par_prog_to,TM_NLS_Get("0090"," To Prog   -----------(XXXXXX)-------> "),6,ALPHA);
	tmprintf(&tmBundle, _TMC(" \n"));
	if ( !*par_prog_to ) goto missing_parm;
ins_prog_range();
 ins_coas_parm(par_prog_from_no,par_prog_from);
 ins_coas_parm(par_prog_to_no,par_prog_to);

}
if (compare(par_prog_option,_TMC("W"),EQS))
  {
    tmstrcpy(parm_ind,_TMC("N"));

    tmprintf(&tmBundle, TM_NLS_Get("0091","  (Can Use % as wildcard character)  \n"));
  ask_prog:
    input(par_prog,TM_NLS_Get("0092"," Prog ---------------------(XXXXXX)-> "),6,ALPHA);
    tmprintf(&tmBundle, _TMC(" \n"));
   
    tmstrcpy(parm_ind,_TMC("Y"));
    if ( !*par_prog ) goto more_coas;
    ins_prog_code();
    goto ask_prog;
  }

if (compare(par_prog_option,_TMC("S"),EQS))
  {
    tmstrcpy(parm_ind,_TMC("N"));

  ask_prog_s:
    input(par_prog,TM_NLS_Get("0093"," Prog ---------------------(XXXXXX)-> "),6,ALPHA);
    tmprintf(&tmBundle, _TMC(" \n"));
   
    tmstrcpy(parm_ind,_TMC("Y"));
    if ( !*par_prog ) goto more_coas;
    ins_prog_s();
    goto ask_prog_s;
  }

  }

more_coas:
    input(par_coas,TM_NLS_Get("0094"," Chart Of Accounts ----(X)--> "),1,ALPHA);
    tmprintf(&tmBundle, _TMC("\n"));
   str2uc(par_coas);
if (*par_coas)   ins_coas_code();
	 }while (*par_coas);

  get_ecls_code:
    tmstrcpy(parm_ind,_TMC("N"));
    tmstrcpy(all_ecls,_TMC("N"));

    tmprintf(&tmBundle, TM_NLS_Get("0095","  (Just Hit Enter for All Employee Classes)  \n"));
    tmprintf(&tmBundle, TM_NLS_Get("0096","  (Can Use % as wildcard character)  \n"));
  ask_ecls_code:
    input(par_ecls,TM_NLS_Get("0097"," ECLS Code --------------(XX)-----> "),2,ALPHA);
    tmprintf(&tmBundle, _TMC(" \n"));
   

   if ((!*par_ecls) && (compare(parm_ind,_TMC("N"),EQS)))
     {
           tmstrcpy(all_ecls,_TMC("Y"));
           goto get_empl_id;
	 }

    tmstrcpy(parm_ind,_TMC("Y"));
    if ( !*par_ecls ) goto get_empl_id;
    ins_ecls_code();
    goto ask_ecls_code;
 
get_empl_id:

    tmstrcpy(parm_ind,_TMC("N"));
    tmstrcpy(all_empl,_TMC("N"));

    tmprintf(&tmBundle, TM_NLS_Get("0098","  (Just Hit Enter for All Employee IDs)  \n"));
    tmprintf(&tmBundle, TM_NLS_Get("0099","  (Can Use % as wildcard character)  \n"));
  ask_empl_id:
    input(par_empl_id,TM_NLS_Get("0100"," Employee ID  --------------(XXXXXXXXX)-----> "),9,ALPHA);
    tmprintf(&tmBundle, _TMC(" \n"));
   

   if ((!*par_empl_id) && (compare(parm_ind,_TMC("N"),EQS)))
     {
           tmstrcpy(all_empl,_TMC("Y"));
           goto end_parameters;
	 }

    tmstrcpy(parm_ind,_TMC("Y"));
    if ( !*par_empl_id ) goto end_parameters;
    ins_empl_id();
    goto ask_empl_id;
 

missing_parm:
	tmstrcpy(are_parameters_valid,TM_NLS_Get("0101","NO"));
	tmprintf(&tmBundle, TM_NLS_Get("0102","Required Parameter is Missing, aborting program\n"));
        tmstrcpy(reenter_parm,_TMC("N"));

no_parms:
	tmstrcpy(are_parameters_valid,TM_NLS_Get("0103","NO"));
	tmstrcpy(one_up_no_msg,TM_NLS_Get("0104"," Invalid Sequence Number "));
	tmprintf(&tmBundle, TM_NLS_Get("0105","Parameter Sequence Number is invalid, aborting program\n"));
        tmstrcpy(reenter_parm,_TMC("N"));
end_parameters:

	linelimit = 55;

}



static void control_info(void)
{
  newpage();
  page_heading();
  setmode(M_CENTER);
  prtstr(TM_NLS_Get("0106","* * * REPORT CONTROL INFORMATION * * *"));
  setmode(M_NORMAL);
  skipline(1);
  setmode(M_CENTER);
  prtstr(parameter_msg);
  skipline(1);
  setmode(M_CENTER);
  if (compare(par_from,_TMC("O"),EQS))  prtstr(TM_NLS_Get("0107","Parameters have been entered from Host Prompt."));
  if (compare(par_from,_TMC("J"),EQS))  prtstr(TM_NLS_Get("0108","Parameters have been entered via Job Submission."));
  
  table(T_END);
  skipline(1);
lineno += 4;
  table(T_BEGIN,4);
  prtstr(TM_NLS_Get("0109","Parameter Name"));
  newcol();
  prtstr(TM_NLS_Get("0110","Value"));
  newcol();
  prtstr(TM_NLS_Get("0111","Message"));
  newcol();
  prtstr(_TMC("_____________________________"));
  newcol();
  prtstr(_TMC("________________"));
  newcol();
  prtstr(_TMC("____________________________________________________________"));
  newcol();
  prtstr(TM_NLS_Get("0112","Parameter Seq No:"));
  newcol();
  prtnum(par_one_up_no,_TMC("99999999"));
  newcol();
  prtstr(one_up_no_msg);
if (compare(rptname,TM_NLS_Get("0113","NHRDIST"),EQS))
  {
  newcol();
  prtstr(TM_NLS_Get("0114","Report Type:"));
  newcol();
  prtstr(par_report_type);
  newcol();
  if (compare(par_report_type,_TMC("D"),EQS)) prtstr(TM_NLS_Get("0115","Detail Report"));
  if (compare(par_report_type,_TMC("S"),EQS)) prtstr(TM_NLS_Get("0116","Summary Report"));
}
  newcol();
  prtstr(TM_NLS_Get("0117","Sort Option:"));
  newcol();
  prtstr(par_sort_option);
  newcol();
  if (compare(par_sort_option,_TMC("H"),EQS)) prtstr(TM_NLS_Get("0118","Sort By Home Organization"));
  if (compare(par_sort_option,_TMC("D"),EQS)) prtstr(TM_NLS_Get("0119","Sort By FOAPAL Distribution Organization"));
  newcol();
  prtstr(TM_NLS_Get("0120","Period Begin Date:"));
  newcol();
  prtstr(par_begin_date);
  newcol();
prtstr(begin_date_msg);

  newcol();
  prtstr(TM_NLS_Get("0121","Period End Date:"));
  newcol();
  prtstr(par_end_date);
  newcol();
  prtstr(end_date_msg);

lineno += 8;
    parm_sel_body(TM_NLS_Get("0122","PAY ID:"),par_pict_no);
    newline();

  newcol();
  prtstr(TM_NLS_Get("0123","Hierarchy:"));
  newcol();
  prtstr(par_hier);
  newcol();
  if (compare(par_hier,_TMC("E"),EQS)) prtstr(TM_NLS_Get("0124","FOAP Fields As Exists"));
  if (compare(par_hier,_TMC("L"),EQS)) prtstr(TM_NLS_Get("0125","Roll Upto Specific FOAP Levels"));
  if (compare(par_hier,_TMC("F"),EQS)) prtstr(TM_NLS_Get("0126","Roll Upto Specific FOAP Fields"));
if (compare(par_hier,_TMC("L"),EQS))
  {
    newcol();
  prtstr(TM_NLS_Get("0127","Fund Level:"));
  newcol();
  prtstr(par_fund_level);
  newcol();
    newcol();
  prtstr(TM_NLS_Get("0128","Orgn Level:"));
  newcol();
  prtstr(par_orgn_level);
  newcol();

  newcol();
  prtstr(TM_NLS_Get("0129","Acct Level:"));
  newcol();
  prtstr(par_acct_level);
  newcol();
    newcol();
  prtstr(TM_NLS_Get("0130","Prog Level:"));
  newcol();
  prtstr(par_prog_level);
  newcol();
  }


if (compare(par_sort_option,_TMC("H"),EQS))
 if (*par_home_coas)
  {

  newcol();
  prtstr(TM_NLS_Get("0131","Home COAS:"));
  newcol();
  prtstr(par_home_coas);
  newcol();
lineno++;
tmstrcpy(home_coas,par_home_coas);
control_home_info();
}
    report(sel_coas,coas_parm_body,NULL,NULL);

    parm_sel_body(TM_NLS_Get("0132","ECLS CODE:"),par_ecls_no);
    parm_sel_body(TM_NLS_Get("0133","Employee ID:"),par_empl_id_no);

}


static void page_heading(void)
{
  table(T_BEGIN,2);
  prtstr(TM_NLS_Get("0134","PAGE"));
  newcol();
  justify(J_RIGHT);
  add(pageno,pageno,_TMC("1"));
  prtnum(pageno,_TMC("99999"));
  table(T_END);

  table(T_BEGIN,3);
  newline();
  prtstr(TM_NLS_Get("0135","REPORT : \\"));
  prtstr(rptname);
  newcol();
  setmode(M_CENTER);
  prtstr(institution);
  newline();
  setmode(M_CENTER);
  prtstr(title_var);
  newline();
  setmode(M_CENTER);
  prtstr(TM_NLS_Get("0136","Reporting Period: "));
  prtstr(par_begin_date);
prtstr(TM_NLS_Get("0137","To: "));
  prtstr(par_end_date);
if (compare(par_sort_option,_TMC("H"),EQS)) 
  if ( (*par_home_coas) && (*par_coas))
    {
 prtstr(TM_NLS_Get("0138","Distribution Chart: "));
 prtstr(par_coas);
}
  setmode(M_NORMAL);
  newcol();
  prtstr(TM_NLS_Get("0139","RUN DATE"));
  prtstr(run_date);
  newline();
  prtstr(TM_NLS_Get("0140","RUN TIME"));
  prtstr(run_time);
  table(T_END);
skipline(1);
  lineno = 5;
}


static void coas_parm_body(void)
{


  newcol();
  prtstr(TM_NLS_Get("0141","COAS"));
  newcol();
  prtstr(par_coas);
  newcol();
  lineno++;

 if (compare(par_sort_option,_TMC("H"),EQS))
  if (!*par_home_coas)
    {
  tmstrcpy(home_coas,par_coas);
  control_home_info();
        }

  if (compare(par_hier,_TMC("F"),EQS))
    {
      parm_body(TM_NLS_Get("0142","Grant to Roll To:"),par_grnt_no,par_grnt);
      parm_body(TM_NLS_Get("0143","Fund to Roll To:"),par_fund_no,par_fund);
      parm_body(TM_NLS_Get("0144","Orgn to Roll To:"),par_orgn_no,par_orgn);
      parm_body(TM_NLS_Get("0145","Acct to Roll To:"),par_acct_no,par_acct);
      parm_body(TM_NLS_Get("0146","Prog to Roll To:"),par_prog_no,par_prog);
  }
if (compare(par_hier,_TMC("E"),EQS))
  {
      parm_body(TM_NLS_Get("0147","Grant Option:"),par_grnt_option_no,par_grnt_option);
    if (inlist(par_grnt_option,ALPHA,_TMC("S"),_TMC("W"),NULL))
      parm_body(TM_NLS_Get("0148","Grant:"),par_grnt_no,par_grnt);

    if (compare(par_grnt_option,_TMC("R"),EQS))
    {
      parm_body(TM_NLS_Get("0149","From Grant:"),par_grnt_from_no,par_grnt_from);
      parm_body(TM_NLS_Get("0150","To Grant:"),par_grnt_to_no,par_grnt_to);
    }
    
      parm_body(TM_NLS_Get("0151","Fund Option:"),par_fund_option_no,par_fund_option);
    if (inlist(par_fund_option,ALPHA,_TMC("S"),_TMC("W"),NULL))
      parm_body(TM_NLS_Get("0152","Fund:"),par_fund_no,par_fund);

    if (compare(par_fund_option,_TMC("R"),EQS))
    {
      parm_body(TM_NLS_Get("0153","From Fund:"),par_fund_from_no,par_fund_from);
      parm_body(TM_NLS_Get("0154","To Fund:"),par_fund_to_no,par_fund_to);
    }

     parm_body(TM_NLS_Get("0155","Orgn Option:"),par_orgn_option_no,par_orgn_option);
    if (inlist(par_orgn_option,ALPHA,_TMC("S"),_TMC("W"),NULL))
     parm_body(TM_NLS_Get("0156","Orgn:"),par_orgn_no,par_orgn);

    if (compare(par_orgn_option,_TMC("R"),EQS))
    {
      parm_body(TM_NLS_Get("0157","From Orgn:"),par_orgn_from_no,par_orgn_from);
      parm_body(TM_NLS_Get("0158","To Orgn:"),par_orgn_to_no,par_orgn_to);
    }

     parm_body(TM_NLS_Get("0159","Acct Option:"),par_acct_option_no,par_acct_option);
    if (inlist(par_acct_option,ALPHA,_TMC("S"),_TMC("W"),NULL))
     parm_body(TM_NLS_Get("0160","Acct:"),par_acct_no,par_acct);
    
    if (compare(par_acct_option,_TMC("R"),EQS))
    {
     parm_body(TM_NLS_Get("0161","From Acct:"),par_acct_from_no,par_acct_from);
     parm_body(TM_NLS_Get("0162","To Acct:"),par_acct_to_no,par_acct_to);
    }
     parm_body(TM_NLS_Get("0163","Prog Option:"),par_prog_option_no,par_prog_option);
    if (inlist(par_prog_option,ALPHA,_TMC("S"),_TMC("W"),NULL))
     parm_body(TM_NLS_Get("0164","Prog:"),par_prog_no,par_prog);
    
    if (compare(par_prog_option,_TMC("R"),EQS))
    {
     parm_body(TM_NLS_Get("0165","From Prog:"),par_prog_from_no,par_prog_from);
     parm_body(TM_NLS_Get("0166","To Prog:"),par_prog_to_no,par_prog_to);
    }

    }
}


static int gen_one_up_no(int mode)
{
  EXEC SQL DECLARE cursor_001 CURSOR FOR
        SELECT GJBPSEQ.NEXTVAL
          FROM DUAL;

  if ( mode==CLOSE_CURSOR )
    {
      EXEC SQL CLOSE cursor_001;
      POSTORA;
      return TRUE;
  }

  if ( mode==FIRST_ROW )
    {
      EXEC SQL OPEN cursor_001;
      POSTORA;
    }

  EXEC SQL FETCH cursor_001 INTO
       :par_one_up_no:Ind_01;
  POSTORA;

  if ( NO_ROWS_FOUND )
    {
      *par_one_up_no='\0';
      return FALSE;
    }

  return TRUE;
}

static int validate_one_up_no(int mode)
{
  EXEC SQL DECLARE cursor_002 CURSOR FOR
        SELECT 'Y'
          FROM GJBPRUN
         WHERE GJBPRUN_JOB       = UPPER(:rptname)
           AND GJBPRUN_ONE_UP_NO = TO_NUMBER(:par_one_up_no)
           AND ROWNUM            = 1;

  if ( mode==CLOSE_CURSOR )
    {
      EXEC SQL CLOSE cursor_002;
      POSTORA;
      return TRUE;
  }

  if ( mode==FIRST_ROW )
    {
      EXEC SQL OPEN cursor_002;
      POSTORA;
    }

  EXEC SQL FETCH cursor_002 INTO
       :valid_ind:Ind_01;
  POSTORA;

  if ( NO_ROWS_FOUND )
    {
      *valid_ind='\0';
      return FALSE;
    }

  return TRUE;
}

static void del_parm(void)
{
  EXEC SQL
DELETE GJBPRUN
where  gjbprun_one_up_no = TO_NUMBER(:par_one_up_no)
and    gjbprun_job       = :rptname;
  POSTORA;
}

/* APPEND 19 TO YEAR */

static int add_19(int mode)
{
  EXEC SQL DECLARE cursor_005 CURSOR FOR
select substr(:par_example_date,1,7)||'19'||substr(:par_example_date,8,2)
from   DUAL
where  substr(:par_example_date,8,2) between 26 and 99;

  if ( mode==CLOSE_CURSOR )
    {
      EXEC SQL CLOSE cursor_005;
      POSTORA;
      return TRUE;
  }

  if ( mode==FIRST_ROW )
    {
      EXEC SQL OPEN cursor_005;
      POSTORA;
    }

  EXEC SQL FETCH cursor_005 INTO
       :par_example_date:Ind_01;
  POSTORA;

  if ( NO_ROWS_FOUND )
    {
      *par_example_date='\0';
      return FALSE;
    }

  return TRUE;
}

/* APPEND 20 TO YEAR */

static int add_20(int mode)
{
  EXEC SQL DECLARE cursor_006 CURSOR FOR
select substr(:par_example_date,1,7)||'20'||
             lpad(substr(:par_example_date,8,2),2,'0')
from   DUAL
where  substr(:par_example_date,8,2) between 0 and 25;

  if ( mode==CLOSE_CURSOR )
    {
      EXEC SQL CLOSE cursor_006;
      POSTORA;
      return TRUE;
  }

  if ( mode==FIRST_ROW )
    {
      EXEC SQL OPEN cursor_006;
      POSTORA;
    }

  EXEC SQL FETCH cursor_006 INTO
       :par_example_date:Ind_01;
  POSTORA;

  if ( NO_ROWS_FOUND )
    {
      *par_example_date='\0';
      return FALSE;
    }

  return TRUE;
}



static void ins_pict_code(void)
{
  EXEC SQL
   INSERT into gjbcolr
         (gjbcolr_one_up_no,
          gjbcolr_job,
          gjbcolr_number,
          gjbcolr_value,
          gjbcolr_activity_date)
select    TO_NUMBER(:par_one_up_no),
          :rptname,
          :par_pict_no,
          ptrpict_code,
          sysdate
from      ptrpict
where     ptrpict_code like UPPER(:par_pict);
  POSTORA;
}


static void ins_ecls_code(void)
{
  EXEC SQL
   INSERT into gjbcolr
         (gjbcolr_one_up_no,
          gjbcolr_job,
          gjbcolr_number,
          gjbcolr_value,
          gjbcolr_activity_date)
select    TO_NUMBER(:par_one_up_no),
          :rptname,
          :par_ecls_no,
          ptrecls_code,
          sysdate
from      ptrecls
where     ptrecls_code like UPPER(:par_ecls);
  POSTORA;
}


static void ins_empl_id(void)
{
  EXEC SQL
   INSERT into gjbcolr
         (gjbcolr_one_up_no,
          gjbcolr_job,
          gjbcolr_number,
          gjbcolr_value,
          gjbcolr_activity_date)
select    TO_NUMBER(:par_one_up_no),
          :rptname,
          :par_empl_id_no,
          spriden_id,
          sysdate
from      spriden
where     spriden_id   like UPPER(:par_empl_id)
and       spriden_change_ind is null;
  POSTORA;
}



static void ins_coas_code(void)
{
  EXEC SQL
   INSERT into gjbcolr
         (gjbcolr_one_up_no,
          gjbcolr_job,
          gjbcolr_number,
          gjbcolr_value,
          gjbcolr_activity_date)
select    TO_NUMBER(:par_one_up_no),
          :rptname,
          :par_coas_no,
          ftvcoas_coas_code,
          sysdate
from      ftvcoas
where     ftvcoas_coas_code = upper(:par_coas)
and       trunc(ftvcoas_eff_date) <= TO_date(:par_end_date,'DD-MON-YYYY')
and       trunc(ftvcoas_nchg_date) >  TO_date(:par_end_date,'DD-MON-YYYY');

  POSTORA;
}




static void ins_fund_option(void)
{
  EXEC SQL
   INSERT into gjbcolr
         (gjbcolr_one_up_no,
          gjbcolr_job,
          gjbcolr_number,
          gjbcolr_value,
          gjbcolr_misc_value,
          gjbcolr_activity_date)
values( TO_NUMBER(:par_one_up_no),
          :rptname,
          :par_fund_option_no,
	   :par_fund_option,
	  upper(:par_coas),
          sysdate);


  POSTORA;
}

static void ins_grnt_option(void)
{
  EXEC SQL
   INSERT into gjbcolr
         (gjbcolr_one_up_no,
          gjbcolr_job,
          gjbcolr_number,
          gjbcolr_value,
          gjbcolr_misc_value,
          gjbcolr_activity_date)
values( TO_NUMBER(:par_one_up_no),
          :rptname,
          :par_grnt_option_no,
	        :par_grnt_option,
	        upper(:par_coas),
          sysdate);


  POSTORA;
}


static void ins_coas_parm(TMCHAR parm_no[4], TMCHAR parm_value[35])
{
EXEC SQL BEGIN DECLARE SECTION;
CHAR4 lparm_no={0}/*TMCI18N CHANGED FROM ""*/;
CHAR32 lparm_value={0}/*TMCI18N CHANGED FROM ""*/;
EXEC SQL END DECLARE SECTION;

tmstrcpy(lparm_no, parm_no);
tmstrcpy(lparm_value, parm_value);

  EXEC SQL
   INSERT into gjbcolr
         (gjbcolr_one_up_no,
          gjbcolr_job,
          gjbcolr_number,
          gjbcolr_value,
          gjbcolr_misc_value,
          gjbcolr_activity_date)
values( TO_NUMBER(:par_one_up_no),
          :rptname,
          :lparm_no,
	  :lparm_value,
	  upper(:par_coas),
          sysdate);


  POSTORA;
}


static void ins_fund_range(void)
{
  EXEC SQL
   INSERT into gjbcolr
         (gjbcolr_one_up_no,
          gjbcolr_job,
          gjbcolr_number,
          gjbcolr_value,
          gjbcolr_misc_value,
          gjbcolr_activity_date)
select    TO_NUMBER(:par_one_up_no),
          :rptname,
          :par_fund_no,
          ftvfund_fund_code,
	  upper(:par_coas),
          sysdate
from      ftvfund
where     ftvfund_coas_code = upper(:par_coas)
and       ftvfund_fund_code between upper(:par_fund_from) and
            upper(:par_fund_to)
and       trunc(ftvfund_eff_date) <= TO_date(:par_end_date,'DD-MON-YYYY')
and       trunc(ftvfund_nchg_date) >  TO_date(:par_end_date,'DD-MON-YYYY');
  POSTORA;
}

static void ins_grnt_range(void)
{
  EXEC SQL
   INSERT into gjbcolr
         (gjbcolr_one_up_no,
          gjbcolr_job,
          gjbcolr_number,
          gjbcolr_value,
          gjbcolr_misc_value,
          gjbcolr_activity_date)
select    TO_NUMBER(:par_one_up_no),
          :rptname,
          :par_grnt_no,
          ftvfund_grnt_code,
	        upper(:par_coas),
          sysdate
from      ftvfund
where     ftvfund_coas_code = upper(:par_coas)
and       ftvfund_grnt_code between upper(:par_grnt_from) and upper(:par_grnt_to)
and       trunc(ftvfund_eff_date) <= TO_date(:par_end_date,'DD-MON-YYYY')
and       trunc(ftvfund_nchg_date) >  TO_date(:par_end_date,'DD-MON-YYYY');
  POSTORA;
}


static void ins_fund_code(void)
{
  EXEC SQL
   INSERT into gjbcolr
         (gjbcolr_one_up_no,
          gjbcolr_job,
          gjbcolr_number,
          gjbcolr_value,
          gjbcolr_misc_value,
          gjbcolr_activity_date)
select    TO_NUMBER(:par_one_up_no),
          :rptname,
          :par_fund_no,
          ftvfund_fund_code,
          upper(:par_coas),
          sysdate
from      ftvfund
where     ftvfund_fund_code like upper(:par_fund)
and       ftvfund_coas_code = upper(:par_coas)
and       trunc(ftvfund_eff_date) <= TO_date(:par_end_date,'DD-MON-YYYY')
and       trunc(ftvfund_nchg_date) >  TO_date(:par_end_date,'DD-MON-YYYY');

  POSTORA;
}

static void ins_grnt_code(void)
{
  EXEC SQL
   INSERT into gjbcolr
         (gjbcolr_one_up_no,
          gjbcolr_job,
          gjbcolr_number,
          gjbcolr_value,
          gjbcolr_misc_value,
          gjbcolr_activity_date)
select    TO_NUMBER(:par_one_up_no),
          :rptname,
          :par_grnt_no,
          ftvfund_grnt_code,
          upper(:par_coas),
          sysdate
from      ftvfund
where     ftvfund_grnt_code like upper(:par_grnt)
and       ftvfund_coas_code = upper(:par_coas)
and       trunc(ftvfund_eff_date) <= TO_date(:par_end_date,'DD-MON-YYYY')
and       trunc(ftvfund_nchg_date) >  TO_date(:par_end_date,'DD-MON-YYYY');

  POSTORA;
}


static void ins_orgn_option(void)
{
  EXEC SQL
   INSERT into gjbcolr
         (gjbcolr_one_up_no,
          gjbcolr_job,
          gjbcolr_number,
          gjbcolr_value,
          gjbcolr_misc_value,
          gjbcolr_activity_date)
values( TO_NUMBER(:par_one_up_no),
          :rptname,
          :par_orgn_option_no,
	   :par_orgn_option,
	  upper(:par_coas),
          sysdate);


  POSTORA;
}


static void ins_orgn_range(void)
{
  EXEC SQL
   INSERT into gjbcolr
         (gjbcolr_one_up_no,
          gjbcolr_job,
          gjbcolr_number,
          gjbcolr_value,
          gjbcolr_misc_value,
          gjbcolr_activity_date)
select    TO_NUMBER(:par_one_up_no),
          :rptname,
          :par_orgn_no,
          ftvorgn_orgn_code,
	  upper(:par_coas),
          sysdate
from      ftvorgn
where     ftvorgn_coas_code = upper(:par_coas)
and       ftvorgn_orgn_code between upper(:par_orgn_from) and
            upper(:par_orgn_to)
and       trunc(ftvorgn_eff_date) <= TO_date(:par_end_date,'DD-MON-YYYY')
and       trunc(ftvorgn_nchg_date) >  TO_date(:par_end_date,'DD-MON-YYYY');
  POSTORA;
}



static void ins_orgn_code(void)
{
  EXEC SQL
   INSERT into gjbcolr
         (gjbcolr_one_up_no,
          gjbcolr_job,
          gjbcolr_number,
          gjbcolr_value,
          gjbcolr_misc_value,
          gjbcolr_activity_date)
select    TO_NUMBER(:par_one_up_no),
          :rptname,
          :par_orgn_no,
          ftvorgn_orgn_code,
          upper(:par_coas),
          sysdate
from      ftvorgn
where     ftvorgn_orgn_code like upper(:par_orgn)
and       ftvorgn_coas_code = upper(:par_coas)
and       trunc(ftvorgn_eff_date) <= TO_date(:par_end_date,'DD-MON-YYYY')
and       trunc(ftvorgn_nchg_date) >  TO_date(:par_end_date,'DD-MON-YYYY');

  POSTORA;
}



static void ins_acct_option(void)
{
  EXEC SQL
   INSERT into gjbcolr
         (gjbcolr_one_up_no,
          gjbcolr_job,
          gjbcolr_number,
          gjbcolr_value,
          gjbcolr_misc_value,
          gjbcolr_activity_date)
values( TO_NUMBER(:par_one_up_no),
          :rptname,
          :par_acct_option_no,
	   :par_acct_option,
	  upper(:par_coas),
          sysdate);


  POSTORA;
}


static void ins_acct_range(void)
{
  EXEC SQL
   INSERT into gjbcolr
         (gjbcolr_one_up_no,
          gjbcolr_job,
          gjbcolr_number,
          gjbcolr_value,
          gjbcolr_misc_value,
          gjbcolr_activity_date)
select    TO_NUMBER(:par_one_up_no),
          :rptname,
          :par_acct_no,
          ftvacct_acct_code,
	  upper(:par_coas),
          sysdate
from      ftvacct
where     ftvacct_coas_code = upper(:par_coas)
and       ftvacct_acct_code between upper(:par_acct_from) and
            upper(:par_acct_to)
and       trunc(ftvacct_eff_date) <= TO_date(:par_end_date,'DD-MON-YYYY')
and       trunc(ftvacct_nchg_date) >  TO_date(:par_end_date,'DD-MON-YYYY');
  POSTORA;
}


static void ins_acct_code(void)
{
  EXEC SQL
   INSERT into gjbcolr
         (gjbcolr_one_up_no,
          gjbcolr_job,
          gjbcolr_number,
          gjbcolr_value,
          gjbcolr_misc_value,
          gjbcolr_activity_date)
select    TO_NUMBER(:par_one_up_no),
          :rptname,
          :par_acct_no,
          ftvacct_acct_code,
          upper(:par_coas),
          sysdate
from      ftvacct
where     ftvacct_acct_code like upper(:par_acct)
and       ftvacct_coas_code = upper(:par_coas)
and       trunc(ftvacct_eff_date) <= TO_date(:par_end_date,'DD-MON-YYYY')
and       trunc(ftvacct_nchg_date) >  TO_date(:par_end_date,'DD-MON-YYYY');

  POSTORA;
}


static void ins_prog_option(void)
{
  EXEC SQL
   INSERT into gjbcolr
         (gjbcolr_one_up_no,
          gjbcolr_job,
          gjbcolr_number,
          gjbcolr_value,
          gjbcolr_misc_value,
          gjbcolr_activity_date)
values( TO_NUMBER(:par_one_up_no),
          :rptname,
          :par_prog_option_no,
	   :par_prog_option,
	  upper(:par_coas),
          sysdate);


  POSTORA;
}


static void ins_prog_range(void)
{
  EXEC SQL
   INSERT into gjbcolr
         (gjbcolr_one_up_no,
          gjbcolr_job,
          gjbcolr_number,
          gjbcolr_value,
          gjbcolr_misc_value,
          gjbcolr_activity_date)
select    TO_NUMBER(:par_one_up_no),
          :rptname,
          :par_prog_no,
          ftvprog_prog_code,
	  upper(:par_coas),
          sysdate
from      ftvprog
where     ftvprog_coas_code = upper(:par_coas)
and       ftvprog_prog_code between upper(:par_prog_from) and
            upper(:par_prog_to)
and       trunc(ftvprog_eff_date) <= TO_date(:par_end_date,'DD-MON-YYYY')
and       trunc(ftvprog_nchg_date) >  TO_date(:par_end_date,'DD-MON-YYYY');
  POSTORA;
}


static void ins_prog_code(void)
{
  EXEC SQL
   INSERT into gjbcolr
         (gjbcolr_one_up_no,
          gjbcolr_job,
          gjbcolr_number,
          gjbcolr_value,
          gjbcolr_misc_value,
          gjbcolr_activity_date)
select    TO_NUMBER(:par_one_up_no),
          :rptname,
          :par_prog_no,
          ftvprog_prog_code,
          upper(:par_coas),
          sysdate
from      ftvprog
where     ftvprog_prog_code like upper(:par_prog)
and       ftvprog_coas_code = upper(:par_coas)
and       trunc(ftvprog_eff_date) <= TO_date(:par_end_date,'DD-MON-YYYY')
and       trunc(ftvprog_nchg_date) >  TO_date(:par_end_date,'DD-MON-YYYY');

  POSTORA;
}

static int parm_sel(int mode,TMCHAR parm_no[4],TMCHAR parm_value[32])
{

EXEC SQL BEGIN DECLARE SECTION;
CHAR32 lparm_value={0}/*TMCI18N CHANGED FROM ""*/;
CHAR4  lparm_no={0}/*TMCI18N CHANGED FROM ""*/;
EXEC SQL END DECLARE SECTION;

tmstrcpy(lparm_no,parm_no);

  EXEC SQL DECLARE cursor_003 CURSOR FOR
   SELECT gjbcolr_value
   FROM   gjbcolr
   WHERE  gjbcolr_one_up_no = TO_NUMBER(:par_one_up_no)
   AND    gjbcolr_number    = :lparm_no
   AND    gjbcolr_job       = :rptname
order by  gjbcolr_value;

  if ( mode==CLOSE_CURSOR )
    {
      EXEC SQL CLOSE cursor_003;
      POSTORA;
      return TRUE;
  }

  if ( mode==FIRST_ROW )
    {
      EXEC SQL OPEN cursor_003;
      POSTORA;
    }

  EXEC SQL FETCH cursor_003 INTO
       :lparm_value:Ind_01;
  POSTORA;

  if ( NO_ROWS_FOUND )
    {
      *lparm_value='\0';
      *parm_value='\0';
      return FALSE;
    }
tmstrcpy(parm_value,lparm_value);

  return TRUE;
}                                        /*  end parm_sel */



static void del_colr(void)
{
  EXEC SQL
  DELETE gjbcolr
  WHERE  gjbcolr_one_up_no = TO_NUMBER(:par_one_up_no)
  AND    gjbcolr_job       = :rptname;
  POSTORA;
}

static void del_hier(void)
{
 EXEC SQL
  DELETE fgrfdhc
  WHERE  fgrfdhc_sess_id  = userenv('SESSIONID');
  POSTORA; 
 EXEC SQL
  DELETE fgrorhc
  WHERE  fgrorhc_sess_id  = userenv('SESSIONID');
  POSTORA; 
 EXEC SQL
  DELETE fgrathc
  WHERE  fgrathc_sess_id  = userenv('SESSIONID');
  POSTORA; 
 EXEC SQL
  DELETE fgrpghc
  WHERE  fgrpghc_sess_id  = userenv('SESSIONID');
  POSTORA; 

}



/*  FUND HIERARCHY SELECT FOR A SPECIFIC FUND      */

static int sel_spec_fundhier(int mode)
{
  EXEC SQL DECLARE spec_fundhier CURSOR FOR
   SELECT FTVFUND_FUND_CODE,
          LEVEL
        FROM FTVFUND
        CONNECT BY PRIOR FTVFUND_FUND_CODE = FTVFUND_FUND_CODE_PRED
               AND PRIOR FTVFUND_COAS_CODE = FTVFUND_COAS_CODE
               AND  trunc(FTVFUND_EFF_DATE) <=  to_date(:par_end_date,'DD-MON-YYYY')
               AND  trunc(FTVFUND_NCHG_DATE) >  to_date(:par_end_date,'DD-MON-YYYY')
         START WITH FTVFUND_FUND_CODE    =  :par_fund
               AND  FTVFUND_COAS_CODE    =  :par_coas
               AND  trunc(FTVFUND_EFF_DATE) <= to_date(:par_end_date,'DD-MON-YYYY')
               AND  trunc(FTVFUND_NCHG_DATE) >  to_date(:par_end_date,'DD-MON-YYYY');

  if ( mode==CLOSE_CURSOR )
    {
      EXEC SQL CLOSE spec_fundhier;
      POSTORA;
      return TRUE;
  }

  if ( mode==FIRST_ROW )
    {
      EXEC SQL OPEN spec_fundhier;
      POSTORA;
    }

  EXEC SQL FETCH spec_fundhier INTO
       :rpt_fund_code:Ind_01,
       :rpt_fund_level:Ind_02;
  POSTORA;

  if ( NO_ROWS_FOUND )
    {
      *rpt_fund_code='\0';
      *rpt_fund_level='\0';
      return FALSE;
    }

  return TRUE;
}

/*  FUND HIERARCHY SELECT ALL FUNDS */

static int sel_all_fundhier(int mode)
{
  EXEC SQL DECLARE all_fundhier CURSOR FOR
   SELECT FTVFUND_FUND_CODE,
          LEVEL
        FROM FTVFUND
        CONNECT BY PRIOR FTVFUND_FUND_CODE = FTVFUND_FUND_CODE_PRED
               AND PRIOR FTVFUND_COAS_CODE = FTVFUND_COAS_CODE
           AND   trunc(FTVFUND_EFF_DATE) <= to_date(:par_end_date,'DD-MON-YYYY')
           AND   trunc(FTVFUND_NCHG_DATE) >  to_date(:par_end_date,'DD-MON-YYYY')
         START WITH FTVFUND_FUND_CODE_PRED IS NULL
           AND   :par_coas = FTVFUND_COAS_CODE
           AND   FTVFUND_EFF_DATE <= to_date(:par_end_date,'DD-MON-YYYY')
           AND   FTVFUND_NCHG_DATE >  to_date(:par_end_date,'DD-MON-YYYY');

  if ( mode==CLOSE_CURSOR )
    {
      EXEC SQL CLOSE all_fundhier;
      POSTORA;
      return TRUE;
  }

  if ( mode==FIRST_ROW )
    {
      EXEC SQL OPEN all_fundhier;
      POSTORA;
    }

  EXEC SQL FETCH all_fundhier INTO
       :rpt_fund_code:Ind_01,
       :rpt_fund_level:Ind_02;
  POSTORA;

  if ( NO_ROWS_FOUND )
    {
      *rpt_fund_code='\0';
      *rpt_fund_level='\0';
      return FALSE;
    }

  return TRUE;
}



static void fund_hier(void)
{
if (compare(par_hier,_TMC("F"),EQS))
  {
    coas_parm_sel(FIRST_ROW,par_fund_no,par_fund,temp);
    if (*par_fund) spec_fund_hier();
    else ins_fund_exists();
   }
if (compare(par_hier,_TMC("L"),EQS))
  {
   if (compare(par_fund_level,_TMC("E"),EQS)) ins_fund_exists();
   else if (compare(par_fund_level,_TMC("1"),EQS)) level_fund_hier_1();
   else if (compare(par_fund_level,_TMC("2"),EQS)) level_fund_hier_2();
   else if (compare(par_fund_level,_TMC("3"),EQS)) level_fund_hier_3();
   else if (compare(par_fund_level,_TMC("4"),EQS)) level_fund_hier_4();
   else if (compare(par_fund_level,_TMC("5"),EQS)) level_fund_hier_5();
   }   
}

static void spec_fund_hier(void)
{
  report(sel_spec_fundhier,fund_body1,fund_body1,NULL);
}

static void level_fund_hier_1(void)
{
  report(sel_all_fundhier,fund_body1,fund_body1,NULL);
}

static void level_fund_hier_2(void)
{
  report(sel_all_fundhier,fund_body2,fund_body2,NULL);
}

static void level_fund_hier_3(void)
{
  report(sel_all_fundhier,fund_body3,fund_body3,NULL);
}

static void level_fund_hier_4(void)
{
  report(sel_all_fundhier,fund_body4,fund_body4,NULL);
}

static void level_fund_hier_5(void)
{
  report(sel_all_fundhier,fund_body5,fund_body5,NULL);
}



static void fund_body1(void)
{
  if ( compare(rpt_fund_level,_TMC("1"),EQS) ) goto level1;
  if ( compare(rpt_fund_level,_TMC("2"),EQS) ) goto level2;
  if ( compare(rpt_fund_level,_TMC("3"),EQS) ) goto level3;
  if ( compare(rpt_fund_level,_TMC("4"),EQS) ) goto level4;
  if ( compare(rpt_fund_level,_TMC("5"),EQS) ) goto level5;
  level1:
    tmstrcpy(save_fund_level_1,rpt_fund_code);
    tmstrcpy(save_fund_level_2,_TMC("!"));
    tmstrcpy(save_fund_level_3,_TMC("!"));
    tmstrcpy(save_fund_level_4,_TMC("!"));
    tmstrcpy(save_fund_level_5,_TMC("!"));
    goto end;
  level2:
    tmstrcpy(save_fund_level_2,rpt_fund_code);
    tmstrcpy(save_fund_level_3,_TMC("!"));
    tmstrcpy(save_fund_level_4,_TMC("!"));
    tmstrcpy(save_fund_level_5,_TMC("!"));
    goto end;
  level3:
    tmstrcpy(save_fund_level_3,rpt_fund_code);
    tmstrcpy(save_fund_level_4,_TMC("!"));
    tmstrcpy(save_fund_level_5,_TMC("!"));
    goto end;
  level4:
    tmstrcpy(save_fund_level_4,rpt_fund_code);
    tmstrcpy(save_fund_level_5,_TMC("!"));
    goto end;
  level5:
    tmstrcpy(save_fund_level_5,rpt_fund_code);
  end:
    ins_fgrfdhc();
}

/* FUND HIERARCHY WHEN PARM_FUND_LEVEL = 2 */

static void fund_body2(void)
{
  if ( compare(rpt_fund_level,_TMC("1"),EQS) ) return;
  if ( compare(rpt_fund_level,_TMC("2"),EQS) ) goto level1;
  if ( compare(rpt_fund_level,_TMC("3"),EQS) ) goto level2;
  if ( compare(rpt_fund_level,_TMC("4"),EQS) ) goto level3;
  if ( compare(rpt_fund_level,_TMC("5"),EQS) ) goto level4;
  level1:
    tmstrcpy(save_fund_level_1,rpt_fund_code);
    tmstrcpy(save_fund_level_2,_TMC("!"));
    tmstrcpy(save_fund_level_3,_TMC("!"));
    tmstrcpy(save_fund_level_4,_TMC("!"));
    tmstrcpy(save_fund_level_5,_TMC("!"));
    goto end;
  level2:
    tmstrcpy(save_fund_level_2,rpt_fund_code);
    tmstrcpy(save_fund_level_3,_TMC("!"));
    tmstrcpy(save_fund_level_4,_TMC("!"));
    tmstrcpy(save_fund_level_5,_TMC("!"));
    goto end;
  level3:
    tmstrcpy(save_fund_level_3,rpt_fund_code);
    tmstrcpy(save_fund_level_4,_TMC("!"));
    tmstrcpy(save_fund_level_5,_TMC("!"));
    goto end;
  level4:
    tmstrcpy(save_fund_level_4,rpt_fund_code);
    tmstrcpy(save_fund_level_5,_TMC("!"));
  end:
    ins_fgrfdhc();

}

/* FUND HIERARCHY WHEN PARM_FUND_LEVEL = 3 */

static void fund_body3(void)
{
  if ( compare(rpt_fund_level,_TMC("1"),EQS) ) return;
  if ( compare(rpt_fund_level,_TMC("2"),EQS) ) return;
  if ( compare(rpt_fund_level,_TMC("3"),EQS) ) goto level1;
  if ( compare(rpt_fund_level,_TMC("4"),EQS) ) goto level2;
  if ( compare(rpt_fund_level,_TMC("5"),EQS) ) goto level3;
  level1:
    tmstrcpy(save_fund_level_1,rpt_fund_code);
    tmstrcpy(save_fund_level_2,_TMC("!"));
    tmstrcpy(save_fund_level_3,_TMC("!"));
    tmstrcpy(save_fund_level_4,_TMC("!"));
    tmstrcpy(save_fund_level_5,_TMC("!"));
    goto end;
  level2:
    tmstrcpy(save_fund_level_2,rpt_fund_code);
    tmstrcpy(save_fund_level_3,_TMC("!"));
    tmstrcpy(save_fund_level_4,_TMC("!"));
    tmstrcpy(save_fund_level_5,_TMC("!"));
    goto end;
  level3:
    tmstrcpy(save_fund_level_3,rpt_fund_code);
    tmstrcpy(save_fund_level_4,_TMC("!"));
    tmstrcpy(save_fund_level_5,_TMC("!"));
  end:
    ins_fgrfdhc();

}

/* FUND HIERARCHY WHEN PARM_FUND_LEVEL = 4 */

static void fund_body4(void)
{
  if ( compare(rpt_fund_level,_TMC("1"),EQS) ) return;
  if ( compare(rpt_fund_level,_TMC("2"),EQS) ) return;
  if ( compare(rpt_fund_level,_TMC("3"),EQS) ) return;
  if ( compare(rpt_fund_level,_TMC("4"),EQS) ) goto level1;
  if ( compare(rpt_fund_level,_TMC("5"),EQS) ) goto level2;
  level1:
    tmstrcpy(save_fund_level_1,rpt_fund_code);
    tmstrcpy(save_fund_level_2,_TMC("!"));
    tmstrcpy(save_fund_level_3,_TMC("!"));
    tmstrcpy(save_fund_level_4,_TMC("!"));
    tmstrcpy(save_fund_level_5,_TMC("!"));
    goto end;
  level2:
    tmstrcpy(save_fund_level_2,rpt_fund_code);
    tmstrcpy(save_fund_level_3,_TMC("!"));
    tmstrcpy(save_fund_level_4,_TMC("!"));
    tmstrcpy(save_fund_level_5,_TMC("!"));
  end:
    ins_fgrfdhc();

}

/* FUND HIERARCHY WHEN PARM_FUND_LEVEL = 5 */

static void fund_body5(void)
{
  if ( compare(rpt_fund_level,_TMC("1"),EQS) ) return;
  if ( compare(rpt_fund_level,_TMC("2"),EQS) ) return;
  if ( compare(rpt_fund_level,_TMC("3"),EQS) ) return;
  if ( compare(rpt_fund_level,_TMC("4"),EQS) ) return;
  tmstrcpy(save_fund_level_1,rpt_fund_code);
  tmstrcpy(save_fund_level_2,_TMC("!"));
  tmstrcpy(save_fund_level_3,_TMC("!"));
  tmstrcpy(save_fund_level_4,_TMC("!"));
  tmstrcpy(save_fund_level_5,_TMC("!"));
  ins_fgrfdhc();

}

/* Insert records into the FUND collector file. */

static void ins_fgrfdhc(void)
{
  EXEC SQL
        INSERT INTO FGRFDHC
               (FGRFDHC_SESS_ID,
                FGRFDHC_FUND_CODE,
                FGRFDHC_LEVEL,
                FGRFDHC_FTYP_CODE,
                FGRFDHC_INTERNAL_FTYP_CODE,
                FGRFDHC_FUND_LEVEL_1,
                FGRFDHC_FUND_LEVEL_2,
                FGRFDHC_FUND_LEVEL_3,
                FGRFDHC_FUND_LEVEL_4,
                FGRFDHC_FUND_LEVEL_5)
        VALUES (USERENV('SESSIONID'),
                :rpt_fund_code,
                :rpt_fund_level,
                'X',
                'X',
                :save_fund_level_1,
                :save_fund_level_2,
                :save_fund_level_3,
                :save_fund_level_4,
                :save_fund_level_5);
  POSTORA;
}


static void ins_fund_exists(void)
{
  EXEC SQL
        INSERT INTO FGRFDHC
               (FGRFDHC_SESS_ID,
                FGRFDHC_FUND_CODE,
                FGRFDHC_LEVEL,
                FGRFDHC_FTYP_CODE,
                FGRFDHC_INTERNAL_FTYP_CODE,
                FGRFDHC_FUND_LEVEL_1)
        select  USERENV('SESSIONID'),
                ftvfund_fund_code,
                'X',
                'X',
                'X',
                ftvfund_fund_code
        from    ftvfund
        where  FTVFUND_COAS_CODE    =  :par_coas
               AND  trunc(FTVFUND_EFF_DATE) <= to_date(:par_end_date,'DD-MON-YYYY')
               AND  trunc(FTVFUND_NCHG_DATE) >  to_date(:par_end_date,'DD-MON-YYYY');
  
  POSTORA;
}


/*  PROG HIERARCHY SELECT FOR A SPECIFIC PROG      */

static int sel_spec_proghier(int mode)
{
  EXEC SQL DECLARE spec_proghier CURSOR FOR
   SELECT FTVPROG_PROG_CODE,
          LEVEL
        FROM FTVPROG
        CONNECT BY PRIOR FTVPROG_PROG_CODE = FTVPROG_PROG_CODE_PRED
               AND PRIOR FTVPROG_COAS_CODE = FTVPROG_COAS_CODE
               AND  trunc(FTVPROG_EFF_DATE) <=  to_date(:par_end_date,'DD-MON-YYYY')
               AND  trunc(FTVPROG_NCHG_DATE) >  to_date(:par_end_date,'DD-MON-YYYY')
         START WITH FTVPROG_PROG_CODE    =  :par_prog
               AND  FTVPROG_COAS_CODE    =  :par_coas
               AND  trunc(FTVPROG_EFF_DATE) <= to_date(:par_end_date,'DD-MON-YYYY')
               AND  trunc(FTVPROG_NCHG_DATE) >  to_date(:par_end_date,'DD-MON-YYYY');

  if ( mode==CLOSE_CURSOR )
    {
      EXEC SQL CLOSE spec_proghier;
      POSTORA;
      return TRUE;
  }

  if ( mode==FIRST_ROW )
    {
      EXEC SQL OPEN spec_proghier;
      POSTORA;
    }

  EXEC SQL FETCH spec_proghier INTO
       :rpt_prog_code:Ind_01,
       :rpt_prog_level:Ind_02;
  POSTORA;

  if ( NO_ROWS_FOUND )
    {
      *rpt_prog_code='\0';
      *rpt_prog_level='\0';
      return FALSE;
    }

  return TRUE;
}

/*  PROG HIERARCHY SELECT ALL PROGS */

static int sel_all_proghier(int mode)
{
  EXEC SQL DECLARE all_proghier CURSOR FOR
   SELECT FTVPROG_PROG_CODE,
          LEVEL
        FROM FTVPROG
        CONNECT BY PRIOR FTVPROG_PROG_CODE = FTVPROG_PROG_CODE_PRED
               AND PRIOR FTVPROG_COAS_CODE = FTVPROG_COAS_CODE
           AND   trunc(FTVPROG_EFF_DATE) <= to_date(:par_end_date,'DD-MON-YYYY')
           AND   trunc(FTVPROG_NCHG_DATE) >  to_date(:par_end_date,'DD-MON-YYYY')
         START WITH FTVPROG_PROG_CODE_PRED IS NULL
           AND   :par_coas = FTVPROG_COAS_CODE
           AND   FTVPROG_EFF_DATE <= to_date(:par_end_date,'DD-MON-YYYY')
           AND   FTVPROG_NCHG_DATE >  to_date(:par_end_date,'DD-MON-YYYY');

  if ( mode==CLOSE_CURSOR )
    {
      EXEC SQL CLOSE all_proghier;
      POSTORA;
      return TRUE;
  }

  if ( mode==FIRST_ROW )
    {
      EXEC SQL OPEN all_proghier;
      POSTORA;
    }

  EXEC SQL FETCH all_proghier INTO
       :rpt_prog_code:Ind_01,
       :rpt_prog_level:Ind_02;
  POSTORA;

  if ( NO_ROWS_FOUND )
    {
      *rpt_prog_code='\0';
      *rpt_prog_level='\0';
      return FALSE;
    }

  return TRUE;
}



static void spec_prog_hier(void)
{
  report(sel_spec_proghier,prog_body1,prog_body1,NULL);
}

static void level_prog_hier_1(void)
{
  report(sel_all_proghier,prog_body1,prog_body1,NULL);
}

static void level_prog_hier_2(void)
{
  report(sel_all_proghier,prog_body2,prog_body2,NULL);
}

static void level_prog_hier_3(void)
{
  report(sel_all_proghier,prog_body3,prog_body3,NULL);
}

static void level_prog_hier_4(void)
{
  report(sel_all_proghier,prog_body4,prog_body4,NULL);
}

static void level_prog_hier_5(void)
{
  report(sel_all_proghier,prog_body5,prog_body5,NULL);
}



static void prog_body1(void)
{
  if ( compare(rpt_prog_level,_TMC("1"),EQS) ) goto level1;
  if ( compare(rpt_prog_level,_TMC("2"),EQS) ) goto level2;
  if ( compare(rpt_prog_level,_TMC("3"),EQS) ) goto level3;
  if ( compare(rpt_prog_level,_TMC("4"),EQS) ) goto level4;
  if ( compare(rpt_prog_level,_TMC("5"),EQS) ) goto level5;
  level1:
    tmstrcpy(save_prog_level_1,rpt_prog_code);
    tmstrcpy(save_prog_level_2,_TMC("!"));
    tmstrcpy(save_prog_level_3,_TMC("!"));
    tmstrcpy(save_prog_level_4,_TMC("!"));
    tmstrcpy(save_prog_level_5,_TMC("!"));
    goto end;
  level2:
    tmstrcpy(save_prog_level_2,rpt_prog_code);
    tmstrcpy(save_prog_level_3,_TMC("!"));
    tmstrcpy(save_prog_level_4,_TMC("!"));
    tmstrcpy(save_prog_level_5,_TMC("!"));
    goto end;
  level3:
    tmstrcpy(save_prog_level_3,rpt_prog_code);
    tmstrcpy(save_prog_level_4,_TMC("!"));
    tmstrcpy(save_prog_level_5,_TMC("!"));
    goto end;
  level4:
    tmstrcpy(save_prog_level_4,rpt_prog_code);
    tmstrcpy(save_prog_level_5,_TMC("!"));
    goto end;
  level5:
    tmstrcpy(save_prog_level_5,rpt_prog_code);
  end:
    ins_fgrpghc();
}

/* PROG HIERARCHY WHEN PARM_PROG_LEVEL = 2 */

static void prog_body2(void)
{
  if ( compare(rpt_prog_level,_TMC("1"),EQS) ) return;
  if ( compare(rpt_prog_level,_TMC("2"),EQS) ) goto level1;
  if ( compare(rpt_prog_level,_TMC("3"),EQS) ) goto level2;
  if ( compare(rpt_prog_level,_TMC("4"),EQS) ) goto level3;
  if ( compare(rpt_prog_level,_TMC("5"),EQS) ) goto level4;
  level1:
    tmstrcpy(save_prog_level_1,rpt_prog_code);
    tmstrcpy(save_prog_level_2,_TMC("!"));
    tmstrcpy(save_prog_level_3,_TMC("!"));
    tmstrcpy(save_prog_level_4,_TMC("!"));
    tmstrcpy(save_prog_level_5,_TMC("!"));
    goto end;
  level2:
    tmstrcpy(save_prog_level_2,rpt_prog_code);
    tmstrcpy(save_prog_level_3,_TMC("!"));
    tmstrcpy(save_prog_level_4,_TMC("!"));
    tmstrcpy(save_prog_level_5,_TMC("!"));
    goto end;
  level3:
    tmstrcpy(save_prog_level_3,rpt_prog_code);
    tmstrcpy(save_prog_level_4,_TMC("!"));
    tmstrcpy(save_prog_level_5,_TMC("!"));
    goto end;
  level4:
    tmstrcpy(save_prog_level_4,rpt_prog_code);
    tmstrcpy(save_prog_level_5,_TMC("!"));
  end:
    ins_fgrpghc();

}

/* PROG HIERARCHY WHEN PARM_PROG_LEVEL = 3 */

static void prog_body3(void)
{
  if ( compare(rpt_prog_level,_TMC("1"),EQS) ) return;
  if ( compare(rpt_prog_level,_TMC("2"),EQS) ) return;
  if ( compare(rpt_prog_level,_TMC("3"),EQS) ) goto level1;
  if ( compare(rpt_prog_level,_TMC("4"),EQS) ) goto level2;
  if ( compare(rpt_prog_level,_TMC("5"),EQS) ) goto level3;
  level1:
    tmstrcpy(save_prog_level_1,rpt_prog_code);
    tmstrcpy(save_prog_level_2,_TMC("!"));
    tmstrcpy(save_prog_level_3,_TMC("!"));
    tmstrcpy(save_prog_level_4,_TMC("!"));
    tmstrcpy(save_prog_level_5,_TMC("!"));
    goto end;
  level2:
    tmstrcpy(save_prog_level_2,rpt_prog_code);
    tmstrcpy(save_prog_level_3,_TMC("!"));
    tmstrcpy(save_prog_level_4,_TMC("!"));
    tmstrcpy(save_prog_level_5,_TMC("!"));
    goto end;
  level3:
    tmstrcpy(save_prog_level_3,rpt_prog_code);
    tmstrcpy(save_prog_level_4,_TMC("!"));
    tmstrcpy(save_prog_level_5,_TMC("!"));
  end:
    ins_fgrpghc();

}

/* PROG HIERARCHY WHEN PARM_PROG_LEVEL = 4 */

static void prog_body4(void)
{
  if ( compare(rpt_prog_level,_TMC("1"),EQS) ) return;
  if ( compare(rpt_prog_level,_TMC("2"),EQS) ) return;
  if ( compare(rpt_prog_level,_TMC("3"),EQS) ) return;
  if ( compare(rpt_prog_level,_TMC("4"),EQS) ) goto level1;
  if ( compare(rpt_prog_level,_TMC("5"),EQS) ) goto level2;
  level1:
    tmstrcpy(save_prog_level_1,rpt_prog_code);
    tmstrcpy(save_prog_level_2,_TMC("!"));
    tmstrcpy(save_prog_level_3,_TMC("!"));
    tmstrcpy(save_prog_level_4,_TMC("!"));
    tmstrcpy(save_prog_level_5,_TMC("!"));
    goto end;
  level2:
    tmstrcpy(save_prog_level_2,rpt_prog_code);
    tmstrcpy(save_prog_level_3,_TMC("!"));
    tmstrcpy(save_prog_level_4,_TMC("!"));
    tmstrcpy(save_prog_level_5,_TMC("!"));
  end:
    ins_fgrpghc();

}

/* PROG HIERARCHY WHEN PARM_PROG_LEVEL = 5 */

static void prog_body5(void)
{
  if ( compare(rpt_prog_level,_TMC("1"),EQS) ) return;
  if ( compare(rpt_prog_level,_TMC("2"),EQS) ) return;
  if ( compare(rpt_prog_level,_TMC("3"),EQS) ) return;
  if ( compare(rpt_prog_level,_TMC("4"),EQS) ) return;
  tmstrcpy(save_prog_level_1,rpt_prog_code);
  tmstrcpy(save_prog_level_2,_TMC("!"));
  tmstrcpy(save_prog_level_3,_TMC("!"));
  tmstrcpy(save_prog_level_4,_TMC("!"));
  tmstrcpy(save_prog_level_5,_TMC("!"));
  ins_fgrpghc();

}

/* Insert records into the PROG collector file. */

static void ins_fgrpghc(void)
{
  EXEC SQL
        INSERT INTO FGRPGHC
               (FGRPGHC_SESS_ID,
                FGRPGHC_PROG_CODE,
                FGRPGHC_LEVEL,
                FGRPGHC_PROG_LEVEL_1,
                FGRPGHC_PROG_LEVEL_2,
                FGRPGHC_PROG_LEVEL_3,
                FGRPGHC_PROG_LEVEL_4,
                FGRPGHC_PROG_LEVEL_5)
        VALUES (USERENV('SESSIONID'),
                :rpt_prog_code,
                :rpt_prog_level,
                :save_prog_level_1,
                :save_prog_level_2,
                :save_prog_level_3,
                :save_prog_level_4,
                :save_prog_level_5);
  POSTORA;
}


static void ins_prog_exists(void)
{
  EXEC SQL
        INSERT INTO FGRPGHC
               (FGRPGHC_SESS_ID,
                FGRPGHC_PROG_CODE,
                FGRPGHC_LEVEL,
                FGRPGHC_PROG_LEVEL_1)
        select  USERENV('SESSIONID'),
                ftvprog_prog_code,
                'X',
                ftvprog_prog_code
        from    ftvprog
        where  FTVPROG_COAS_CODE    =  :par_coas
               AND  trunc(FTVPROG_EFF_DATE) <= to_date(:par_end_date,'DD-MON-YYYY')
               AND  trunc(FTVPROG_NCHG_DATE) >  to_date(:par_end_date,'DD-MON-YYYY');
  
  POSTORA;
}



static void prog_hier(void)
{
if (compare(par_hier,_TMC("F"),EQS))
  {
    coas_parm_sel(FIRST_ROW,par_prog_no,par_prog,temp);
    if (*par_prog) spec_prog_hier();
    else ins_prog_exists();
   }
if (compare(par_hier,_TMC("L"),EQS))
  {
   if (compare(par_prog_level,_TMC("E"),EQS)) ins_prog_exists();
   else if (compare(par_prog_level,_TMC("1"),EQS)) level_prog_hier_1();
   else if (compare(par_prog_level,_TMC("2"),EQS)) level_prog_hier_2();
   else if (compare(par_prog_level,_TMC("3"),EQS)) level_prog_hier_3();
   else if (compare(par_prog_level,_TMC("4"),EQS)) level_prog_hier_4();
   else if (compare(par_prog_level,_TMC("5"),EQS)) level_prog_hier_5();
   }   
}


/*  ACCT HIERARCHY SELECT FOR A SPECIFIC ACCT      */

static int sel_spec_accthier(int mode)
{
  EXEC SQL DECLARE spec_accthier CURSOR FOR
   SELECT FTVACCT_ACCT_CODE,
          LEVEL
        FROM FTVACCT
        CONNECT BY PRIOR FTVACCT_ACCT_CODE = FTVACCT_ACCT_CODE_PRED
               AND PRIOR FTVACCT_COAS_CODE = FTVACCT_COAS_CODE
               AND  trunc(FTVACCT_EFF_DATE) <=  to_date(:par_end_date,'DD-MON-YYYY')
               AND  trunc(FTVACCT_NCHG_DATE) >  to_date(:par_end_date,'DD-MON-YYYY')
         START WITH FTVACCT_ACCT_CODE    =  :par_acct
               AND  FTVACCT_COAS_CODE    =  :par_coas
               AND  trunc(FTVACCT_EFF_DATE) <= to_date(:par_end_date,'DD-MON-YYYY')
               AND  trunc(FTVACCT_NCHG_DATE) >  to_date(:par_end_date,'DD-MON-YYYY');

  if ( mode==CLOSE_CURSOR )
    {
      EXEC SQL CLOSE spec_accthier;
      POSTORA;
      return TRUE;
  }

  if ( mode==FIRST_ROW )
    {
      EXEC SQL OPEN spec_accthier;
      POSTORA;
    }

  EXEC SQL FETCH spec_accthier INTO
       :rpt_acct_code:Ind_01,
       :rpt_acct_level:Ind_02;
  POSTORA;

  if ( NO_ROWS_FOUND )
    {
      *rpt_acct_code='\0';
      *rpt_acct_level='\0';
      return FALSE;
    }

  return TRUE;
}

/*  ACCT HIERARCHY SELECT ALL ACCTS */

static int sel_all_accthier(int mode)
{
  EXEC SQL DECLARE all_accthier CURSOR FOR
   SELECT FTVACCT_ACCT_CODE,
          LEVEL
        FROM FTVACCT
        CONNECT BY PRIOR FTVACCT_ACCT_CODE = FTVACCT_ACCT_CODE_PRED
               AND PRIOR FTVACCT_COAS_CODE = FTVACCT_COAS_CODE
           AND   trunc(FTVACCT_EFF_DATE) <= to_date(:par_end_date,'DD-MON-YYYY')
           AND   trunc(FTVACCT_NCHG_DATE) >  to_date(:par_end_date,'DD-MON-YYYY')
         START WITH FTVACCT_ACCT_CODE_PRED IS NULL
           AND   :par_coas = FTVACCT_COAS_CODE
           AND   FTVACCT_EFF_DATE <= to_date(:par_end_date,'DD-MON-YYYY')
           AND   FTVACCT_NCHG_DATE >  to_date(:par_end_date,'DD-MON-YYYY');

  if ( mode==CLOSE_CURSOR )
    {
      EXEC SQL CLOSE all_accthier;
      POSTORA;
      return TRUE;
  }

  if ( mode==FIRST_ROW )
    {
      EXEC SQL OPEN all_accthier;
      POSTORA;
    }

  EXEC SQL FETCH all_accthier INTO
       :rpt_acct_code:Ind_01,
       :rpt_acct_level:Ind_02;
  POSTORA;

  if ( NO_ROWS_FOUND )
    {
      *rpt_acct_code='\0';
      *rpt_acct_level='\0';
      return FALSE;
    }

  return TRUE;
}



static void spec_acct_hier(void)
{
  report(sel_spec_accthier,acct_body1,acct_body1,NULL);
}

static void level_acct_hier_1(void)
{
  report(sel_all_accthier,acct_body1,acct_body1,NULL);
}

static void level_acct_hier_2(void)
{
  report(sel_all_accthier,acct_body2,acct_body2,NULL);
}

static void level_acct_hier_3(void)
{
  report(sel_all_accthier,acct_body3,acct_body3,NULL);
}

static void level_acct_hier_4(void)
{
  report(sel_all_accthier,acct_body4,acct_body4,NULL);
}




static void acct_body1(void)
{
  if ( compare(rpt_acct_level,_TMC("1"),EQS) ) goto level1;
  if ( compare(rpt_acct_level,_TMC("2"),EQS) ) goto level2;
  if ( compare(rpt_acct_level,_TMC("3"),EQS) ) goto level3;
  if ( compare(rpt_acct_level,_TMC("4"),EQS) ) goto level4;
  level1:
    tmstrcpy(save_acct_level_1,rpt_acct_code);
    tmstrcpy(save_acct_level_2,_TMC("!"));
    tmstrcpy(save_acct_level_3,_TMC("!"));
    tmstrcpy(save_acct_level_4,_TMC("!"));
    goto end;
  level2:
    tmstrcpy(save_acct_level_2,rpt_acct_code);
    tmstrcpy(save_acct_level_3,_TMC("!"));
    tmstrcpy(save_acct_level_4,_TMC("!"));
    goto end;
  level3:
    tmstrcpy(save_acct_level_3,rpt_acct_code);
    tmstrcpy(save_acct_level_4,_TMC("!"));
    goto end;
  level4:
    tmstrcpy(save_acct_level_4,rpt_acct_code);
    goto end;
  end:
    ins_fgrathc();
}

/* ACCT HIERARCHY WHEN PARM_ACCT_LEVEL = 2 */

static void acct_body2(void)
{
  if ( compare(rpt_acct_level,_TMC("1"),EQS) ) return;
  if ( compare(rpt_acct_level,_TMC("2"),EQS) ) goto level1;
  if ( compare(rpt_acct_level,_TMC("3"),EQS) ) goto level2;
  if ( compare(rpt_acct_level,_TMC("4"),EQS) ) goto level3;
  level1:
    tmstrcpy(save_acct_level_1,rpt_acct_code);
    tmstrcpy(save_acct_level_2,_TMC("!"));
    tmstrcpy(save_acct_level_3,_TMC("!"));
    tmstrcpy(save_acct_level_4,_TMC("!"));
    goto end;
  level2:
    tmstrcpy(save_acct_level_2,rpt_acct_code);
    tmstrcpy(save_acct_level_3,_TMC("!"));
    tmstrcpy(save_acct_level_4,_TMC("!"));
    goto end;
  level3:
    tmstrcpy(save_acct_level_3,rpt_acct_code);
    tmstrcpy(save_acct_level_4,_TMC("!"));
    goto end;
  end:
    ins_fgrathc();

}

/* ACCT HIERARCHY WHEN PARM_ACCT_LEVEL = 3 */

static void acct_body3(void)
{
  if ( compare(rpt_acct_level,_TMC("1"),EQS) ) return;
  if ( compare(rpt_acct_level,_TMC("2"),EQS) ) return;
  if ( compare(rpt_acct_level,_TMC("3"),EQS) ) goto level1;
  if ( compare(rpt_acct_level,_TMC("4"),EQS) ) goto level2;
  level1:
    tmstrcpy(save_acct_level_1,rpt_acct_code);
    tmstrcpy(save_acct_level_2,_TMC("!"));
    tmstrcpy(save_acct_level_3,_TMC("!"));
    tmstrcpy(save_acct_level_4,_TMC("!"));
    goto end;
  level2:
    tmstrcpy(save_acct_level_2,rpt_acct_code);
    tmstrcpy(save_acct_level_3,_TMC("!"));
    tmstrcpy(save_acct_level_4,_TMC("!"));
    goto end;
  end:
    ins_fgrathc();

}

/* ACCT HIERARCHY WHEN PARM_ACCT_LEVEL = 4 */

static void acct_body4(void)
{
  if ( compare(rpt_acct_level,_TMC("1"),EQS) ) return;
  if ( compare(rpt_acct_level,_TMC("2"),EQS) ) return;
  if ( compare(rpt_acct_level,_TMC("3"),EQS) ) return;
  if ( compare(rpt_acct_level,_TMC("4"),EQS) ) goto level1;
  level1:
    tmstrcpy(save_acct_level_1,rpt_acct_code);
    tmstrcpy(save_acct_level_2,_TMC("!"));
    tmstrcpy(save_acct_level_3,_TMC("!"));
    tmstrcpy(save_acct_level_4,_TMC("!"));
    goto end;
  end:
    ins_fgrathc();

}

/* Insert records into the ACCT collector file. */

static void ins_fgrathc(void)
{
  EXEC SQL
        INSERT INTO FGRATHC
               (FGRATHC_SESS_ID,
                FGRATHC_ACCT_CODE,
                FGRATHC_LEVEL,
                FGRATHC_ATYP_CODE,
                FGRATHC_INTERNAL_ATYP_CODE,
                FGRATHC_ACCT_LEVEL_1,
                FGRATHC_ACCT_LEVEL_2,
                FGRATHC_ACCT_LEVEL_3,
                FGRATHC_ACCT_LEVEL_4)
        VALUES (USERENV('SESSIONID'),
                :rpt_acct_code,
                :rpt_acct_level,
                'X',
                'X',
                :save_acct_level_1,
                :save_acct_level_2,
                :save_acct_level_3,
                :save_acct_level_4);
  POSTORA;
}


static void ins_acct_exists(void)
{
  EXEC SQL
        INSERT INTO FGRATHC
               (FGRATHC_SESS_ID,
                FGRATHC_ACCT_CODE,
                FGRATHC_LEVEL,
                FGRATHC_ATYP_CODE,
                FGRATHC_INTERNAL_ATYP_CODE,
                FGRATHC_ACCT_LEVEL_1)
        select  USERENV('SESSIONID'),
                ftvacct_acct_code,
                'X',
                'X',
                'X',
                ftvacct_acct_code
        from    ftvacct
        where  FTVACCT_COAS_CODE    =  :par_coas
               AND  trunc(FTVACCT_EFF_DATE) <= to_date(:par_end_date,'DD-MON-YYYY')
               AND  trunc(FTVACCT_NCHG_DATE) >  to_date(:par_end_date,'DD-MON-YYYY');
  
  POSTORA;
}



static void acct_hier(void)
{
if (compare(par_hier,_TMC("F"),EQS))
  {
    coas_parm_sel(FIRST_ROW,par_acct_no,par_acct,temp);
    if (*par_acct) spec_acct_hier();
    else ins_acct_exists();
   }
if (compare(par_hier,_TMC("L"),EQS))
  {
   if (compare(par_acct_level,_TMC("E"),EQS)) ins_acct_exists();
   else if (compare(par_acct_level,_TMC("1"),EQS)) level_acct_hier_1();
   else if (compare(par_acct_level,_TMC("2"),EQS)) level_acct_hier_2();
   else if (compare(par_acct_level,_TMC("3"),EQS)) level_acct_hier_3();
   else if (compare(par_acct_level,_TMC("4"),EQS)) level_acct_hier_4();
   }   
}


/*  ORGN HIERARCHY SELECT FOR A SPECIFIC ORGN      */

static int sel_spec_orgnhier(int mode)
{
  EXEC SQL DECLARE spec_orgnhier CURSOR FOR
   SELECT FTVORGN_ORGN_CODE,
          LEVEL,
          ftvorgn_title
        FROM FTVORGN
        CONNECT BY PRIOR FTVORGN_ORGN_CODE = FTVORGN_ORGN_CODE_PRED
               AND PRIOR FTVORGN_COAS_CODE = FTVORGN_COAS_CODE
               AND  trunc(FTVORGN_EFF_DATE) <=  to_date(:par_end_date,'DD-MON-YYYY')
               AND  trunc(FTVORGN_NCHG_DATE) >  to_date(:par_end_date,'DD-MON-YYYY')
         START WITH FTVORGN_ORGN_CODE    =  :par_orgn
               AND  FTVORGN_COAS_CODE    =  :par_coas
               AND  trunc(FTVORGN_EFF_DATE) <= to_date(:par_end_date,'DD-MON-YYYY')
               AND  trunc(FTVORGN_NCHG_DATE) >  to_date(:par_end_date,'DD-MON-YYYY');

  if ( mode==CLOSE_CURSOR )
    {
      EXEC SQL CLOSE spec_orgnhier;
      POSTORA;
      return TRUE;
  }

  if ( mode==FIRST_ROW )
    {
      EXEC SQL OPEN spec_orgnhier;
      POSTORA;
    }

  EXEC SQL FETCH spec_orgnhier INTO
       :rpt_orgn_code:Ind_01,
       :rpt_orgn_level:Ind_02,
       :rpt_orgn_title:Ind_03;
  POSTORA;

  if ( NO_ROWS_FOUND )
    {
      *rpt_orgn_code='\0';
      *rpt_orgn_level='\0';
      *rpt_orgn_title='\0';
      return FALSE;
    }

  return TRUE;
}

/*  ORGN HIERARCHY SELECT ALL ORGNS */

static int sel_all_orgnhier(int mode)
{
  EXEC SQL DECLARE all_orgnhier CURSOR FOR
   SELECT FTVORGN_ORGN_CODE,
          LEVEL,
          ftvorgn_title
        FROM FTVORGN
        CONNECT BY PRIOR FTVORGN_ORGN_CODE = FTVORGN_ORGN_CODE_PRED
               AND PRIOR FTVORGN_COAS_CODE = FTVORGN_COAS_CODE
           AND   trunc(FTVORGN_EFF_DATE) <= to_date(:par_end_date,'DD-MON-YYYY')
           AND   trunc(FTVORGN_NCHG_DATE) >  to_date(:par_end_date,'DD-MON-YYYY')
         START WITH FTVORGN_ORGN_CODE_PRED IS NULL
           AND   :par_coas = FTVORGN_COAS_CODE
           AND   FTVORGN_EFF_DATE <= to_date(:par_end_date,'DD-MON-YYYY')
           AND   FTVORGN_NCHG_DATE >  to_date(:par_end_date,'DD-MON-YYYY');

  if ( mode==CLOSE_CURSOR )
    {
      EXEC SQL CLOSE all_orgnhier;
      POSTORA;
      return TRUE;
  }

  if ( mode==FIRST_ROW )
    {
      EXEC SQL OPEN all_orgnhier;
      POSTORA;
    }

  EXEC SQL FETCH all_orgnhier INTO
       :rpt_orgn_code:Ind_01,
       :rpt_orgn_level:Ind_02,
       :rpt_orgn_title:Ind_03;
  POSTORA;

  if ( NO_ROWS_FOUND )
    {
      *rpt_orgn_code='\0';
      *rpt_orgn_level='\0';
      *rpt_orgn_title='\0';
      return FALSE;
    }

  return TRUE;
}



static void spec_orgn_hier(void)
{
  report(sel_spec_orgnhier,orgn_body1,orgn_body1,NULL);
}

static void level_orgn_hier_1(void)
{
  report(sel_all_orgnhier,orgn_body1,orgn_body1,NULL);
}

static void level_orgn_hier_2(void)
{
  report(sel_all_orgnhier,orgn_body2,orgn_body2,NULL);
}

static void level_orgn_hier_3(void)
{
  report(sel_all_orgnhier,orgn_body3,orgn_body3,NULL);
}

static void level_orgn_hier_4(void)
{
  report(sel_all_orgnhier,orgn_body4,orgn_body4,NULL);
}

static void level_orgn_hier_5(void)
{
  report(sel_all_orgnhier,orgn_body5,orgn_body5,NULL);
}

static void level_orgn_hier_6(void)
{
  report(sel_all_orgnhier,orgn_body6,orgn_body6,NULL);
}

static void level_orgn_hier_7(void)
{
  report(sel_all_orgnhier,orgn_body7,orgn_body7,NULL);
}


static void level_orgn_hier_8(void)
{
  report(sel_all_orgnhier,orgn_body8,orgn_body8,NULL);
}




static void orgn_body1(void)
{
  if ( compare(rpt_orgn_level,_TMC("1"),EQS) ) goto level1;
  if ( compare(rpt_orgn_level,_TMC("2"),EQS) ) goto level2;
  if ( compare(rpt_orgn_level,_TMC("3"),EQS) ) goto level3;
  if ( compare(rpt_orgn_level,_TMC("4"),EQS) ) goto level4;
 if ( compare(rpt_orgn_level,_TMC("5"),EQS) ) goto level5;
  if ( compare(rpt_orgn_level,_TMC("6"),EQS) ) goto level6;
  if ( compare(rpt_orgn_level,_TMC("7"),EQS) ) goto level7;
  if ( compare(rpt_orgn_level,_TMC("8"),EQS) ) goto level8;
  level1:
    tmstrcpy(save_orgn_level_1,rpt_orgn_code);
    tmstrcpy(save_orgn_level_2,_TMC("!"));
    tmstrcpy(save_orgn_level_3,_TMC("!"));
    tmstrcpy(save_orgn_level_4,_TMC("!"));
    tmstrcpy(save_orgn_level_5,_TMC("!"));
    tmstrcpy(save_orgn_level_6,_TMC("!"));
    tmstrcpy(save_orgn_level_7,_TMC("!"));
    tmstrcpy(save_orgn_level_8,_TMC("!"));
    goto end;
  level2:
    tmstrcpy(save_orgn_level_2,rpt_orgn_code);
    tmstrcpy(save_orgn_level_3,_TMC("!"));
    tmstrcpy(save_orgn_level_4,_TMC("!"));
    tmstrcpy(save_orgn_level_5,_TMC("!"));
    tmstrcpy(save_orgn_level_6,_TMC("!"));
    tmstrcpy(save_orgn_level_7,_TMC("!"));
    tmstrcpy(save_orgn_level_8,_TMC("!"));
    goto end;
  level3:
    tmstrcpy(save_orgn_level_3,rpt_orgn_code);
    tmstrcpy(save_orgn_level_4,_TMC("!"));
    tmstrcpy(save_orgn_level_5,_TMC("!"));
    tmstrcpy(save_orgn_level_6,_TMC("!"));
    tmstrcpy(save_orgn_level_7,_TMC("!"));
    tmstrcpy(save_orgn_level_8,_TMC("!"));
    goto end;
  level4:
    tmstrcpy(save_orgn_level_4,rpt_orgn_code);
    tmstrcpy(save_orgn_level_5,_TMC("!"));
    tmstrcpy(save_orgn_level_6,_TMC("!"));
    tmstrcpy(save_orgn_level_7,_TMC("!"));
    tmstrcpy(save_orgn_level_8,_TMC("!"));
    goto end;
  level5:
    tmstrcpy(save_orgn_level_5,rpt_orgn_code);
    tmstrcpy(save_orgn_level_6,_TMC("!"));
    tmstrcpy(save_orgn_level_7,_TMC("!"));
    tmstrcpy(save_orgn_level_8,_TMC("!"));
    goto end;
  level6:
    tmstrcpy(save_orgn_level_6,rpt_orgn_code);
    tmstrcpy(save_orgn_level_7,_TMC("!"));
    tmstrcpy(save_orgn_level_8,_TMC("!"));
    goto end;
  level7:
    tmstrcpy(save_orgn_level_7,rpt_orgn_code);
    tmstrcpy(save_orgn_level_8,_TMC("!"));
    goto end;
  level8:
    tmstrcpy(save_orgn_level_8,rpt_orgn_code);
    goto end;

  end:
    ins_fgrorhc();
}

/* ORGN HIERARCHY WHEN PARM_ORGN_LEVEL = 2 */

static void orgn_body2(void)
{
  if ( compare(rpt_orgn_level,_TMC("1"),EQS) ) return;
  if ( compare(rpt_orgn_level,_TMC("2"),EQS) ) goto level1;
  if ( compare(rpt_orgn_level,_TMC("3"),EQS) ) goto level2;
  if ( compare(rpt_orgn_level,_TMC("4"),EQS) ) goto level3;
  if ( compare(rpt_orgn_level,_TMC("5"),EQS) ) goto level4;
  if ( compare(rpt_orgn_level,_TMC("6"),EQS) ) goto level5;
  if ( compare(rpt_orgn_level,_TMC("7"),EQS) ) goto level6;
  if ( compare(rpt_orgn_level,_TMC("8"),EQS) ) goto level7;
  level1:
    tmstrcpy(save_orgn_level_1,rpt_orgn_code);
    tmstrcpy(save_orgn_level_2,_TMC("!"));
    tmstrcpy(save_orgn_level_3,_TMC("!"));
    tmstrcpy(save_orgn_level_4,_TMC("!"));
    tmstrcpy(save_orgn_level_5,_TMC("!"));
    tmstrcpy(save_orgn_level_6,_TMC("!"));
    tmstrcpy(save_orgn_level_7,_TMC("!"));
    tmstrcpy(save_orgn_level_8,_TMC("!"));
    goto end;
  level2:
    tmstrcpy(save_orgn_level_2,rpt_orgn_code);
    tmstrcpy(save_orgn_level_3,_TMC("!"));
    tmstrcpy(save_orgn_level_4,_TMC("!"));
    tmstrcpy(save_orgn_level_5,_TMC("!"));
    tmstrcpy(save_orgn_level_6,_TMC("!"));
    tmstrcpy(save_orgn_level_7,_TMC("!"));
    tmstrcpy(save_orgn_level_8,_TMC("!"));
    goto end;
  level3:
    tmstrcpy(save_orgn_level_3,rpt_orgn_code);
    tmstrcpy(save_orgn_level_4,_TMC("!"));
    tmstrcpy(save_orgn_level_5,_TMC("!"));
    tmstrcpy(save_orgn_level_6,_TMC("!"));
    tmstrcpy(save_orgn_level_7,_TMC("!"));
    tmstrcpy(save_orgn_level_8,_TMC("!"));
    goto end;
  level4:
    tmstrcpy(save_orgn_level_4,rpt_orgn_code);
    tmstrcpy(save_orgn_level_5,_TMC("!"));
    tmstrcpy(save_orgn_level_6,_TMC("!"));
    tmstrcpy(save_orgn_level_7,_TMC("!"));
    tmstrcpy(save_orgn_level_8,_TMC("!"));
    goto end;
  level5:
    tmstrcpy(save_orgn_level_5,rpt_orgn_code);
    tmstrcpy(save_orgn_level_6,_TMC("!"));
    tmstrcpy(save_orgn_level_7,_TMC("!"));
    tmstrcpy(save_orgn_level_8,_TMC("!"));
    goto end;
  level6:
    tmstrcpy(save_orgn_level_6,rpt_orgn_code);
    tmstrcpy(save_orgn_level_7,_TMC("!"));
    tmstrcpy(save_orgn_level_8,_TMC("!"));
    goto end;
  level7:
    tmstrcpy(save_orgn_level_7,rpt_orgn_code);
    tmstrcpy(save_orgn_level_8,_TMC("!"));
    goto end;

  end:
    ins_fgrorhc();

}

/* ORGN HIERARCHY WHEN PARM_ORGN_LEVEL = 3 */

static void orgn_body3(void)
{
  if ( compare(rpt_orgn_level,_TMC("1"),EQS) ) return;
  if ( compare(rpt_orgn_level,_TMC("2"),EQS) ) return;
  if ( compare(rpt_orgn_level,_TMC("3"),EQS) ) goto level1;
  if ( compare(rpt_orgn_level,_TMC("4"),EQS) ) goto level2;
 if ( compare(rpt_orgn_level,_TMC("5"),EQS) ) goto level3;
  if ( compare(rpt_orgn_level,_TMC("6"),EQS) ) goto level4;
  if ( compare(rpt_orgn_level,_TMC("7"),EQS) ) goto level5;
  if ( compare(rpt_orgn_level,_TMC("8"),EQS) ) goto level6;
  level1:
    tmstrcpy(save_orgn_level_1,rpt_orgn_code);
    tmstrcpy(save_orgn_level_2,_TMC("!"));
    tmstrcpy(save_orgn_level_3,_TMC("!"));
    tmstrcpy(save_orgn_level_4,_TMC("!"));
    tmstrcpy(save_orgn_level_5,_TMC("!"));
    tmstrcpy(save_orgn_level_6,_TMC("!"));
    tmstrcpy(save_orgn_level_7,_TMC("!"));
    tmstrcpy(save_orgn_level_8,_TMC("!"));
    goto end;
  level2:
    tmstrcpy(save_orgn_level_2,rpt_orgn_code);
    tmstrcpy(save_orgn_level_3,_TMC("!"));
    tmstrcpy(save_orgn_level_4,_TMC("!"));
    tmstrcpy(save_orgn_level_5,_TMC("!"));
    tmstrcpy(save_orgn_level_6,_TMC("!"));
    tmstrcpy(save_orgn_level_7,_TMC("!"));
    tmstrcpy(save_orgn_level_8,_TMC("!"));
    goto end;
  level3:
    tmstrcpy(save_orgn_level_3,rpt_orgn_code);
    tmstrcpy(save_orgn_level_4,_TMC("!"));
    tmstrcpy(save_orgn_level_5,_TMC("!"));
    tmstrcpy(save_orgn_level_6,_TMC("!"));
    tmstrcpy(save_orgn_level_7,_TMC("!"));
    tmstrcpy(save_orgn_level_8,_TMC("!"));
    goto end;
  level4:
    tmstrcpy(save_orgn_level_4,rpt_orgn_code);
    tmstrcpy(save_orgn_level_5,_TMC("!"));
    tmstrcpy(save_orgn_level_6,_TMC("!"));
    tmstrcpy(save_orgn_level_7,_TMC("!"));
    tmstrcpy(save_orgn_level_8,_TMC("!"));
    goto end;
  level5:
    tmstrcpy(save_orgn_level_5,rpt_orgn_code);
    tmstrcpy(save_orgn_level_6,_TMC("!"));
    tmstrcpy(save_orgn_level_7,_TMC("!"));
    tmstrcpy(save_orgn_level_8,_TMC("!"));
    goto end;
  level6:
    tmstrcpy(save_orgn_level_6,rpt_orgn_code);
    tmstrcpy(save_orgn_level_7,_TMC("!"));
    tmstrcpy(save_orgn_level_8,_TMC("!"));
    goto end;

  end:
    ins_fgrorhc();

}

/* ORGN HIERARCHY WHEN PARM_ORGN_LEVEL = 4 */

static void orgn_body4(void)
{
  if ( compare(rpt_orgn_level,_TMC("1"),EQS) ) return;
  if ( compare(rpt_orgn_level,_TMC("2"),EQS) ) return;
  if ( compare(rpt_orgn_level,_TMC("3"),EQS) ) return;
  if ( compare(rpt_orgn_level,_TMC("4"),EQS) ) goto level1;
 if ( compare(rpt_orgn_level,_TMC("5"),EQS) ) goto level2;
  if ( compare(rpt_orgn_level,_TMC("6"),EQS) ) goto level3;
  if ( compare(rpt_orgn_level,_TMC("7"),EQS) ) goto level4;
  if ( compare(rpt_orgn_level,_TMC("8"),EQS) ) goto level5;
  level1:
    tmstrcpy(save_orgn_level_1,rpt_orgn_code);
    tmstrcpy(save_orgn_level_2,_TMC("!"));
    tmstrcpy(save_orgn_level_3,_TMC("!"));
    tmstrcpy(save_orgn_level_4,_TMC("!"));
    tmstrcpy(save_orgn_level_5,_TMC("!"));
    tmstrcpy(save_orgn_level_6,_TMC("!"));
    tmstrcpy(save_orgn_level_7,_TMC("!"));
    tmstrcpy(save_orgn_level_8,_TMC("!"));
    goto end;
  level2:
    tmstrcpy(save_orgn_level_2,rpt_orgn_code);
    tmstrcpy(save_orgn_level_3,_TMC("!"));
    tmstrcpy(save_orgn_level_4,_TMC("!"));
    tmstrcpy(save_orgn_level_5,_TMC("!"));
    tmstrcpy(save_orgn_level_6,_TMC("!"));
    tmstrcpy(save_orgn_level_7,_TMC("!"));
    tmstrcpy(save_orgn_level_8,_TMC("!"));
    goto end;
  level3:
    tmstrcpy(save_orgn_level_3,rpt_orgn_code);
    tmstrcpy(save_orgn_level_4,_TMC("!"));
    tmstrcpy(save_orgn_level_5,_TMC("!"));
    tmstrcpy(save_orgn_level_6,_TMC("!"));
    tmstrcpy(save_orgn_level_7,_TMC("!"));
    tmstrcpy(save_orgn_level_8,_TMC("!"));
    goto end;
  level4:
    tmstrcpy(save_orgn_level_4,rpt_orgn_code);
    tmstrcpy(save_orgn_level_5,_TMC("!"));
    tmstrcpy(save_orgn_level_6,_TMC("!"));
    tmstrcpy(save_orgn_level_7,_TMC("!"));
    tmstrcpy(save_orgn_level_8,_TMC("!"));
    goto end;
  level5:
    tmstrcpy(save_orgn_level_5,rpt_orgn_code);
    tmstrcpy(save_orgn_level_6,_TMC("!"));
    tmstrcpy(save_orgn_level_7,_TMC("!"));
    tmstrcpy(save_orgn_level_8,_TMC("!"));
    goto end;
  end:
    ins_fgrorhc();

}


/* ORGN HIERARCHY WHEN PARM_ORGN_LEVEL = 5 */

static void orgn_body5(void)
{
  if ( compare(rpt_orgn_level,_TMC("1"),EQS) ) return;
  if ( compare(rpt_orgn_level,_TMC("2"),EQS) ) return;
  if ( compare(rpt_orgn_level,_TMC("3"),EQS) ) return;
  if ( compare(rpt_orgn_level,_TMC("4"),EQS) ) return;
 if ( compare(rpt_orgn_level,_TMC("5"),EQS) ) goto level1;
  if ( compare(rpt_orgn_level,_TMC("6"),EQS) ) goto level2;
  if ( compare(rpt_orgn_level,_TMC("7"),EQS) ) goto level3;
  if ( compare(rpt_orgn_level,_TMC("8"),EQS) ) goto level4;
  level1:
    tmstrcpy(save_orgn_level_1,rpt_orgn_code);
    tmstrcpy(save_orgn_level_2,_TMC("!"));
    tmstrcpy(save_orgn_level_3,_TMC("!"));
    tmstrcpy(save_orgn_level_4,_TMC("!"));
    tmstrcpy(save_orgn_level_5,_TMC("!"));
    tmstrcpy(save_orgn_level_6,_TMC("!"));
    tmstrcpy(save_orgn_level_7,_TMC("!"));
    tmstrcpy(save_orgn_level_8,_TMC("!"));
    goto end;
  level2:
    tmstrcpy(save_orgn_level_2,rpt_orgn_code);
    tmstrcpy(save_orgn_level_3,_TMC("!"));
    tmstrcpy(save_orgn_level_4,_TMC("!"));
    tmstrcpy(save_orgn_level_5,_TMC("!"));
    tmstrcpy(save_orgn_level_6,_TMC("!"));
    tmstrcpy(save_orgn_level_7,_TMC("!"));
    tmstrcpy(save_orgn_level_8,_TMC("!"));
    goto end;
  level3:
    tmstrcpy(save_orgn_level_3,rpt_orgn_code);
    tmstrcpy(save_orgn_level_4,_TMC("!"));
    tmstrcpy(save_orgn_level_5,_TMC("!"));
    tmstrcpy(save_orgn_level_6,_TMC("!"));
    tmstrcpy(save_orgn_level_7,_TMC("!"));
    tmstrcpy(save_orgn_level_8,_TMC("!"));
    goto end;
  level4:
    tmstrcpy(save_orgn_level_4,rpt_orgn_code);
    tmstrcpy(save_orgn_level_5,_TMC("!"));
    tmstrcpy(save_orgn_level_6,_TMC("!"));
    tmstrcpy(save_orgn_level_7,_TMC("!"));
    tmstrcpy(save_orgn_level_8,_TMC("!"));
    goto end;
  end:
    ins_fgrorhc();

}


/* ORGN HIERARCHY WHEN PARM_ORGN_LEVEL = 6 */

static void orgn_body6(void)
{
  if ( compare(rpt_orgn_level,_TMC("1"),EQS) ) return;
  if ( compare(rpt_orgn_level,_TMC("2"),EQS) ) return;
  if ( compare(rpt_orgn_level,_TMC("3"),EQS) ) return;
  if ( compare(rpt_orgn_level,_TMC("4"),EQS) ) return;
 if ( compare(rpt_orgn_level,_TMC("5"),EQS) )  return;
  if ( compare(rpt_orgn_level,_TMC("6"),EQS) ) goto level1;
  if ( compare(rpt_orgn_level,_TMC("7"),EQS) ) goto level2;
  if ( compare(rpt_orgn_level,_TMC("8"),EQS) ) goto level3;
  level1:
    tmstrcpy(save_orgn_level_1,rpt_orgn_code);
    tmstrcpy(save_orgn_level_2,_TMC("!"));
    tmstrcpy(save_orgn_level_3,_TMC("!"));
    tmstrcpy(save_orgn_level_4,_TMC("!"));
    tmstrcpy(save_orgn_level_5,_TMC("!"));
    tmstrcpy(save_orgn_level_6,_TMC("!"));
    tmstrcpy(save_orgn_level_7,_TMC("!"));
    tmstrcpy(save_orgn_level_8,_TMC("!"));
    goto end;
  level2:
    tmstrcpy(save_orgn_level_2,rpt_orgn_code);
    tmstrcpy(save_orgn_level_3,_TMC("!"));
    tmstrcpy(save_orgn_level_4,_TMC("!"));
    tmstrcpy(save_orgn_level_5,_TMC("!"));
    tmstrcpy(save_orgn_level_6,_TMC("!"));
    tmstrcpy(save_orgn_level_7,_TMC("!"));
    tmstrcpy(save_orgn_level_8,_TMC("!"));
    goto end;
  level3:
    tmstrcpy(save_orgn_level_3,rpt_orgn_code);
    tmstrcpy(save_orgn_level_4,_TMC("!"));
    tmstrcpy(save_orgn_level_5,_TMC("!"));
    tmstrcpy(save_orgn_level_6,_TMC("!"));
    tmstrcpy(save_orgn_level_7,_TMC("!"));
    tmstrcpy(save_orgn_level_8,_TMC("!"));
    goto end;
  end:
    ins_fgrorhc();

}


/* ORGN HIERARCHY WHEN PARM_ORGN_LEVEL = 7 */

static void orgn_body7(void)
{
  if ( compare(rpt_orgn_level,_TMC("1"),EQS) ) return;
  if ( compare(rpt_orgn_level,_TMC("2"),EQS) ) return;
  if ( compare(rpt_orgn_level,_TMC("3"),EQS) ) return;
  if ( compare(rpt_orgn_level,_TMC("4"),EQS) ) return;
 if ( compare(rpt_orgn_level,_TMC("5"),EQS) ) return;
  if ( compare(rpt_orgn_level,_TMC("6"),EQS) ) return;
  if ( compare(rpt_orgn_level,_TMC("7"),EQS) ) goto level1;
  if ( compare(rpt_orgn_level,_TMC("8"),EQS) ) goto level2;
  level1:
    tmstrcpy(save_orgn_level_1,rpt_orgn_code);
    tmstrcpy(save_orgn_level_2,_TMC("!"));
    tmstrcpy(save_orgn_level_3,_TMC("!"));
    tmstrcpy(save_orgn_level_4,_TMC("!"));
    tmstrcpy(save_orgn_level_5,_TMC("!"));
    tmstrcpy(save_orgn_level_6,_TMC("!"));
    tmstrcpy(save_orgn_level_7,_TMC("!"));
    tmstrcpy(save_orgn_level_8,_TMC("!"));
    goto end;
  level2:
    tmstrcpy(save_orgn_level_2,rpt_orgn_code);
    tmstrcpy(save_orgn_level_3,_TMC("!"));
    tmstrcpy(save_orgn_level_4,_TMC("!"));
    tmstrcpy(save_orgn_level_5,_TMC("!"));
    tmstrcpy(save_orgn_level_6,_TMC("!"));
    tmstrcpy(save_orgn_level_7,_TMC("!"));
    tmstrcpy(save_orgn_level_8,_TMC("!"));
    goto end;
  end:
    ins_fgrorhc();

}


/* ORGN HIERARCHY WHEN PARM_ORGN_LEVEL = 8 */

static void orgn_body8(void)
{
  if ( compare(rpt_orgn_level,_TMC("1"),EQS) ) return;
  if ( compare(rpt_orgn_level,_TMC("2"),EQS) ) return;
  if ( compare(rpt_orgn_level,_TMC("3"),EQS) ) return;
  if ( compare(rpt_orgn_level,_TMC("4"),EQS) ) return;
 if ( compare(rpt_orgn_level,_TMC("5"),EQS) ) return;
  if ( compare(rpt_orgn_level,_TMC("6"),EQS) ) return;
  if ( compare(rpt_orgn_level,_TMC("7"),EQS) ) return;
  if ( compare(rpt_orgn_level,_TMC("8"),EQS) ) goto level1;
  level1:
    tmstrcpy(save_orgn_level_1,rpt_orgn_code);
    tmstrcpy(save_orgn_level_2,_TMC("!"));
    tmstrcpy(save_orgn_level_3,_TMC("!"));
    tmstrcpy(save_orgn_level_4,_TMC("!"));
    tmstrcpy(save_orgn_level_5,_TMC("!"));
    tmstrcpy(save_orgn_level_6,_TMC("!"));
    tmstrcpy(save_orgn_level_7,_TMC("!"));
    tmstrcpy(save_orgn_level_8,_TMC("!"));
    goto end;
  end:
    ins_fgrorhc();

}


/* Insert records into the ORGN collector file. */

static void ins_fgrorhc(void)
{
  EXEC SQL
        INSERT INTO FGRORHC
               (FGRORHC_SESS_ID,
                FGRORHC_ORGN_CODE,
                FGRORHC_LEVEL,
                FGRORHC_title,
                FGRORHC_ORGN_LEVEL_1,
                FGRORHC_ORGN_LEVEL_2,
                FGRORHC_ORGN_LEVEL_3,
                FGRORHC_ORGN_LEVEL_4,
                FGRORHC_ORGN_LEVEL_5,
                FGRORHC_ORGN_LEVEL_6,
                FGRORHC_ORGN_LEVEL_7,
                FGRORHC_ORGN_LEVEL_8)
        VALUES (USERENV('SESSIONID'),
                :rpt_orgn_code,
                :rpt_orgn_level,
                :rpt_orgn_title,
                :save_orgn_level_1,
                :save_orgn_level_2,
                :save_orgn_level_3,
                :save_orgn_level_4,
                :save_orgn_level_5,
                :save_orgn_level_6,
                :save_orgn_level_7,
                :save_orgn_level_8);
  POSTORA;
}


static void ins_orgn_exists(void)
{
  EXEC SQL
        INSERT INTO FGRORHC
               (FGRORHC_SESS_ID,
                FGRORHC_ORGN_CODE,
                FGRORHC_LEVEL,
                fgrorhc_title,
                FGRORHC_ORGN_LEVEL_1)
        select  USERENV('SESSIONID'),
                ftvorgn_orgn_code,
                'X',
                ftvorgn_title,
                ftvorgn_orgn_code
        from    ftvorgn
        where  FTVORGN_COAS_CODE    =  :par_coas
               AND  trunc(FTVORGN_EFF_DATE) <= to_date(:par_end_date,'DD-MON-YYYY')
               AND  trunc(FTVORGN_NCHG_DATE) >  to_date(:par_end_date,'DD-MON-YYYY');
  
  POSTORA;
}



static void orgn_hier(void)
{
if (compare(par_hier,_TMC("F"),EQS))
  {
    coas_parm_sel(FIRST_ROW,par_orgn_no,par_orgn,temp);
    if (*par_orgn) spec_orgn_hier();
    else ins_orgn_exists();
   }
if (compare(par_hier,_TMC("L"),EQS))
  {
   if (compare(par_orgn_level,_TMC("E"),EQS)) ins_orgn_exists();
   else if (compare(par_orgn_level,_TMC("1"),EQS)) level_orgn_hier_1();
   else if (compare(par_orgn_level,_TMC("2"),EQS)) level_orgn_hier_2();
   else if (compare(par_orgn_level,_TMC("3"),EQS)) level_orgn_hier_3();
   else if (compare(par_orgn_level,_TMC("4"),EQS)) level_orgn_hier_4();
   else if (compare(par_orgn_level,_TMC("5"),EQS)) level_orgn_hier_5();
   else if (compare(par_orgn_level,_TMC("6"),EQS)) level_orgn_hier_6();
   else if (compare(par_orgn_level,_TMC("7"),EQS)) level_orgn_hier_7();
   else if (compare(par_orgn_level,_TMC("8"),EQS)) level_orgn_hier_8();
   }   
}


static void retrieve_parms(void)
{
        tmstrcpy(par_from,_TMC("J"));

get_report_type:
        sel_gjbprun_par(FIRST_ROW,par_report_type_no,par_report_type);
        sel_gjbprun_par(FIRST_ROW,par_sort_option_no,par_sort_option);
        sel_gjbprun_par(FIRST_ROW,par_begin_date_no,par_begin_date);
        sel_gjbprun_par(FIRST_ROW,par_end_date_no,par_end_date);
   validate_dates();
if (compare(are_parameters_valid,TM_NLS_Get("0167","NO"),EQS)) return;

  get_pict:
      sel_gjbprun_par(FIRST_ROW,par_pict_no,par_pict);      
      if (*par_pict)    ins_par_pict();
      else   tmstrcpy(all_pict,_TMC("Y"));


      sel_gjbprun_par(FIRST_ROW,par_ecls_no,par_ecls);      
      if (*par_ecls)    ins_par_ecls_code();
      else   tmstrcpy(all_ecls,_TMC("Y"));
      sel_gjbprun_par(FIRST_ROW,par_empl_id_no,par_empl_id);      
      if (*par_empl_id)    ins_par_empl_id();
      else   tmstrcpy(all_empl,_TMC("Y"));
         sel_gjbprun_par(FIRST_ROW,par_hier_no,par_hier);
get_levels:
     if (compare(par_hier,_TMC("L"),EQS))
 {
         sel_gjbprun_par(FIRST_ROW,par_fund_level_no,par_fund_level);
         sel_gjbprun_par(FIRST_ROW,par_orgn_level_no,par_orgn_level);
         sel_gjbprun_par(FIRST_ROW,par_acct_level_no,par_acct_level);
         sel_gjbprun_par(FIRST_ROW,par_prog_level_no,par_prog_level);
}

get_coas_code:
if (compare(par_sort_option,_TMC("H"),EQS))
  {
      sel_gjbprun_par(FIRST_ROW,par_home_coas_no,par_home_coas);      
if (*par_home_coas) retr_home_parms();
    }
            ins_par_coas_code();
         report(sel_coas,retr_coas_parms_body,NULL,NULL);
}

static void retr_coas_parms_body(void)
{


if (compare(par_sort_option,_TMC("H"),EQS))
  if (!*par_home_coas) retr_home_parms();
chk_hier:
if (compare(par_hier,_TMC("L"),EQS)) return;

  if (compare(par_hier,_TMC("F"),EQS))
    {
          sel_coas_gjbprun_par(FIRST_ROW,par_coas,par_fund_no,par_fund);
          validate_parm_format(par_fund_no,par_fund);
          if (invalid_parm_format) return;
 ins_fund_s();
          sel_coas_gjbprun_par(FIRST_ROW,par_coas,par_orgn_no,par_orgn);
          validate_parm_format(par_orgn_no,par_orgn);
          if (invalid_parm_format) return;
 ins_orgn_s();
          sel_coas_gjbprun_par(FIRST_ROW,par_coas,par_acct_no,par_acct);
          validate_parm_format(par_acct_no,par_acct);
          if (invalid_parm_format) return;
 ins_acct_s();
          sel_coas_gjbprun_par(FIRST_ROW,par_coas,par_prog_no,par_prog);
          validate_parm_format(par_prog_no,par_prog);
          if (invalid_parm_format) return;
 ins_prog_s();
   
}

if (compare(par_hier,_TMC("E"),EQS))
  {

get_fund_option:
          sel_coas_gjbprun_par(FIRST_ROW,par_coas,par_fund_option_no,par_fund_option);
          validate_parm_format(par_fund_option_no,par_fund_option);
          if (invalid_parm_format) return;
 ins_fund_option();

if (compare(par_fund_option,_TMC("R"),EQS))
  {
          sel_coas_gjbprun_par(FIRST_ROW,par_coas,par_fund_from_no,par_fund_from);
          validate_parm_format(par_fund_from_no,par_fund_from);
          if (invalid_parm_format) return;
          sel_coas_gjbprun_par(FIRST_ROW,par_coas,par_fund_to_no,par_fund_to);
          validate_parm_format(par_fund_to_no,par_fund_to);
          if (invalid_parm_format) return;
ins_fund_range();
 ins_coas_parm(par_fund_from_no,par_fund_from);
 ins_coas_parm(par_fund_to_no,par_fund_to);

}

if (compare(par_fund_option,_TMC("W"),EQS))
  {
          sel_coas_gjbprun_par(FIRST_ROW,par_coas,par_fund_no,par_fund_to);
          validate_parm_format(par_fund_no,par_fund_to);
          if (invalid_parm_format) return;
    ins_par_fund_code();

  }
if (compare(par_fund_option,_TMC("S"),EQS))
  {
          sel_coas_gjbprun_par(FIRST_ROW,par_coas,par_fund_no,par_fund_to);
          validate_parm_format(par_fund_no,par_fund_to);
          if (invalid_parm_format) return;
    ins_par_fund_s();

  }


get_grnt_option:
 if (compare(rptname,_TMC("NHRDIST"),EQS))
 {
   sel_coas_gjbprun_par(FIRST_ROW,par_coas,par_grnt_option_no,par_grnt_option);
   validate_parm_format(par_grnt_option_no,par_grnt_option);
   if (invalid_parm_format) return;
   ins_grnt_option();
   if (compare(par_grnt_option,_TMC("R"),EQS))
   {
         sel_coas_gjbprun_par(FIRST_ROW,par_coas,par_grnt_from_no,par_grnt_from);
          validate_parm_format(par_grnt_from_no,par_grnt_from);
          if (invalid_parm_format) return;
          sel_coas_gjbprun_par(FIRST_ROW,par_coas,par_grnt_to_no,par_grnt_to);
          validate_parm_format(par_grnt_to_no,par_grnt_to);
          if (invalid_parm_format) return;
          ins_grnt_range();
          ins_coas_parm(par_grnt_from_no,par_grnt_from);
          ins_coas_parm(par_grnt_to_no,par_grnt_to);
   }

  if (compare(par_grnt_option,_TMC("W"),EQS))
  {
          sel_coas_gjbprun_par(FIRST_ROW,par_coas,par_grnt_no,par_grnt_to);
          validate_parm_format(par_grnt_no,par_grnt_to);
          if (invalid_parm_format) return;
          ins_par_grnt_code();
  }
  if (compare(par_grnt_option,_TMC("S"),EQS))
  {
          sel_coas_gjbprun_par(FIRST_ROW,par_coas,par_grnt_no,par_grnt_to);
          validate_parm_format(par_grnt_no,par_grnt_to);
          if (invalid_parm_format) return;
          ins_par_grnt_s();

  }
 }
  
get_orgn_option:
          sel_coas_gjbprun_par(FIRST_ROW,par_coas,par_orgn_option_no,par_orgn_option);
          validate_parm_format(par_orgn_option_no,par_orgn_option);
          if (invalid_parm_format) return;
 ins_orgn_option();
if (compare(par_orgn_option,_TMC("R"),EQS))
  {
          sel_coas_gjbprun_par(FIRST_ROW,par_coas,par_orgn_from_no,par_orgn_from);
          validate_parm_format(par_orgn_from_no,par_orgn_from);
          if (invalid_parm_format) return;
          sel_coas_gjbprun_par(FIRST_ROW,par_coas,par_orgn_to_no,par_orgn_to);
          validate_parm_format(par_orgn_to_no,par_orgn_to);
          if (invalid_parm_format) return;
ins_orgn_range();
 ins_coas_parm(par_orgn_from_no,par_orgn_from);
 ins_coas_parm(par_orgn_to_no,par_orgn_to);

}

if (compare(par_orgn_option,_TMC("W"),EQS))
  {
          sel_coas_gjbprun_par(FIRST_ROW,par_coas,par_orgn_no,par_orgn_to);
          validate_parm_format(par_orgn_no,par_orgn_to);
          if (invalid_parm_format) return;
    ins_par_orgn_code();

  }
if (compare(par_orgn_option,_TMC("S"),EQS))
  {
          sel_coas_gjbprun_par(FIRST_ROW,par_coas,par_orgn_no,par_orgn_to);
          validate_parm_format(par_orgn_no,par_orgn_to);
          if (invalid_parm_format) return;
    ins_par_orgn_s();

  }
get_acct_option:
          sel_coas_gjbprun_par(FIRST_ROW,par_coas,par_acct_option_no,par_acct_option);
          validate_parm_format(par_acct_option_no,par_acct_option);
          if (invalid_parm_format) return;
 ins_acct_option();
if (compare(par_acct_option,_TMC("R"),EQS))
  {
          sel_coas_gjbprun_par(FIRST_ROW,par_coas,par_acct_from_no,par_acct_from);
          validate_parm_format(par_acct_from_no,par_acct_from);
          if (invalid_parm_format) return;
          sel_coas_gjbprun_par(FIRST_ROW,par_coas,par_acct_to_no,par_acct_to);
          validate_parm_format(par_acct_to_no,par_acct_to);
          if (invalid_parm_format) return;
ins_acct_range();
 ins_coas_parm(par_acct_from_no,par_acct_from);
 ins_coas_parm(par_acct_to_no,par_acct_to);

}
if (compare(par_acct_option,_TMC("W"),EQS))
  {
          sel_coas_gjbprun_par(FIRST_ROW,par_coas,par_acct_no,par_acct_to);
          validate_parm_format(par_acct_no,par_acct_to);
          if (invalid_parm_format) return;
    ins_par_acct_code();

  }
if (compare(par_acct_option,_TMC("S"),EQS))
  {
          sel_coas_gjbprun_par(FIRST_ROW,par_coas,par_acct_no,par_acct_to);
          validate_parm_format(par_acct_no,par_acct_to);
          if (invalid_parm_format) return;
    ins_par_acct_s();

  }
get_prog_option:
          sel_coas_gjbprun_par(FIRST_ROW,par_coas,par_prog_option_no,par_prog_option);
          validate_parm_format(par_prog_option_no,par_prog_option);
          if (invalid_parm_format) return;
 ins_prog_option();
if (compare(par_prog_option,_TMC("R"),EQS))
  {
          sel_coas_gjbprun_par(FIRST_ROW,par_coas,par_prog_from_no,par_prog_from);
          validate_parm_format(par_prog_from_no,par_prog_from);
          if (invalid_parm_format) return;
          sel_coas_gjbprun_par(FIRST_ROW,par_coas,par_prog_to_no,par_prog_to);
          validate_parm_format(par_prog_to_no,par_prog_to);
          if (invalid_parm_format) return;
ins_prog_range();
 ins_coas_parm(par_prog_from_no,par_prog_from);
 ins_coas_parm(par_prog_to_no,par_prog_to);

}
if (compare(par_prog_option,_TMC("W"),EQS))
  {
          sel_coas_gjbprun_par(FIRST_ROW,par_coas,par_prog_no,par_prog_to);
          validate_parm_format(par_prog_no,par_prog_to);
          if (invalid_parm_format) return;
    ins_par_prog_code();

  }
if (compare(par_prog_option,_TMC("S"),EQS))
  {
          sel_coas_gjbprun_par(FIRST_ROW,par_coas,par_prog_no,par_prog_to);
          validate_parm_format(par_prog_no,par_prog_to);
          if (invalid_parm_format) return;
    ins_par_prog_s();

  }
	}

}


static int sel_gjbprun_par(int mode,TMCHAR par_no[4], TMCHAR par_value[35])  
{

EXEC SQL BEGIN DECLARE SECTION;
  TMCHAR lpar_no[4]={0}/*TMCI18N CHANGED FROM ""*/;
  TMCHAR lpar_value[12]={0}/*TMCI18N CHANGED FROM ""*/;
EXEC SQL END DECLARE SECTION;

tmstrcpy(lpar_no,par_no);



  EXEC SQL DECLARE cur_gjbprun_par CURSOR FOR
   SELECT upper(gjbprun_value)
   FROM   gjbprun
   WHERE  gjbprun_job       = :rptname
   AND    gjbprun_number    = :lpar_no
   AND    gjbprun_one_up_no = TO_NUMBER(:par_one_up_no);

  if ( mode==CLOSE_CURSOR )
    {
      EXEC SQL CLOSE cur_gjbprun_par;
      POSTORA;
      return TRUE;
  }

  if ( mode==FIRST_ROW )
    {
      EXEC SQL OPEN cur_gjbprun_par;
      POSTORA;
    }

  EXEC SQL FETCH cur_gjbprun_par INTO
       :lpar_value:Ind_01;
  POSTORA;




  if ( NO_ROWS_FOUND )
    {
      *lpar_value='\0';
      *par_value='\0';
/* printf("\n par_no %s par_value %s",par_no,par_value);       */
      return FALSE;
    }
  tmstrcpy(par_value,lpar_value);

/* printf("\n par_no %s par_value %s",par_no,par_value); */

  return TRUE;
}


static int sel_coas_gjbprun_par(int mode,TMCHAR coas[2],TMCHAR par_no[4], TMCHAR par_value[35])  /*  table lookup */
{

EXEC SQL BEGIN DECLARE SECTION;
  TMCHAR lpar_no[4]={0}/*TMCI18N CHANGED FROM ""*/;
  TMCHAR lpar_value[12]={0}/*TMCI18N CHANGED FROM ""*/;
  TMCHAR lcoas[2]={0}/*TMCI18N CHANGED FROM ""*/;
EXEC SQL END DECLARE SECTION;

tmstrcpy(lpar_no,par_no);
tmstrcpy(lcoas,coas);



  EXEC SQL DECLARE cur_prun_par CURSOR FOR
   SELECT upper(substr(gjbprun_value,3))
   FROM   gjbprun
   WHERE  gjbprun_job       = :rptname
   AND    gjbprun_number    = :lpar_no
   and    upper(substr(gjbprun_value,1,1)) = :lcoas
   AND    gjbprun_one_up_no = TO_NUMBER(:par_one_up_no);

  if ( mode==CLOSE_CURSOR )
    {
      EXEC SQL CLOSE cur_prun_par;
      POSTORA;
      return TRUE;
  }

  if ( mode==FIRST_ROW )
    {
      EXEC SQL OPEN cur_prun_par;
      POSTORA;
    }

  EXEC SQL FETCH cur_prun_par INTO
       :lpar_value:Ind_01;
  POSTORA;

  
  if ( NO_ROWS_FOUND )
    {
      *lpar_value='\0';
      *par_value='\0';
/* printf("\n par_no %s par_value %s",par_no,par_value); */
      return FALSE;
    }
  tmstrcpy(par_value,lpar_value);

/* printf("\n par_no %s par_value %s",par_no,par_value); */

  return TRUE;
}


static void ins_par_pict(void)
{
  EXEC SQL
   INSERT into gjbcolr
         (gjbcolr_one_up_no,
          gjbcolr_job,
          gjbcolr_number,
          gjbcolr_value,
          gjbcolr_activity_date)
select    TO_NUMBER(:par_one_up_no),
          :rptname,
          :par_pict_no,
          ptrpict_code,
          sysdate
from      gjbprun,
          ptrpict
   WHERE  gjbprun_job       = :rptname
   AND    gjbprun_number    = :par_pict_no
   AND    gjbprun_one_up_no = TO_NUMBER(:par_one_up_no)
   and     ptrpict_code like UPPER(gjbprun_value);
  POSTORA;
}


static void ins_par_ecls_code(void)
{
  EXEC SQL
   INSERT into gjbcolr
         (gjbcolr_one_up_no,
          gjbcolr_job,
          gjbcolr_number,
          gjbcolr_value,
          gjbcolr_activity_date)
select    TO_NUMBER(:par_one_up_no),
          :rptname,
          :par_ecls_no,
          ptrecls_code,
          sysdate
from      gjbprun,
          ptrecls
   WHERE  gjbprun_job       = :rptname
   AND    gjbprun_number    = :par_ecls_no
   AND    gjbprun_one_up_no = TO_NUMBER(:par_one_up_no) 
   and    ptrecls_code like UPPER(gjbprun_value);
  POSTORA;
}


static void ins_par_empl_id(void)
{
  EXEC SQL
   INSERT into gjbcolr
         (gjbcolr_one_up_no,
          gjbcolr_job,
          gjbcolr_number,
          gjbcolr_value,
          gjbcolr_activity_date)
select    TO_NUMBER(:par_one_up_no),
          :rptname,
          :par_empl_id_no,
          spriden_id,
          sysdate
from      gjbprun,
          spriden
   WHERE  gjbprun_job       = :rptname
   AND    gjbprun_number    = :par_empl_id_no
   AND    gjbprun_one_up_no = TO_NUMBER(:par_one_up_no)
   and    spriden_id   like UPPER(gjbprun_value)
and       spriden_change_ind is null;
  POSTORA;
}



static void ins_par_coas_code(void)
{
  EXEC SQL
   INSERT into gjbcolr
         (gjbcolr_one_up_no,
          gjbcolr_job,
          gjbcolr_number,
          gjbcolr_value,
          gjbcolr_activity_date)
select    TO_NUMBER(:par_one_up_no),
          :rptname,
          :par_coas_no,
          ftvcoas_coas_code,
          sysdate
from      gjbprun,
          ftvcoas
   WHERE  gjbprun_job       = :rptname
   AND    gjbprun_number    = :par_coas_no
   AND    gjbprun_one_up_no = TO_NUMBER(:par_one_up_no)
and       ftvcoas_coas_code = upper(gjbprun_value)
and       trunc(ftvcoas_eff_date) <= TO_date(:par_end_date,'DD-MON-YYYY')
and       trunc(ftvcoas_nchg_date) >  TO_date(:par_end_date,'DD-MON-YYYY');

  POSTORA;
}




static void ins_par_fund_code(void)
{
  EXEC SQL
   INSERT into gjbcolr
         (gjbcolr_one_up_no,
          gjbcolr_job,
          gjbcolr_number,
          gjbcolr_value,
          gjbcolr_misc_value,
          gjbcolr_activity_date)
select    TO_NUMBER(:par_one_up_no),
          :rptname,
          :par_fund_no,
          ftvfund_fund_code,
          upper(:par_coas),
          sysdate
from      gjbprun,
          ftvfund
 WHERE  gjbprun_job       = :rptname
   AND    gjbprun_number    = :par_fund_no
   AND    gjbprun_one_up_no = TO_NUMBER(:par_one_up_no)
and       upper(substr(gjbprun_value,1,1)) = :par_coas
and       ftvfund_coas_code = :par_coas 
and       ftvfund_fund_code like upper(substr(gjbprun_value,3))
and       trunc(ftvfund_eff_date) <= TO_date(:par_end_date,'DD-MON-YYYY')
and       trunc(ftvfund_nchg_date) >  TO_date(:par_end_date,'DD-MON-YYYY');

  POSTORA;
}


static void ins_par_grnt_code(void)
{
  EXEC SQL
   INSERT into gjbcolr
         (gjbcolr_one_up_no,
          gjbcolr_job,
          gjbcolr_number,
          gjbcolr_value,
          gjbcolr_misc_value,
          gjbcolr_activity_date)
select    TO_NUMBER(:par_one_up_no),
          :rptname,
          :par_grnt_no,
          ftvfund_grnt_code,
          upper(:par_coas),
          sysdate
from      gjbprun,
          ftvfund
 WHERE    gjbprun_job       = :rptname
   AND    gjbprun_number    = :par_grnt_no
   AND    gjbprun_one_up_no = TO_NUMBER(:par_one_up_no)
and       upper(substr(gjbprun_value,1,1)) = :par_coas
and       ftvfund_coas_code = :par_coas 
and       ftvfund_grnt_code like upper(substr(gjbprun_value,3))
and       trunc(ftvfund_eff_date) <= TO_date(:par_end_date,'DD-MON-YYYY')
and       trunc(ftvfund_nchg_date) >  TO_date(:par_end_date,'DD-MON-YYYY');

  POSTORA;
}


static void ins_par_orgn_code(void)
{
  EXEC SQL
   INSERT into gjbcolr
         (gjbcolr_one_up_no,
          gjbcolr_job,
          gjbcolr_number,
          gjbcolr_value,
          gjbcolr_misc_value,
          gjbcolr_activity_date)
select    TO_NUMBER(:par_one_up_no),
          :rptname,
          :par_orgn_no,
          ftvorgn_orgn_code,
          upper(:par_coas),
          sysdate
from      gjbprun,
          ftvorgn
 WHERE  gjbprun_job       = :rptname
   AND    gjbprun_number    = :par_orgn_no
   AND    gjbprun_one_up_no = TO_NUMBER(:par_one_up_no)
and       upper(substr(gjbprun_value,1,1)) = :par_coas
and       ftvorgn_coas_code = :par_coas 
and       ftvorgn_orgn_code like upper(substr(gjbprun_value,3))
and       trunc(ftvorgn_eff_date) <= TO_date(:par_end_date,'DD-MON-YYYY')
and       trunc(ftvorgn_nchg_date) >  TO_date(:par_end_date,'DD-MON-YYYY');

  POSTORA;
}



static void ins_par_acct_code(void)
{
  EXEC SQL
   INSERT into gjbcolr
         (gjbcolr_one_up_no,
          gjbcolr_job,
          gjbcolr_number,
          gjbcolr_value,
          gjbcolr_misc_value,
          gjbcolr_activity_date)
select    TO_NUMBER(:par_one_up_no),
          :rptname,
          :par_acct_no,
          ftvacct_acct_code,
          upper(:par_coas),
          sysdate
from      gjbprun,
          ftvacct
 WHERE  gjbprun_job       = :rptname
   AND    gjbprun_number    = :par_acct_no
   AND    gjbprun_one_up_no = TO_NUMBER(:par_one_up_no)
and       upper(substr(gjbprun_value,1,1)) = :par_coas
and       ftvacct_coas_code = :par_coas 
and       ftvacct_acct_code like upper(substr(gjbprun_value,3))
and       trunc(ftvacct_eff_date) <= TO_date(:par_end_date,'DD-MON-YYYY')
and       trunc(ftvacct_nchg_date) >  TO_date(:par_end_date,'DD-MON-YYYY');

  POSTORA;
}


static void ins_par_prog_code(void)
{
  EXEC SQL
   INSERT into gjbcolr
         (gjbcolr_one_up_no,
          gjbcolr_job,
          gjbcolr_number,
          gjbcolr_value,
          gjbcolr_misc_value,
          gjbcolr_activity_date)
select    TO_NUMBER(:par_one_up_no),
          :rptname,
          :par_prog_no,
          ftvprog_prog_code,
          upper(:par_coas),
          sysdate
from      gjbprun,
          ftvprog
 WHERE  gjbprun_job       = :rptname
   AND    gjbprun_number    = :par_prog_no
   AND    gjbprun_one_up_no = TO_NUMBER(:par_one_up_no)
and       upper(substr(gjbprun_value,1,1)) = :par_coas
and       ftvprog_coas_code = :par_coas 
and       ftvprog_prog_code like upper(substr(gjbprun_value,3))
and       trunc(ftvprog_eff_date) <= TO_date(:par_end_date,'DD-MON-YYYY')
and       trunc(ftvprog_nchg_date) >  TO_date(:par_end_date,'DD-MON-YYYY');

  POSTORA;
}

static int sel_coas(int mode)     
{
  EXEC SQL DECLARE cur_coas CURSOR FOR
   SELECT gjbcolr_value
   FROM   gjbcolr
   WHERE  gjbcolr_one_up_no = TO_NUMBER(:par_one_up_no)
   AND    gjbcolr_number    = :par_coas_no
   AND    gjbcolr_job       = :rptname
order by gjbcolr_value;

  if ( mode==CLOSE_CURSOR )
    {
      EXEC SQL CLOSE cur_coas;
      POSTORA;
      return TRUE;
  }

  if ( mode==FIRST_ROW )
    {
      EXEC SQL OPEN cur_coas;
      POSTORA;
    }

  EXEC SQL FETCH cur_coas INTO
       :par_coas:Ind_01;
  POSTORA;

  if ( NO_ROWS_FOUND )
    {
      *par_coas='\0';
      return FALSE;
    }

  return TRUE;
}


static void ins_orgn_s(void)
{
  EXEC SQL
   INSERT into gjbcolr
         (gjbcolr_one_up_no,
          gjbcolr_job,
          gjbcolr_number,
          gjbcolr_value,
          gjbcolr_misc_value,
          gjbcolr_activity_date)
select    TO_NUMBER(:par_one_up_no),
          :rptname,
          :par_orgn_no,
          ftvorgn_orgn_code,
          upper(:par_coas),
          sysdate
from      ftvorgn
where     ftvorgn_orgn_code = upper(:par_orgn)
and       ftvorgn_coas_code = upper(:par_coas)
and       trunc(ftvorgn_eff_date) <= TO_date(:par_end_date,'DD-MON-YYYY')
and       trunc(ftvorgn_nchg_date) >  TO_date(:par_end_date,'DD-MON-YYYY');

  POSTORA;
}


static void ins_fund_s(void)
{
  EXEC SQL
   INSERT into gjbcolr
         (gjbcolr_one_up_no,
          gjbcolr_job,
          gjbcolr_number,
          gjbcolr_value,
          gjbcolr_misc_value,
          gjbcolr_activity_date)
select    TO_NUMBER(:par_one_up_no),
          :rptname,
          :par_fund_no,
          ftvfund_fund_code,
          upper(:par_coas),
          sysdate
from      ftvfund
where     ftvfund_fund_code = upper(:par_fund)
and       ftvfund_coas_code = upper(:par_coas)
and       trunc(ftvfund_eff_date) <= TO_date(:par_end_date,'DD-MON-YYYY')
and       trunc(ftvfund_nchg_date) >  TO_date(:par_end_date,'DD-MON-YYYY');

  POSTORA;
}


static void ins_grnt_s(void)
{
  EXEC SQL
   INSERT into gjbcolr
         (gjbcolr_one_up_no,
          gjbcolr_job,
          gjbcolr_number,
          gjbcolr_value,
          gjbcolr_misc_value,
          gjbcolr_activity_date)
select    TO_NUMBER(:par_one_up_no),
          :rptname,
          :par_grnt_no,
          ftvfund_grnt_code,
          upper(:par_coas),
          sysdate
from      ftvfund
where     ftvfund_fund_code = upper(:par_fund)
and       ftvfund_grnt_code = upper(:par_grnt)
and       ftvfund_coas_code = upper(:par_coas)
and       trunc(ftvfund_eff_date) <= TO_date(:par_end_date,'DD-MON-YYYY')
and       trunc(ftvfund_nchg_date) >  TO_date(:par_end_date,'DD-MON-YYYY');

  POSTORA;
}

static void ins_acct_s(void)
{
  EXEC SQL
   INSERT into gjbcolr
         (gjbcolr_one_up_no,
          gjbcolr_job,
          gjbcolr_number,
          gjbcolr_value,
          gjbcolr_misc_value,
          gjbcolr_activity_date)
select    TO_NUMBER(:par_one_up_no),
          :rptname,
          :par_acct_no,
          ftvacct_acct_code,
          upper(:par_coas),
          sysdate
from      ftvacct
where     ftvacct_acct_code = upper(:par_acct)
and       ftvacct_coas_code = upper(:par_coas)
and       trunc(ftvacct_eff_date) <= TO_date(:par_end_date,'DD-MON-YYYY')
and       trunc(ftvacct_nchg_date) >  TO_date(:par_end_date,'DD-MON-YYYY');

  POSTORA;
}


static void ins_prog_s(void)
{
  EXEC SQL
   INSERT into gjbcolr
         (gjbcolr_one_up_no,
          gjbcolr_job,
          gjbcolr_number,
          gjbcolr_value,
          gjbcolr_misc_value,
          gjbcolr_activity_date)
select    TO_NUMBER(:par_one_up_no),
          :rptname,
          :par_prog_no,
          ftvprog_prog_code,
          upper(:par_coas),
          sysdate
from      ftvprog
where     ftvprog_prog_code = upper(:par_prog)
and       ftvprog_coas_code = upper(:par_coas)
and       trunc(ftvprog_eff_date) <= TO_date(:par_end_date,'DD-MON-YYYY')
and       trunc(ftvprog_nchg_date) >  TO_date(:par_end_date,'DD-MON-YYYY');

  POSTORA;
}


static void ins_par_fund_s(void)
{
  EXEC SQL
   INSERT into gjbcolr
         (gjbcolr_one_up_no,
          gjbcolr_job,
          gjbcolr_number,
          gjbcolr_value,
          gjbcolr_misc_value,
          gjbcolr_activity_date)
select    TO_NUMBER(:par_one_up_no),
          :rptname,
          :par_fund_no,
          ftvfund_fund_code,
          upper(:par_coas),
          sysdate
from      gjbprun,
          ftvfund
 WHERE  gjbprun_job       = :rptname
   AND    gjbprun_number    = :par_fund_no
   AND    gjbprun_one_up_no = TO_NUMBER(:par_one_up_no)
and       upper(substr(gjbprun_value,1,1)) = :par_coas
and       ftvfund_coas_code = :par_coas 
and       ftvfund_fund_code = upper(substr(gjbprun_value,3))
and       trunc(ftvfund_eff_date) <= TO_date(:par_end_date,'DD-MON-YYYY')
and       trunc(ftvfund_nchg_date) >  TO_date(:par_end_date,'DD-MON-YYYY');

  POSTORA;
}


static void ins_par_grnt_s(void)
{
  EXEC SQL
   INSERT into gjbcolr
         (gjbcolr_one_up_no,
          gjbcolr_job,
          gjbcolr_number,
          gjbcolr_value,
          gjbcolr_misc_value,
          gjbcolr_activity_date)
select    TO_NUMBER(:par_one_up_no),
          :rptname,
          :par_grnt_no,
          frbgrnt_code,
          upper(:par_coas),
          sysdate
from      gjbprun,
          frbgrnt
 WHERE  gjbprun_job       = :rptname
   AND    gjbprun_number    = :par_grnt_no
   AND    gjbprun_one_up_no = TO_NUMBER(:par_one_up_no)
and       upper(substr(gjbprun_value,1,1)) = :par_coas
and       frbgrnt_coas_code = :par_coas 
and       frbgrnt_code = upper(substr(gjbprun_value,3))
and       trunc(frbgrnt_project_start_date) <= TO_date(:par_end_date,'DD-MON-YYYY')
and       trunc(frbgrnt_project_end_date)   >  TO_date(:par_end_date,'DD-MON-YYYY');

  POSTORA;
}

static void ins_par_orgn_s(void)
{
  EXEC SQL
   INSERT into gjbcolr
         (gjbcolr_one_up_no,
          gjbcolr_job,
          gjbcolr_number,
          gjbcolr_value,
          gjbcolr_misc_value,
          gjbcolr_activity_date)
select    TO_NUMBER(:par_one_up_no),
          :rptname,
          :par_orgn_no,
          ftvorgn_orgn_code,
          upper(:par_coas),
          sysdate
from      gjbprun,
          ftvorgn
 WHERE  gjbprun_job       = :rptname
   AND    gjbprun_number    = :par_orgn_no
   AND    gjbprun_one_up_no = TO_NUMBER(:par_one_up_no)
and       upper(substr(gjbprun_value,1,1)) = :par_coas
and       ftvorgn_coas_code = :par_coas 
and       ftvorgn_orgn_code = upper(substr(gjbprun_value,3))
and       trunc(ftvorgn_eff_date) <= TO_date(:par_end_date,'DD-MON-YYYY')
and       trunc(ftvorgn_nchg_date) >  TO_date(:par_end_date,'DD-MON-YYYY');

  POSTORA;
}


static void ins_par_acct_s(void)
{
  EXEC SQL
   INSERT into gjbcolr
         (gjbcolr_one_up_no,
          gjbcolr_job,
          gjbcolr_number,
          gjbcolr_value,
          gjbcolr_misc_value,
          gjbcolr_activity_date)
select    TO_NUMBER(:par_one_up_no),
          :rptname,
          :par_acct_no,
          ftvacct_acct_code,
          upper(:par_coas),
          sysdate
from      gjbprun,
          ftvacct
 WHERE  gjbprun_job       = :rptname
   AND    gjbprun_number    = :par_acct_no
   AND    gjbprun_one_up_no = TO_NUMBER(:par_one_up_no)
and       upper(substr(gjbprun_value,1,1)) = :par_coas
and       ftvacct_coas_code = :par_coas 
and       ftvacct_acct_code = upper(substr(gjbprun_value,3))
and       trunc(ftvacct_eff_date) <= TO_date(:par_end_date,'DD-MON-YYYY')
and       trunc(ftvacct_nchg_date) >  TO_date(:par_end_date,'DD-MON-YYYY');

  POSTORA;
}

static void ins_par_prog_s(void)
{
  EXEC SQL
   INSERT into gjbcolr
         (gjbcolr_one_up_no,
          gjbcolr_job,
          gjbcolr_number,
          gjbcolr_value,
          gjbcolr_misc_value,
          gjbcolr_activity_date)
select    TO_NUMBER(:par_one_up_no),
          :rptname,
          :par_prog_no,
          ftvprog_prog_code,
          upper(:par_coas),
          sysdate
from      gjbprun,
          ftvprog
 WHERE  gjbprun_job       = :rptname
   AND    gjbprun_number    = :par_prog_no
   AND    gjbprun_one_up_no = TO_NUMBER(:par_one_up_no)
and       upper(substr(gjbprun_value,1,1)) = :par_coas
and       ftvprog_coas_code = :par_coas 
and       ftvprog_prog_code = upper(substr(gjbprun_value,3))
and       trunc(ftvprog_eff_date) <= TO_date(:par_end_date,'DD-MON-YYYY')
and       trunc(ftvprog_nchg_date) >  TO_date(:par_end_date,'DD-MON-YYYY');

  POSTORA;
}
/* ****************************************************************  */
/* Mods for Extra Home Orgn Chart */

static int sel_home_orgn_option (int mode)
{
  EXEC SQL DECLARE home_orgn_option CURSOR FOR
   SELECT :parm_name,
          gjbcolr_value,
          gjbcolr_misc_value
   FROM   gjbcolr
   WHERE  gjbcolr_one_up_no = TO_NUMBER(:par_one_up_no)
   AND    gjbcolr_number    = :par_home_orgn_option_no
   and    gjbcolr_misc_value = :home_coas
   AND    gjbcolr_job       = :rptname;

  if ( mode==CLOSE_CURSOR )
    {
      EXEC SQL CLOSE home_orgn_option;
      POSTORA;
      return TRUE;
  }

  if ( mode==FIRST_ROW )
    {
      EXEC SQL OPEN home_orgn_option;
      POSTORA;
    }

  EXEC SQL FETCH home_orgn_option INTO
       :parm_name:Ind_01,
       :parm:Ind_02,
       :parm_source:Ind_03;
  POSTORA;

  if ( NO_ROWS_FOUND )
    {
      *parm_name='\0';
      *parm='\0';
      *parm_source='\0';
      return FALSE;
    }
     tmstrcpy(par_home_orgn_option,parm);
  return TRUE;
}

static void ins_par_home_orgn(void)
{
  EXEC SQL
   INSERT into gjbcolr
         (gjbcolr_one_up_no,
          gjbcolr_job,
          gjbcolr_number,
          gjbcolr_value,
          gjbcolr_misc_value,
          gjbcolr_activity_date)
select    TO_NUMBER(:par_one_up_no),
          :rptname,
          :par_home_orgn_no,
          ftvorgn_orgn_code,
          :home_coas,
          sysdate
from      gjbprun,
          ftvorgn
   WHERE  gjbprun_job       = :rptname
   AND    gjbprun_number    = :par_home_orgn_no
   AND    gjbprun_one_up_no = TO_NUMBER(:par_one_up_no)
and       upper(substr(gjbprun_value,1,1)) = :home_coas
and       ftvorgn_coas_code = :home_coas 
and       ftvorgn_orgn_code like upper(substr(gjbprun_value,3))
and       trunc(ftvorgn_eff_date) <= TO_date(:par_end_date,'DD-MON-YYYY')
and       trunc(ftvorgn_nchg_date) >  TO_date(:par_end_date,'DD-MON-YYYY');
  POSTORA;
}


static void ins_par_home_orgn_s(void)
{
  EXEC SQL
   INSERT into gjbcolr
         (gjbcolr_one_up_no,
          gjbcolr_job,
          gjbcolr_number,
          gjbcolr_value,
          gjbcolr_misc_value,
          gjbcolr_activity_date)
select    TO_NUMBER(:par_one_up_no),
          :rptname,
          :par_home_orgn_no,
          ftvorgn_orgn_code,
          :home_coas,
          sysdate
from      gjbprun,
          ftvorgn
   WHERE  gjbprun_job       = :rptname
   AND    gjbprun_number    = :par_home_orgn_no
   AND    gjbprun_one_up_no = TO_NUMBER(:par_one_up_no)
and       upper(substr(gjbprun_value,1,1)) = :home_coas
and       ftvorgn_coas_code = :home_coas 
and       ftvorgn_orgn_code = upper(substr(gjbprun_value,3))
and       trunc(ftvorgn_eff_date) <= TO_date(:par_end_date,'DD-MON-YYYY')
and       trunc(ftvorgn_nchg_date) >  TO_date(:par_end_date,'DD-MON-YYYY');
  POSTORA;
}



static void ins_home_orgn_s(void)
{
  EXEC SQL
   INSERT into gjbcolr
         (gjbcolr_one_up_no,
          gjbcolr_job,
          gjbcolr_number,
          gjbcolr_value,
          gjbcolr_misc_value,
          gjbcolr_activity_date)
select    TO_NUMBER(:par_one_up_no),
          :rptname,
          :par_home_orgn_no,
          ftvorgn_orgn_code,
	  upper(:home_coas),
          sysdate
from      ftvorgn
where     ftvorgn_coas_code = upper(:home_coas)
and       ftvorgn_orgn_code = upper(:par_home_orgn)
and       trunc(ftvorgn_eff_date) <= TO_date(:par_end_date,'DD-MON-YYYY')
and       trunc(ftvorgn_nchg_date) >  TO_date(:par_end_date,'DD-MON-YYYY');
  POSTORA;
}




static void ins_home_orgn(void)
{
  EXEC SQL
   INSERT into gjbcolr
         (gjbcolr_one_up_no,
          gjbcolr_job,
          gjbcolr_number,
          gjbcolr_value,
          gjbcolr_misc_value,
          gjbcolr_activity_date)
select    TO_NUMBER(:par_one_up_no),
          :rptname,
          :par_home_orgn_no,
          ftvorgn_orgn_code,
	  upper(:home_coas),
          sysdate
from      ftvorgn
where     ftvorgn_coas_code = upper(:home_coas)
and       ftvorgn_orgn_code like upper(:par_home_orgn)
and       trunc(ftvorgn_eff_date) <= TO_date(:par_end_date,'DD-MON-YYYY')
and       trunc(ftvorgn_nchg_date) >  TO_date(:par_end_date,'DD-MON-YYYY');
  POSTORA;
}


static void ins_home_orgn_range(void)
{
  EXEC SQL
   INSERT into gjbcolr
         (gjbcolr_one_up_no,
          gjbcolr_job,
          gjbcolr_number,
          gjbcolr_value,
          gjbcolr_misc_value,
          gjbcolr_activity_date)
select    TO_NUMBER(:par_one_up_no),
          :rptname,
          :par_home_orgn_no,
          ftvorgn_orgn_code,
	  upper(:home_coas),
          sysdate
from      ftvorgn
where     ftvorgn_coas_code = upper(:home_coas)
and       ftvorgn_orgn_code between upper(:par_home_orgn_from) and
            upper(:par_home_orgn_to)
and       trunc(ftvorgn_eff_date) <= TO_date(:par_end_date,'DD-MON-YYYY')
and       trunc(ftvorgn_nchg_date) >  TO_date(:par_end_date,'DD-MON-YYYY');
  POSTORA;
}

static void ins_home_orgn_pars(TMCHAR par_no[3],TMCHAR par[7],TMCHAR coas[2])
{

EXEC SQL BEGIN DECLARE SECTION;
 TMCHAR lpar_no[3]={0}/*TMCI18N CHANGED FROM ""*/;
 TMCHAR lpar[7]={0}/*TMCI18N CHANGED FROM ""*/;
 TMCHAR lcoas[2]={0}/*TMCI18N CHANGED FROM ""*/;
EXEC SQL END DECLARE SECTION;

tmstrcpy(lpar_no,par_no);
tmstrcpy(lpar,par);
tmstrcpy(lcoas,coas);

  EXEC SQL
   INSERT into gjbcolr
         (gjbcolr_one_up_no,
          gjbcolr_job,
          gjbcolr_number,
          gjbcolr_value,
          gjbcolr_misc_value,
          gjbcolr_activity_date)
values( TO_NUMBER(:par_one_up_no),
          :rptname,
          :lpar_no,
	   :lpar,
	  upper(:lcoas),
          sysdate);


  POSTORA;
}

static void get_home_orgn (void)
{

	if  (*par_home_coas) tmstrcpy(home_coas,par_home_coas);
	else tmstrcpy(home_coas,par_coas);

	do
	{

		tmprintf(&tmBundle, _TMC(" \n"));
		tmprintf(&tmBundle, TM_NLS_Get("0168"," Home Organization Options                        \n"));
		tmprintf(&tmBundle, _TMC(" \n"));
		tmprintf(&tmBundle, TM_NLS_Get("0169","  All Home Organizations -------------------->   A\n"));
		tmprintf(&tmBundle, _TMC(" \n"));
		tmprintf(&tmBundle, TM_NLS_Get("0170","  Range of Home Organizations --------------->   R\n"));
		tmprintf(&tmBundle, _TMC(" \n"));
		tmprintf(&tmBundle, TM_NLS_Get("0171","  Home Organizations - Wildcards ------------>   W\n"));
		tmprintf(&tmBundle, _TMC(" \n"));
		tmprintf(&tmBundle, TM_NLS_Get("0172","  Specific Home Organizations --------------->   S\n"));
		tmprintf(&tmBundle, _TMC(" \n"));

		tmprintf(&tmBundle, TM_NLS_Get("0173","  Default : A\n"));
		tmprintf(&tmBundle, _TMC(" \n"));

		input(par_home_orgn_option,TM_NLS_Get("0174"," Home Orgn Options (A,R,W,S)---------> "),1,ALPHA);
		tmprintf(&tmBundle, _TMC(" \n"));
		if ( !*par_home_orgn_option ) tmstrcpy(par_home_orgn_option,_TMC("A"));
		str2uc(par_home_orgn_option);
	}  while( ! inlist(par_home_orgn_option,ALPHA,_TMC("A"),_TMC("R"),_TMC("S"),_TMC("W"),NULL) );



	ins_home_orgn_pars(par_home_orgn_option_no,par_home_orgn_option,home_coas);

	if (compare(par_home_orgn_option,_TMC("R"),EQS))
	{
		input(par_home_orgn_from,TM_NLS_Get("0175"," From Home Orgn ------(XXXXXX)-------> "),6,ALPHA);
		tmprintf(&tmBundle, _TMC(" \n"));
		if ( !*par_home_orgn_from )
		{
			missing_parm();
			return;
		}
		input(par_home_orgn_to,TM_NLS_Get("0176"," To Home Orgn ------(XXXXXX)-------> "),6,ALPHA);
		tmprintf(&tmBundle, _TMC(" \n"));
		if ( !*par_home_orgn_to )
		{
			missing_parm();
			return;
		}
                 ins_home_orgn_range();
		ins_home_orgn_pars(par_home_orgn_from_no,par_home_orgn_from,home_coas);
		ins_home_orgn_pars(par_home_orgn_to_no,par_home_orgn_to,home_coas);

	}
	if (compare(par_home_orgn_option,_TMC("W"),EQS))
	{
		tmstrcpy(parm_ind,_TMC("N"));

		tmprintf(&tmBundle, TM_NLS_Get("0177","  (Can Use % as wildcard character)  \n"));
ask_home_orgn:
		input(par_home_orgn,TM_NLS_Get("0178"," Home Organization --------(XXXXXX)-> "),6,ALPHA);
		tmprintf(&tmBundle, _TMC(" \n"));

		tmstrcpy(parm_ind,_TMC("Y"));
		if ( !*par_home_orgn ) return;
		ins_home_orgn();
		goto ask_home_orgn;
	}
	if (compare(par_home_orgn_option,_TMC("S"),EQS))
	{
		tmstrcpy(parm_ind,_TMC("N"));

ask_home_orgn_s:
		input(par_home_orgn,TM_NLS_Get("0179"," Home Organization --------(XXXXXX)-> "),6,ALPHA);
		tmprintf(&tmBundle, _TMC(" \n"));

		tmstrcpy(parm_ind,_TMC("Y"));
		if ( !*par_home_orgn ) return;
		ins_home_orgn_s();
		goto ask_home_orgn_s;
	}

      }


static void control_home_info(void)
{
home_parm_body(TM_NLS_Get("0180","Home Orgn Option:"),par_home_orgn_option_no,par_home_orgn_option);

    if (inlist(par_home_orgn_option,ALPHA,_TMC("S"),_TMC("W"),NULL))
     home_parm_body(TM_NLS_Get("0181","Home Orgn:"),par_home_orgn_no,par_home_orgn);

    if (compare(par_home_orgn_option,_TMC("R"),EQS))
      {
    home_parm_body(TM_NLS_Get("0182","From Home Orgn:"),par_home_orgn_from_no,par_home_orgn_from);
    home_parm_body(TM_NLS_Get("0183","To Home Orgn:"),par_home_orgn_to_no,par_home_orgn_to);
  }
  }

static void retr_home_parms(void)
{


if (*par_home_coas) tmstrcpy(home_coas,par_home_coas);
 else tmstrcpy(home_coas,par_coas);

    sel_coas_gjbprun_par(FIRST_ROW,home_coas,par_home_orgn_option_no,par_home_orgn_option);
    validate_parm_format(par_home_orgn_option_no,par_home_orgn_option);
    if (invalid_parm_format) return;

          ins_home_orgn_pars(par_home_orgn_option_no,par_home_orgn_option,home_coas);

if (compare(par_home_orgn_option,_TMC("R"),EQS))
  {
          sel_coas_gjbprun_par(FIRST_ROW,home_coas,par_home_orgn_from_no,par_home_orgn_from);
          validate_parm_format(par_home_orgn_from_no,par_home_orgn_from);
          if (invalid_parm_format) return;
          sel_coas_gjbprun_par(FIRST_ROW,home_coas,par_home_orgn_to_no,par_home_orgn_to);
          validate_parm_format(par_home_orgn_to_no,par_home_orgn_to);
          if (invalid_parm_format) return;
 ins_home_orgn_range();
 ins_home_orgn_pars(par_home_orgn_from_no,par_home_orgn_from,home_coas);
 ins_home_orgn_pars(par_home_orgn_to_no,par_home_orgn_to,home_coas);

}

if (compare(par_home_orgn_option,_TMC("W"),EQS))
  {
     sel_coas_gjbprun_par(FIRST_ROW,home_coas,par_home_orgn_no,par_home_orgn_to);
     validate_parm_format(par_home_orgn_no,par_home_orgn_to);
     if (invalid_parm_format) return;
     ins_par_home_orgn();
  }
if (compare(par_home_orgn_option,_TMC("S"),EQS))
  {
     sel_coas_gjbprun_par(FIRST_ROW,home_coas,par_home_orgn_no,par_home_orgn_to);
     validate_parm_format(par_home_orgn_no,par_home_orgn_to);
     if (invalid_parm_format) return;
     ins_par_home_orgn_s();
  }
}


static void missing_parm(void)
  {
	tmstrcpy(are_parameters_valid,TM_NLS_Get("0184","NO"));
	tmprintf(&tmBundle, TM_NLS_Get("0185","Required Parameter is Missing, aborting program\n"));
        tmstrcpy(reenter_parm,_TMC("N"));
        
  }


static void validate_dates(void)
{
    dateconv(par_begin_date); /*converts DD-MON-YY to DD-MON-YYYY date format*/
    EXEC SQL SELECT 'X' INTO :DUMMY FROM DUAL
         WHERE  TO_NUMBER(SUBSTR(:par_begin_date,8,4)) > 100;
    POSTORA;
    if ( ROWS_FOUND ) goto chk_begin_date;
 /*   EXEC SQL SELECT 'X' INTO :DUMMY FROM DUAL
         WHERE  substr(:par_begin_date,8,2) between 26 and 99;
    POSTORA;
    if ( ROWS_FOUND ) goto do_19;
    else goto do_20;
  do_19:
    strcpy(par_example_date,par_begin_date);
    add_19(FIRST_ROW);
    strcpy(par_begin_date,par_example_date);
    goto chk_begin_date;
  do_20:
    strcpy(par_example_date,par_begin_date);
    add_20(FIRST_ROW);
    strcpy(par_begin_date,par_example_date);
 */ 
 chk_begin_date:
    str2uc(par_begin_date);
    EXEC SQL SELECT 'X' INTO :DUMMY FROM DUAL
         WHERE TO_DATE(:par_begin_date,'DD-MON-YYYY') > TO_DATE('01-JAN-1200',
               'DD-MON-YYYY');
    POSTORA;
    if ( ROWS_FOUND ) goto val_end_date;

    tmstrcpy(are_parameters_valid,TM_NLS_Get("0186","NO"));
    tmstrcpy(begin_date_msg,TM_NLS_Get("0187","Begin Date invalid."));

  val_end_date:
    dateconv(par_end_date);
    EXEC SQL SELECT 'X' INTO :DUMMY FROM DUAL
         WHERE  TO_NUMBER(SUBSTR(:par_end_date,8,4)) > 100;
    POSTORA;
    if ( ROWS_FOUND ) goto chk_end_date;
   /*
    EXEC SQL SELECT 'X' INTO :DUMMY FROM DUAL
         WHERE  substr(:par_end_date,8,2) between 26 and 99;
    POSTORA;
    if ( ROWS_FOUND ) goto do_19_s;
    else goto do_20_s;
  do_19_s:
    strcpy(par_example_date,par_end_date);
    add_19(FIRST_ROW);
    strcpy(par_end_date,par_example_date);
    goto chk_end_date;
  do_20_s:
    strcpy(par_example_date,par_end_date);
    add_20(FIRST_ROW);
    strcpy(par_end_date,par_example_date);
   */
  chk_end_date:
    str2uc(par_end_date);
    EXEC SQL SELECT 'X' INTO :DUMMY FROM DUAL
         WHERE TO_DATE(:par_end_date,'DD-MON-YYYY') > TO_DATE('01-JAN-1200',
               'DD-MON-YYYY');
    POSTORA;
    if ( ROWS_FOUND ) goto c_order;

    tmstrcpy(are_parameters_valid,TM_NLS_Get("0188","NO"));
    tmstrcpy(end_date_msg,TM_NLS_Get("0189","End Date invalid."));
  c_order:
    if ( compare(are_parameters_valid,TM_NLS_Get("0190","NO"),EQS) ) 
  {
 tmstrcpy(reenter_parm,_TMC("N"));
 return;                      
}
	
    EXEC SQL SELECT 'X' INTO :DUMMY FROM DUAL
         WHERE TO_DATE(:par_begin_date,'DD-MON-YYYY') <= TO_DATE(:par_end_date,
               'DD-MON-YYYY');
    POSTORA;
    if ( ROWS_FOUND) return;

    tmstrcpy(are_parameters_valid,TM_NLS_Get("0191","NO"));
    tmstrcpy(begin_date_msg,TM_NLS_Get("0192","Begin Date has to be earlier than End Date."));
    tmstrcpy(end_date_msg,TM_NLS_Get("0193","End Date has to be later than Begin Date."));
        tmstrcpy(reenter_parm,_TMC("N"));
}
/****************************************************************************/
static void parm_body(TMCHAR parm_name[32],TMCHAR parm_no[4],TMCHAR parm_dest[32])
{

CHAR32 parm_source, parm;

  EXEC SQL BEGIN DECLARE SECTION;
   int openmode;
  EXEC SQL END DECLARE SECTION;

openmode = FIRST_ROW;

  while ( coas_parm_sel(openmode,parm_no,parm,parm_source) )
  {
    openmode = NEXT_ROW;

  newcol();
  prtstr(parm_name);
  newcol();
  if (*parm_source) 
     prtstr(parm_source);

  prtstr(parm);
  tmstrcpy(parm_dest,parm);
  newcol();

  if (inlist(parm_no,ALPHA,par_grnt_option_no,par_fund_option_no,par_orgn_option_no,par_acct_option_no,par_prog_option_no,NULL))
  {
    if (compare(parm,_TMC("R"),EQS)) prtstr(TM_NLS_Get("0194","Range"));
    if (compare(parm,_TMC("A"),EQS)) prtstr(TM_NLS_Get("0195","All"));
    if (compare(parm,_TMC("W"),EQS)) prtstr(TM_NLS_Get("0196","Wildcards"));
    if (compare(parm,_TMC("S"),EQS)) prtstr(TM_NLS_Get("0197","Specific"));
  }

  lineno++;

  if ( lineno >= linelimit ) 
    {
  table(T_END);
  newpage();
  page_heading();
  table(T_BEGIN,4);
  newcol(); 
  newcol();
}
  } /* coas_parm_sel */

}

/****************************************************************************/
static void parm_sel_body(TMCHAR parm_name[32],TMCHAR parm_no[4])
{

CHAR32 parm;

  EXEC SQL BEGIN DECLARE SECTION;
   int openmode;
  EXEC SQL END DECLARE SECTION;

openmode = FIRST_ROW;

  while ( parm_sel(openmode,parm_no,parm) )
  {
    openmode = NEXT_ROW;

  newcol();
  prtstr(parm_name);
  newcol();
  prtstr(parm);

  newcol();

  lineno++;

  if ( lineno >= linelimit ) 
    {
  table(T_END);
  newpage();
  page_heading();
  table(T_BEGIN,4);
  newcol(); 
  newcol();
}
  } /*parm_sel */
}

static int coas_parm_sel(int mode,TMCHAR parm_no[4], TMCHAR parm_value[32], TMCHAR parm_source[32])
{

EXEC SQL BEGIN DECLARE SECTION;
  TMCHAR  lparm_no[4]={0}/*TMCI18N CHANGED FROM ""*/;
  TMCHAR lparm_value[32]={0}/*TMCI18N CHANGED FROM ""*/;
  TMCHAR lparm_source[32]={0}/*TMCI18N CHANGED FROM ""*/;
EXEC SQL END DECLARE SECTION;

tmstrcpy(lparm_no,parm_no);


  EXEC SQL DECLARE cur_003 CURSOR FOR
   SELECT gjbcolr_value,
          gjbcolr_misc_value
   FROM   gjbcolr
   WHERE  gjbcolr_one_up_no = TO_NUMBER(:par_one_up_no)
   AND    gjbcolr_number    = :lparm_no
   AND    gjbcolr_job       = :rptname
   and    gjbcolr_misc_value = :par_coas
order by gjbcolr_value;

  if ( mode==CLOSE_CURSOR )
    {
      EXEC SQL CLOSE cur_003;
      POSTORA;
      return TRUE;
  }

  if ( mode==FIRST_ROW )
    {
      EXEC SQL OPEN cur_003;
      POSTORA;
    }

  EXEC SQL FETCH cur_003 INTO
       :lparm_value:Ind_01,
       :lparm_source:Ind_02;
  POSTORA;

  if ( NO_ROWS_FOUND )
    {
      *lparm_value='\0';
      *lparm_source='\0';
      *parm_value='\0';
      *parm_source='\0';
      
      return FALSE;
    }

tmstrcpy(parm_value,lparm_value);
tmstrcpy(parm_source,lparm_source);

  return TRUE;
}                                        /*  end parm_sel */
/* ************************************************************************ */
static int home_parm_sel(int mode,TMCHAR parm_no[4], TMCHAR parm_value[32], TMCHAR parm_source[32])
{

EXEC SQL BEGIN DECLARE SECTION;
  TMCHAR  lparm_no[4]={0}/*TMCI18N CHANGED FROM ""*/;
  TMCHAR lparm_value[32]={0}/*TMCI18N CHANGED FROM ""*/;
  TMCHAR lparm_source[32]={0}/*TMCI18N CHANGED FROM ""*/;
EXEC SQL END DECLARE SECTION;

tmstrcpy(lparm_no,parm_no);


  EXEC SQL DECLARE home_par CURSOR FOR
   SELECT gjbcolr_value,
          gjbcolr_misc_value
   FROM   gjbcolr
   WHERE  gjbcolr_one_up_no = TO_NUMBER(:par_one_up_no)
   AND    gjbcolr_number    = :lparm_no
   AND    gjbcolr_job       = :rptname
   and    gjbcolr_misc_value = :home_coas
order by gjbcolr_value;

  if ( mode==CLOSE_CURSOR )
    {
      EXEC SQL CLOSE home_par;
      POSTORA;
      return TRUE;
  }

  if ( mode==FIRST_ROW )
    {
      EXEC SQL OPEN home_par;
      POSTORA;
    }

  EXEC SQL FETCH home_par INTO
       :lparm_value:Ind_01,
       :lparm_source:Ind_02;
  POSTORA;

  if ( NO_ROWS_FOUND )
    {
      *lparm_value='\0';
      *lparm_source='\0';
      *parm_value='\0';
      *parm_source='\0';
      
      return FALSE;
    }

tmstrcpy(parm_value,lparm_value);
tmstrcpy(parm_source,lparm_source);

  return TRUE;
}                                        /*  end parm_sel */
static void home_parm_body(TMCHAR parm_name[32],TMCHAR parm_no[4],TMCHAR parm_dest[32])
{

CHAR32 parm_source, parm;

  EXEC SQL BEGIN DECLARE SECTION;
   int openmode;
  EXEC SQL END DECLARE SECTION;

openmode = FIRST_ROW;

  while ( home_parm_sel(openmode,parm_no,parm,parm_source) )
  {
    openmode = NEXT_ROW;

  newcol();
  prtstr(parm_name);
  newcol();
  if (*parm_source) 
     prtstr(parm_source);

  prtstr(parm);
  tmstrcpy(parm_dest,parm);
  newcol();

  if (inlist(parm_no,ALPHA,par_home_orgn_option_no,NULL))
  {
    if (compare(parm,_TMC("R"),EQS)) prtstr(TM_NLS_Get("0198","Range"));
    if (compare(parm,_TMC("A"),EQS)) prtstr(TM_NLS_Get("0199","All"));
    if (compare(parm,_TMC("W"),EQS)) prtstr(TM_NLS_Get("0200","Wildcards"));
    if (compare(parm,_TMC("S"),EQS)) prtstr(TM_NLS_Get("0201","Specific"));
  }

  lineno++;

  if ( lineno >= linelimit ) 
    {
  table(T_END);
  newpage();
  page_heading();
  table(T_BEGIN,4);
  newcol(); 
  newcol();
}
  } /* home_parm_sel */

}

static void validate_parm_format(TMCHAR parm_no[3], TMCHAR in_value[10])
{
EXEC SQL BEGIN DECLARE SECTION;
  TMCHAR parm_err_msg[40]={0}/*TMCI18N CHANGED FROM ""*/;
  TMCHAR parm_desc[40]={0}/*TMCI18N CHANGED FROM ""*/;
EXEC SQL END DECLARE SECTION;

EXEC SQL 
         select GJBPDEF_DESC 
                into :parm_desc from GJBPDEF
                where GJBPDEF_JOB=:rptname
                  and GJBPDEF_NUMBER=:parm_no;
POSTORA;

if (!*in_value)
   {
   tmstrcpy(parm_err_msg,TM_NLS_Get("0202","Missing/Invalid Parameter: "));
   tmstrcat(parm_err_msg,parm_desc);
   tmprintf(&tmBundle, _TMC("\n{0}\n"),parm_err_msg);
   invalid_parm_format=1;
   }
}
#undef tmBundle
