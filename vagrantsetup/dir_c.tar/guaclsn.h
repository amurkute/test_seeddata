/*TMCI18N BEGIN HEADER*/
#if !defined( _TMBGUACLSN_H_EXISTS )
/* No Initialisation Required */                                               
#include "tmcilib.h"
static struct TMBundle _TMBGUACLSN_H = {"guaclsn.h",NULL,NULL,NULL,NULL};
#define _TMBGUACLSN_H_EXISTS
#endif
/*TMCI18N END HEADER*/

/* AUDIT_TRAIL_SCB
-- Solution Centre Baseline 
-- PROJECT : BAN74c
-- MODULE  : GUACLSN
-- SOURCE  : enUS
-- TARGET  : I18N
-- DATE    : Tue Mar 20 13:03:28 2007
END AUDIT_TRAIL_SCB */
/* Object: guaclsn.h
   Author: John Morgan
 Mod Date: 12/5/94
  Release: General 2.x
*/

/***************************************************/
/*                                                 */
/*       CONFIDENTIAL BUSINESS INFORMATION         */
/*                                                 */
/*      **********************************         */
/*                                                 */
/*  THIS PROGRAM IS PROPRIETARY INFORMATION OF     */
/* SYSTEMS AND COMPUTER TECHNOLOGY CORPORATION     */
/* AND IS NOT TO BE COPIED, REPRODUCED, LENT OR    */
/* DISPOSED OF, NOR USED FOR ANY PURPOSE OTHER     */
/* THAN THAT FOR WHICH IT IS SPECIFICALLY PROVIDED */
/* WITHOUT THE WRITTEN PERMISSION OF SAID COMPANY  */
/*                                                 */
/***************************************************/

/* AUDIT TRAIL: 2.x                                INIT      DATE           */
/*                                                                          */
/* 1. File no longer specifically versioned, since  JWM    12/05/94         */
/*    it is primarily for SCT internal use and is                           */
/*    unlikely to be used by clients.                                       */
/* 2. Added COLLIDE macro to simplify commenting  JWM    12/05/94         */
/*    out identifiers which cause collisions in                             */
/*    development environment.                                              */
/*                                                                          */
/* AUDIT TRAIL: 8.0                                                         */
/* TAM 10/08/2007                                                           */
/* 1. Internationalization unicode conversion                               */
/* AUDIT TRAIL END                                                          */

/* guaclsn.h is optionally included by guastdf.h in order to check for
   potential problems with non-ANSI functions which may appear in otherwise
   standard header files with some compilers.  The following list should be
   edited to reflect changing conditions and new information, and if used
   by client-sites will need to be modified for the local environment.
*/

#ifndef _GUACLSN_H_

/* a local int should be sufficient to flush out most problems */

#define COLLIDE(s) static int(s);
#define NOCOLLIDE(s) /* NOCOLLIDE(s) */

/* supply function names as arguments to the COLLIDE macro; the following
   list should be added to, but nothing should be deleted; if identifier
   causes a collision on the development platform then use COLLIDE instead
   of COLLIDE
*/

NOCOLLIDE(access)
NOCOLLIDE(acct)
NOCOLLIDE(brk)
NOCOLLIDE(chdir)
COLLIDE(chmod)
NOCOLLIDE(class)
COLLIDE(closedir)
COLLIDE(creat)
NOCOLLIDE(dup)
NOCOLLIDE(dup2)
NOCOLLIDE(ecvt)
COLLIDE(ERR)
NOCOLLIDE(fcvt) 
COLLIDE(fstat)
COLLIDE(ftime)
NOCOLLIDE(gcvt) 
NOCOLLIDE(getpass) 
NOCOLLIDE(getpid)
NOCOLLIDE(getw) 
NOCOLLIDE(hypot) 
NOCOLLIDE(ioctl)
NOCOLLIDE(isascii) 
NOCOLLIDE(isatty) 
COLLIDE(lfind)
NOCOLLIDE(link)
COLLIDE(lsearch)
NOCOLLIDE(lseek)
COLLIDE(major)
NOCOLLIDE(memccpy) 
COLLIDE(memicmp)
COLLIDE(mkdir)
NOCOLLIDE(mktemp) 
COLLIDE(open)
COLLIDE(opendir)
COLLIDE(poly)
COLLIDE(pow10)
NOCOLLIDE(putenv) 
NOCOLLIDE(putw) 
NOCOLLIDE(read)
COLLIDE(readdir)
NOCOLLIDE(remainder)
NOCOLLIDE(readlink)
COLLIDE(rewinddir)
NOCOLLIDE(rmdir)
NOCOLLIDE(sbrk)
NOCOLLIDE(sleep)
COLLIDE(sopen)
COLLIDE(stat)
NOCOLLIDE(stime)
COLLIDE(stpcpy)
NOCOLLIDE(strdup) 
NOCOLLIDE(swab) 
NOCOLLIDE(tell)
NOCOLLIDE(tempnam) 
NOCOLLIDE(toascii) 
COLLIDE(to_term)
NOCOLLIDE(tzset) 
COLLIDE(ungetch)
NOCOLLIDE(unlink)
COLLIDE(utime)
NOCOLLIDE(vfscanf)
NOCOLLIDE(vscanf)
NOCOLLIDE(vsscanf)
NOCOLLIDE(write)

#endif
