/*TMCI18N BEGIN HEADER*/
#if !defined( _TMBSMRBCMP_H_EXISTS )
/* No Initialisation Required */                                               
#include "tmcilib.h"
static struct TMBundle _TMBSMRBCMP_H = {"smrbcmp.h",NULL,NULL,NULL,NULL};
#define _TMBSMRBCMP_H_EXISTS
#endif
/*TMCI18N END HEADER*/

/* AUDIT_TRAIL_TM63
-- TranMan 6.3 
-- PROJECT : PVV_TEST
-- MODULE  : SMRBCMP
-- SOURCE  : enUS
-- TARGET  : I18N
-- DATE    : Fri Oct 19 07:54:18 2007
END AUDIT_TRAIL_TM63 */
/******************************************************************************/
/* SMRCMPL.H Copyright (c) SCT Corporation 1993.  All rights reserved.       */
/******************************************************************************/

/***************************************************/
/*                                                 */
/*       CONFIDENTIAL BUSINESS INFORMATION         */
/*                                                 */
/*      **********************************         */
/*                                                 */
/*  THIS PROGRAM IS PROPRIETARY INFORMATION OF     */
/* SYSTEMS AND COMPUTER TECHNOLOGY CORPORATION     */
/* AND IS NOT TO BE COPIED, REPRODUCED, LENT OR    */
/* DISPOSED OF, NOR USED FOR ANY PURPOSE OTHER     */
/* THAN THAT FOR WHICH IT IS SPECIFICALLY PROVIDED */
/* WITHOUT THE WRITTEN PERMISSION OF SAID COMPANY  */
/*                                                 */
/***************************************************/
/* SMRCMPL.H                                                           */
/* Program Compliance Header File.                                     */
/*                                                                     */
/* AUDIT TRAIL: 2.1.8                                  INIT    DATE    */
/*                                                     ____  ________  */
/* 1. New Header file to be used for the Program         AP  06/01/95  */
/*    Compliance Process.                                              */
/* AUDIT TRAIL: 2.1.11                                                 */
/* 1. Add GPA variables, last earned variables,          AP  04/01/96  */
/*    and other variables and prototypes needed for                    */
/*    rule logic.                                                      */
/*                                                                     */
/* AUDIT TRAIL: 2.1.15                                                 */
/* 1. Shorten the routine name.                          AP  11/18/96  */
/*      old: match_crseused_in_restriction_range                       */
/*      new: match_crseused_in_restr_range                             */
/* 2. Remove duplicate variables.                                      */
/*      program_code, program_levl, credhrs_used.                      */
/* 3. Replace these variables, program_camp, program_coll,             */
/*    and program_degc, with stu_camp, stu_coll, and stu_degc.         */
/* 4. Add variable crse_sel_file_open to indicate if     AP  12/09/96  */
/*    .lis file is open.                                               */
/*                                                                     */
/* AUDIT TRAIL: 2.1.20                                   AP  11/19/96  */
/* 1. Add Non-Captive logic.                                           */
/* 2. Remove the following gpa calculation prototypes:                 */
/*     - cal_area_gpa, cal_prog_gpa, cal_cum_gpa.                      */
/*    and replace them with Database Package Function (SMKCGPA).       */
/*                                                                     */
/* AUDIT TRAIL: 2.1.21                                                 */
/* 1. Initialized rule_cursor_value, rule_cursor_value_2,              */
/*    g_rule_cursor_value, and g_rule_cursor_value_2 = 99 to break the */
/*    case statement.                                 NM   06/30/97    */
/* AUDIT TRAIL: 8.0 (I18N)                                             */
/*   Description: Unicode Translation for I18N Done                    */
/* AUDIT TRAIL END                                                     */
/********************************************************************* */

#ifndef _SMRCMPL_C_
#define STORE_CLASS extern
#else
#define STORE_CLASS /* */
#endif

#define MAXLEVELS 10 
#define MAXRESGRD 20
#define MAXATTR   10
#define MAXRESTR  500
#define MAXEXCL   50
#define MAXSPLITS 100

#define TRUE 1
#define FALSE 0
#define GOOD  1
#define NOT_GOOD 0
#define ZEROCRED 0.00
#define ISZERO   0.001
#define NOVAL    99999

/* Define cursor names */
#define AREA_EXCLUSION           1
#define GROP_EXCLUSION           2
#define RULE_AREA_EXCLUSION      3
#define RULE_GROP_EXCLUSION      4
#define SADJ_AREA_EXCLUSION      5
#define SADJ_GROP_EXCLUSION      6
#define SADJ_RULE_AREA_EXCLUSION 7
#define SADJ_RULE_GROP_EXCLUSION 8

#define AREA_DETL_ADDL_LEVEL      1
#define GROP_DETL_ADDL_LEVEL      2
#define RULE_AREA_DETL_ADDL_LEVEL 3
#define RULE_GROP_DETL_ADDL_LEVEL 4
#define AREA_DETL_ADDL_LEVEL_2    5
#define GROP_DETL_ADDL_LEVEL_2    6
#define RULE_AREA_DETL_ADDL_LEVEL_2 7
#define RULE_GROP_DETL_ADDL_LEVEL_2 8

/* define cursor values for group general requirements. */
#define GRPGENL              1
#define GRPGENL_SADJ         2

/* Reject Reasons (Max length - 60 char) */
#define REASON1  TM_NLS_HGet( &_TMBSMRBCMP_H, "0000","Campus/Coll/Dept Not Valid for Requirement.") 
#define REASON2  TM_NLS_HGet( &_TMBSMRBCMP_H, "0001","Outside Term Range.")
#define REASON3  TM_NLS_HGet( &_TMBSMRBCMP_H, "0002","Exceeded Year Rule Limit.")
#define REASON4  TM_NLS_HGet( &_TMBSMRBCMP_H, "0003","Outside Credits Per Crse Range.")
#define REASON5  TM_NLS_HGet( &_TMBSMRBCMP_H, "0004","Detail Min Grade Not Met.")     
#define REASON6  TM_NLS_HGet( &_TMBSMRBCMP_H, "0005","Group Min Grade Not Met.")     
#define REASON7  TM_NLS_HGet( &_TMBSMRBCMP_H, "0006","Area Min Grade Not Met.")     
#define REASON8  TM_NLS_HGet( &_TMBSMRBCMP_H, "0007","Program Min Grade Not Met.")     
#define REASON9  TM_NLS_HGet( &_TMBSMRBCMP_H, "0008","Detail Addl. Level Not Met.")    
#define REASON10 TM_NLS_HGet( &_TMBSMRBCMP_H, "0009","Group Addl. Level Not Met.")    
#define REASON11 TM_NLS_HGet( &_TMBSMRBCMP_H, "0010","Area Addl. Level Not Met.")    
#define REASON12 TM_NLS_HGet( &_TMBSMRBCMP_H, "0011","Program Addl. Level Not Met.")    
#define REASON13 TM_NLS_HGet( &_TMBSMRBCMP_H, "0012","Intentionally Excluded from the Requirement.")
#define REASON14 TM_NLS_HGet( &_TMBSMRBCMP_H, "0013","Course Level Not Valid for Group/Area/Program.")
#define REASON15 TM_NLS_HGet( &_TMBSMRBCMP_H, "0014","Group Restricted Subject/Attribute.")
#define REASON16 TM_NLS_HGet( &_TMBSMRBCMP_H, "0015","Area Restricted Subject/Attribute.")
#define REASON17 TM_NLS_HGet( &_TMBSMRBCMP_H, "0016","Program Restricted Subject/Attribute.")
#define REASON18 TM_NLS_HGet( &_TMBSMRBCMP_H, "0017","Group Restricted Grade.")
#define REASON19 TM_NLS_HGet( &_TMBSMRBCMP_H, "0018","Area Restricted Grade.")
#define REASON20 TM_NLS_HGet( &_TMBSMRBCMP_H, "0019","Program Restricted Grade.")
#define REASON21 TM_NLS_HGet( &_TMBSMRBCMP_H, "0020","Transfer Course Not Allowed.")
#define REASON22 TM_NLS_HGet( &_TMBSMRBCMP_H, "0021","Exceeded Max Tranfer Credits/Courses.")
#define REASON23 TM_NLS_HGet( &_TMBSMRBCMP_H, "0022","Exceeded Max Non-Traditional Credits/Courses.")
#define REASON24 TM_NLS_HGet( &_TMBSMRBCMP_H, "0023","Course Was Targeted to Different Area/Group.")

/* Student Attribute Structure */
typedef struct stud_attr_type {
   struct stud_attr_type *next;
   BANNUMSTR(pidm);
   TMCHAR  term_code[7];
   TMCHAR  atts_code[5];
   TMCHAR  a_reuse[2];          /* Attribute Reuse Indicator */
   TMCHAR area_used[11];       
   TMCHAR group_used[11];
   int    caa_seqno;        /* Indicate a detail req. seqno for which */
                            /* compliance tries to fullfill */ 
   int    p_counted;
   int    a_counted;
   int    g_counted;
   int    used_flg;
} ATTS_TYPE;

/* Course Attribute Structure */
typedef struct crse_attr_type {
   TMCHAR  attr_code[5];
   float  hours;
   float  hours_avail;
   float  hours_used;
   TMCHAR  a_reuse[2];          /* Attribute reuse indicator */
   int    partial_flg; 
   int    all_flg; 
   int    used_flg;
   TMCHAR  remainder_ind[2];
   TMCHAR  used_ind[2];
   TMCHAR area_used[11];       
   TMCHAR group_used[11];
   int    caa_seqno;        /* Indicate a detail req. seqno for which */
                            /* compliance tries to fullfill */ 
   int    crse_counted;
   int    p_counted;
   int    a_counted;
   int    g_counted;
} ATTR_TYPE;

/* Student Course Structure */
typedef struct stud_crse_type {
   struct stud_crse_type *next;
   BANNUMSTR(pidm);
   TMCHAR id_number[10];
   TMCHAR  term_code[7];
   TMCHAR  subject[5];
   TMCHAR  crse_numb[6];
   TMCHAR  crn[7];
   TMCHAR title[31];
   TMCHAR  camp[2];
   TMCHAR  coll[3];
   TMCHAR  dept[5];
   TMCHAR  crse_levl[3];
   float  hours;
   float  hours_used;
   TMCHAR  grde[4];
   TMCHAR  grde_mode[2];
   float  grde_qual_pt;
   int    grde_num_val;
   TMCHAR  grde_gpa_ind[2];
   TMCHAR  tran_ind[2];
   TMCHAR  enrl_ind[2];
   TMCHAR  multi_use_ind[2];
   float  gpa_hrs;
   float  qual_pt;
   TMCHAR  rep_equiv_ind[2];
   TMCHAR  trad_ind[2];
   TMCHAR  earned_ind[2];
   TMCHAR  source[2];
   int    tckn_seq;
   int    trit_seq;
   int    tram_seq;
   int    trcr_seq;
   int    trce_seq;
   TMCHAR  c_reuse[2];          /* Course Reuse Indicator    */
   TMCHAR  a_reuse[2];          /* Attribute Reuse Indicator */
   int    partial_flg; 
   int    all_flg; 
   TMCHAR area_used[11];       
   TMCHAR group_used[11];
   int    caa_seqno;        /* Indicate a detail req. seqno for which */
                            /* compliance tries to fullfill */ 
   int    p_counted;
   int    a_counted;
   int    g_counted;
   int    used_flg;
   TMCHAR  used_ind[2];     
   float  g_totcred_used;
   int    g_totcrse_used;
   float  a_totcred_used;
   int    a_totcrse_used;
   float  p_totcred_used;
   int    p_totcrse_used;

   TMCHAR  equivalent_ind[2]; 
   ATTR_TYPE attr[MAXATTR];
   int    n_attr;
} S_CRSE;  

typedef struct split_crse_type {
   int    seqno;
   TMCHAR area_used[11];
   TMCHAR group_used[11];
   float  hours_remain;
   float  hours_used;
   TMCHAR  c_reuse[2];
   int    partial_ind;
   int    total_ind;
   int    used_ind;
   int    cntin_prog;
   int    cntin_area;
   int    cntin_group;
} SPLIT_CRSE;

/* Attached Area Structure */
typedef struct attached_area {
   struct attached_area *next;
   TMCHAR area[11];   
   TMCHAR  area_levl[3];
   TMCHAR  term_code_catalog[7];     /* Term code catalog used to read area reqs. */
   TMCHAR  term_code[7];             /* Term code when area was attached to prog. */
   TMCHAR  crse_reuse[2];
   TMCHAR  attr_reuse[2];
   TMCHAR  dynamic_ind[2];
   TMCHAR  within_ind[2];
   int    year_rule;
   int    priority;  
   int    met_ind;
   TMCHAR  adj_actn_code[4];
   float  adj_cred;
   int    adj_crse;    
} PRG_AREA;

typedef struct attached_group {
   struct attached_group *next;
   TMCHAR group[11];   
   TMCHAR  group_levl[3];
   TMCHAR  term_code[7];
   TMCHAR  crse_reuse[2];
   TMCHAR  attr_reuse[2];
   TMCHAR  within_ind[2]; 
   int    year_rule;
   TMCHAR  set[4];
   int    subset;
   TMCHAR rule[11];
   int    met_ind;
   int    dupl_ind;     
   TMCHAR  adj_actn_code[4];
   float  adj_cred;
   int    adj_crse;    
} AREA_GRP;

/* Restricted Subject and Attribute Structure */
typedef struct rstrict_type {
   int   res_subj_type;
   TMCHAR res_term_eff[7];
   int   res_seqno;
   TMCHAR res_subj[5];
   TMCHAR res_crse[6];
   TMCHAR res_crse_low[6];
   TMCHAR res_crse_high[6];
   TMCHAR res_attr[5];
   TMCHAR res_camp[2];
   TMCHAR res_coll[3];
   TMCHAR res_dept[5];
   float res_max_cred;
   int   res_max_crse;
   TMCHAR res_conn[2];
   float res_cred_used;
   int   res_crse_used;
   TMCHAR exceeded[2];
   int   range_numb;      /* the nth range restriction */
   TMCHAR res_actn_code[4];
} RSTRICT;

/* Restricted Grade Structure */
typedef struct rstrgrd_type { 
   TMCHAR res_grd[4];
   int   res_grd_n_val;
   TMCHAR res_term_eff[7];
   float res_max_cred;
   int   res_max_crse;
   TMCHAR res_conn[2];
   float res_cred_used;
   int   res_crse_used;
   TMCHAR res_actn_code[4];
} RSTRGRD;

/* Additional Level Structure */
typedef struct addlvl_type {
   TMCHAR alvl_term_eff[7];
   TMCHAR alvl_levl[3];
   TMCHAR alvl_grde[4];
   float alvl_max_cred;
   int   alvl_max_crse;
   TMCHAR alvl_conn[2];
   float alvl_cred_used;
   int   alvl_crse_used;
   TMCHAR alvl_actn_code[4];
} ADDLVL;

/* Course Exclusion Structure */
typedef struct exclusion_type {
  TMCHAR e_term_eff[7];
  TMCHAR e_subj[5];
  int   e_subj_type;
  TMCHAR e_crse[6];
  TMCHAR e_low[6];
  TMCHAR e_high[6];
  TMCHAR e_attr[5]; 
  TMCHAR e_atts[5];
  TMCHAR e_frterm[7];
  TMCHAR e_toterm[7];
  TMCHAR e_camp[2];
  TMCHAR e_coll[3];
  TMCHAR e_dept[5];
  TMCHAR e_excluded[2];
  int   e_type;   
  int   range_numb;
  TMCHAR e_actn[4];   
} CRSE_EXCL;

/* Course Range Structure */      
typedef struct range_type {
  TMCHAR r_subj[5];
  TMCHAR r_crse[6];
  float r_hrs;
  TMCHAR r_term[7];
  TMCHAR r_levl[3];
  TMCHAR r_match[2];
  TMCHAR r_excluded[2];
} CRSE_RANGE;

/* Course Range Structure */
typedef struct crange_type {
  struct crange_type *next;
  TMCHAR subj[5];
  TMCHAR crse[6]; 
  int   match_flag;
  int   split_flag;
  int   excluded_flag;
} C_RANGE;

EXEC SQL BEGIN DECLARE SECTION;
   STORE_CLASS TMCHAR  create_crse_sel_rpt[2];
   STORE_CLASS BANNUMSTR(linelimit);
   STORE_CLASS int    lineno;

   STORE_CLASS BANNUMSTR(stud_pidm);
   STORE_CLASS TMCHAR  temp_val[2];
   STORE_CLASS int    request_no;
   STORE_CLASS TMCHAR  catlg_term_parm[7];
   STORE_CLASS TMCHAR  eval_term_parm[7];
   STORE_CLASS TMCHAR  degr_crse_parm[2];
   STORE_CLASS int    degree_seq;
   STORE_CLASS BANNUMSTR(grde_num_val_parm);
   STORE_CLASS TMCHAR  min_term_parm[7];   
   STORE_CLASS TMCHAR  max_term_parm[7];    
   STORE_CLASS int    agam_year_rule;
   STORE_CLASS TMCHAR  source_ind[2];
   STORE_CLASS TMCHAR  use_within_area[2];
   STORE_CLASS TMCHAR  use_within_group[2];
   STORE_CLASS int    next_compl_order;

/* Program general requirements */
   STORE_CLASS int    program_met;
   STORE_CLASS TMCHAR program_code[13];
   STORE_CLASS TMCHAR  program_levl[3];
   STORE_CLASS TMCHAR  pgen_active[2];
   STORE_CLASS TMCHAR  pgen_captive[2];
   STORE_CLASS TMCHAR  pgen_term_eff[7];
   STORE_CLASS int    pgen_year_rule;
   STORE_CLASS TMCHAR  pgen_min_grde[4];
   STORE_CLASS float  pgen_min_gpa;  
   STORE_CLASS float  pgen_min_prog_gpa;
   STORE_CLASS float  pgen_cmpl_cred;
   STORE_CLASS int    pgen_cmpl_crse;
   STORE_CLASS float  pgen_overall_cred;
   STORE_CLASS int    pgen_overall_crse;
   STORE_CLASS TMCHAR  pgen_conn_overall[2];
   STORE_CLASS float  pgen_inst_cred;
   STORE_CLASS int    pgen_inst_crse;
   STORE_CLASS TMCHAR  pgen_conn_inst[2];
   STORE_CLASS float  pgen_itrad_cred;
   STORE_CLASS int    pgen_itrad_crse;
   STORE_CLASS TMCHAR  pgen_conn_itrad[2];
   STORE_CLASS float  pgen_intrad_cred;
   STORE_CLASS int    pgen_intrad_crse;
   STORE_CLASS TMCHAR  pgen_conn_intrad[2];
   STORE_CLASS float  pgen_xfer_cred;
   STORE_CLASS int    pgen_xfer_crse;
   STORE_CLASS TMCHAR  pgen_conn_xfer[2];
   STORE_CLASS float  pgen_last_i_cred;
   STORE_CLASS int    pgen_last_i_crse;
   STORE_CLASS TMCHAR  pgen_conn_last_i[2];
   STORE_CLASS float  pgen_last_e_cred;
   STORE_CLASS int    pgen_last_e_crse;
   STORE_CLASS TMCHAR  pgen_conn_last_e[2];
   STORE_CLASS TMCHAR  plvl_excl_ind[2];

   STORE_CLASS TMCHAR  attached_areas_term[7];
   STORE_CLASS TMCHAR  attached_groups_term[7];

/* Area general requirements */
   STORE_CLASS int    numb_areas;
   STORE_CLASS TMCHAR  agen_active[2];
   STORE_CLASS TMCHAR  agen_term_eff[7];
   STORE_CLASS int    agen_year_rule;
   STORE_CLASS TMCHAR  agen_min_grde[4];
   STORE_CLASS float  agen_min_area_gpa;
   STORE_CLASS float  agen_cmpl_cred;
   STORE_CLASS int    agen_cmpl_crse;
   STORE_CLASS float  agen_overall_cred;
   STORE_CLASS int    agen_overall_crse;
   STORE_CLASS TMCHAR  agen_conn_overall[2];
   STORE_CLASS float  agen_inst_cred;
   STORE_CLASS int    agen_inst_crse;
   STORE_CLASS TMCHAR  agen_conn_inst[2];
   STORE_CLASS float  agen_itrad_cred;
   STORE_CLASS int    agen_itrad_crse;
   STORE_CLASS TMCHAR  agen_conn_itrad[2];
   STORE_CLASS float  agen_intrad_cred;
   STORE_CLASS int    agen_intrad_crse;
   STORE_CLASS TMCHAR  agen_conn_intrad[2];
   STORE_CLASS float  agen_xfer_cred;
   STORE_CLASS int    agen_xfer_crse;
   STORE_CLASS TMCHAR  agen_conn_xfer[2];
   STORE_CLASS TMCHAR  agen_gc_ind[2];
   STORE_CLASS TMCHAR  alvl_excl_ind[2];
   STORE_CLASS TMCHAR reason[31];
   STORE_CLASS TMCHAR reject_reason[61];
   STORE_CLASS TMCHAR  dynamic_ind[2];

/* Group Variables */
   STORE_CLASS TMCHAR group_code[11];
   STORE_CLASS TMCHAR  group_levl[3];
   STORE_CLASS int    group_exist;
   STORE_CLASS TMCHAR  agam_set[4];
   STORE_CLASS int    agam_subset;

   /* Group general requirements */
   STORE_CLASS TMCHAR  ggen_active[2];
   STORE_CLASS TMCHAR  ggen_term_eff[7];
   STORE_CLASS int    ggen_year_rule;
   STORE_CLASS TMCHAR  ggen_min_grde[4];
   STORE_CLASS float  ggen_cmpl_cred;
   STORE_CLASS int    ggen_cmpl_crse;
   STORE_CLASS float  ggen_overall_cred;
   STORE_CLASS int    ggen_overall_crse;
   STORE_CLASS TMCHAR  ggen_conn_overall[2];
   STORE_CLASS float  ggen_inst_cred;
   STORE_CLASS int    ggen_inst_crse;
   STORE_CLASS TMCHAR  ggen_conn_inst[2];
   STORE_CLASS float  ggen_itrad_cred;
   STORE_CLASS int    ggen_itrad_crse;
   STORE_CLASS TMCHAR  ggen_conn_itrad[2];
   STORE_CLASS float  ggen_intrad_cred;
   STORE_CLASS int    ggen_intrad_crse;
   STORE_CLASS TMCHAR  ggen_conn_intrad[2];
   STORE_CLASS float  ggen_xfer_cred;
   STORE_CLASS int    ggen_xfer_crse;
   STORE_CLASS TMCHAR  ggen_conn_xfer[2];
   STORE_CLASS TMCHAR  glvl_excl_ind[2];

/* Temporary variables */
   STORE_CLASS TMCHAR t_var1[11];   
   STORE_CLASS TMCHAR  t_var2[7];
   STORE_CLASS TMCHAR  t_var3[2];
   STORE_CLASS TMCHAR  t_var4[2];
   STORE_CLASS int    t_var5;
   STORE_CLASS TMCHAR  t_var6[4];
   STORE_CLASS int    t_var7;
   STORE_CLASS TMCHAR t_var8[11];
   STORE_CLASS TMCHAR  t_var9[2];
   STORE_CLASS TMCHAR  t_var10[4];
   STORE_CLASS float  t_var11;
   STORE_CLASS int    t_var12;
   STORE_CLASS TMCHAR t_frterm[7];
   STORE_CLASS TMCHAR t_toterm[7];
   STORE_CLASS TMCHAR t_term_eff[7];
   STORE_CLASS int   t_seqno;
   STORE_CLASS TMCHAR t_subj[5];
   STORE_CLASS TMCHAR t_crse[6];
   STORE_CLASS TMCHAR t_crse_high[6];
   STORE_CLASS TMCHAR t_attr[5];
   STORE_CLASS TMCHAR t_atts[5];
   STORE_CLASS TMCHAR t_levl[3];
   STORE_CLASS TMCHAR t_camp[2];
   STORE_CLASS TMCHAR t_coll[3];
   STORE_CLASS TMCHAR t_dept[5];
   STORE_CLASS TMCHAR t_degc[7];
   STORE_CLASS TMCHAR t_grd[4];
   STORE_CLASS float t_max_cred;
   STORE_CLASS TMCHAR t_conn_max[2];
   STORE_CLASS int   t_max_crse;
   STORE_CLASS float t_max_cred_used;
   STORE_CLASS int   t_max_crse_used;
   STORE_CLASS TMCHAR t_actn_code[4];
   STORE_CLASS float t_actl_cred; 
   STORE_CLASS int   t_actl_crse;
   STORE_CLASS TMCHAR low_val[6];
   STORE_CLASS TMCHAR high_val[6];
   STORE_CLASS TMCHAR subj_val[5];
   STORE_CLASS int   stype;
   STORE_CLASS int   subj_type;
   STORE_CLASS int   subj_typ;
   STORE_CLASS int   grde_n_val;
   STORE_CLASS TMCHAR cred_type[2];

/* First Pass variables */
   STORE_CLASS int    paap_year_rule;
   STORE_CLASS TMCHAR  subj[5];
   STORE_CLASS TMCHAR  crse_low[6];
   STORE_CLASS TMCHAR  crse_high[6];
   STORE_CLASS TMCHAR  catalog_ind[2];
   STORE_CLASS int    seqno;
   STORE_CLASS TMCHAR  set[4];
   STORE_CLASS int    subset;
   STORE_CLASS TMCHAR  req_attr[5];
   STORE_CLASS TMCHAR  req_atts[5];
   STORE_CLASS TMCHAR  camp[2];
   STORE_CLASS TMCHAR  coll[3];
   STORE_CLASS TMCHAR  dept[5];
   STORE_CLASS TMCHAR rule[11];
   STORE_CLASS float  req_cred;
   STORE_CLASS int    req_crse;
   STORE_CLASS TMCHAR  req_conn[2];
   STORE_CLASS float  max_cred;
   STORE_CLASS int    max_crse;
   STORE_CLASS TMCHAR  max_conn[2];
   STORE_CLASS float  xfer_cred;
   STORE_CLASS int    xfer_crse;
   STORE_CLASS TMCHAR  xfer_conn[2];
   STORE_CLASS TMCHAR  xfer_ind[2];
   STORE_CLASS TMCHAR  fr_term[7];
   STORE_CLASS TMCHAR  toterm[7];
   STORE_CLASS TMCHAR  min_grde[4];
   STORE_CLASS float  min_cred_crse;
   STORE_CLASS float  max_cred_crse;
   STORE_CLASS int    yr_rule;
   STORE_CLASS TMCHAR  split_ind[2];
   STORE_CLASS TMCHAR  caa_term[7];
   STORE_CLASS TMCHAR  caa_cnt_in_gpa[2];
   STORE_CLASS TMCHAR  orig_caa_cnt_in_gpa[2];
   STORE_CLASS TMCHAR  dlvl_incl_ind[2];
   STORE_CLASS TMCHAR  dlvl_excl_ind[2];
   STORE_CLASS int    only_crseattr;
   STORE_CLASS float  detl_cmpl_cred;
   STORE_CLASS int    detl_cmpl_crse;

   STORE_CLASS float  detl_cmpl_cred_used;
   STORE_CLASS int    detl_cmpl_crse_used;
/* Second Pass variables */
   STORE_CLASS TMCHAR scndpass_for_rule[11];
   STORE_CLASS int    rule_scndpass_flag;
   STORE_CLASS TMCHAR  evaluated_set[4];
   STORE_CLASS int    evaluated_seqno;
   STORE_CLASS int    evaluated_rule_seqno;
   STORE_CLASS TMCHAR  evaluated_group_set[4];
   STORE_CLASS TMCHAR evaluated_group[11];
   STORE_CLASS TMCHAR  prev_caa_term[7];
   STORE_CLASS TMCHAR prev_caa_rule[11];
   STORE_CLASS int    prev_caa_seqno;
   STORE_CLASS TMCHAR  prev_caa_set[4];
   STORE_CLASS int    prev_caa_subset;
   STORE_CLASS int    prev_caa_set_met;

   STORE_CLASS TMCHAR  prev_agam_term[7];
   STORE_CLASS TMCHAR prev_agam_group[11];
   STORE_CLASS TMCHAR  prev_agam_set[4];
   STORE_CLASS int    prev_agam_subset;
   STORE_CLASS int    prev_agam_set_met;

   STORE_CLASS TMCHAR  potential_used_ind[2];
   STORE_CLASS TMCHAR  s_subj[5];
   STORE_CLASS TMCHAR  s_crse_low[6];
   STORE_CLASS TMCHAR  s_crse_high[6];
   STORE_CLASS TMCHAR  s_catalog_ind[2];
   STORE_CLASS int    s_seqno;
   STORE_CLASS TMCHAR  s_set[4];
   STORE_CLASS int    s_subset;
   STORE_CLASS TMCHAR  s_req_attr[5];
   STORE_CLASS TMCHAR  s_req_atts[5];
   STORE_CLASS TMCHAR  s_camp[2];
   STORE_CLASS TMCHAR  s_coll[3];
   STORE_CLASS TMCHAR  s_dept[5];
   STORE_CLASS TMCHAR s_rule[11];
   STORE_CLASS float  s_req_cred;
   STORE_CLASS int    s_req_crse;
   STORE_CLASS TMCHAR  s_req_conn[2];
   STORE_CLASS float  s_max_cred;
   STORE_CLASS int    s_max_crse;
   STORE_CLASS TMCHAR  s_max_conn[2];
   STORE_CLASS float  s_xfer_cred;
   STORE_CLASS int    s_xfer_crse;
   STORE_CLASS TMCHAR  s_xfer_conn[2];
   STORE_CLASS TMCHAR  s_xfer_ind[2];
   STORE_CLASS TMCHAR  s_frterm[7];
   STORE_CLASS TMCHAR  s_toterm[7];
   STORE_CLASS TMCHAR  s_min_grde[4];
   STORE_CLASS float  s_min_cred_crse;
   STORE_CLASS float  s_max_cred_crse;
   STORE_CLASS int    s_yr_rule;
   STORE_CLASS TMCHAR  s_split_ind[2];
   STORE_CLASS TMCHAR  s_caa_term[7];
   STORE_CLASS TMCHAR  s_caa_cnt_in_gpa[2];
   STORE_CLASS float  s_detl_cmpl_cred;
   STORE_CLASS int    s_detl_cmpl_crse;
   STORE_CLASS TMCHAR  s_actn_code[4];
   STORE_CLASS float  s_adj_cred; 
   STORE_CLASS int    s_adj_crse;
   STORE_CLASS TMCHAR  s_actn_ind[2];
   STORE_CLASS TMCHAR  s_actn_cnt[2];

/* Detail Processing variables */
   STORE_CLASS int    processed;
   STORE_CLASS TMCHAR  course_term[7];
   STORE_CLASS TMCHAR  course_crn[7];
   STORE_CLASS TMCHAR  course_levl[3];
   STORE_CLASS TMCHAR  course_camp[2];
   STORE_CLASS TMCHAR  course_coll[3];
   STORE_CLASS TMCHAR  course_dept[5];
   STORE_CLASS float  course_hours;
   STORE_CLASS TMCHAR  course_grde[4];
   STORE_CLASS TMCHAR  course_grde_mode[2];
   STORE_CLASS int    course_grde_n_val;
   STORE_CLASS float  course_grde_qual_pt;
   STORE_CLASS TMCHAR  course_subj[5];
   STORE_CLASS TMCHAR  course_numb[6];      
   STORE_CLASS TMCHAR  course_attr[5];
   STORE_CLASS TMCHAR  course_source[2];
   STORE_CLASS TMCHAR  course_earned_ind[2];
   STORE_CLASS TMCHAR  course_grde_gpa_ind[2];
   STORE_CLASS TMCHAR course_title[31];
   STORE_CLASS TMCHAR  eval_subj[5];
   STORE_CLASS TMCHAR  eval_crse_numb[6];
   STORE_CLASS TMCHAR  r_subj[5];
   STORE_CLASS TMCHAR  r_crse[6];
   STORE_CLASS TMCHAR  c_term_parm[7];
   STORE_CLASS TMCHAR  frterm_parm[7];
   STORE_CLASS TMCHAR  toterm_parm[7];
   STORE_CLASS int    yr_rule_parm;
   STORE_CLASS int    cnt_in_area;
   STORE_CLASS int    cnt_in_prog;
   STORE_CLASS int    cnt_in_group;
   STORE_CLASS int    cnt_in_gpa;
   STORE_CLASS TMCHAR  cnt_in_prog_gpa[2];
   STORE_CLASS TMCHAR  cnt_in_area_gpa[2];
   STORE_CLASS int    course_cntin_area;
   STORE_CLASS int    course_cntin_prog;
   STORE_CLASS int    course_cntin_group;
   STORE_CLASS TMCHAR  course_trad_ind[2];
   STORE_CLASS TMCHAR  course_repeat_ind[2];
   STORE_CLASS TMCHAR  course_equiv_ind[2]; 
   STORE_CLASS TMCHAR  course_split_ind[2];
   STORE_CLASS TMCHAR  curr_crse_reuse[2];        
   STORE_CLASS TMCHAR  curr_attr_reuse[2];        
   STORE_CLASS TMCHAR  g_curr_crse_reuse[2];        
   STORE_CLASS TMCHAR  g_curr_attr_reuse[2];        
   STORE_CLASS TMCHAR  a_curr_crse_reuse[2];        
   STORE_CLASS TMCHAR  a_curr_attr_reuse[2];        
   STORE_CLASS int    course_tckn_seq;
   STORE_CLASS int    course_trit_seq;
   STORE_CLASS int    course_tram_seq;
   STORE_CLASS int    course_trcr_seq;
   STORE_CLASS int    course_trce_seq;
   STORE_CLASS int    avail_flag;

/****** *******/
/* Student Attributes Variables */
   STORE_CLASS TMCHAR atts_used[5];
   STORE_CLASS int   p_attr_met_ind;
   STORE_CLASS TMCHAR p_attr_req_term_eff[7];
   STORE_CLASS TMCHAR p_attr_conn[2];
   STORE_CLASS float p_attr_req_cred;
   STORE_CLASS int   p_attr_req_crse;
   STORE_CLASS float act_attr_cred;
   STORE_CLASS int   act_attr_crse;
   STORE_CLASS TMCHAR prog_atts_code[5];
   STORE_CLASS int   prog_atts_met;
   STORE_CLASS TMCHAR prog_attr_code[5];
   STORE_CLASS int   prog_attr_met;
   STORE_CLASS TMCHAR p_attr_actn_code[4];

/* Attributes Variables */
   STORE_CLASS TMCHAR attr_used[5];
   STORE_CLASS TMCHAR  grde_parm[4];
   STORE_CLASS TMCHAR  levl_parm[3];
   STORE_CLASS TMCHAR  term_parm[7];
   STORE_CLASS TMCHAR  subj_parm[5];
   STORE_CLASS TMCHAR  crse_parm[6];
   STORE_CLASS TMCHAR  crse_parm_high[6];
   STORE_CLASS TMCHAR area_code[11];
   STORE_CLASS TMCHAR  area_levl[3];
   STORE_CLASS TMCHAR  r_set[4];        /* used to identify course to be released*/
   STORE_CLASS int    r_subset;    

   STORE_CLASS TMCHAR  ncrq_term_eff[7];
   STORE_CLASS TMCHAR  ncrq_code[5];
   STORE_CLASS int    ncrq_year_rule;
   STORE_CLASS int    ncrq_satisfied_yr;  
   STORE_CLASS TMCHAR  ncrq_actn_code[4];
   STORE_CLASS TMCHAR  ncst_code[3];
   STORE_CLASS TMCHAR ncst_date[12];
   STORE_CLASS int    ncrs_seq_no;
   STORE_CLASS int    num_ncrse_req;   /* Number of non-course requirements   */
   STORE_CLASS TMCHAR  ncrse_req_met[2];    /* Y=Met N=Not Met Z=No Non-Crse Req. */
   STORE_CLASS TMCHAR  attr_req_met[2];     /* Y=Met N=Not Met Z=No Attribute Req.*/
   STORE_CLASS TMCHAR  detl_req_met[2];     /* Y=Met N=Not Met Z=No Detail Req.   */

   STORE_CLASS float credhrs_used;
   STORE_CLASS float cred_avail;  
   STORE_CLASS float tot_cred_used;
   STORE_CLASS int   tot_crse_used;
   STORE_CLASS float tot_xfer_cred_used;
   STORE_CLASS int   tot_xfer_crse_used;
   STORE_CLASS float addl_cred_used;
   STORE_CLASS int   satisfy_ind; 
   STORE_CLASS int   num_old_crse;
   STORE_CLASS int   reuse_flag;

/* Split credits variables */
   STORE_CLASS int   splt_seqno;
   STORE_CLASS TMCHAR splt_subj[5];
   STORE_CLASS TMCHAR splt_crse_numb[6];
   STORE_CLASS TMCHAR splt_attr[5];
   STORE_CLASS TMCHAR splt_levl[3];
   STORE_CLASS TMCHAR splt_term[7];
   STORE_CLASS float splt_hours;
   STORE_CLASS float splt_hours_remain;
   STORE_CLASS TMCHAR splt_grde[4];
   STORE_CLASS TMCHAR splt_grde_mode[2];
   STORE_CLASS int   splt_grde_n_val;
   STORE_CLASS float splt_grde_qual_pt;
   STORE_CLASS int   splt_cntin_prog;
   STORE_CLASS int   splt_cntin_area;
   STORE_CLASS int   splt_cntin_group;
   STORE_CLASS int   splt_counted_ind;
   STORE_CLASS float splt_hours_used;
   STORE_CLASS TMCHAR splt_c_reuse[2];
   STORE_CLASS TMCHAR splt_a_reuse[2];
   STORE_CLASS TMCHAR splt_area_used[11];
   STORE_CLASS TMCHAR splt_group_used[11];
   STORE_CLASS int    splt_partial_ind;
   STORE_CLASS int    splt_total_ind;
   STORE_CLASS int    splt_used_ind;
   STORE_CLASS int    splt_tckn_seq;
   STORE_CLASS int    splt_trit_seq;
   STORE_CLASS int    splt_tram_seq;
   STORE_CLASS int    splt_trcr_seq;
   STORE_CLASS int    splt_trce_seq;
   STORE_CLASS TMCHAR  splt_crn[7];
   STORE_CLASS TMCHAR splt_title[31];
   STORE_CLASS TMCHAR  splt_source[2];
   STORE_CLASS TMCHAR  splt_camp[2];
   STORE_CLASS TMCHAR  splt_coll[3];
   STORE_CLASS TMCHAR  splt_dept[5];
   STORE_CLASS TMCHAR  splt_trad_ind[2];
   STORE_CLASS TMCHAR  splt_earned_ind[2];
   STORE_CLASS TMCHAR  splt_prev_c_reuse[2];
   STORE_CLASS TMCHAR splt_prev_area_used[11];
   STORE_CLASS TMCHAR splt_prev_group_used[11];
   STORE_CLASS int    splt_transfer;
   STORE_CLASS float  splt_transfer_cred_used;

/* Last Earned variables */
   STORE_CLASS float last_i_cred;
   STORE_CLASS int   last_i_crse;
   STORE_CLASS float last_e_cred;
   STORE_CLASS int   last_e_crse;
   STORE_CLASS float last_i_cred_hist;
   STORE_CLASS int   last_i_crse_hist;
   STORE_CLASS float last_i_cred_inprog;
   STORE_CLASS int   last_i_crse_inprog;
   STORE_CLASS float last_i_cred_planned;
   STORE_CLASS int   last_i_crse_planned;
   STORE_CLASS int   met_last_earned;
 
/* Program general requirements variables */
   STORE_CLASS int   satisfy_ncrse;
   STORE_CLASS int   prog_ncrse_met;
   STORE_CLASS int   satisfy_pattr;
   STORE_CLASS int   num_pattr;
   STORE_CLASS int   p_detl_met_ind;
   STORE_CLASS int   p_genrl_met_ind;
   STORE_CLASS float p_tot_cred_used;
   STORE_CLASS int   p_tot_crse_used;
   STORE_CLASS float p_i_cred_used;
   STORE_CLASS int   p_i_crse_used;
   STORE_CLASS float p_itrad_cred_used;
   STORE_CLASS int   p_itrad_crse_used;
   STORE_CLASS float p_intrad_cred_used;
   STORE_CLASS int   p_intrad_crse_used;
   STORE_CLASS float p_xfer_cred_used;
   STORE_CLASS int   p_xfer_crse_used;
   STORE_CLASS float temp_p_xfer_cred;
   STORE_CLASS int   temp_p_xfer_crse;

/* Area general requirements variables */
   STORE_CLASS int   area_met;       
   STORE_CLASS int   area_priority;       
   STORE_CLASS TMCHAR area_crse_reuse[2];       
   STORE_CLASS TMCHAR area_attr_reuse[2];       
   STORE_CLASS int   a_detl_met_ind;
   STORE_CLASS int   a_genrl_met_ind;
   STORE_CLASS float a_tot_cred_used;
   STORE_CLASS int   a_tot_crse_used;
   STORE_CLASS float a_i_cred_used;
   STORE_CLASS int   a_i_crse_used;
   STORE_CLASS float a_itrad_cred_used;
   STORE_CLASS int   a_itrad_crse_used;
   STORE_CLASS float a_intrad_cred_used;
   STORE_CLASS int   a_intrad_crse_used;
   STORE_CLASS float a_xfer_cred_used;
   STORE_CLASS int   a_xfer_crse_used;
   STORE_CLASS float temp_a_xfer_cred;
   STORE_CLASS int   temp_a_xfer_crse;

/* Group general requirements variables */
   STORE_CLASS int   group_met;       
   STORE_CLASS TMCHAR group_crse_reuse[2];       
   STORE_CLASS TMCHAR group_attr_reuse[2];       
   STORE_CLASS TMCHAR g_term_code[7];
   STORE_CLASS TMCHAR g_rule[11];
   STORE_CLASS TMCHAR g_met[2];             /* Values: Yes, No, Inactive */
   STORE_CLASS int   g_detl_met_ind;
   STORE_CLASS int   g_genrl_met_ind;
   STORE_CLASS float g_tot_cred_used;
   STORE_CLASS int   g_tot_crse_used;
   STORE_CLASS float g_i_cred_used;
   STORE_CLASS int   g_i_crse_used;
   STORE_CLASS float g_itrad_cred_used;
   STORE_CLASS int   g_itrad_crse_used;
   STORE_CLASS float g_intrad_cred_used;
   STORE_CLASS int   g_intrad_crse_used;
   STORE_CLASS float g_xfer_cred_used;
   STORE_CLASS int   g_xfer_crse_used;
   STORE_CLASS float temp_g_xfer_cred;
   STORE_CLASS int   temp_g_xfer_crse;
   STORE_CLASS int   grp_satisfy_ind;
   STORE_CLASS TMCHAR g_set[4];
   STORE_CLASS int   g_subset; 
   STORE_CLASS TMCHAR g_curr_set[4];
   STORE_CLASS int   g_curr_subset;
   STORE_CLASS int   g_req_flg;
   STORE_CLASS int   g_subset1; 
   STORE_CLASS int   g_subset2; 
   STORE_CLASS int   g_subset_met;
   STORE_CLASS int   g_subset_grp_met;
   STORE_CLASS int   g_meet_req;
   STORE_CLASS int   g_or_cond;
   STORE_CLASS int   g_or_met;
   STORE_CLASS int   g_set1;
   STORE_CLASS int   g_set2;
   STORE_CLASS int   g_set_changed;  

/* GPAs variables */
   STORE_CLASS float actual_area_gpa;
   STORE_CLASS float actual_prog_gpa;
   STORE_CLASS float actual_min_gpa;

/* Passing variables used in different routines */
   STORE_CLASS int   seqno_parm;
   STORE_CLASS TMCHAR min_grde_parm[4];
   STORE_CLASS float detl_cmpl_cred_parm;
   STORE_CLASS int   detl_cmpl_crse_parm;
   STORE_CLASS TMCHAR caa_term_parm[7];
   STORE_CLASS TMCHAR caa_cnt_in_gpa_parm[2];
   STORE_CLASS TMCHAR camp_parm[2];
   STORE_CLASS TMCHAR coll_parm[3];
   STORE_CLASS TMCHAR dept_parm[5];
   STORE_CLASS int   year_rule_parm;
   

/* Count variables */
   STORE_CLASS int   num_p_res;            /* Number of prog restrictions */
   STORE_CLASS int   num_a_res;            /* Number of area restrictions */
   STORE_CLASS int   num_g_res;            /* Number of group restrictions */
   STORE_CLASS int   old_num_range;        /* # of prog restr with crse range */
   STORE_CLASS int   num_pres_range;       /* # of prog restr with crse range */
   STORE_CLASS int   num_ares_range;       /* # of area restr with crse range */
   STORE_CLASS int   num_gres_range;       /* # of area restr with crse range */
   STORE_CLASS int   num_excl_range;       /* # of exclusions with crse range */
   STORE_CLASS int   num_p_rgd;            /* Number of prog restr. grades */
   STORE_CLASS int   num_a_rgd;            /* Number of area restr. grades */
   STORE_CLASS int   num_g_rgd;            /* Number of group restr. grades */
   STORE_CLASS int   num_plvl;             /* Number of prog addl. levels  */
   STORE_CLASS int   num_alvl;             /* Number of area addl. levels  */
   STORE_CLASS int   num_glvl;             /* Number of group addl. levels  */
   STORE_CLASS int   num_d_levl;           /* Number of detail addl. levls */

   STORE_CLASS int   numb_groups;
   STORE_CLASS int   tot_crse_range;

/* Group rule variables */
   STORE_CLASS TMCHAR group_rule[11];
   STORE_CLASS int    agrl_rule_seqno;
   STORE_CLASS TMCHAR  agrl_rule_set[4];
   STORE_CLASS int    agrl_rule_subset;
   STORE_CLASS TMCHAR agrl_rule_within_rule[11];
   STORE_CLASS TMCHAR agrl_group[11];
   STORE_CLASS TMCHAR  agrl_crse_reuse[2];
   STORE_CLASS TMCHAR  agrl_attr_reuse[2];
   STORE_CLASS int    agrl_yr_rule;
   STORE_CLASS TMCHAR  agrl_within_ind[2];
   STORE_CLASS TMCHAR agrl_umbrl_desc[31];
   STORE_CLASS TMCHAR  agrl_umbrl_term[7];
   STORE_CLASS int    agrl_umbrl_no_cond;
   STORE_CLASS TMCHAR  agrl_actn_code[4];
   STORE_CLASS float  agrl_adj_cred;
   STORE_CLASS int    agrl_adj_crse;

/* Rule variables */
   STORE_CLASS TMCHAR rule_code_parm[11];
   STORE_CLASS int    rule_seqno_parm;
   STORE_CLASS TMCHAR group_code_parm[11];
   STORE_CLASS int    rule_met;
   STORE_CLASS int    met_umbrl_cred_1;
   STORE_CLASS int    met_umbrl_cred_2;
   STORE_CLASS TMCHAR umbrl_desc[31];
   STORE_CLASS TMCHAR  umbrl_term[7];
   STORE_CLASS int    umbrl_no_cond;
   STORE_CLASS float  umbrl_req_cred;
   STORE_CLASS int    umbrl_req_crse;
   STORE_CLASS TMCHAR  umbrl_req_conn[2];
   STORE_CLASS float  umbrl_max_cred;
   STORE_CLASS int    umbrl_max_crse;
   STORE_CLASS TMCHAR  umbrl_max_conn[2];
   STORE_CLASS float  umbrl_req_cred_cond;
   STORE_CLASS int    umbrl_req_crse_cond;
   STORE_CLASS TMCHAR  umbrl_req_conn_cond[2];
   STORE_CLASS float  umbrl_max_cred_cond;
   STORE_CLASS int    umbrl_max_crse_cond;
   STORE_CLASS TMCHAR  umbrl_max_conn_cond[2];
   STORE_CLASS int    rule_seqno;
   STORE_CLASS TMCHAR  rule_set[4];
   STORE_CLASS int    rule_subset;
   STORE_CLASS TMCHAR rule_within_rule[11];

/* Course Rule */
   STORE_CLASS TMCHAR key_rule_val[11];
   STORE_CLASS TMCHAR  key_rule_set_val[4];
   STORE_CLASS int    key_rule_seqno_val;
   STORE_CLASS TMCHAR rule_val[11];
   STORE_CLASS TMCHAR  rule_set_val[4];
   STORE_CLASS int    rule_seqno_val;
/* Group Rule */
   STORE_CLASS TMCHAR key_rule_val_agrl[11];
   STORE_CLASS TMCHAR  key_rule_set_val_agrl[4];
   STORE_CLASS int    key_rule_seqno_val_agrl;
   STORE_CLASS TMCHAR rule_val_agrl[11];
   STORE_CLASS TMCHAR  rule_set_val_agrl[4];
   STORE_CLASS int    rule_seqno_val_agrl;

   STORE_CLASS TMCHAR layer2_rule[11];
   STORE_CLASS int    layer2_rule_seqno;

   STORE_CLASS int   act_no_conditions;
/* Actual credits/courses per condition */
   STORE_CLASS float act_cred_per_cond;           
   STORE_CLASS int   act_crse_per_cond;
/* Actual credits/courses per rule */
   STORE_CLASS float act_cred_per_rule;
   STORE_CLASS int   act_crse_per_rule;

   STORE_CLASS TMCHAR dous_subj[5];
   STORE_CLASS TMCHAR dous_crse[6];
   STORE_CLASS TMCHAR dous_levl[3];
   STORE_CLASS TMCHAR dous_camp[2];
   STORE_CLASS TMCHAR dous_coll[3];
   STORE_CLASS TMCHAR dous_dept[5];
   STORE_CLASS TMCHAR dous_grde[4];
   STORE_CLASS int   dous_caa_seqno;
   STORE_CLASS int   caa_seqno_parm;
   STORE_CLASS TMCHAR dous_actn[4];
   STORE_CLASS TMCHAR dous_actn_ind[2];
   STORE_CLASS TMCHAR dous_actn_cnt[2];
   STORE_CLASS float dous_adj_cred;
   STORE_CLASS int   dous_adj_crse;
   STORE_CLASS TMCHAR dous_cntin_prog[2];
   STORE_CLASS TMCHAR dous_cntin_area[2];
   STORE_CLASS TMCHAR dous_cntin_grop[2];
   STORE_CLASS TMCHAR dous_adj_source[3];
   

/* Student adjustment variables. */
   STORE_CLASS TMCHAR detl_req_source[2];
   STORE_CLASS int    g_valid_flag;
   STORE_CLASS TMCHAR sadj_group[11];
   STORE_CLASS TMCHAR slib_prog_ind[2];
   STORE_CLASS TMCHAR slib_area_ind[2];
   STORE_CLASS TMCHAR slib_grop_ind[2];
   STORE_CLASS TMCHAR slib_targ_ind[2];
   STORE_CLASS TMCHAR slib_waiv_ind[2];
   STORE_CLASS TMCHAR slib_subs_ind[2];
   STORE_CLASS TMCHAR action_ind[2];
   STORE_CLASS TMCHAR action_cnt[2];
   STORE_CLASS TMCHAR attch_a_actn_code[4];
   STORE_CLASS float attch_a_adj_cred;
   STORE_CLASS int   attch_a_adj_crse;
   STORE_CLASS TMCHAR attch_a_actn_ind[2];
   STORE_CLASS TMCHAR attch_a_actn_cnt[2];
   STORE_CLASS TMCHAR attch_g_actn_code[4];
   STORE_CLASS float attch_g_adj_cred;
   STORE_CLASS int   attch_g_adj_crse;
   STORE_CLASS TMCHAR attch_g_actn_ind[2];
   STORE_CLASS TMCHAR attch_g_actn_cnt[2];
   STORE_CLASS TMCHAR saca_actn_code[4];
   STORE_CLASS float saca_adj_cred; 
   STORE_CLASS int   saca_adj_crse;
   STORE_CLASS TMCHAR rule_actn_ind[2];
   STORE_CLASS TMCHAR rule_actn_cnt[2];


   STORE_CLASS int   targeted_crse;  
   STORE_CLASS int   targeted_seqno;
   STORE_CLASS int   num_subs;
   STORE_CLASS int   num_waivers;
   STORE_CLASS TMCHAR substitute_subj[5];
   STORE_CLASS TMCHAR substitute_crse[6];
   STORE_CLASS TMCHAR substitute_attr[5];
   STORE_CLASS float substitute_hours;
   STORE_CLASS float orig_course_hours;      
   STORE_CLASS TMCHAR orig_subj[5];
   STORE_CLASS TMCHAR orig_crse_low[6];
   STORE_CLASS TMCHAR orig_crse_high[6];
   STORE_CLASS TMCHAR orig_req_attr[5];
   STORE_CLASS TMCHAR orig_actn_code[4];
   STORE_CLASS float orig_saca_adj_cred;
   STORE_CLASS float orig_saca_adj_crse;
   STORE_CLASS TMCHAR waive_actn_code[4];
   STORE_CLASS float waive_hours;
   STORE_CLASS int   rule_cursor_value; /* 1st layer rule cursor value */
   STORE_CLASS int   rule_cursor_value_2; /* 2nd layer rule cursor value */
   STORE_CLASS int   g_rule_cursor_value; /* 1st GROUP rule cursor value */
   STORE_CLASS int   g_rule_cursor_value_2; /* 2nd GROUP rule cursor value */

/* Source indicator variables for different output tables.  */
/* Valid values are: (O)riginal and (A)djusted.             */
   STORE_CLASS TMCHAR ponc_source_ind[2];         /* Non-Course              */
   STORE_CLASS TMCHAR poat_source_ind[2];         /* Program Attributes      */
   STORE_CLASS TMCHAR aogn_source_ind[2];         /* Area General Requirement*/
   STORE_CLASS TMCHAR attch_a_source_ind[2];      /* Area General Requirement*/
   STORE_CLASS TMCHAR attch_g_source_ind[2];      /* Area General Requirement*/
   

   STORE_CLASS short Ind_01;
   STORE_CLASS short Ind_02;
   STORE_CLASS short Ind_03;
   STORE_CLASS short Ind_04;
   STORE_CLASS short Ind_05;
   STORE_CLASS short Ind_06;
   STORE_CLASS short Ind_07;
   STORE_CLASS short Ind_08;
   STORE_CLASS short Ind_09;
   STORE_CLASS short Ind_10;
   STORE_CLASS short Ind_11;
   STORE_CLASS short Ind_12;
   STORE_CLASS short Ind_13;
   STORE_CLASS short Ind_14;
   STORE_CLASS short Ind_15;
   STORE_CLASS short Ind_16;
   STORE_CLASS short Ind_17;
   STORE_CLASS short Ind_18;
   STORE_CLASS short Ind_19;
   STORE_CLASS short Ind_20;
   STORE_CLASS short Ind_21;
   STORE_CLASS short Ind_22;
   STORE_CLASS short Ind_23;
   STORE_CLASS short Ind_24;
   STORE_CLASS short Ind_25;
   STORE_CLASS short Ind_26;
   STORE_CLASS short Ind_27;
   STORE_CLASS short Ind_28;
   STORE_CLASS short Ind_29;
   STORE_CLASS short Ind_30;
   STORE_CLASS short Ind_31;
   STORE_CLASS short Ind_32;
   STORE_CLASS short Ind_33;
   STORE_CLASS short Ind_34;
   STORE_CLASS short Ind_35;
   STORE_CLASS short Ind_36;
   STORE_CLASS short Ind_37;
   STORE_CLASS short Ind_38;
   STORE_CLASS short Ind_39;
   STORE_CLASS short Ind_40;
   STORE_CLASS short Ind_41;
   STORE_CLASS short Ind_42;
   STORE_CLASS short Ind_43;
   STORE_CLASS short Ind_44;
   STORE_CLASS short Ind_45;
   STORE_CLASS short Ind_46;
   STORE_CLASS short Ind_47;
   STORE_CLASS short Ind_48;
   STORE_CLASS short Ind_49;
   STORE_CLASS short Ind_50;
   STORE_CLASS short Ind_51;
   STORE_CLASS short Ind_52;
   STORE_CLASS short Ind_53;
   STORE_CLASS short Ind_54;
   STORE_CLASS short Ind_55;
   STORE_CLASS short Ind_56;
   STORE_CLASS short Ind_57;
   STORE_CLASS short Ind_58;
   STORE_CLASS short Ind_59;
   STORE_CLASS short Ind_60;
   STORE_CLASS short Ind_61;
   STORE_CLASS short Ind_62;
   STORE_CLASS short Ind_63;
   STORE_CLASS short Ind_64;
   STORE_CLASS short Ind_65;
   STORE_CLASS short Ind_66;
   STORE_CLASS short Ind_67;
   STORE_CLASS short Ind_68;
   STORE_CLASS short Ind_69;
   STORE_CLASS short Ind_70;
   STORE_CLASS short Ind_71;
   STORE_CLASS short Ind_72;
   STORE_CLASS short Ind_73;
   STORE_CLASS short Ind_74;
   STORE_CLASS short Ind_75;
   STORE_CLASS short Ind_76;
   STORE_CLASS short Ind_77;
   STORE_CLASS short Ind_78;
   STORE_CLASS short Ind_79;
   STORE_CLASS short Ind_80;
   STORE_CLASS short Ind_81;
   STORE_CLASS short Ind_82;
   STORE_CLASS short Ind_83;
   STORE_CLASS short Ind_84;
   STORE_CLASS short Ind_85;
   STORE_CLASS short Ind_86;
   STORE_CLASS short Ind_87;
   STORE_CLASS short Ind_88;
   STORE_CLASS short Ind_89;
   STORE_CLASS short Ind_90;
   STORE_CLASS short Ind_91;
   STORE_CLASS short Ind_92;
   STORE_CLASS short Ind_93;
   STORE_CLASS short Ind_94;
   STORE_CLASS short Ind_95;
   STORE_CLASS short Ind_96;
   STORE_CLASS short Ind_97;
   STORE_CLASS short Ind_98;
   STORE_CLASS short Ind_99;
   STORE_CLASS short Ind_100;
   STORE_CLASS short Ind_101;
   STORE_CLASS short Ind_102;
   STORE_CLASS short Ind_103;
   STORE_CLASS short Ind_104;
   STORE_CLASS short Ind_105;
   STORE_CLASS short Ind_106;
   STORE_CLASS short Ind_107;
   STORE_CLASS short Ind_108;
   STORE_CLASS short Ind_109;
   STORE_CLASS short Ind_110;
EXEC SQL END DECLARE SECTION;

   STORE_CLASS int   crse_sel_file_open;
   STORE_CLASS UFILE *oput_file;
   STORE_CLASS FNSTRUC outfile;
   STORE_CLASS TMCHAR prev_group_used[11];
   STORE_CLASS int    same_group;
/* Variables that are used to adjust the actual credits and courses used */
   STORE_CLASS float transfer_cred_used;
   STORE_CLASS float nontrad_cred_used;
   STORE_CLASS float restr_cred_used;
   STORE_CLASS float resgrd_cred_used;
   STORE_CLASS float addlevl_cred_used;
   STORE_CLASS int found_arestr;              /* found area restriction flag*/
   STORE_CLASS int found_grestr;              /* found group restriction flag*/
   STORE_CLASS int found_aresgd;              /* found area restr. grde flag*/
   STORE_CLASS int found_gresgd;              /* found group restr. grde flag*/
   /* Flags associated with Max Credits and Courses */
   STORE_CLASS int transfer;
   STORE_CLASS int nontrad;
   STORE_CLASS int plvl_flag;                 /* Additional Level Flags */
   STORE_CLASS int alvl_flag;
   STORE_CLASS int glvl_flag;
   STORE_CLASS int dlvl_flag;                 /* Detail Requirement Flags */
   STORE_CLASS int prgd_flag;                 /* Restricted Grade Flags */
   STORE_CLASS int argd_flag;
   STORE_CLASS int grgd_flag;
   STORE_CLASS int prsa_flag;                 /* Restricted Subj & Attr Flags*/
   STORE_CLASS int arsa_flag;
   STORE_CLASS int grsa_flag;

   STORE_CLASS int keep_looking_flg;
   STORE_CLASS int cred_only;
   STORE_CLASS int crse_only;
   STORE_CLASS int both_flag; 
   STORE_CLASS int usedsplit;
   STORE_CLASS int   match;
   STORE_CLASS int   split_flag; 

/* Exclusion variables */
   STORE_CLASS int   excl_flg;
   STORE_CLASS int   n_excl;               /* Number of exclusions */
/**** ******/
   STORE_CLASS int   num_caa_detl;
   STORE_CLASS int   num_rul_detl;
   STORE_CLASS int   details_attach_met;
   STORE_CLASS int   groups_attach_met;
   STORE_CLASS int   ok_flg;
   STORE_CLASS TMCHAR curr_set[4];
   STORE_CLASS int   curr_subset;
   STORE_CLASS int   req_flg;
   STORE_CLASS int   subset1; 
   STORE_CLASS int   subset2; 
   STORE_CLASS int   subset_met;
   STORE_CLASS int   subset_grp1;
   STORE_CLASS int   subset_grp2;
   STORE_CLASS int   subset_grp_met;
   STORE_CLASS int   meet_req;
   STORE_CLASS int   or_cond;
   STORE_CLASS int   or_met;
   STORE_CLASS int   set1;
   STORE_CLASS int   set2;
   STORE_CLASS int   set_changed;  
   STORE_CLASS int   found;
   STORE_CLASS int   diff_set;
   STORE_CLASS TMCHAR tmp_set[4];
   STORE_CLASS int   diff_group_set;
   STORE_CLASS TMCHAR tmp_group_set[4];
   STORE_CLASS int   second_flg ; 
   STORE_CLASS int   no_scnd_pass;
   STORE_CLASS int   done_scnd_pass;
   STORE_CLASS TMCHAR connector[2];
   STORE_CLASS float stot_xfer_cred_used; 
   STORE_CLASS int   stot_xfer_crse_used;
   STORE_CLASS float split_cred;
   STORE_CLASS float leftover_cred;

   STORE_CLASS int   n_splits ;

   STORE_CLASS float glvl_ex_cred;
   STORE_CLASS float alvl_ex_cred;
   STORE_CLASS float plvl_ex_cred;
   STORE_CLASS int   alvl_inx;           
   STORE_CLASS int   glvl_inx;           
   STORE_CLASS int   d_levl_inx;         

   STORE_CLASS int   cred_met; 
   STORE_CLASS int   detl_range;

/* Satisfied program general requirement flags */
   STORE_CLASS int satisfy_p_totreq;
   STORE_CLASS int satisfy_p_inst;
   STORE_CLASS int satisfy_p_itrad;
   STORE_CLASS int satisfy_p_intrad;
   STORE_CLASS int satisfy_p_xfer;

/* Satisfy area general requirement flags */
   STORE_CLASS int satisfy_a_totreq; 
   STORE_CLASS int satisfy_a_inst;
   STORE_CLASS int satisfy_a_itrad;
   STORE_CLASS int satisfy_a_xfer;  

/* Satisfy area general requirement flags */
   STORE_CLASS int satisfy_g_totreq; 
   STORE_CLASS int satisfy_g_inst;
   STORE_CLASS int satisfy_g_itrad;
   STORE_CLASS int access_split_attr_rec;

/* Compliance Credits or Course flags */
   STORE_CLASS int area_cmpl_flag;
   STORE_CLASS int group_cmpl_flag;
   STORE_CLASS int detl_cmpl_flag;
   STORE_CLASS int old_detl_cmpl_flag;
   STORE_CLASS int area_rule_cmpl_flag;
   STORE_CLASS int group_rule_cmpl_flag;
   STORE_CLASS float tot_ggen_cmpl_cred;
   STORE_CLASS int   tot_ggen_cmpl_crse;
   STORE_CLASS float tot_detl_cmpl_cred;
   STORE_CLASS int   tot_detl_cmpl_crse;
/* Rule variables */
   STORE_CLASS float tmp_credhrs_used;
   STORE_CLASS float tmp_act_cred_per_rule_wi;
   STORE_CLASS int   tmp_act_crse_per_rule_wi;
   STORE_CLASS int   credhrs_used_chg;
   STORE_CLASS int   reach_umbrl_max_1;
   STORE_CLASS int   reach_umbrl_max_2;
   STORE_CLASS TMCHAR umbrl_cred_type_1[2];
   STORE_CLASS TMCHAR umbrl_cred_type_2[2];
   STORE_CLASS TMCHAR umbrl_cred_type[2];
   STORE_CLASS int   duplicate_flag;
   STORE_CLASS TMCHAR dupl_group_parm[11];

/* Holding Variables for the original rule (attached under area or group). */
   STORE_CLASS TMCHAR  hold_rule[11];
   STORE_CLASS TMCHAR  hold_rule_wi[11];
   STORE_CLASS int   hold_rule_met;
   STORE_CLASS int   hold_met_umbrl_cred_1;
   STORE_CLASS int   hold_met_umbrl_cred_2;
   STORE_CLASS TMCHAR  hold_umbrl_desc[31];
   STORE_CLASS TMCHAR  hold_umbrl_term[7];
   STORE_CLASS int   hold_umbrl_no_cond;
   STORE_CLASS float hold_umbrl_req_cred;
   STORE_CLASS int   hold_umbrl_req_crse;
   STORE_CLASS TMCHAR  hold_umbrl_req_conn[2];
   STORE_CLASS float hold_umbrl_max_cred;
   STORE_CLASS int   hold_umbrl_max_crse;
   STORE_CLASS TMCHAR  hold_umbrl_max_conn[2];
   STORE_CLASS float hold_umbrl_req_cred_cond;
   STORE_CLASS int   hold_umbrl_req_crse_cond;
   STORE_CLASS TMCHAR  hold_umbrl_req_conn_cond[2];
   STORE_CLASS float hold_umbrl_max_cred_cond;
   STORE_CLASS int   hold_umbrl_max_crse_cond;
   STORE_CLASS TMCHAR  hold_umbrl_max_conn_cond[2];
   STORE_CLASS int   hold_rule_seqno;
   STORE_CLASS TMCHAR  hold_rule_set[4];
   STORE_CLASS int   hold_rule_subset;
   STORE_CLASS int   hold_act_no_conditions;
   STORE_CLASS float hold_act_cred_per_cond;           
   STORE_CLASS int   hold_act_crse_per_cond;
   STORE_CLASS float hold_act_cred_per_rule;
   STORE_CLASS int   hold_act_crse_per_rule;
   STORE_CLASS int   hold_tot_no_conditions;
   STORE_CLASS TMCHAR  hold_bounced_set[4];   
   STORE_CLASS int   hold_indiv_detl_met;   
   STORE_CLASS TMCHAR  hold_last_bounced_set[4];   
   STORE_CLASS TMCHAR  hold_prev_set_cond[4];
   STORE_CLASS int   hold_new_cond;
   STORE_CLASS int   hold_meet_no_conditions;
   STORE_CLASS int   hold_prev_subset_cond;
   STORE_CLASS int   hold_same_subset_cond;
   STORE_CLASS int   hold_rule_cursor_value;
   STORE_CLASS int   hold_skip_to_next_set;
   STORE_CLASS int   hold_rule_satisfied;  
   STORE_CLASS int   hold_rule_or_cond_flg;
   STORE_CLASS int   hold_no_cond_added;    
   STORE_CLASS int   hold_num_rul_detl;     
   STORE_CLASS TMCHAR  hold_umbrl_cred_type_1[2];
   STORE_CLASS TMCHAR  hold_umbrl_cred_type_2[2];
   STORE_CLASS int   hold_elim_rule_detl_req;
   STORE_CLASS int   wi_rule_done;
   STORE_CLASS float wi_act_cred_per_rule;
   STORE_CLASS int   wi_act_crse_per_rule;
/* Holding Variables for the original group rule (attached under area). */
   STORE_CLASS TMCHAR hold_rule_agrl[11];
   STORE_CLASS TMCHAR hold_rule_wi_agrl[11];
   STORE_CLASS int  hold_rule_met_agrl;
   STORE_CLASS int  hold_rule_satisfied_agrl;
   STORE_CLASS TMCHAR hold_umbrl_desc_agrl[31];
   STORE_CLASS TMCHAR hold_umbrl_term_agrl[7];
   STORE_CLASS int  hold_umbrl_no_cond_agrl;
   STORE_CLASS int  hold_rule_seqno_agrl;
   STORE_CLASS TMCHAR hold_rule_set_agrl[4];
   STORE_CLASS int  hold_rule_subset_agrl;
   STORE_CLASS int  hold_act_no_conditions_agrl;
   STORE_CLASS int  hold_tot_no_conditions_agrl;
/* STORE_CLASS char hold_bounced_set_agrl[4];   */
   STORE_CLASS int  hold_indiv_detl_met_agrl ;  
/* STORE_CLASS char hold_last_bounced_set_agrl[4]; */
   STORE_CLASS TMCHAR hold_prev_set_cond_agrl[4];
   STORE_CLASS int  hold_new_cond_agrl;
   STORE_CLASS int  hold_prev_subset_cond_agrl;
   STORE_CLASS int  hold_same_subset_cond_agrl;
   STORE_CLASS int  hold_skip_to_next_set_agrl;
   STORE_CLASS int  hold_rule_or_cond_flg_agrl;
   STORE_CLASS int  hold_no_cond_added_agrl;
   STORE_CLASS int  hold_num_grp_rule_detl;
   STORE_CLASS int  agrl_wi_rule_done;

/* Passing parameters for cred/crse per condition and all conditions */
   STORE_CLASS float req_cred_parm;
   STORE_CLASS int   req_crse_parm;
   STORE_CLASS TMCHAR req_conn_parm[2];
   STORE_CLASS float max_cred_parm;
   STORE_CLASS int   max_crse_parm;
   STORE_CLASS TMCHAR max_conn_parm[2];
   STORE_CLASS float act_cred_parm;
   STORE_CLASS int   act_crse_parm;

/* Student Adjustment variables. */
   STORE_CLASS int   slib_flag;
   STORE_CLASS int   subs_valid_flag;
   STORE_CLASS int   waiv_valid_flag;
   STORE_CLASS int   targ_valid_flag;
   STORE_CLASS int   waive_requirement;
   STORE_CLASS int   eliminate_detl_req;
   STORE_CLASS int   eliminate_rule_detl_req;

   /* Program Adjustment flags. */
   STORE_CLASS int   sadj_prstr_exist;      /* Prog Restr Subj/Attr flag */
   STORE_CLASS int   sadj_prsgd_exist;      /* Prog Restr Grade flag     */
   STORE_CLASS int   sadj_padlv_exist;      /* Prog Addl  Level flag     */
   STORE_CLASS int   sadj_padlv_excl_exist; /* Prog Excl Level flag      */
   STORE_CLASS int   sadj_pgen_exist;       /* Prog General Req flag     */

   /* Area Adjustement flags. */
   STORE_CLASS int   sadj_attch_a_exist   ; /* Area Attachment flag       */
   STORE_CLASS int   sadj_agen_exist;       /* Area General Req flag      */
   STORE_CLASS int   sadj_arstr_exist;      /* Area Restr Subj/Attr flag  */
   STORE_CLASS int   sadj_arsgd_exist;      /* Area Restr Grade flag      */
   STORE_CLASS int   sadj_aadlv_exist;      /* Area Addl  Level flag      */
   STORE_CLASS int   sadj_aadlv_excl_exist; /* Area Excl Level flag       */
   STORE_CLASS int   sadj_crse_exist;

   /* Group Adjustement flags. */
   STORE_CLASS int   sadj_attch_g_exist   ; /* Group Attachment flag      */
   STORE_CLASS int   sadj_ggen_exist;       /* Group General Req flag     */
   STORE_CLASS int   sadj_grstr_exist;      /* Group Restr Subj/Attr flag */
   STORE_CLASS int   sadj_grsgd_exist;      /* Group Restr Grade flag     */
   STORE_CLASS int   sadj_gadlv_exist;      /* Group Addl  Level flag     */
   STORE_CLASS int   sadj_gadlv_excl_exist; /* Group Excl Level flag      */
   STORE_CLASS int   num_sadj_glvl;

   /* Area/Group detail requirement action indicator and count flag.*/
   STORE_CLASS TMCHAR saca_actn_ind[2];
   STORE_CLASS TMCHAR saca_actn_cnt[2];
   STORE_CLASS int   sadj_crse_excl_exist;
   STORE_CLASS TMCHAR sace_actn_ind[2];       
   STORE_CLASS TMCHAR sace_actn_cnt[2];       
   STORE_CLASS int   sadj_dadlv_exist;      /* Detail Incl Level flag     */
   STORE_CLASS int   sadj_dadlv_excl_exist; /* Detail Incl Level flag     */
   STORE_CLASS TMCHAR sacl_actn_ind[2];       
   STORE_CLASS TMCHAR sacl_actn_cnt[2];       

   STORE_CLASS int   eliminate_flag;
   STORE_CLASS TMCHAR p_attr_actn_ind[2];    /* Program attribute action ind.    */
   STORE_CLASS TMCHAR p_attr_actn_cnt[2];    /* Program attribute count  ind.    */

/******************* LINK LISTS and ARRAYS DECLARATION SECTION ***************/
/* Single Link List */
/* **************** */
   STORE_CLASS PRG_AREA *arealst_anchor;
   STORE_CLASS PRG_AREA *attch_areas;    
   STORE_CLASS S_CRSE   *crselst_anchor;   /* Student Course Link List */
   STORE_CLASS PRG_AREA *curr_area;
   STORE_CLASS S_CRSE   *curr_crse;
   STORE_CLASS S_CRSE   *old_crse;         /* Course info before it was used */
   STORE_CLASS S_CRSE   *old_crse_anchor;  /* to fullfill detail requirements*/
   STORE_CLASS S_CRSE   *old_crse_g;       /* Course info before it was used */
   STORE_CLASS S_CRSE   *old_crse_g_anchor;/* to fullfill group requirements.*/
   STORE_CLASS S_CRSE   *curr_old_crse;    /* Course info before it was used */
   STORE_CLASS S_CRSE   *avail_addr;  
   STORE_CLASS S_CRSE   *previous;    
   STORE_CLASS S_CRSE   *previous_g;    
   STORE_CLASS C_RANGE  *rangelst;
   STORE_CLASS C_RANGE  *rangelst_anchor;
   STORE_CLASS C_RANGE  *hold_addr;
   STORE_CLASS AREA_GRP *group_addr;
   STORE_CLASS AREA_GRP *grouplst_anchor;
   STORE_CLASS AREA_GRP *grouplst;
   STORE_CLASS AREA_GRP *curr_group;
   STORE_CLASS ATTS_TYPE *attslst_anchor;   /* Student Attribute Link List */
   STORE_CLASS ATTS_TYPE *avail_atts_addr;  /* Student Attribute Link List */

/* Arrays */
/* ****** */
   STORE_CLASS RSTRICT  p_res[MAXRESTR];      /* Program Restriction */
   STORE_CLASS RSTRICT  a_res[MAXRESTR];      /* Area Restriction */
   STORE_CLASS RSTRICT  g_res[MAXRESTR];      /* Group Restriction */
   STORE_CLASS RSTRGRD  p_resg[MAXRESGRD];    /* Program Restricted Grade */
   STORE_CLASS RSTRGRD  a_resg[MAXRESGRD];    /* Area Restricted Grade */
   STORE_CLASS RSTRGRD  g_resg[MAXRESGRD];    /* Group Restr. Grade */
   STORE_CLASS ADDLVL   p_levl[MAXLEVELS];    /* Program Additional Level */
   STORE_CLASS ADDLVL   a_levl[MAXLEVELS];    /* Area Additional Level */
   STORE_CLASS ADDLVL   g_levl[MAXLEVELS];    /* Group Additional Level */
   STORE_CLASS ADDLVL   d_levl[MAXLEVELS];    /* Detail Additional Level */
   STORE_CLASS CRSE_EXCL   excl_arr[MAXEXCL]; /* Course exclusion */
   STORE_CLASS SPLIT_CRSE split[MAXSPLITS];   /* Split Course */

/************************ PROTOTYPING SECTION ********************************/

/* Main Components of program evaluations (Area or Group) */
/* ****************************************************** */
   STORE_CLASS void eval_program (TMCHAR *catalog_term, TMCHAR *eval_term, 
                    PRG_AREA *arealst, S_CRSE *crselst);
   STORE_CLASS void process_groups(AREA_GRP *grouplst, S_CRSE *crselst_anchor);

/* Common Initializing prototypes */
/* ****************************** */
   STORE_CLASS void close_oput_file(void);
   STORE_CLASS int  chk_new_page(void);
   STORE_CLASS void init_var(void);
   STORE_CLASS void init_t_var(void);
   STORE_CLASS void init_adj_var(void);
   STORE_CLASS void init_set_subset_var (void);
   STORE_CLASS int  set_subj_type(TMCHAR *par_subj1, TMCHAR *par_clow,
                    TMCHAR *par_chigh);

/* Detail processing prototypes. */
/* ***************************** */
   STORE_CLASS int  found_crse(void);
   STORE_CLASS int  process_detl(S_CRSE *crselst);
   STORE_CLASS int  chk_satisfy (S_CRSE *crselst);
   STORE_CLASS void eval_set_subset (void);
   STORE_CLASS int  chkccd(void);
   STORE_CLASS int  chktrm(void);
   STORE_CLASS int  chkyr(int yr_rule_parm);
   STORE_CLASS int  chk_min_grde(void);
   STORE_CLASS int  chk_shrgrde(void);
   STORE_CLASS int  chk_year_rule(void);
   STORE_CLASS void chk_exclusion(int range_indx);
   STORE_CLASS int  chk_in_range(void);
   STORE_CLASS int  match_restr_excl(int match_restr_excl_parm);
   STORE_CLASS int  match_restr_excl_range(void);

/* Restrictions Checking prototypes */
/* ******************************** */
   STORE_CLASS void chk_restrictions(void);
   STORE_CLASS int  chk_area_restr(void);
   STORE_CLASS void chk_prog_restr(float *a_cred_used_addr, 
                    int *a_crse_used_addr);
   STORE_CLASS void chk_max_restr(float *actl_maxcred_addr, float *maxcred_addr,
                    int *actl_maxcrse_addr, int *maxcrse_addr, TMCHAR *conn_ind,
                    int prog_restr_cnt);
   STORE_CLASS void chk_resgrd(void);
   STORE_CLASS int  chk_area_resgrd(void);
   STORE_CLASS void chk_prog_resgrd(float *a_cred_used_addr,
                    int *a_crse_used_addr);
   STORE_CLASS int  chk_grp_resgrd(void);
   STORE_CLASS int  chk_grp_restr(void);

/* General Requirements checkings prototypes */
/* ***************************************** */
   STORE_CLASS void chk_grp_genrl(void);
   STORE_CLASS void chk_area_genrl(void);
   STORE_CLASS void chk_prog_genrl(void);

/* Non-Course and student attributes prototypes */
/* ******************************************** */
   STORE_CLASS void chk_noncrse_req(void);
   STORE_CLASS int  chk_prog_attr(int met_prog_attributes);
   STORE_CLASS int  process_detl_stu_atts(ATTS_TYPE *attslst);

/* STORE_CLASS int  match_subj_crse (S_CRSE *crselst); */
/* STORE_CLASS int  match_subj_crse2 (S_CRSE *crselst2); */

/* Additional Levels prototypes. */
/* ***************************** */
   STORE_CLASS int  chk_grp_other_levl(void);
   STORE_CLASS int  chk_other_levl(void);

   /* Course Detail Exclude/Include Additional Levels functions. */
   STORE_CLASS int  chk_gclv_excl(void);  /* Group Course Detail EXCLUDED Level. */
   STORE_CLASS int  chk_grlv_excl(void);  /* Group Rule Detail EXCLUDED Level.   */
   STORE_CLASS int  chk_aclv_excl(void);  /* Area Course Detail EXCLUDED Level.  */
   STORE_CLASS int  chk_arlv_excl(void);  /* Area Rule Detail EXCLUDED level.    */
   STORE_CLASS int  chk_dlvl_incl(void);  /* Group or Area Detail INCLUDED level.*/

   STORE_CLASS int  chk_d_levl_incl(void);/* Detail INCLUDED Level.         */

   /* Group Exclude/Include Additional Levels functions. */
   STORE_CLASS int  chk_glvl_excl(void);  /* Group EXCLUDED Level.         */
   STORE_CLASS int  chk_glvl_incl(void);  /* Group INCLUDED Level.         */

   /* Area Exclude/Include Additional Levels functions. */
   STORE_CLASS int  chk_alvl_excl(void);  /* Area EXCLUDED level.          */
   STORE_CLASS int  chk_alvl_incl(void);  /* Area INCLUDED level.          */

   /* Program Exclude/Include Additional Levels functions. */
   STORE_CLASS int  chk_plvl_excl(void);  /* Program EXCLUDED level.       */
   STORE_CLASS int  chk_plvl_incl(void);  /* Program INCLUDED level.       */
   
/* Check Tranfer Credits and Courses prototypes */
/* ******************************************** */
   STORE_CLASS int  chk_max_xfer(void);
   STORE_CLASS void chk_area_xfer(void);
   STORE_CLASS void chk_prog_xfer(void);

/* Credits and Courses checkings and countes prototypes. */
/* ***************************************************** */
   STORE_CLASS int  chk_cred_and_crse(void);
   STORE_CLASS int  increment_tot_cred_used(int met_cred_flg_parm);
   STORE_CLASS int  max_with_no_req(void);
   STORE_CLASS int  req_with_no_max(void);
   STORE_CLASS int  req_with_max(void);
   STORE_CLASS int  chk_met_credtype(int met_credtype);
   STORE_CLASS int  chk_met_req(int met_req);
   STORE_CLASS int  chk_met_undermax(int met_undermax);
   STORE_CLASS void chk_other_max (TMCHAR *ctype, int *cnt_in_area_addr, 
                           int *cnt_in_prog_addr, TMCHAR *earned);
   STORE_CLASS void chk_max(float *actl_maxcred_addr, float *genl_maxcred_addr,
                    int  *actl_maxcrse_addr, int   *genl_maxcrse_addr, 
                    TMCHAR *conn_ind,
                    int  prog_crse_cnt);
   STORE_CLASS int  chk_req(float *actlcred_addr, float *reqcred_addr,
                    int  *actlcrse_addr, int   *reqcrse_addr, 
                    TMCHAR *conn_ind,      int   ok_flag);
   STORE_CLASS int  chk_req_cred_crse (float *required_cred_addr, 
                    int   *required_crse_addr, TMCHAR *conn_ind,
                    float *actual_cred_addr, int *actual_crse_addr);
   STORE_CLASS void count_cred_crse(int *gcount_addr, int *acount_addr, 
                    int   *pcount_addr, TMCHAR *crse_source, TMCHAR *crse_trad);
   STORE_CLASS void count_crse_in_area(int *area_totcrse_addr);
   STORE_CLASS void count_crse_in_group(int *group_totcrse_addr);
   STORE_CLASS void count_crse_in_detl(int *detl_totcrse_addr);

/* Credits/Course Adjustments prototypes */
/* ************************************* */
   STORE_CLASS void adjust_cred_crse(float *actlcred_addr, int *actlcrse_addr,
                             float *old_cred_addr);
   STORE_CLASS void adjust_cred_ap(float *a_actlcred_addr, int *a_actlcrse_addr,
                           float *p_maxcred_addr,  int *p_maxcrse_addr,
                           float *old_cred_addr);
   STORE_CLASS void adjust_transfer(void);
   STORE_CLASS void adjust_nontrad(void);
   STORE_CLASS void adjust_addlevl(void);
   STORE_CLASS void adjust_restr(void);
   STORE_CLASS void adjust_resgrd(void);

/* Check and store remain credits. */
/* ******************************* */
   STORE_CLASS void chk_remain_cred(void);
   STORE_CLASS void chk_remain_cred_2(void);
   STORE_CLASS void store_remain_cred(void);

/* Prototypes for releasing logic. */
/* ******************************* */
   STORE_CLASS void copy_before_use(void);
   STORE_CLASS void copy_before_use_in_group(void);
   STORE_CLASS void end_old_crse(void);
   STORE_CLASS void end_old_crse_g(void);
   STORE_CLASS void release_used_info(void);
   STORE_CLASS void release_used_info_in_group(void);
   STORE_CLASS void release_cred_crse (float *cred_release_addr,
              float *tot_cred_addr,    float *i_cred_addr,
              float *itrad_cred_addr,  float *intrad_cred_addr,
              float *xfer_cred_addr,   int *tot_crse_addr,
              int   *i_crse_addr,      int *itrad_crse_addr,
              int   *intrad_crse_addr, int   *xfer_crse_addr,
              TMCHAR  *crse_type,        TMCHAR  *trad_crse);
/* Release creds/crses used in Restricted Subjects and Attributes. */
   STORE_CLASS void release_grop_restr_cred(float cred_hours_used_parm);
   STORE_CLASS void release_area_restr_cred(float cred_hours_used_parm);
   STORE_CLASS void release_prog_restr_cred(float cred_hours_used_parm);
   STORE_CLASS int  match_crseused_in_restrictions(int match_restr_excl_parm);
   STORE_CLASS int  match_crseused_in_restr_range(void);
   STORE_CLASS int  chk_crseused_in_range(void);
/* Release creds/crses used in Restricted Grades. */
   STORE_CLASS void release_grop_resgd_cred(float cred_hours_used_parm);
   STORE_CLASS void release_area_resgd_cred(float cred_hours_used_parm);
   STORE_CLASS void release_prog_resgd_cred(float cred_hours_used_parm);
/* Release creds/crses used in Included Levels. */
   STORE_CLASS void release_detl_incl_levl(float cred_hours_used_parm);
   STORE_CLASS void release_grop_incl_levl(float cred_hours_used_parm);
   STORE_CLASS void release_area_incl_levl(float cred_hours_used_parm);
   STORE_CLASS void release_prog_incl_levl(float cred_hours_used_parm);
   STORE_CLASS int  chk_crse_counted(void);

/* Course Range prototypes */
/* *********************** */
   STORE_CLASS void sel_crse_range (void); 
   STORE_CLASS void get_course_range(void);
   STORE_CLASS void get_detl_range(int stype, C_RANGE *rangelst);
   STORE_CLASS void copy_crse_range(C_RANGE *rangelst);
   STORE_CLASS int  match_crse_range(void);

/* Compliance passes: Find Unused, Find Used Course, Course Range, or split. */
/* ************************************************************************* */
   STORE_CLASS int  process_course(S_CRSE *c_crse, int fine);
   STORE_CLASS int  process_crse_range(S_CRSE *c_crse);
   STORE_CLASS int  process_unusedsplt_range(int satisfy);
   STORE_CLASS int  process_unusedsplt(int satisfy);
   STORE_CLASS int  process_usedcrse_range(S_CRSE *c_crse, int range_match);
   STORE_CLASS int  process_usedsplt_range(int satisfy);
   STORE_CLASS int  process_usedsplt(int satisfy);
   STORE_CLASS int  find_equivalent (S_CRSE *crselst, int found_equiv);
   STORE_CLASS int  find_equivalent_range (S_CRSE *crselst, int found_equiv);
   STORE_CLASS int  find_equivalent_splt      (int found_equiv);
   STORE_CLASS int  find_equivalent_splt_range(int found_equiv);
   STORE_CLASS int  find_used_crse(S_CRSE *crselst);
   STORE_CLASS int  find_unused_split(int prev_match);
   STORE_CLASS int  area_let_out(void);

/* Prototypes for inserting output tables */
/* ************************************** */
   STORE_CLASS void ins_smbpogn(void);   
   STORE_CLASS void ins_smbaogn(void);   
   STORE_CLASS void ins_smbgogn(TMCHAR rule_or_group);   
   STORE_CLASS void ins_smrgoat(void);   
   STORE_CLASS void ins_smrpogd(void);   
   STORE_CLASS void ins_smraogd(void);   
   STORE_CLASS void ins_smrgogd(void);   
   STORE_CLASS void ins_smrpolv(void);   
   STORE_CLASS void ins_smrpolv_excl(void);   
   STORE_CLASS void ins_smraolv(void);   
   STORE_CLASS void ins_smraolv_excl(void);   
   STORE_CLASS void ins_smrgolv(void);   
   STORE_CLASS void ins_smrgolv_excl(void);   
   STORE_CLASS void ins_smrposa(void);   
   STORE_CLASS void ins_smraosa(void);   
   STORE_CLASS void ins_smrgosa(void);   
   STORE_CLASS void ins_smrponc(void);   
   STORE_CLASS void ins_smrpoat(void);   
   STORE_CLASS void ins_smrpoat_2(void);   
   STORE_CLASS void ins_smrdocn(void);
   STORE_CLASS void ins_smrdoan(void);
   STORE_CLASS void ins_smrdorq(void);
   STORE_CLASS void generate_oneup (void);
   STORE_CLASS void ins_smrdous(void);
   STORE_CLASS void ins_smrpoan(void);
   STORE_CLASS void ins_smrdolv(void);
   STORE_CLASS void ins_smrdolv_excl(void);
   STORE_CLASS void ins_smrdoex(void);
   STORE_CLASS void ins_smrdorj(void);
   STORE_CLASS void ins_smrdost(void);
   STORE_CLASS void ins_smraost(void);
   STORE_CLASS void ins_smrdrlv(void);
   STORE_CLASS void ins_smrdrlv_excl(void);

/* Course Attributes prototypes. */
/* ***************************** */
   STORE_CLASS int  chk_attr_excl(void);
   STORE_CLASS void set_group_attr_reuse(void);
   STORE_CLASS void set_attr_reuse(void);
   STORE_CLASS int  find_crseattr(void);
   STORE_CLASS int  find_crseattr_avail(void);
   STORE_CLASS int  find_crseattr_used(void);
   STORE_CLASS int  find_crseattr_subj(TMCHAR *req_attr_parm);
   STORE_CLASS int  find_crseattr_subj_used(void);
   STORE_CLASS int  find_used_attr(S_CRSE *crselst);
   STORE_CLASS int  find_crseattr_splt(void);
   STORE_CLASS int  find_crseattr_usedsplt(void);
   STORE_CLASS int  process_usedsplt_attr(int satisfy);

/* Use Within prototypes */
/* ********************* */
   STORE_CLASS int  use_within(S_CRSE *crselst);
   STORE_CLASS int  find_crse_wi(void);
   STORE_CLASS int  find_crseattr_wi(void);
   STORE_CLASS int  find_crseandattr_wi(void);

/* Split Credits prototypes */
/* ************************ */
   STORE_CLASS int  get_equivalent(void);
   STORE_CLASS int  get_smtsplt(void);
   STORE_CLASS int  get_smtsplt_equiv(void);
   STORE_CLASS int  get_smtsplt_used(void);
   STORE_CLASS int  get_smtspat(void);
   STORE_CLASS int  get_smtspat_used(void);
   STORE_CLASS int  new_find_used_split(int prev_match);
   STORE_CLASS void copy_split_arr(void);
   STORE_CLASS int  use_split(void);


/* Insert/Update temporary compliance tables */
/* ***************************************** */
   STORE_CLASS void ins_smtcuse(void);
   STORE_CLASS void update_smtsplt(void);
   STORE_CLASS void upd_smtcuse_detl_cmpl(void);

/* Last x of x, and GPAs calculations. */
/* *********************************** */
   STORE_CLASS int  cal_last_earned(void);
   STORE_CLASS int  chk_req_last_earned_1line(void);
   STORE_CLASS int  chk_req_last_earned(void);

/* Second pass */
/* ****************/
   STORE_CLASS void perform_second_pass(void);
   STORE_CLASS void perform_second_pass_2(void);
   STORE_CLASS void perform_second_pass_rule(void);
   STORE_CLASS int  fetch_detl_req(int cursor_parm);
   STORE_CLASS int  chk_satisfy_scndpass  (S_CRSE *crselst2);
   STORE_CLASS int  process_detl_scndpass (S_CRSE *crselst2);
   STORE_CLASS int  process_course_scndpass (S_CRSE *c_crse, int fine);
   STORE_CLASS void ins_smtcuse_scndpass(void);

/* Error checking for max limits */
/* ***************************** */
   STORE_CLASS void chk_error_maxresgrd(int limit_no);
   STORE_CLASS void chk_error_maxlevels(int limit_no);
   STORE_CLASS void chk_error_maxattr  (int limit_no);
   STORE_CLASS void chk_error_maxrestr (int limit_no);
   STORE_CLASS void chk_error_maxexcl  (int limit_no);

/* Rule prototypes */
/* *************** */
   STORE_CLASS int   process_rule_caa (void);
   STORE_CLASS int   chk_umbrl_cred_and_crse(TMCHAR *cred_type_parm);
   STORE_CLASS void  set_parms_cred_1(void);
   STORE_CLASS void  set_parms_cred_2(void);
   STORE_CLASS void  set_parms_cred_3(void);
   STORE_CLASS void  set_parms_cred_4(void);
   STORE_CLASS int   chk_umbrl_1st_layer(TMCHAR *cred_type_parm);
   STORE_CLASS int   process_rule_agam(void);

/* Common Record Fetching prototypes. */
/* ********************************** */
   STORE_CLASS void  fetch_exclusions(int cursor_parm);
   STORE_CLASS void  fetch_detl_addlvl(int cursor_parm);

/* Group processing prototypes */
/* *************************** */
   STORE_CLASS void get_grp_genrl(int cursor_parm);
   STORE_CLASS void init_grp_cred_crse_val(void);
   STORE_CLASS void get_grp_restr(void);
   STORE_CLASS void get_grp_resgrd(void);   
   STORE_CLASS void get_grp_addlvl(void);   
   STORE_CLASS void crses_undergrp(S_CRSE *crselst_anchor);   
   STORE_CLASS int  chk_duplicate_group(void);

/* Student adjustment prototypes */
/* ***************************** */
   STORE_CLASS void chk_action_type(TMCHAR *action_code,
                                    TMCHAR *action_ind,
                                    TMCHAR *action_cnt);
   STORE_CLASS int  chk_sadj_prog_attr(int met_prog_attributes);
   STORE_CLASS void ins_smbaogn_waived(void);   
   STORE_CLASS void ins_smbgogn_waived(TMCHAR rule_or_group);   
   STORE_CLASS void get_sadj_grp_restr(void);
   STORE_CLASS void get_sadj_grp_resgrd(void);
   STORE_CLASS void get_sadj_grp_addlvl(void);
   STORE_CLASS void init_saca_var(void);
   STORE_CLASS int  waive_caa_requirement(void);
   STORE_CLASS void ins_waived_smrdous(void);
   STORE_CLASS int  chk_valid_area_for_group(void);
   STORE_CLASS int  chk_target_crse(void);

   STORE_CLASS int  find_subst_crse(S_CRSE *crselst, int found_substitute);
   STORE_CLASS int  find_used_subst_crse(int found_substitute);
   STORE_CLASS int  find_unused_crse(S_CRSE *crselst, int found_unused);
   STORE_CLASS void set_orig_var(void);
   STORE_CLASS void reset_orig_var(void);

   STORE_CLASS int  find_waive_crse(int found_waive_req);
