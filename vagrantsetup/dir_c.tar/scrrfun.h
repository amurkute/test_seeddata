/*TMCI18N BEGIN HEADER*/
#if !defined( _TMBSCRRFUN_H_EXISTS )
/* No Initialisation Required */                                               
#include "tmcilib.h"
static struct TMBundle _TMBSCRRFUN_H = {"scrrfun.h",NULL,NULL,NULL,NULL};
#define _TMBSCRRFUN_H_EXISTS
#endif
/*TMCI18N END HEADER*/

/* AUDIT_TRAIL_TM63
-- TranMan 6.3 
-- PROJECT : HEGDE_I18N
-- MODULE  : SCRRFUN
-- SOURCE  : enUS
-- TARGET  : I18N
-- DATE    : Sat Oct 27 06:29:42 2007
END AUDIT_TRAIL_TM63 */
/*****************************************************************************/
/* SCRRFUN.H Copyright (c) SCT Corporation 2001.  All rights reserved.       */
/*****************************************************************************/

/*****************************************************************************/
/*                                                                           */
/*       CONFIDENTIAL BUSINESS INFORMATION                                   */
/*                                                                           */
/*      **********************************                                   */
/*                                                                           */
/* THIS PROGRAM IS PROPRIETARY INFORMATION OF                                */
/* SYSTEMS AND COMPUTER TECHNOLOGY CORPORATION                               */
/* AND IS NOT TO BE COPIED, REPRODUCED, LENT OR                              */
/* DISPOSED OF, NOR USED FOR ANY PURPOSE OTHER                               */
/* THAN THAT FOR WHICH IT IS SPECIFICALLY PROVIDED                           */
/* WITHOUT THE WRITTEN PERMISSION OF SAID COMPANY                            */
/*                                                                           */
/*****************************************************************************/
/* SCRRFUN.H                                                                 */
/* Program SCRRFUN.PC Header File.                                           */
/*                                                                           */
/* AUDIT TRAIL: 5.1                                  INIT    DATE            */
/* ZYB 28MAR2001                                                             */
/* The Course catalog functional extraction process                          */
/*                                                                           */
/* -----------------------------------------------------------------------   */
/* AUDIT TRAIL: 5.4                                                          */
/*                                                    JRZ    18 DEC 2001     */
/* 2. Moved from intcomp to student and renamed to scrrfun.h.                */
/*                                                     ZYB   28Feb2002       */
/* 1. Added camp_ind variable.                                               */
/*                                                                           */
/* AUDIT TRAIL: 8.0 (I18N)
   1. Internationalization Unicode Conversion                                */ 
/* AUDIT TRAIL END                                                           */
/*****************************************************************************/

#ifndef _SCRRFUN_C_
#define STORE_CLASS2 extern
#else
#define STORE_CLASS2 /* */
#endif
       
   STORE_CLASS2 long course_cnt;
   STORE_CLASS2 TMCHAR acyr_code[10];
   STORE_CLASS2 TMCHAR acyr_desc[100];
   STORE_CLASS2 TMCHAR camp_ind[2];
   STORE_CLASS2 TMCHAR max_term[10];
   STORE_CLASS2 TMCHAR min_term[10];
/************************************************************************/
/*  Course Data Extract prototypes                                      */
/************************************************************************/

   STORE_CLASS2 void  writeCourse(void);
