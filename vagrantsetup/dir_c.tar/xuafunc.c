/* AUDIT TRAIL: 8.0 */
/* AUDIT TRAIL END */
/****************************************************************************
 XUAFUNC.C    -    This is a C function library that has functions used in
                   various records indexing reports. Below is a description
                   of each function.

  FUNCTION                PURPOSE
  Allocate_Cover_Sheet()  Used to reserve space for a cover sheet in outfile
                          before the report is generated.
  Error_Handling()        Used to trap for expected errors.
                          -1410 rowid not found error - this error is produced
                          because we send the user_id for the cover sheet or
                          the remote access rowid for the cover sheet in the
                          same parameter.
  Print_Cover_Sheet()     Used to determine if a Cover Sheet should be 
                          produced.  Checks for valid User_Id and a value of
                          'Y' in the Print Cover Sheet parameter. This function
                          returns an int value of 1 for TRUE and 0 for FALSE.
  Generate_Cover_Sheet()  Used to generate cover sheet and bill remote 
                          customers.  This function is almost always paired with
                          Allocate_Cover_Sheet. 
  Determine_Security_User()
  Append_Dtype_List()     Used to append the select_string with document type 
                          list to check for security. 
 
*****************************************************************************/
/***************************************************************************
 Parameter definitions
****************************************************************************/
typedef char      CHAR12000[12000];         /* define for Oracle null
                                             * terminated string */

EXEC SQL BEGIN DECLARE SECTION;

EXEC SQL TYPE CHAR12000 IS STRING(12000);

/* miscellaneous variables */
static CHAR31     h_user_id = "";
static CHAR31     h_report_user = "";
static CHAR31     h_rowid = "";
static int        h_no_pages = 0;
static float      h_print_rate = 0.0;
static CHAR12000  h_long_dummy = "";      /* exclude doc. types        */
static CHAR12000  h_exc_sec_list = "";      /* exclude doc. types        */
static CHAR12000  h_inc_sec_list = "";      /* include doc. types        */
static CHAR12000  h_ovr_sec_list = "";      /* override security         */
static CHAR12000  h_inc_rpt_list = "";      /* include report Dtypes     */

EXEC SQL END DECLARE SECTION;

/***************************************************************************
 FUNCTIONS 
****************************************************************************/

/*******************************************************************************
 Function Name: Error_Handling() 
 Description:   Traps for errors that the programmer expects.
*******************************************************************************/
static void Error_Handling()
{
  char msg_buf[100];
  int buf_size = 100;
  int msg_len;

  if (sqlca.sqlcode == -1410)
     return;

}
/*******************************************************************************
 Function Name: Print_Cover_Sheet() 
 Description:   Determines if a cover sheet should be produced. 
*******************************************************************************/
static int Print_Cover_Sheet()
{
   int loop_counter;
   int user_parm_index=0;
   int cover_sheet_index=0;

   for (loop_counter=0; loop_counter<20; loop_counter++) {
       if (!strcmp(p_parm_fields[loop_counter][1], "User Id: "))
          user_parm_index = loop_counter;
       if (!strcmp(p_parm_fields[loop_counter][1], "Print Cover Sheet? "))
          cover_sheet_index = loop_counter;
      }

   if (strcmp(p_parm_values[user_parm_index][0], NULL_STRING) && 
       strcmp(p_parm_values[cover_sheet_index][0],"N"))
       return 1;
   else return 0;
}
/*******************************************************************************
 Function Name: Allocate_Cover_Sheet() 
 Description:   This function reserves space for the cover sheet information.  
*******************************************************************************/
static void Allocate_Cover_Sheet()
{
  int loop_counter = 0;

   if (Print_Cover_Sheet())
      for (loop_counter=1; loop_counter<67; loop_counter++)
          fprintf(outfile, "%120.120s\n"," "); 

}
/*******************************************************************************
 Function Name: Generate_Cover_Sheet() 
 Description:   This function generates the cover sheet information.  
*******************************************************************************/
static void Generate_Cover_Sheet(struct Page_Stats * current)
{
   int loop_counter=0;
   int user_parm_index=0;
   float tot_amt_due = 0.0;
   char user_id_msg[70] = "S U B M I T T E D   B Y : ";
   char no_pages_msg[70] = "N U M B E R   O F   P A G E S   P R I N T E D : ";
   char per_page_msg[70] = "C O S T   P E R   P A G E :";
   char amt_due_msg[70]  = "A M O U N T   D U E :";
 

   if (Print_Cover_Sheet()) {
       for (loop_counter=0; loop_counter<20; loop_counter++) 
          if (!strcmp(p_parm_fields[loop_counter][1], "User Id: "))
             user_parm_index = loop_counter;
      rewind(outfile);
      h_no_pages = current->page - 1;
      strcpy(h_rowid,p_parm_values[user_parm_index][0]);
      EXEC SQL SELECT XIVCNTL_PRINT_RATE
               INTO :h_print_rate
               FROM XIVCNTL
               WHERE XIVCNTL_KEY = 'MASTER';
      EXEC SQL WHENEVER SQLERROR DO Error_Handling();
      EXEC SQL SELECT XIVACCT_CODE
               INTO :h_user_id
               FROM XIVACCT
               WHERE XIVACCT.ROWID = :h_rowid;
      if (ROWS_FOUND){
        EXEC SQL EXECUTE
             BEGIN X$_MAIN_SRCH_PKG.X$_UPDATE_TRANS_PRD
                   (:h_rowid, 0, 0, 0, :h_no_pages, 0);
             END;
        END-EXEC;
        tot_amt_due = 0;
       }
      else{
        EXEC SQL SELECT UPPER(REPLACE(:h_rowid,'~',' '))
            into :h_user_id from dual;
        tot_amt_due = h_no_pages * h_print_rate;
       }

      for (loop_counter=0; loop_counter<2; loop_counter++){
          fprintf(outfile,"%-60.60s",
          "**************************************************************");
          fprintf(outfile,"%-60.60s\n",
          "**************************************************************");
         }
      for (loop_counter=0; loop_counter<7; loop_counter++)
          fprintf(outfile,"%120.120s\n"," ");
      fprintf(outfile,"%-20.20s%-50.50s%-30.30s%-20.20s\n",
              " ", user_id_msg, h_user_id, " ");
      fprintf(outfile,"%120.120s\n"," ");
      fprintf(outfile,"%-20.20s%-70.70s%10d%-20.20s\n",
              " ", no_pages_msg, h_no_pages, " ");
      fprintf(outfile,"%120.120s\n"," ");
      fprintf(outfile,"%-20.20s%-70.70s%10.2f%-20.20s\n",
              " ", per_page_msg, h_print_rate, " ");
      fprintf(outfile,"%120.120s\n"," ");
      fprintf(outfile,"%-20.20s%-70.70s%10.2f%-20.20s\n",
              " ", amt_due_msg, tot_amt_due, " ");
      for (loop_counter=0; loop_counter<7; loop_counter++)
          fprintf(outfile,"%120.120s\n"," ");
      for (loop_counter=0; loop_counter<2; loop_counter++){
          fprintf(outfile,"%-60.60s",
          "**************************************************************");
          fprintf(outfile,"%-60.60s\n",
          "**************************************************************");
         }
     }
}
/*******************************************************************************
 Function Name: Determine_User_Security() 
 Description:   This function generates the cover sheet information.  
*******************************************************************************/
static void Determine_Security_User()
{
   int loop_counter;
   int user_parm_index=0;

      for (loop_counter=0; loop_counter<20; loop_counter++) 
          if (!strcmp(p_parm_fields[loop_counter][1], "Security Row Id: "))
             user_parm_index = loop_counter;
      strcpy(h_rowid,p_parm_values[user_parm_index][0]);
      EXEC SQL WHENEVER SQLERROR DO Error_Handling();
      EXEC SQL SELECT XIVACCT_USEC_USER
               INTO :h_report_user
               FROM XIVACCT
               WHERE XIVACCT.ROWID = :h_rowid;
      if (!ROWS_FOUND)
         strcpy(h_report_user, h_user);
}
/*******************************************************************************
 Function Name: Append_Dtype_List() 
 Description:   This function appends the select_string with following
                document type list to check for security :- 
                (1) Include Document types
                (2) Override Security Document types
                (3) Include Report Document types
                List # 2 & 3 are required by all Special Reports.
                Certain non-Special reports may use list # 1 & 2.
 Parameters:    *select_string = Pointer to a string variable that is used
                                 for parsing the select statement.
                max_len = Maximum length of the select statement.
                special_rpt_ind = For Special Reports, this indicator should
                                  be set to 1 else 0.
*******************************************************************************/

Append_Dtype_List(char *select_string, int max_len, int special_rpt_ind)
{
char temp_string[12000] = "";  /* Used to build parts of statement */

    /* In case of Special Reports, DON'T plug in inc/exc security doc types */
    if (!special_rpt_ind)
    {
       /** begin h_inc_sec_list **/
       if (strcmp(h_inc_sec_list,"***"))  /* if include list is not null */
       {
           sprintf(temp_string, " AND XIBDOCM_DTYP_CODE IN (%s) ",
              h_inc_sec_list);
           strncat(select_string, temp_string, max_len);
       }
    }

    /** begin h_ovr_sec_list **/
    if (strcmp(h_ovr_sec_list,"***"))  /* if the override list is not null */
    {
        sprintf(temp_string, " AND ( (XIBDOCM_SECURE_IND <> 'Y') OR \
(XIBDOCM_SECURE_IND = 'Y' AND XIBDOCM_DTYP_CODE IN (%s) )) ", h_ovr_sec_list);
        strncat(select_string, temp_string, max_len);
    }

    /* In case of Special Reports, plug in the inc report doc types */
    if (special_rpt_ind)
    {
       /** begin h_inc_rpt_list **/
       if (strcmp(h_inc_rpt_list,"***"))  /* if the include list is not null */
       {
           sprintf(temp_string, " AND XIBDOCM_DTYP_CODE IN (%s) ",
              h_inc_rpt_list);
           strncat(select_string, temp_string, max_len);
       }
    }

}
