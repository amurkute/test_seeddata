/******************************************************************************/
/* UBPBPFM.C - Bill Print Format Subroutines                                  */
/*                                                                            */
/* UBPBPFM.C Copyright (c) SCT Corporation 1993.  All rights reserved.        */
/******************************************************************************/

/******************************************************************************/
/* A brief description of the program - N Mills - 30/8/96                     */
/*                                                                            */
/* BODY - iteration for each selected account                                 */
/*                                                                            */
/*      print_(un)printed_bill                                                */
/*                                                                            */
/*           prints Page 1 general section (top of bill data)                 */
/*                                                                            */
/*           UABOPEN_HEAD                                                     */
/*           UABOPEN_BODY  iteration for each open item                       */
/*              store entry for each detail line in table UBRBILL             */
/*              if > 21 detail lines required                                 */
/*                 increment page no                                          */
/*                 print Page n general section (top details)                 */
/*                 print Page n stub (dummy stub)                             */
/*                                                                            */
/*           UABOPEN_FOOT                                                     */
/*              store real entry for each Page 1 stub line in table UBRBILL   */
/*                                                                            */
/*           if no open items found                                           */
/*              UABOPEN_FOOT to complete record for account                   */
/*                                                                            */
/*                                                                            */
/*      if account needs a bill                                               */
/*         store recipient data in table UBRRECP                              */
/*                                                                            */
/* UBRRECP_BODY  iteration for each recipient in UBRRECP                      */
/*                                                                            */
/*      read bill details for recipient back from UBRBILL and output a 159    */
/*      field record for each bill 'page'.                                    */
/*                                                                            */
/******************************************************************************/



/***************************************************/
/*                                                 */
/*       CONFIDENTIAL BUSINESS INFORMATION         */
/*                                                 */
/*      **********************************         */
/*                                                 */
/*  THIS PROGRAM IS PROPRIETARY INFORMATION OF     */
/* SYSTEMS AND COMPUTER TECHNOLOGY CORPORATION     */
/* AND IS NOT TO BE COPIED, REPRODUCED, LENT OR    */
/* DISPOSED OF, NOR USED FOR ANY PURPOSE OTHER     */
/* THAN THAT FOR WHICH IT IS SPECIFICALLY PROVIDED */
/* WITHOUT THE WRITTEN PERMISSION OF SAID COMPANY  */
/*                                                 */
/**************************************************************************** */
/* UBPBPFM.PC                                                                 */
/* Bill Print Format Subroutines                                              */
/*                                                                            */
/* This is the customer specific set of subroutines to be included in         */
/* program UBPBILP.PC.                                                        */
/* See that program's documentation for Tables, etc.                          */
/*                                                                            */
/* AUDIT TRAIL                                            INIT    DATE     */
/* --------------------------------------------------------- ---- ----------- */
/******************************************************************************/
/* AUDIT TRAIL: 8.0 */
/* AUDIT TRAIL END */

/******************************************************************************/
/* LOCAL FUNCTION PROTOTYPES                                                  */
/******************************************************************************/

static int   ActiveBankDraft            ( void );
static void  adjustment_body            ( void );
static void  adjustment_foot            ( void );
static void  adjustment_head            ( void );
static void  calculate_totals           ( void );
static void  check_detail_count         ( void );
static void  DebugMsg                   ( NUMSTR  nsCustCode,
                                          char   *pszPremCode,
                                          NUMSTR  nsBillNo,
                                          NUMSTR  nsPageNo,
                                          NUMSTR  nsLineNo,
                                          int     iSessionID,
                                          long    lLine );
static void  increment_page_no          ( void );
static void  InsertSpecialMessages      ( char   *pszPageNum );
static void  insert_service_total       ( void );
static void  installation_body_init     ( void );
static void  installation_init          ( void );
static void  NonOUCChargeBreakLogic     ( void );
static void  PrintAccountNumber         ( char   *pszPage,
                                          char   *pszLine );
static void  PrintAddress               ( char   *pszLineNum );
static void  PrintPremAddress               ( char   *pszLineNum );
static void  PrintBillChgTotalSection   ( char   *pszPageNo,
                                          short   sPrintDataFlag );

static void  PrintBillHeaderSection     ( char   *pszPageNo );
static void  PrintBillStubSection       ( char   *pszPageNo,
                                          short   sPrintDataFlag );
static void  PrintBudgetSummary         ( void );
static void  PrintChgAdjDetail          ( char   *pszChgAdjText,
                                          char   *pszChgAdjAmount,
                                          char   *pszChgAdjTotal );
static void  PrintConsumptionAdjustment ( char   *pszChrgCalcNum );
static void  PrintCurrentAmountDue      ( char   *pszPage );
static void  PrintDepositInstallment    ( char   *seq_num,
                                          char   *install_num );
static void  PrintDetailLineAdjustments ( void );
static void  PrintPrintedBill           ( void );
static void  PrintUnprintedBill         ( void );
static short PrintMeterChangeOut        ( void );
static short PrintMeteredService        ( void );
static short PrintMiscCharge            ( void );
static short PrintNonMeteredSvc         ( void );
static void  PrintPreviousBalance       ( char   *pszPage,
                                          char   *szLineNum );
static void  PrintRateChangeMsg         ( void );
static void  PrintRecalcMsg             ( void );
static void  PrintRoundUpYear           ( void );
static void  PrintServConsumption       ( char   *pszCustCode,
                                          char   *pszPremCode,
                                          char   *pszServNum,
                                          char   *pszScatCode,
                                          char   *pszPresentDate,
                                          char   *pszChrgCalcNum );
static void  PrintServiceAddress        ( void );
static void  GetAddress                 ( void );
static void  PrintStepDetail            ( char   *pszPrevDate,
                                          char   *pszPresDate,
                                          long    lPrevRead,
                                          long    lPresRead,
                                          long    lDOS );
static void  PrintSteps                 ( void  (*DetailLine)(
                                          char *, char *, char *),
                                          char   *pszPrevDate,
                                          char   *pszPresDate,
                                          long    lPrevRead,
                                          long    lPresRead,
                                          long    lDOS,
                                          char   *pszDetailLineText,
                                          char   *pszDetailLineAmount );
static void  PrintTotalsAndFillBlanks   ( void );
static void  Section                    ( char   *pszPageNo );
static short SelectMeteredServiceData   ( void );
static int   select_ubrrchs             ( void );  
static void  uabopen_body               ( void );
/*static void  uabopen_foot_non_ouc       ( void ); */
static void  uabopen_foot           ( void );
static void  uabopen_head               ( void );
static void print_line_53_55(void);


  /*--------------------------------------------------------------------------*/
  /* Installation Initializations                                             */
  /*--------------------------------------------------------------------------*/

static void installation_init(void)
{
   printf("\n");
}

/******************************************************************************/

static void installation_body_init(void)
{
   printf("\n");
  return;
}

  /*--------------------------------------------------------------------------*/
  /*  PrintUnprintedBill and PrintPrintedBill, top level control for          */
  /*  format modules.  Called from BODY in ubpbilp.pc                         */
  /*--------------------------------------------------------------------------*/

/* ************************************************************************** */
/* print bills that have never been printed before (printed_inds = 'N')       */
/* ************************************************************************** */

static void PrintUnprintedBill(void)
{
  NUMSTR szLocalLineNum;
  NUMSTR szLocalRdupAmt;



  /* select the next bhst_tran_num from the sequence */

  select_ubsbhst(FIRST_ROW);

  strcpy(amount_due,"0");
  strcpy(adjustments,"0");
  strcpy(adjustment_cons,"0");
  PrintBillHeaderSection(szGChgAdjPageNo);


  tonum(prev_bal,null);
  select_prev_bal(FIRST_ROW);
  if ( !*prev_bal )
     strcpy(prev_bal,"0");
  else
     add(amount_due,amount_due,prev_bal);


  tonum(payments,null);
  select_payments_unbilled(FIRST_ROW);
  if ( !*payments )
     strcpy(payments,"0");
  else
     subtract(amount_due,amount_due,payments);

  strcpy(szGTotalAmountDue,payments);

    SelectPastDueTotal( ucracct_cust_code,
                        ucracct_prem_code,
                        printed_date,
                        szGPastDueTotal );




    select_payments_zero_bill(FIRST_ROW);
    uabopen_bill_balance(FIRST_ROW);
    subtract(amount_due_balance,bill_balance,payments_zero_bill);



   if ( BPIsActiveRoundUpAcct( ucracct_status_ind,
                               ucracct_rdup_start_date,
                               ucracct_rdup_end_date,
                               printed_date,
                               ucbmbil_rdup_ind,
                               ucbmbil_sub_pymt_ind,
                               ucbmbil_rdup_start_date,
                               ucbmbil_rdup_end_date,
                               ucrmbil_rdup_ind) &&
                              *uobsysc_srat_code_rdup &&
                              lOpenItemCount) {

    /*       If this is the master customer's account, use *
     *     the flat amount from the UCBMBIL row if the     *
     *     round-up ind is set to 'F'lat and the master    *
     *     is responsible for payment                      */

      if ( ( strcmp(ucracct_cust_code, ucbmbil_cust_code)==0 )  &&
           ( strcmp(ucracct_prem_code, ucbmbil_prem_code)==0 )  &&
           ( strcmp(ucbmbil_rdup_ind, "F") == 0 ) &&
           ( strcmp(ucbmbil_sub_pymt_ind, "N") == 0 ) )
         strcpy( szLocalRdupAmt, ucbmbil_rdup_amt );
      else
         strcpy( szLocalRdupAmt, ucracct_rdup_amt );
     

      BPInsertRoundup( ucracct_cust_code,
                       ucracct_prem_code,
                       printed_date,
                       uobsysc_srat_code_rdup,
                       uobsysc_srat_code_mbil_rdup,
                       amount_due_balance,
                       szLocalRdupAmt,
                       ucbmbil_sub_pymt_ind, 
                       EXEC_NAME,
                       ucbmbil_rdup_ind );
   }

      if ( ( strcmp(ucracct_cust_code, ucbmbil_cust_code)==0 )  &&
           ( strcmp(ucracct_prem_code, ucbmbil_prem_code)==0 ) ) 
         {
         InsertServiceCharge(ucbmbil_cust_code,
			     ucbmbil_prem_code,
                             ucbmbil_srat_code_svchg,
		             printed_date,    /*szGPrintDate, */
			     rpt_user );      /* szGRptUser   */ 
         }


   active_draft = 0;
   if (ucracct_draft_acct_status[0]=='A')
      ActiveBankDraft();

     sGPrintingOutsideAgencies = TRUE;
   SelectPrintedButNotDueTotal( ucracct_cust_code,
                                ucracct_prem_code,
                                printed_date,
                                szBalanceForward);



   open_item_found = 0;
   adjustments_found=0;
   strcpy(szGChgAdjPageNo, "1");
   strcpy(szGNumBillPages, "1");

   sGPrintingOutsideAgencies = FALSE;

   open_item_found = 0;
   adjustments_found=0;


   
  report(uabopen_selm_unprinted,uabopen_body,uabopen_head,uabopen_foot);

     report(select_adjs_unprinted,adjustment_body,adjustment_head,
                adjustment_foot);

    /*  IncludeWeather();  Weather */
    if ( asvc_open_item_found || asvc_adjustments_found )
       insert_service_total();

     if (IsBudgeted==0)
     {
       if ((sGLastDetailLine-no_of_detail_lines) <=6)
      { while(no_of_detail_lines <=sGLastDetailLine)
             PrintChgAdjDetail("","","");
           }
      }
  


   if (compare( szBalanceForward,"0",NE))
      PrintChgAdjDetail( BALANCE_FORWARD_FORMAT,"", szBalanceForward );

   /**Commented this line for DocuCorp****RAM 03/feb/98 **********/
   
  /* add(szGCurrChgsAndAdjs,szGCurrChgsAndAdjs,szBalanceForward); */

   PrintTotalsAndFillBlanks();

   strcpy(szGChgAdjPageNo,"1");

   PrintBillStubSection(szGChgAdjPageNo,PRINT_DATA);

  InsertBankDraft(); 
  print_line_53_55(); 

}                                                 /* end PrintUnprintedBill */

/* ************************************************************************** */
/* print bills that have been printed before (printed_inds = 'Y')             */
/* ************************************************************************** */

static void PrintPrintedBill(void)
{
   NUMSTR szLocalLineNum;



   select_due_date_printed(FIRST_ROW);
   lGAdditionalSections=0;
   NumberofSections=0;
   strcpy(amount_due,"0");
   strcpy(adjustments,"0");
   strcpy(adjustment_cons,"0");

   PrintBillHeaderSection(szGChgAdjPageNo);

   strcpy(szGTotalAmountDue,ubbbhst_prev_bal);
   strcpy(prev_bal,ubbbhst_prev_bal);
   add(amount_due,amount_due,prev_bal);

   strcpy(payments,ubbbhst_payments);
   subtract(amount_due,amount_due,payments);

   strcpy(szGTotalAmountDue,payments);

   SelectPastDueTotal( ucracct_cust_code,
                        ucracct_prem_code,
                        printed_date,
                        szGPastDueTotal );



   active_draft = 0;
   if (ucracct_draft_acct_status[0]=='A')
      ActiveBankDraft();

  sGPrintingOutsideAgencies = TRUE;

   SelectPrintedButNotDueTotal( ucracct_cust_code,
                                ucracct_prem_code,
                                reprint_date_var,
                                szBalanceForward);



   open_item_found = 0;
   adjustments_found=0;


   strcpy(szGChgAdjPageNo, "1");
   strcpy(szGNumBillPages, "1"); 

   sGPrintingOutsideAgencies = FALSE;

   open_item_found = 0;
   adjustments_found=0;                         
   report(uabopen_selm_printed,uabopen_body,uabopen_head,uabopen_foot);

     
   report(select_adjs_for_bhst_tran,adjustment_body,adjustment_head,
                adjustment_foot);
   
 /*  if(SelectWeather()) */            /* uobsysc_print_weather_ind = 'Y' */
 /*  IncludeWeather();  */          /* print degree days information */ 
  





     if (IsBudgeted==0)
     {
       if ((sGLastDetailLine-no_of_detail_lines) <=6)
      { while(no_of_detail_lines <=sGLastDetailLine)
             PrintChgAdjDetail("","","");
           }
      }
   

      PrintChgAdjDetail("","", "" );

   if (compare( szBalanceForward,"0",NE))
      PrintChgAdjDetail( BALANCE_FORWARD_FORMAT,"", szBalanceForward );

   /*  add(szGCurrChgsAndAdjs,szGCurrChgsAndAdjs,szBalanceForward); 
   /* RAM 04/feb/98 DocuCorp */

   strcpy(szGTotalAmountDue,ubbbhst_ending_bal);
   PrintTotalsAndFillBlanks();

   strcpy(szGChgAdjPageNo,"1");

   PrintBillStubSection(szGChgAdjPageNo,PRINT_DATA);
   InsertBankDraft();   
   print_line_53_55(); 
} /* end PrintPrintedBill */


/******************************************************************************/

static void calculate_totals(void)
{

    if (strcmp(szUtrsratBillPrintDesc,"Service Fee")==0)
       return;

    tonum(uabadje_budget_variance,null);
    tonum(uabadje_billed_chg,null);
    strcpy(adj_ind,null);
    select_adj_total_printed(FIRST_ROW);


    if ( ( strcmp(uabopen_item_type,"B") == 0 ) &&
            *budgeted_service_ind               &&
         (strcmp(budgeted_service_ind,"C")==0)  &&
         ((utrbdgm_restart_ind[0]=='R')||
          (utrbdgm_restart_ind[0]=='N')) )
    {

      add(total_new_charges,total_new_charges,uabopen_billed_chg);
      add(total_due_charges,total_due_charges,uabopen_billed_chg);
    }
    else
    {

       /* we have a budgeted service, add the budget charges to the */
       /* charges total and insert the budget charge line           */
       strcpy(budget_footnote,"Y");

       
       /*******Commented by ram 12/feb/98/ to remove adjustments from total charges **
       if ( *uabadje_billed_chg )
          add(uabopen_billed_chg,uabopen_billed_chg,uabadje_billed_chg);
       /******************************************/
          

       subtract(budget_amount,uabopen_billed_chg,uabopen_budget_variance);
       /*
        * Per K. Moore/H. Shepherd, we should always add
        * the billed_chg to the 'Total New Charges' for a budgeted service,
        * rather than adding the budget_amount.  This ensures that the
        * detail new charges always add up to the total new charges.
        * The budget amounts will still be used to calculate the 'Total
        * Due'.
        */
       add(total_new_charges,total_new_charges,uabopen_billed_chg);
       add(total_due_charges,total_due_charges,budget_amount);
      /* add(total_budget_amount,total_budget_amount,budget_amount); */
    }

    add(break_total,break_total,uabopen_billed_chg);

     add(taxt_break_total,taxt_break_total,uabopen_billed_chg);

    if (*uabopen_tax_ind == 'Y')
       add(subtotal,subtotal,uabopen_billed_chg);

}   /*end calculate_totals*/

  /*--------------------------------------------------------------------------*/
  /*   uabopen head and body.  Called from PrintPrintedBill,                */
  /*   PrintUnprintedBill for each open item to print in center of page.    */
  /*--------------------------------------------------------------------------*/

/* ************************************************************************** */
/* uabopen head                                                               */
/* ************************************************************************** */
static void uabopen_head(void)
{


   strcpy( szGConsumptionLineNum, FIELD_1_CONSUMPTION_HISTORY );
   strcpy( szGBudgetGridPageNum, "" );
   strcpy( szGBudgetGridLineNum, "" );

   select_serv_info(FIRST_ROW);

   test_for_budget();
   
   
                            /* sets budgeted_service_ind                 */

   serv_taxable=0;          /* set if current service taxable            */
   print_subtot=1;          /* Only print one subtotal per service       */
   serv_misc=0;             /* Set if item non service specific          */
   no_of_detail_lines= 1;   /* Detail line count                         */
   no_of_agency_lines= 1;
   strcpy(break_bill_print_group_num, driver_bill_print_group_num);
   strcpy(break_serv_num,             uabopen_serv_num);
   strcpy(break_charge_date,          uabopen_charge_date);
   strcpy(break_srat_code,            uabopen_srat_code);
   strcpy(break_asvc_code,            utvsrat_asvc_code);
   strcpy(break_taxt_code,            utrsrat_taxt_srat_code);


   /****For First Service of The Account ***** RAM ***/
     if (IsBudgeted ==0) 
      {
       PrintBudgetSummary();
       extract_budginfo();
       IsBudgeted = 1;
      }

   
   if (sGPrintingOutsideAgencies == FALSE) {
      if (ubtibil_type_ind[0] == 'D') {
         PrintChgAdjDetail("", "", "");
         PrintChgAdjDetail(DUPLICATE_BILL_TEXT_FORMAT, "", "");
      }
      else if (ubtibil_type_ind[0] == 'C') {
         PrintChgAdjDetail("", "", "");
         PrintChgAdjDetail(CORRECTED_BILL_TEXT_FORMAT, "", "");
        }
     else if (ubtibil_type_ind[0] == 'A') {
         PrintChgAdjDetail("", "", "");
         PrintChgAdjDetail(ADJUSTED_BILL_TEXT_FORMAT, "", "");
      }

      else if (*reprint_date_var) {
         PrintChgAdjDetail("", "", "");
         PrintChgAdjDetail(REPRINTED_BILL_TEXT_FORMAT, "", "");
      }
   }

  if (open_item_found)
      uabopen_body();

}                                                         /* end uabopen_head */

/* ************************************************************************** */
/* uabopen body                                                               */
/* ************************************************************************** */

static void uabopen_body(void)
{
          if (szUtrsratBillPrintDesc[0] !='\0')
          strcpy(szBillPrintDesc,szUtrsratBillPrintDesc);


            if ( strcmp( break_asvc_code, utvsrat_asvc_code ) != 0 )
              strcpy( break_asvc_code, utvsrat_asvc_code );

         strcpy(curr_srat_code,uabopen_srat_code);
         if (*uabopen_billed_chg)
            strcpy(curr_chg,uabopen_billed_chg);

         if (prev_srat_code[0] =='\0')
            strcpy(prev_srat_code,curr_srat_code);
         
   
      if ( ( *uabopen_tax_ind == 'N' || *ucrsvtx_rate_code_tax ) &&
           serv_taxable && print_subtot ) {
         print_subtot = 0;
      }

         if ( ( strcmp( break_serv_num, uabopen_serv_num)  !=0)  ||
              ( strcmp( break_srat_code, uabopen_srat_code) !=0)  ) {

               if (*budgeted_service_ind) {
                  if ( strcmp(budgeted_service_ind,"Y")!=0)  {
                     if ((!*reprint_date_var) && ((!*sleep_wake_ind ||
                        (*sleep_wake_ind && ubtibil_type_ind[0] == 'D'))))
                        if( (strcmp(break_serv_num,uabopen_serv_num)!=0)||
                            (uabopen_serv_num[0]=='\0'))
                           update_budget();
                  }
                  else {
                     if ( uabbudg_status_ind[0] == 'C' )
                        if ( (strcmp(break_serv_num,uabopen_serv_num)!=0)||
                             (uabopen_serv_num[0]=='\0'))
                           update_budget();
                  }
               }

   
            select_serv_info(FIRST_ROW);
            if ( (strcmp(break_serv_num,uabopen_serv_num)!=0) ||
                 (uabopen_serv_num[0]=='\0'))
             {  
              test_for_budget(); 
               if (IsBudgeted ==0) 
                {
                 PrintBudgetSummary();
                 extract_budginfo();
                 IsBudgeted = 1;
                } 
             }
          


            

            if (strcmp(ucrserv_styp_code,prev_styp_code) != 0) {
               strcpy(prev_styp_code,ucrserv_styp_code);
               strcpy(cycle_code,ucracct_cycl_code);
               strcpy(service_type,ucrserv_styp_code);
               strcpy(cycle_code,"00000");
               strcpy(service_type,ucrserv_styp_code);
            }
            strcpy(break_serv_num,    uabopen_serv_num);
            strcpy(break_charge_date, uabopen_charge_date);
            strcpy(break_srat_code,   uabopen_srat_code);
         }
         
         /* clear detail line fields */
         BPInitShisStruc( pstPrevShis        );
         BPInitShisStruc( pstCurrShis        );
         BPInitShisStruc( pstOutOldMeterShis );
         BPInitShisStruc( pstInNewMeterShis  );

         if (uabopen_tax_ind[0] == 'Y')
            serv_taxable=1;

         if (uabopen_serv_num[0] == '0')
            serv_misc=1;

         /* Print the charge */

         if (*uabopen_chrg_calc_num && *non_metered_ind)
            PrintNonMeteredSvc();
         else {
            if (*uabopen_chrg_calc_num) {
               SelectMeteredServiceData();
               if (change_out_ind[0]=='Y')
                  PrintMeterChangeOut();
               else {
                  PrintMeteredService();
               }
               if (sGPrintingOutsideAgencies == FALSE )
                  PrintServConsumption(ucracct_cust_code,
                                       ucracct_prem_code,
                                       uabopen_serv_num,
                                       uabopen_scat_code,
                                       stCurrShis.szActionDate,
                                       uabopen_chrg_calc_num);
            }
            else
               PrintMiscCharge();
         }
     



   atleastone_found =1;
   if (atleastone_found==0)
   {
    asvc_open_item_found=0;
    open_item_found=0;
   }

   /* *********************************************************************** */
   /* update routines - do not execute if in reprint mode                     */
   /*   or, in sleep-wake, update-ind is off                                  */
   /* *********************************************************************** */

   if ( ( *reprint_date_var ) ||
        (*sleep_wake_ind && ubtibil_type_ind[0] == 'D') )
      return;

/* If the account has a payment arrangement, check the open item        */
/* and determine if it needs to be updated into uarpyar.  It needs to   */
/* be updated/inserted when:                                            */
/*  1) A debit open item is found with no due date (31-dec-2099) and    */
/*     has not been printed on a bill                                   */
/*  2) A debit adjustment is found that has not been printed on a bill. */

   if ( *ucracct_pmnt_arr ) {

      strcpy(adj_ind,null);
      select_adjs_pay_arrng(FIRST_ROW);
      if ( *adj_ind )
         add(debit_adjs,debit_adjs,uabadje_balance);

      /* check to see if the open item has a due date and a debit amount */
      if ( compare(uabopen_due_date,"31-DEC-2099",EQS) &&
           compare(uabopen_billed_chg,"0",GT) )
       {
         /* we have a positive charge, update/insert a row to uarpyar  */
         strcpy(szGTotalAmountDue,uabopen_billed_chg);

         BPUpdateInsertPmntArrng(ucracct_cust_code, ucracct_prem_code,
                                 ucracct_arrng_num, account_due_date,
                                 szGTotalAmountDue, ucbmbil_sub_pymt_ind,
                                 EXEC_NAME);
      }
   }

   /* update the printed indicator, printed date, and due date in uabopen */
   CalculateDiscount();
   update_uabopen();
}                                                    /* end uabopen_body */

/******************************************************************************/


static short PrintNonMeteredSvc( void )
{
   /* select the non-metered info if we have the primary rate */
   est_usage_ind[0] = '\0';
   BPSelectFlatServiceData( uabopen_chrg_calc_num,
                            stCurrShis.szDOS,
                            stCurrShis.szConsumption,
                            stCurrShis.szActionDate,
                            stCurrShis.szRtypCode );

   BPSelectPresentDateFlat( uabopen_chrg_calc_num, stCurrShis.szActionDate );
   BPSelectPreviousDateFlat( ucracct_cust_code,
                             ucracct_prem_code,
                             uabopen_serv_num,
                             ucrserv_styp_code,
                             uabopen_scat_code,
                             uabopen_charge_date,
                             uabopen_chrg_calc_num,
                             reprint_date_var,
                             stPrevShis.szActionDate );

   BPSelectRecalcIndForUnmetered( ucracct_cust_code,
                                  ucracct_prem_code,
                                  uabopen_serv_num,
                                  ucrserv_styp_code,
                                  uabopen_scat_code,
                                  uabopen_charge_date,
                                  uabopen_chrg_calc_num,
                                  stCurrShis.szHighLowExcp );

   /* print the open item detail */
   select_ubrrchs(); 


   sprintf(szLineAmount,"%lf",dSumOUCSubordCharges);
   sprintf(szVarianceAmount,"%lf",dSumOUCSubordVariance);

   add(uabopen_billed_chg,uabopen_billed_chg,szLineAmount);
   add(uabopen_budget_variance,uabopen_budget_variance,szVarianceAmount);



   /**** to call printsteps for docucorp ***/
   strcpy(szDetailLineText, szUtrsratBillPrintDesc);
      strcpy(szDetailLineAmount, uabopen_billed_chg);
      PrintSteps( PrintChgAdjDetail,
                  stPrevShis.szActionDate,
                  stCurrShis.szActionDate,
                  atol(stPrevShis.szReading),
                  atol(stCurrShis.szReading),
                  atol(stCurrShis.szDOS),
                  szDetailLineText,
                  szDetailLineAmount);

   calculate_totals();

   if (sGPrintingOutsideAgencies == TRUE )
      return( 0 );


        PrintChgAdjDetail(szUtrsratBillPrintDesc,"", uabopen_billed_chg);



   return( 0 ); /* success */
}                                                   /* end PrintNonMeteredSvc */

/******************************************************************************/

static short SelectMeteredServiceData( void )
{
   /* select the metered info if we have the primary rate */
   BPSelectPreviousReading(ucracct_cust_code,
                           ucracct_prem_code,
                           uabopen_serv_num,
                           ucrserv_styp_code,
                           uabopen_scat_code,
                           uabopen_charge_date,
                           uabopen_chrg_calc_num,
                           reprint_date_var,
                           pstPrevShis);
   BPSelectChangeOutReading( uabopen_chrg_calc_num,
                             ucrserv_invn_code,
                             change_out_ind,
                             pstOutOldMeterShis);
   BPSelectDOS( uabopen_chrg_calc_num, stCurrShis.szDOS );

   return( 0 ); /* success */
}                                            /* end SelectMeteredServiceData */

/******************************************************************************/

static short PrintMeterChangeOut( void )
{
   NUMSTR total_dos = "";


   BPSelectPresentReading(uabopen_chrg_calc_num, pstCurrShis);
   BPSelectPreviousReadingNewMeter( ucracct_cust_code,
                                    ucracct_prem_code,
                                    uabopen_serv_num,
                                    ucrserv_styp_code,
                                    uabopen_scat_code,
                                    stCurrShis.szInvnCode,
                                    uabopen_charge_date,
				    reprint_date_var,
                                    pstInNewMeterShis);

   /*
    * NOTE: BPSelectChangeOutReading() has already been called from
    * SelectMeteredServiceData() at this point.
    */

   BPSelectChangeOutReadingPrev( ucracct_cust_code,
                                 ucracct_prem_code,
                                 uabopen_serv_num,
                                 ucrserv_styp_code,
                                 uabopen_scat_code,
                                 stOutOldMeterShis.szInvnCode,
                                 stOutOldMeterShis.szActionDate,
                                 pstPrevShis );

   calculate_totals();
    select_change_out_reading(FIRST_ROW);
    select_change_out_reading_prev(FIRST_ROW);
     


      /* Print meter # heading line */

      if ( sFirstChargeForService == TRUE ) {
         sprintf(szDetailLineText, METER_INFO_TEXT_FORMAT,
                      szUtrsratBillPrintDesc,
                      ucrserv_invn_code,
                      ((szGEmployeeStatus[0] != '\0') ? " - " : ""),
                      ((szGEmployeeStatus[0] != '\0') ? METER_INFO_EMP_IND_TEXT_FORMAT : "") );

         PrintChgAdjDetail(szDetailLineText, "", "");

         sFirstChargeForService = FALSE;
      }

      /* Print last reading for new meter */

      sprintf(szDetailLineText, CURRENT_READING_TEXT_FORMAT, "",
            stCurrShis.szActionDate, stCurrShis.szReading,
            ((stCurrShis.szRtypCode[0] == 'E') ? ESTIMATED_TEXT_FORMAT : ""),
            ((*(stCurrShis.szCadjNum))         ? CORRECTED_TEXT_FORMAT : ""));
      PrintChgAdjDetail(szDetailLineText, "", "");

      /* Print in reading for new meter */

      sprintf(szDetailLineText, METER_INFO_NEW_METER_1_FORMAT, "",
                   stInNewMeterShis.szActionDate, stInNewMeterShis.szReading );
      PrintChgAdjDetail(szDetailLineText, "", "");

      /* Print days of service and consumption for new meter */

      sprintf(szDetailLineText, "     %-3s Days         %10.10s",
              stCurrShis.szDOS, stCurrShis.szConsumption );
      PrintChgAdjDetail(szDetailLineText, "", "");

      /* Print last reading for old meter */

      sprintf(szDetailLineText, "%5.5s%s Reading: %9.9s Meter Exchange", "",
              stOutOldMeterShis.szActionDate, stOutOldMeterShis.szReading,
              ((stCurrShis.szRtypCode[0] == 'E') ? ESTIMATED_TEXT_FORMAT : ""),
              ((*(stCurrShis.szCadjNum))         ? CORRECTED_TEXT_FORMAT : ""));
      PrintChgAdjDetail(szDetailLineText, "", "");

      /* Print prior reading for old meter */

      sprintf(szDetailLineText, "%5.5s%s Reading: %9.9s%s%s", "",
             stPrevShis.szActionDate, stPrevShis.szReading,
             ((stPrevShis.szRtypCode[0] == 'E') ? ESTIMATED_TEXT_FORMAT : ""),
             ((*(stPrevShis.szCadjNum))         ? CORRECTED_TEXT_FORMAT : ""));
      PrintChgAdjDetail(szDetailLineText, "", "");

      /* Print days of service and consumption for old meter */

      sprintf(szDetailLineText, "     %-3s Days         %10.10s",
              stOutOldMeterShis.szDOS, stOutOldMeterShis.szConsumption );
      PrintChgAdjDetail(szDetailLineText, "", "");

      /****Changes Made to Write a separate Service header 
       *   if there is a meter change out
       *   Ram 01/23/97
       ******/
                
                GDocSeqNo=GDocSeqNo+1;
                Init_ServHead();
                
                  Extract_BillDetail();
                First_Primary=FALSE;
      /* Print charge steps */

      strcpy(szDetailLineText, szUtrsratBillPrintDesc);
      strcpy(szDetailLineAmount, uabopen_billed_chg);
      add(total_dos,stCurrShis.szDOS,stOutOldMeterShis.szDOS);
      
      strcpy(change_out_ind,"N");
      PrintSteps( PrintChgAdjDetail,
                  stOutOldMeterShis.szActionDate,
                  stCurrShis.szActionDate,
                  atol(stInNewMeterShis.szReading),
                  atol(stCurrShis.szReading),
                  atol(total_dos),
                  szDetailLineText,
                  szDetailLineAmount);

    return( 0 ); /* success */
}

                                                 /* end PrintMeterChangeOut() */

/******************************************************************************/

static short PrintMeteredService( void )
{
   BPSelectPreviousReading(ucracct_cust_code,
                           ucracct_prem_code,
                           uabopen_serv_num,
                           ucrserv_styp_code,
                           uabopen_scat_code,
                           uabopen_charge_date,
                           uabopen_chrg_calc_num,
                           reprint_date_var,
                           pstPrevShis);
   BPSelectPresentReading(uabopen_chrg_calc_num, pstCurrShis);
   BPSelectDOS( uabopen_chrg_calc_num, stCurrShis.szDOS );

   /* print the open item detail */
   select_ubrrchs();


   if (sGPrintingOutsideAgencies == FALSE ) {

         /* Print meter # heading line */
    if ( sFirstChargeForService == TRUE ) {
       sprintf(szDetailLineText, METER_INFO_TEXT_FORMAT,
       szUtrsratBillPrintDesc,
       ucrserv_invn_code,
       ((szGEmployeeStatus[0] != '\0') ? " - " : ""),
       ((szGEmployeeStatus[0] != '\0') ? METER_INFO_EMP_IND_TEXT_FORMAT : "") );

            PrintChgAdjDetail(szDetailLineText, "", "");

            sFirstChargeForService = FALSE;
         }

         /* Print current reading line */

         sprintf(szDetailLineText, CURRENT_READING_TEXT_FORMAT, "",
            stCurrShis.szActionDate, stCurrShis.szReading,
            ((stCurrShis.szRtypCode[0] == 'E') ? ESTIMATED_TEXT_FORMAT : ""),
            ((*(stCurrShis.szCadjNum))           ? CORRECTED_TEXT_FORMAT : ""));
         PrintChgAdjDetail(szDetailLineText, "", "");

         /* Print prior reading line */

         sprintf(szDetailLineText, "%5.5s%s Reading: %9.9s%s%s", "",
                      stPrevShis.szActionDate, stPrevShis.szReading,
                      ((prev_rtyp_code[0] == 'E') ? ESTIMATED_TEXT_FORMAT : ""),
                      ((*prev_cadj_num)           ? CORRECTED_TEXT_FORMAT : ""));
         PrintChgAdjDetail(szDetailLineText, "", "");
      }

      /* Print charge steps */

      strcpy(szDetailLineText, szUtrsratBillPrintDesc);
      strcpy(szDetailLineAmount, uabopen_billed_chg);
      PrintSteps( PrintChgAdjDetail,
                  stPrevShis.szActionDate,
                  stCurrShis.szActionDate,
                  atol(stPrevShis.szReading),
                  atol(stCurrShis.szReading),
                  atol(stCurrShis.szDOS),
                  szDetailLineText,
                  szDetailLineAmount);

         calculate_totals();
   return( 0 ); /* success */
}                                                /* end PrintMeteredService() */

/******************************************************************************/

static void PrintConsumptionAdjustment( char *pszChrgCalcNum )
{
   EXEC SQL BEGIN DECLARE SECTION;
      NUMSTR szLocalCadjNum     [100];
      NUMSTR szLocalChrgCalcNum      ="";
      CHAR9  szLocalAdjDate     [100];
      double dLocalBillConsAdjAmt [100];
      NUMSTR szLocalMultiplier    [100];


      NUMSTR szCadjNum           = "";
      CHAR9  szAdjDate           = "";
      double dBillConsAdjAmt     = 0;
      NUMSTR szMultiplier        = "";

      NUMSTR szLocalAdjBilledChg      = "";
      NUMSTR szLocalAdjBalance        = "";

      double dLocalConsumpLevel       = 0;
      NUMSTR szLocalStepCharge        = "";
      CHAR5  szLocalSratCode          = "";
      CHAR5  szLocalScatCode          = "";
      CHAR12 szLocalChargeDate        = "";
      CHAR2  szLocalRateStepInd       = "";
      CHAR5  szLocalUomsCode          = "";

      short  i  =0;
      short  NoOfRows=0;
      short  sLocalCadjNum_Ni        [100];
      short  sLocalAdjDate_Ni        [100];
      short  sLocalBillConsAdjAmt_Ni [100];
      short  sLocalMultiplier_Ni     [100];

      short  sLocalAdjBilledChg_Ni    = 0;
      short  sLocalAdjBalance_Ni      = 0;
      short  sLocalConsumpLevel_Ni    = 0;
      short  sLocalStepCharge_Ni      = 0;
      short  sLocalSratCode_Ni        = 0;
      short  sLocalScatCode_Ni        = 0;
      short  sLocalChargeDate_Ni      = 0;
      short  sLocalRowID_Ni           = 0;
      short  sLocalRateStepInd_Ni     = 0;
      short  sLocalUomsCode_Ni        = 0;
   EXEC SQL END   DECLARE SECTION;

   double dConsumpLeft = 0;


   strcpy( szLocalChrgCalcNum, pszChrgCalcNum );

   /* Get the consumption adjustment info */

   EXEC SQL DECLARE ConsumAdj CURSOR FOR
      SELECT ubrcadj_num,
             TO_CHAR( ubrcadj_adj_date, 'MM/DD/RR' ),
             ubrcadj_bill_cons_adj_amt,
             ubrcadj_multiplier
        FROM uabopen,
             uabadje,
             ubrcadj
       WHERE uabopen_cust_code = :ucracct_cust_code           
         AND uabopen_prem_code = :ucracct_prem_code
         AND uabopen_serv_num  = :ucrserv_num                 
         AND uabadje_origin_ar_trans = uabopen_ar_trans
         AND uabopen_chrg_calc_num IS NOT NULL                
         AND :non_metered_ind IS NULL                         
         AND ubrcadj_type = 'C'
         AND ( ( uabadje_printed_ind IN ('N','R'))            
          OR   ( uabadje_bhst_tran_num = :ubbbhst_tran_num ) );

      EXEC SQL OPEN ConsumAdj;
      POSTORA;


      EXEC SQL
         FETCH ConsumAdj
          INTO :szLocalCadjNum        :sLocalCadjNum_Ni,
               :szLocalAdjDate        :sLocalAdjDate_Ni,
               :dLocalBillConsAdjAmt  :sLocalBillConsAdjAmt_Ni,
               :szLocalMultiplier     :sLocalMultiplier_Ni;

        POSTORA;
        NoOfRows =sqlca.sqlerrd[2];


  
   for (i=0;i<NoOfRows;i++)
   {
    strcpy(szCadjNum,szLocalCadjNum[i]);
    strcpy(szAdjDate,szLocalAdjDate[i]);
    strcpy(szMultiplier,szLocalMultiplier[i]);
    dBillConsAdjAmt=dLocalBillConsAdjAmt[i];

     add(break_total,break_total,szLocalAdjBilledChg);
   add(taxt_break_total,taxt_break_total,szLocalAdjBilledChg);
   
   /*add(szGCurrChgsAndAdjs,szGCurrChgsAndAdjs,szLocalAdjBilledChg);
     RAM 02/feb/98
    */
   
   add(adjustments,adjustments,szLocalAdjBilledChg);

   add(adjustment_cons,adjustment_cons,szLocalAdjBilledChg);

   add(amount_due,amount_due,szLocalAdjBilledChg); 
   add(adjustment_total,adjustment_total,szLocalAdjBilledChg);

   PrintChgAdjDetail( CONS_ADJ_HEADER_TEXT_FORMAT, "", "" );

   EXEC SQL DECLARE ConsumAdjSteps CURSOR FOR
      SELECT utrsrat_rate_step_ind,
             utrsrat_uoms_code,
             utrrstp_consump_level,
             utrrstp_charge_amt
        FROM utrsrat,
             utrrstp
       WHERE utrrstp_srat_code = :szLocalSratCode      
         AND utrrstp_scat_code = :szLocalScatCode      
         AND utrrstp_temp_rate_ind = 'P'
         AND utrrstp_srat_code = utrsrat_srat_code
         AND utrrstp_scat_code = utrsrat_scat_code
         AND utrrstp_effect_date = utrsrat_effect_date
         AND utrrstp_temp_rate_ind = utrsrat_temp_rate_ind
         AND to_date(:szLocalChargeDate, 'DD-MON-YYYY')
             BETWEEN utrsrat_effect_date AND utrsrat_nchg_date
       ORDER BY utrrstp_step_num;

   EXEC SQL OPEN ConsumAdjSteps;
   POSTORA;

   for ( dConsumpLeft = dBillConsAdjAmt; dConsumpLeft != 0; ) {

      EXEC SQL
         FETCH ConsumAdjSteps
          INTO :szLocalRateStepInd :sLocalRateStepInd_Ni,
               :szLocalUomsCode    :sLocalUomsCode_Ni,
               :dLocalConsumpLevel :sLocalConsumpLevel_Ni,
               :szLocalStepCharge  :sLocalStepCharge_Ni;
      POSTORA;

      if ( NO_ROWS_FOUND)
         break;

      /*
       *  The inline conditions ( "x ? y : z" ) are used to print
       *  additional information for ramp rates (R,M).  These rates
       *  need to show "@ .000/KWH" instead of a specific charge,
       *  since ramp rates are (consump * step charge).
       */

      if ( ( strcmp( szLocalRateStepInd, "M" ) == 0 ) ||    /* Accum rates */
           ( strcmp( szLocalRateStepInd, "T" ) == 0 ) ) {
         if ( dBillConsAdjAmt >= dLocalConsumpLevel ) { /* Step 1..(n-1) */
            sprintf( szDetailLineText, CONS_ADJ_DETAIL_TEXT_FORMAT,
                     szAdjDate,
                     dConsumpLeft,
                     szLocalUomsCode,
                     ((szLocalRateStepInd[0] == 'M') ? "@" : ":"),
                     szLocalStepCharge,
                     ((szLocalRateStepInd[0] == 'M') ? "/" : ""),
                     ((szLocalRateStepInd[0] == 'M') ? szLocalUomsCode : "") );
            PrintChgAdjDetail( szDetailLineText, "", "" );
            dConsumpLeft -= dLocalConsumpLevel;
         }
         else {                                                  /* Last Step */
            sprintf( szDetailLineText, CONS_ADJ_DETAIL_TEXT_FORMAT,
                     szLocalAdjDate,
                     dConsumpLeft,
                     szLocalUomsCode,
                     ((szLocalRateStepInd[0] == 'M') ? "@" : ":"),
                     szLocalStepCharge,
                     ((szLocalRateStepInd[0] == 'M') ? "/" : ""),
                     ((szLocalRateStepInd[0] == 'M') ? szLocalUomsCode : "") );
            PrintChgAdjDetail( szDetailLineText, szLocalAdjBilledChg, "" );
            dConsumpLeft = 0;
         }
      }
      else if ( dBillConsAdjAmt < dLocalConsumpLevel ) {    /* Non-accum */
         sprintf( szDetailLineText, CONS_ADJ_DETAIL_TEXT_FORMAT,
                  szLocalAdjDate,
                  dConsumpLeft,
                  szLocalUomsCode,
                  ((szLocalRateStepInd[0] == 'R') ? "@" : ":"),
                  szLocalStepCharge,
                  ((szLocalRateStepInd[0] == 'R') ? "/" : ""),
                  ((szLocalRateStepInd[0] == 'R') ? szLocalUomsCode : "") );
         PrintChgAdjDetail( szDetailLineText, szLocalAdjBilledChg, "" );
         dConsumpLeft = 0;
      }
   } /* end for() */

  }   /*
    * Update the consumption-related monetary adjustments with the printed ind
    * and date.  This needs to be done here since these adjustments will not be
    * printed and updated in the normal adjustment loops in
    * PrintUnprintedBill() and PrintPrintedBill().
    */
   if (*sleep_wake_ind && ubtibil_type_ind[0] == 'D')  
      return;                                          

   update_uabadje();

}                                           /* end PrintConsumptionAdjustment */

/******************************************************************************/

static short PrintMiscCharge( void )
{
   EXEC SQL BEGIN DECLARE SECTION;
    CHAR81  szLocalText = "";
    CHAR20  TmpTotal    = "";
   EXEC SQL END DECLARE SECTION;


   /* print the open item detail */
   select_ubrrchs();           /* Mid-period rate changes */

   calculate_totals();

   
   if (sGPrintingOutsideAgencies == TRUE )
      return( 0 );

      if (strcmp (uabopen_origin,"UCADPST") == 0) 
   {
     GDocSeqNo= GDocSeqNo+1;
     strcpy(GDepText,szUtrsratBillPrintDesc); 
     sprintf(GDeposit,"%.2f",atof(uabopen_billed_chg));
     
     /*extract_Deposit();                   */
     Init_Deposit();
     Extract_BillDetail();
   }
   else if ( strcmp( uabopen_origin, "LOANP" ) == 0 ) {
      EXEC SQL
         SELECT uabloan_loan_type
           INTO :szLocalText:Ind_01
           FROM uabloan,
                uarloan
          WHERE uabloan_cust_code = :ucracct_cust_code
            AND uabloan_prem_code = :ucracct_prem_code
            AND uarloan_cust_code = uabloan_cust_code
            AND uarloan_prem_code = uabloan_prem_code
            AND uarloan_loan_num  = uabloan_loan_num
            AND uarloan_ar_trans_princ = :uabopen_ar_trans;
       POSTORA;
       GDocSeqNo= GDocSeqNo+1;
       strcpy(GLoanText,szLocalText); 
       sprintf(GLoan,"%.2f",atof(uabopen_billed_chg));
       
       /*extract_Loan();                      */
       Init_Loan();
       Extract_BillDetail();

   }
   else if ( strcmp( uabopen_origin, "LOANI" ) == 0 ) {
      EXEC SQL
         SELECT uabloan_loan_type
           INTO :szLocalText:Ind_01
           FROM uabloan,
                uarloan
          WHERE uabloan_cust_code = :ucracct_cust_code
            AND uabloan_prem_code = :ucracct_prem_code
            AND uarloan_cust_code = uabloan_cust_code
            AND uarloan_prem_code = uabloan_prem_code
            AND uarloan_loan_num  = uabloan_loan_num
            AND uarloan_ar_trans_interest = :uabopen_ar_trans;
      POSTORA;
      GDocSeqNo= GDocSeqNo+1;
      sprintf(GLoan,"%.2f",atof(uabopen_billed_chg));
      strcpy(GLoanText,szLocalText); 
      
      /*extract_Loan(); ram 30/jan/98        */
        Init_Loan();
        Extract_BillDetail();
   }
   
   else if (utrsrat_tax_ind[0] == 'T') {
      if (szUtrsratBillDetailInd[0] != 'Y') {
        
      GDocSeqNo = GDocSeqNo+1;
      strcpy(GTaxText,szLocalText);
      sprintf(GTax,"%.2f",atof(uabopen_billed_chg));
      
      /*extract_Tax(); ram 30/jan/98         */
        Init_Tax();
        Extract_BillDetail();

      }
      else
      {
       strcpy(szDetailLineText, szUtrsratBillPrintDesc);
       strcpy(szDetailLineAmount, uabopen_billed_chg);
       PrintSteps( PrintChgAdjDetail,
                 stPrevShis.szActionDate,
                 stCurrShis.szActionDate,
                 atol(stPrevShis.szReading),
                 atol(stCurrShis.szReading),
                 atol(stCurrShis.szDOS),
                 szDetailLineText,
                 szDetailLineAmount); 
      }
   }


  else if  ((strcmp( uabopen_origin, "UAPDELQ" ) == 0 ) ||
            (utrsrat_tax_ind[0] == 'P') )
   {

      if (szUtrsratBillDetailInd[0] != 'Y' || 
          (strcmp(uabopen_origin,"UAPDELQ")==0)) 
      {
      GDocSeqNo = GDocSeqNo+1;
      sprintf(GPenalty,"%.2f",atof(uabopen_billed_chg));
      strcpy(GPenText,"Penalty");
      
      /*extract_Penalty(); ram 30/jan/98     */
        Init_Penalty();
        Extract_BillDetail();
      }
     else
      {
       strcpy(szDetailLineText, szUtrsratBillPrintDesc);
       strcpy(szDetailLineAmount, uabopen_billed_chg);
       PrintSteps( PrintChgAdjDetail,
                 stPrevShis.szActionDate,
                 stCurrShis.szActionDate,
                 atol(stPrevShis.szReading),
                 atol(stCurrShis.szReading),
                 atol(stCurrShis.szDOS),
                 szDetailLineText,
                 szDetailLineAmount); 
      }
  }

  else if ((*uabopen_srat_code_source && *uabopen_scat_code_source)
      && (utrsrat_tax_ind[0] =='R')) 
    {
      strcpy(szDetailLineText, szUtrsratBillPrintDesc);
      strcpy(szDetailLineAmount, uabopen_billed_chg);
      PrintSteps( PrintChgAdjDetail,
                  stPrevShis.szActionDate,
                  stCurrShis.szActionDate,
                  atol(stPrevShis.szReading),
                  atol(stCurrShis.szReading),
                  atol(stCurrShis.szDOS),
                  szDetailLineText,
                  szDetailLineAmount); 
   }
  else
  {
    

         strcpy( szLocalText, szUtrsratBillPrintDesc );
         PrintChgAdjDetail(szLocalText,"", uabopen_billed_chg);
         strcpy(GMiscText,szLocalText);
         GDocSeqNo = GDocSeqNo+1;
         sprintf(GMisc,"%.2f",atof(uabopen_billed_chg));
         
         /*extract_Misc(); ram 30/jan/98        */
         Init_Misc();
         Extract_BillDetail();
   }

   return( 0 ); /* success */
}                                       /* end PrintMiscCharge() */

/******************************************************************************/

static void set_detail_page_limits(void)
{
   char szBuf[20];
   long lPageNo;
   long lAgencySectionsOnThisPage;

    tochar(szBuf, szGChgAdjPageNo, "99999");
    lPageNo = atol(szBuf);

    lAgencySectionsOnThisPage = ((lGObagCount+lGAdditionalSections) - ((lPageNo - 1) *2));
    NumberofSections=lAgencySectionsOnThisPage;

    if (lAgencySectionsOnThisPage < 1) {
       if (sGPrintingOutsideAgencies == TRUE ) {
          sGPrintFirstLogo = FALSE;
          sGPrintSecondLogo = TRUE;
          strcpy(szGChgAdjLineNo, FIELD_1_OBAG_SINGLE);
          sGLastDetailLine =  4;
       } else {
          strcpy(szGChgAdjLineNo, FIELD_1_CHARGES );
          sGLastDetailLine =  30;
       }
    } else if (lAgencySectionsOnThisPage == 1) {
          if (sGPrintingOutsideAgencies == TRUE ) {
             sGPrintFirstLogo = FALSE;
             sGPrintSecondLogo = TRUE;
             strcpy(szGChgAdjLineNo, FIELD_1_OBAG_SINGLE);
             sGLastDetailLine =  4;
          } else {
             strcpy(szGChgAdjLineNo, FIELD_1_CHARGES );
             sGLastDetailLine =  26;
          }
    } else {
       if (sGPrintingOutsideAgencies == TRUE ) {
          sGPrintFirstLogo = TRUE;
          sGPrintSecondLogo = TRUE;
          strcpy(szGChgAdjLineNo, FIELD_1_OBAG_MULTIPLE);
          sGLastDetailLine =  9;
       } else {
          strcpy(szGChgAdjLineNo, FIELD_1_CHARGES );
          sGLastDetailLine =  21;
       }
    }
}                                              /* end set_detail_page_limits */

/* ************************************************************************** */
/* Get the consumption history for a metered account.                         */
/* ************************************************************************** */

static void PrintServConsumption(char *pszCustCode,
                                 char *pszPremCode,
                                 char *pszServNum,
                                 char *pszScatCode,
                                 char *pszPresentDate,
                                 char *pszChrgCalcNum)
{
   EXEC SQL BEGIN DECLARE SECTION;
     NUMSTR szCustCode            = "";
     CHAR8  szPremCode            = "";
     NUMSTR szServNum             = "";
     CHAR5  szScatCode            = "";
     NUMSTR szChrgCalcNum         = "";
     CHAR5  szCurrUbbchstUomsCode = "";
     CHAR5  szPrevUbbchstUomsCode = "";
     CHAR36 szUtrstypDesc         = "";
     CHAR36 szPrevUtrstypDesc     = "";
     double dCurrentConsumption   = 0;
     double dPrevYearConsumption  = 0;
     CHAR12 szFirstDate           = "";
     CHAR12 szPrevYearDate        = "";
     CHAR12 szPresentDate         = "";
     CHAR9  szSpellPrevYear       = "";
     CHAR9  szSpellCurrYear       = "";

     CHAR30 szTmpMsg              = "";

     short  sInd_01;
     short  sInd_02;
     short  sInd_03;
     short  sInd_04;
     short  sInd_05;
     short  sInd_06;
     short  sInd_07;

     short  more                  = TRUE;

   EXEC SQL END DECLARE SECTION;

   if (!(*pszPresentDate))
      return;

   strcpy(szCustCode,    pszCustCode);
   strcpy(szPremCode,    pszPremCode);
   strcpy(szPresentDate, pszPresentDate);
   strcpy(szServNum,     pszServNum);
   strcpy(szScatCode,    pszScatCode);
   strcpy(szChrgCalcNum, pszChrgCalcNum);

   memset(szFirstDate, 0x00, sizeof(szFirstDate));
   sprintf(szFirstDate, "%2.2s/01/%2.2s", szPresentDate, szPresentDate + 6);

      EXEC SQL DECLARE ConsumHistory CURSOR FOR
            SELECT utrstyp_desc,
                   ubbchst_uoms_code,
                   nvl(sum(nvl(ubbchst_billed_consump, 0) +
                           nvl(ubbchst_billed_consump_adj, 0)
                          ) ,0),
                   TO_CHAR(TO_DATE(:szPresentDate, 'MM/DD/RR'),
                                      'Mon YYYY'),
                   TO_CHAR(ADD_MONTHS(TO_DATE(:szPresentDate, 'MM/DD/RR'), -12),
                        'DD-MON-YYYY'),
                   TO_CHAR(ADD_MONTHS(TO_DATE(:szPresentDate, 'MM/DD/RR'), -12),
                        'Mon YYYY')
              FROM ubbchst, utrstyp
             WHERE ubbchst_chrg_calc_num = :szChrgCalcNum
               AND ubbchst_styp_code = utrstyp_code (+)
          GROUP BY utrstyp_desc, ubbchst_uoms_code;

       EXEC SQL OPEN ConsumHistory;
    POSTORA;

    memset(szUtrstypDesc,          ' ',  sizeof(szUtrstypDesc));
    memset(szCurrUbbchstUomsCode,  ' ',  sizeof(szCurrUbbchstUomsCode));
    dCurrentConsumption = 0;
    memset(szSpellCurrYear,        ' ',  sizeof(szSpellCurrYear));
    memset(szPrevYearDate,         ' ',  sizeof(szPrevYearDate));
    memset(szSpellPrevYear,        ' ',  sizeof(szSpellPrevYear));

    EXEC SQL FETCH ConsumHistory
              INTO :szUtrstypDesc:sInd_02,
                   :szCurrUbbchstUomsCode:sInd_03,
                   :dCurrentConsumption:sInd_04,
                   :szSpellCurrYear:sInd_05,
                   :szPrevYearDate:sInd_06,
                   :szSpellPrevYear:sInd_07;
    POSTORA;


    if ( NO_ROWS_FOUND)
       return;
     /*  break; */

       if (strcmp(szGConsumptionLineNum, FIELD_1_CONSUMPTION_HISTORY) == 0) {
   
       add(szGConsumptionLineNum, szGConsumptionLineNum, "1");
       
       
    }

    sprintf(szFirstDate, "01-%s", szPrevYearDate + 3);

    EXEC SQL
         SELECT nvl(sum(nvl(ubbchst_billed_consump, 0) +
                    nvl(ubbchst_billed_consump_adj, 0)), 0),
                ubbchst_uoms_code
           INTO :dPrevYearConsumption:sInd_01,
                :szPrevUbbchstUomsCode:sInd_02
           FROM ubbchst
          WHERE ubbchst_chrg_calc_num IN
              ( SELECT urrshis_chrg_calc_num
                  FROM urrshis
                 WHERE urrshis_prem_code = :szPremCode
                   AND urrshis_serv_num  = :szServNum
                   AND urrshis_cust_code = :szCustCode
                   AND urrshis_scat_code = :szScatCode
                   AND urrshis_action_date
                       BETWEEN TO_DATE(:szFirstDate, 'DD-MON-YYYY')
                           AND LAST_DAY(TO_DATE(:szPrevYearDate, 'DD-MON-YYYY')))
       GROUP BY ubbchst_uoms_code;

       
    POSTORA;

    if ( sInd_01 == -1 )
       dPrevYearConsumption = 0;

    if ( sInd_02 == -1 )
       szPrevUbbchstUomsCode[0] = '\0';

    BPPrintField(session_id, billno, szGChgAdjPageNo,
                 szGConsumptionLineNum, szUtrstypDesc, "", "");
    add(szGConsumptionLineNum, szGConsumptionLineNum, "1");

    if ((dPrevYearConsumption == 0) || (NO_ROWS_FOUND))
       sprintf(szTmpMsg, CONS_HIST_DTL_TEXT_NA_FORMAT, szSpellPrevYear,
                                              "",
                                              "N/A");
    else
       sprintf(szTmpMsg, CONS_HIST_DTL_TEXT_PREV_FORMAT, szSpellPrevYear,
                                            dPrevYearConsumption,
                                            szPrevUbbchstUomsCode);

   
       sprintf(szTmpMsg, CONS_HIST_DTL_TEXT_CURR_FORMAT, szSpellCurrYear,
                                          dCurrentConsumption,
                                          szCurrUbbchstUomsCode);

       EXEC SQL CLOSE ConsumHistory;
    POSTORA;

}                                                 /* end PrintServConsumption */


static void UnMarkYs(char *pszCurBillInds, char *pszNextBillInds)
{
   short i=0;
   short sBinInds=0;

   /* below i+3 is to skip the first 3 cells which are
      not insert indicators and a maximum of 4 inserts
      can be specified for a bill hence i < 4 */

   for (i = 0; i < 4; i++) {
      if (pszCurBillInds[i+3] == 'Y')
         sBinInds++;
      if (sBinInds == 3) {
         if ( i != 3 )
            pszCurBillInds[i+3+1] = 'N';
         memset(pszNextBillInds+3, 'N', 4);
      }
   }

   if (sBinInds < 3) {
      for (i = 0; i < 4; i++) {
         if (pszNextBillInds[i+3] == 'Y')
            sBinInds++;
         if (sBinInds == 3)
            memset(pszNextBillInds+(i+3+1),'N', 4-(i+1));
      }
   }
}

/* ************************************************************************** */
/* uabopen foot for charges                                               */
/* ************************************************************************** */




static void uabopen_foot(void)
{
   /*
    *  Since security light charges are printed using "control break" logic,
    *  we must check to see if we need to print a final security light
    *  charge after all detail charges are printed.
    */

   if (  (*uabopen_chrg_calc_num && *non_metered_ind) &&
        ( strcmp(utvsrat_asvc_code, "SL") == 0 ) )
      PrintNonMeteredSvc();                       /* Calls PrintSecurityLight */
   if (ucrserv_num[0]!='\0')
     insert_service_total();

   if (*budgeted_service_ind) {
      if ( strcmp(budgeted_service_ind,"Y")!=0)  {
         if ((!*reprint_date_var) && ((!*sleep_wake_ind ||
             (*sleep_wake_ind && ubtibil_type_ind[0] == 'D'))))
            if( (strcmp(break_serv_num,uabopen_serv_num)!=0)||(uabopen_serv_num[0]=='\0'))
               update_budget();
      }
      else {
         if ( uabbudg_status_ind[0] == 'C' )
            if( (strcmp(break_serv_num,uabopen_serv_num)!=0)||(uabopen_serv_num[0]=='\0'))
               update_budget();
      }
   }


   if (*uobsysc_srat_code_rdup)
      check_rdup_msg();

}

                                                      /* end uabopen_foot */

  /*--------------------------------------------------------------------------*/
  /*   adjustment head, body, and foot.  Called from PrintUnprintedBill.      */
  /*--------------------------------------------------------------------------*/

/* ************************************************************************** */
/*   a d j u s t m e n t   h e a d                                            */
/* ************************************************************************** */

static void adjustment_head(void)
{
   strcpy( adjustments, "0" );
   adjustment_body();
}

/* ************************************************************************** */
/*   a d j u s t m e n t   b o d y                                            */
/* ************************************************************************** */

static void adjustment_body(void)
{
  add(adjustment_total,adjustment_total,uabadje_balance);  
   add(amount_due,amount_due,uabadje_balance);
  
   if ((*uabadje_billed_chg) && (*uabadje_budget_variance))
      subtract(amount_due,amount_due,uabadje_budget_variance);

   /*add(szGCurrChgsAndAdjs,szGCurrChgsAndAdjs,uabadje_balance); 02/feb/98 Ram */
   add(adjustments,adjustments,uabadje_balance);
   add(break_total,break_total,uabadje_balance);           
   add(taxt_break_total,taxt_break_total,uabadje_balance); 

  
  if (*sleep_wake_ind && ubtibil_type_ind[0] == 'D')
    return;

  update_uabadje();
     sprintf(GAdj,"%.2f",atof(uabadje_balance));
     GDocSeqNo = GDocSeqNo+1;
     
     
     /*extract_Adj(); ram 30/jan/98         */
       Init_Adjustment();
       Extract_BillDetail();
     
 }

/* ************************************************************************** */
/*   a d j u s t m e n t   f o o t                                            */
/* ************************************************************************** */

static void adjustment_foot(void)
{
 EXEC SQL BEGIN DECLARE SECTION;
  CHAR255 text;
 EXEC SQL END DECLARE SECTION;

  add(adjustments,adjustments,adjustment_cons);
 if (adjustments_found)
 {
 
   if ( NonOucAdj==0 )
   {
     sprintf(text, TOTAL_OUC_ADJUSTMENTS_LABEL, utvasvc_desc);
 
    PrintChgAdjDetail(text, adjustments,"");
   }
 }

}

/******************************************************************************/

static void PrintTotalsAndFillBlanks( void )
{
   int    i;
   int    j;
   NUMSTR szLastAgencyPageNum = "";
   NUMSTR szLocalLineNum      = "";

   EXEC SQL BEGIN DECLARE SECTION;
    NUMSTR szLocalPageNum      = "";
    NUMSTR lPage = "";
    CHAR2 szUtrbdgm_restart_ind ="";
    short sUtrbdgm_restart_ind_ni;
   EXEC SQL END DECLARE SECTION;



   /* if we had a budgeted service, print footnote explaining */
   /* '*' beside charges                                      */

   PrintChgAdjDetail( "", "", "" );
   
   PrintRateChangeMsg();                             
   PrintRecalcMsg();                                 

   strcpy(szLocalPageNum, szGChgAdjPageNo);

   i = (int) ceil((lGObagCount+lGAdditionalSections) / 2.0);
   i= sGLastAgencyPageNo;
   sprintf(szLastAgencyPageNum, "%d", i);

   
   do {
         while (compare(szGConsumptionLineNum, LAST_CONSUMPTION_LINE, LE)) {
          BPPrintField(session_id, billno, szGChgAdjPageNo, szGConsumptionLineNum, "", "", "");
          add(szGConsumptionLineNum, szGConsumptionLineNum, "1");
      }

      if (compare(szGChgAdjPageNo,szLocalPageNum,GT))
        { PrintBillHeaderSection(szGChgAdjPageNo);
    }

          while (no_of_detail_lines <= sGLastDetailLine)
            PrintChgAdjDetail("","","");

      if (compare(szGChgAdjPageNo, szLastAgencyPageNum, LE)) {
         strcpy(szGConsumptionLineNum, FIELD_1_CONSUMPTION_HISTORY);
         strcpy(szGChgAdjLineNo, FIELD_1_CHARGES);
         no_of_detail_lines = 1;
         add(szGChgAdjPageNo, szGChgAdjPageNo, "1");
      }

      if (compare(szGChgAdjPageNo, szLastAgencyPageNum, EQ)) {
         if ((lGObagCount+lGAdditionalSections) % 2 == 1 ) {
            sGLastDetailLine =  LAST_CHG_ADJ_DTL_LINE_1;
         } else
            sGLastDetailLine =  LAST_CHG_ADJ_DTL_LINE_2;
      }

   } while (compare(szGChgAdjPageNo, szLastAgencyPageNum, LE));


   strcpy( szGNumBillPages, szGChgAdjPageNo );
   strcpy( szGChgAdjPageNo, szLocalPageNum );

   add(amount_due,amount_due,total_due_charges);
   add(szGCurrChgsAndAdjs,szGCurrChgsAndAdjs,total_new_charges);

   strcpy(szGTotalAmountDue,amount_due);

   

   if (compare(szGChgAdjPageNo, szLastAgencyPageNum, LT))
      strcpy( szLocalPageNum, szLastAgencyPageNum);
   else
      strcpy( szLocalPageNum, szGChgAdjPageNo);


   PrintBillChgTotalSection(szLocalPageNum, PRINT_DATA);
   IsBudgeted=1;

   /* Bill Stub for page 1 is handled in print_(un)printed_bill() */

   if (compare(szLocalPageNum, "1", GT))
   {
     for (j=2;j<=atol(szLocalPageNum);j++)
   
    { sprintf(lPage,"%ld",j);

      PrintBillStubSection(lPage,PRINT_DATA);
       InsertSpecialMessages(lPage);
           EXEC SQL update ubrbill
              set ubrbill_text     = :szGUpdateAmt
            where ubrbill_sess_id  = :session_id
              and ubrbill_bill_num   = to_number(:billno)
              and ubrbill_line_num  = 148
              and ubrbill_page_num  < to_number(:lPage);
           POSTORA;

    }
   }


}                                             /* end PrintTotalsAndFillBlanks */

  /*--------------------------------------------------------------------------*/
  /*           Report line creation                                           */
  /*--------------------------------------------------------------------------*/

/* ************************************************************************** */
/* print the address lines                                                    */
/* ************************************************************************** */

static void PrintAddress(char *pszLineNum)
{
  char szTempStr[93];         
  CHAR80 szBarcodeLine="";
  int  addr_line_ctr=0;
  char  szCoapName[93];      
  char  szCoapName1[93];
  char  szCoapName2[93];
  char  szCoapName3[93];
  short FetchMode;           
  short CoapCtr;
  short sLinesPrinted=0;
  short Printed_line4=FALSE;

  strcpy( szCoapName1, null );
  strcpy( szCoapName2, null );
  strcpy( szCoapName3, null );

  if (strcmp(pszLineNum, FIELD_1_BARCODE) == 0) {
     BPPrintBarcodeZip(ubrrecp_zip_1_5, ubrrecp_zip_7_10, ubrrecp_delivery_point,
                        szBarcodeLine);
     setmode(M_COLLIT);
     prtstr(szBarcodeLine);
     setmode(M_NORMAL);
     newline();
     add(prev_line_num,prev_line_num,"1");
     sLinesPrinted++;
  }

/* clear the address lines */

  strcpy(address_line1_text,null);
  strcpy(address_line2_text,null);
  strcpy(address_line3_text,null);
  strcpy(address_line4_text,null);
  strcpy(address_line5_text,null);
  strcpy(address_line6_text,null);
  strcpy(address_line7_text,null);
  strcpy(address_line8_text,null);

/* load the address fields */

  strcpy(address_line1_text,ubrrecp_print_name);
  strcpy(address_line2_text,ubrrecp_dba);
  strcpy(address_line3_text,ubrrecp_street_line1);
  strcpy(address_line4_text,ubrrecp_street_address);
  strcpy(address_line5_text,ubrrecp_street_line2);
  strcpy(address_line6_text,ubrrecp_street_line3);
  if (*ubrrecp_utyp_code || *ubrrecp_unit) {
    sprintf(szTempStr,"%0.6s %0.6s",ubrrecp_utyp_code,ubrrecp_unit);
    strcpy(address_line7_text,szTempStr);
  }
  if (*ubrrecp_city || *ubrrecp_stat_code || *ubrrecp_zip_1_5 ||
   strcmp(gubinst_natn_code,ubrrecp_natn_code) != 0) {
    sprintf(szTempStr,"%0.20s %0.3s %0.5s",ubrrecp_city,ubrrecp_stat_code,
      ubrrecp_zip_1_5);
    if (*ubrrecp_zip_7_10) {
      if (strcmp(ubrrecp_natn_code,USA_NATION_CODE) == 0 ||
	  strcmp(ubrrecp_natn_code,"") == 0)
	strcat(szTempStr,"-");
      strcat(szTempStr,ubrrecp_zip_7_10);
    }
    if (strcmp(gubinst_natn_code,ubrrecp_natn_code) != 0) {
      strcat(szTempStr," ");
      strcat(szTempStr,ubrrecp_nation);
    }
    strcpy(address_line8_text,szTempStr);
  }
  if (*address_line1_text)
    addr_line_ctr++;
  if (*address_line2_text)
    addr_line_ctr++;
  if (*address_line3_text)
    addr_line_ctr++;
  if (*address_line4_text)
    addr_line_ctr++;
  if (*address_line5_text)
    addr_line_ctr++;
  if (*address_line6_text)
    addr_line_ctr++;
  if (*address_line7_text)
    addr_line_ctr++;
  if (*address_line8_text)
    addr_line_ctr++;

  /*------------------------------------------------------------------*
   * This loop will fetch coapplicant names.  It will fetch a         *
   * maximum of 3 coapplicant names.                                  *
   *------------------------------------------------------------------*/
  for ( FetchMode = FIRST_ROW,CoapCtr = addr_line_ctr ;
	CoapCtr < 6 ;
	CoapCtr++,FetchMode = NEXT_ROW )
  {
    if ( !FetchCoapNames( FetchMode, szCoapName ) ) break;
    if ( !*szCoapName1 )
      strcpy( szCoapName1, szCoapName );
    else if ( !*szCoapName2 )
      strcpy( szCoapName2, szCoapName );
    else if ( !*szCoapName3 )
      strcpy( szCoapName3, szCoapName );
  }
  /*------------------------------------------------------------------*
   * END OF LOOP                                                      *
   *------------------------------------------------------------------*/

  newline();
  if (*address_line1_text) {
    strcpy(szTempStr,"");
    strcat(szTempStr,address_line1_text);  /* Customer name */
    setmode(M_COLLIT);
    prtstr(szTempStr);
    setmode(M_NORMAL);
    newline();
    add(prev_line_num,prev_line_num,"1");
    sLinesPrinted++;
  }

    if (strcmp(pszLineNum, FIELD_1_BARCODE) == 0) {
  if (*address_line2_text) {
    strcpy(szTempStr,"");
    strcat(szTempStr,address_line2_text);
    setmode(M_COLLIT);
    prtstr(szTempStr);
    setmode(M_NORMAL);
    newline();
    add(prev_line_num,prev_line_num,"1");
    sLinesPrinted++;
  }
  }


  if (*address_line3_text) {
    strcpy(szTempStr,"");
    strcat(szTempStr,address_line3_text);
    setmode(M_COLLIT);
    prtstr(szTempStr);
    setmode(M_NORMAL);
    newline();
    add(prev_line_num,prev_line_num,"1");
    sLinesPrinted++;
  }

  if (*address_line4_text) {
    strcpy(szTempStr,"");
    strcat(szTempStr,address_line4_text);
    setmode(M_COLLIT);
    prtstr(szTempStr);
    setmode(M_NORMAL);
    newline();
    add(prev_line_num,prev_line_num,"1");
    sLinesPrinted++;
    Printed_line4 = TRUE;
  }

  
  if (strcmp(pszLineNum, FIELD_1_BARCODE) != 0) {
     if (Printed_line4==FALSE) {

     if (*address_line5_text ) {
       strcpy(szTempStr,"");
       strcat(szTempStr,address_line5_text);
       setmode(M_COLLIT);
       prtstr(szTempStr);
       setmode(M_NORMAL);
       newline();
       add(prev_line_num,prev_line_num,"1");
       sLinesPrinted++;
      }
     }
  }
  else
  {
  if (*address_line5_text ) { 
      if(Printed_line4==FALSE)
      {
       strcpy(szTempStr,"");
       strcat(szTempStr,address_line5_text);
       setmode(M_COLLIT);
       prtstr(szTempStr);
       setmode(M_NORMAL);
       newline();
       add(prev_line_num,prev_line_num,"1");
       sLinesPrinted++;
     }
    }
   }



 if (strcmp(pszLineNum, FIELD_1_BARCODE) == 0) {
  if (*address_line6_text && addr_line_ctr < 6) {
    strcpy(szTempStr,"");
    strcat(szTempStr,address_line6_text);
    setmode(M_COLLIT);
    prtstr(szTempStr);
    setmode(M_NORMAL);
    newline();
    add(prev_line_num,prev_line_num,"1");
    sLinesPrinted++;
  }

  if (*address_line7_text && addr_line_ctr < 6) {
    strcpy(szTempStr,"");
    strcat(szTempStr,address_line7_text);
    setmode(M_COLLIT);
    prtstr(szTempStr);
    setmode(M_NORMAL);
    newline();
    add(prev_line_num,prev_line_num,"1");
    sLinesPrinted++;
  }
 }


  if (*address_line8_text) {
    strcpy(szTempStr,"");
    strcat(szTempStr,address_line8_text);
    setmode(M_COLLIT);
    prtstr(szTempStr);
    setmode(M_NORMAL);
    newline();
    add(prev_line_num,prev_line_num,"1");
    sLinesPrinted++;
  }

  
  if (strcmp(pszLineNum, FIELD_1_BARCODE) == 0) {
    while (sLinesPrinted++ < 6) {
       setmode(M_COLLIT);
       prtstr("");
       setmode(M_NORMAL);
       newline();
    }
  } else {
     while (sLinesPrinted++ < 4) {
        setmode(M_COLLIT);
        prtstr("");
        setmode(M_NORMAL);
        newline();
     }
  }
}                                                         /* end PrintAddress */

/* ***************************************************** */
static void PrintPremAddress(char *pszLineNum)
{
  char szTempStr[93];        
  CHAR80 szBarcodeLine="";
  int  addr_line_ctr=0;
  char  szCoapName[93];      
  char  szCoapName1[93];
  char  szCoapName2[93];
  char  szCoapName3[93];
  short FetchMode;           
  short CoapCtr;
  short sLinesPrinted=0;

  strcpy( szCoapName1, null );
  strcpy( szCoapName2, null );
  strcpy( szCoapName3, null );


/* clear the address lines */

  strcpy(address_line1_text,null);
  strcpy(address_line2_text,null);
  strcpy(address_line3_text,null);
  strcpy(address_line4_text,null);
  strcpy(address_line5_text,null);
  strcpy(address_line6_text,null);
  strcpy(address_line7_text,null);
  strcpy(address_line8_text,null);

/* load the address fields */

  strcpy(address_line1_text,ubrrecp_print_name);
  
  strcpy(address_line4_text,ucbprem_street_address);
  if (*ucbprem_utyp_code || *ucbprem_unit) {
    sprintf(szTempStr,"%0.6s %0.6s",ucbprem_utyp_code,ucbprem_unit);
    strcpy(address_line7_text,szTempStr);
  }
  if (*ucbprem_city || *ucbprem_stat_code || *ucbprem_zipc_code ||
   strcmp(gubinst_natn_code,ucbprem_natn_code) != 0) {
    sprintf(szTempStr,"%0.20s %0.3s %0.5s",ucbprem_city,ucbprem_stat_code,
      ucbprem_zipc_code);

    if (strcmp(gubinst_natn_code,ucbprem_natn_code) != 0) {
      strcat(szTempStr," ");
      strcat(szTempStr,ucbprem_nation);
    }
    strcpy(address_line8_text,szTempStr);
  }
  if (*address_line1_text)
    addr_line_ctr++;
  if (*address_line2_text)
    addr_line_ctr++;
  if (*address_line3_text)
    addr_line_ctr++;
  if (*address_line4_text)
    addr_line_ctr++;
  if (*address_line5_text)
    addr_line_ctr++;
  if (*address_line6_text)
    addr_line_ctr++;
  if (*address_line7_text)
    addr_line_ctr++;
  if (*address_line8_text)
    addr_line_ctr++;

  /*------------------------------------------------------------------*
   * This loop will fetch coapplicant names.  It will fetch a         *
   * maximum of 3 coapplicant names.                                  *
   *------------------------------------------------------------------*/
  for ( FetchMode = FIRST_ROW,CoapCtr = addr_line_ctr ;
	CoapCtr < 6 ;
	CoapCtr++,FetchMode = NEXT_ROW )
  {
    if ( !FetchCoapNames( FetchMode, szCoapName ) ) break;
    if ( !*szCoapName1 )
      strcpy( szCoapName1, szCoapName );
    else if ( !*szCoapName2 )
      strcpy( szCoapName2, szCoapName );
    else if ( !*szCoapName3 )
      strcpy( szCoapName3, szCoapName );
  }
  /*------------------------------------------------------------------*
   * END OF LOOP                                                      *
   *------------------------------------------------------------------*/

  newline();
  if (*address_line1_text) {
    strcpy(szTempStr,"");
    strcat(szTempStr,address_line1_text);  /* Customer name */
    setmode(M_COLLIT);
    prtstr(szTempStr);
    setmode(M_NORMAL);
    newline();
    add(prev_line_num,prev_line_num,"1");
    sLinesPrinted++;
  }

  if (*address_line2_text) {
    strcpy(szTempStr,"");
    strcat(szTempStr,address_line2_text);
    setmode(M_COLLIT);
    prtstr(szTempStr);
    setmode(M_NORMAL);
    newline();
    add(prev_line_num,prev_line_num,"1");
    sLinesPrinted++;
  }

  if (*address_line3_text) {
    strcpy(szTempStr,"");
    strcat(szTempStr,address_line3_text);
    setmode(M_COLLIT);
    prtstr(szTempStr);
    setmode(M_NORMAL);
    newline();
    add(prev_line_num,prev_line_num,"1");
    sLinesPrinted++;
  }

  if (*address_line4_text) {
    strcpy(szTempStr,"");
    strcat(szTempStr,address_line4_text);
    setmode(M_COLLIT);
    prtstr(szTempStr);
    setmode(M_NORMAL);
    newline();
    add(prev_line_num,prev_line_num,"1");
    sLinesPrinted++;
  }

    if (*address_line6_text && addr_line_ctr < 6) {
    strcpy(szTempStr,"");
    strcat(szTempStr,address_line6_text);
    setmode(M_COLLIT);
    prtstr(szTempStr);
    setmode(M_NORMAL);
    newline();
    add(prev_line_num,prev_line_num,"1");
    sLinesPrinted++;
  }

  if (*address_line7_text && addr_line_ctr < 6) {
    strcpy(szTempStr,"");
    strcat(szTempStr,address_line7_text);
    setmode(M_COLLIT);
    prtstr(szTempStr);
    setmode(M_NORMAL);
    newline();
    add(prev_line_num,prev_line_num,"1");
    sLinesPrinted++;
  }

  if (*address_line8_text) {
    strcpy(szTempStr,"");
    strcat(szTempStr,address_line8_text);  /* City/State/ZIP */
    setmode(M_COLLIT);
    prtstr(szTempStr);
    setmode(M_NORMAL);
    newline();
    add(prev_line_num,prev_line_num,"1");
    sLinesPrinted++;
  }

     while (sLinesPrinted++ < 4) {
        setmode(M_COLLIT);
        prtstr("");
        setmode(M_NORMAL);
        newline();
     }
}                                                         /* end PrintPremAddress */

/* ************************************************************************** */
/* print budget line                                                          */
/* ************************************************************************** */

static void PrintBudgetSummary( void )
{
   EXEC SQL BEGIN DECLARE SECTION;
      CHAR7  szLocalMonYY   = "";
      NUMSTR szLocalAmount1 = "";
      NUMSTR szLocalAmount2 = "";
   EXEC SQL END   DECLARE SECTION;

   char szLocalDetailText[81] = "";
   char szTempStr[81]         = "";


   select_budget_totals(FIRST_ROW);

   memset(szGTotalAmountDue, 0x00, sizeof(szGTotalAmountDue));
   EXEC SQL
      SELECT TO_CHAR( TO_DATE( :break_charge_date, 'DD-MON-YYYY' ), 'Mon YY' )
        INTO :szLocalMonYY :Ind_01
        FROM SYS.DUAL;
   POSTORA;

   strcpy( szGBudgetGridPageNum, szGChgAdjPageNo );
   sprintf( szTempStr, "%d", no_of_detail_lines-1 );
   tochar( szGBudgetGridLineNum, szTempStr, "99");

   sprintf( szLocalDetailText, BUDGET_GRID_HEADER_2_FORMAT,
                               szLocalMonYY );
   tochar( szLocalAmount1, mtd_actual_charges, BUDGET_AMOUNT_FORMAT );
   tochar( szLocalAmount2, ytd_actual_charges, BUDGET_AMOUNT_FORMAT );
   sprintf( szLocalDetailText, BUDGET_GRID_DETAIL_1_FORMAT,
                               szLocalAmount1,
                               szLocalAmount2 );
   tochar( szLocalAmount1, mtd_budget_charges, BUDGET_AMOUNT_FORMAT );
   tochar( szLocalAmount2, ytd_budget_charges, BUDGET_AMOUNT_FORMAT );
   
   sprintf( szLocalDetailText, BUDGET_GRID_DETAIL_2_FORMAT,
                               szLocalAmount1,
                               szLocalAmount2 );
   
   tochar( szLocalAmount1, mtd_budget_variance, BUDGET_AMOUNT_FORMAT );
   tochar( szLocalAmount2, ytd_budget_variance, BUDGET_AMOUNT_FORMAT );
   sprintf( szLocalDetailText, BUDGET_GRID_DETAIL_3_FORMAT,
                               szLocalAmount1,
                               szLocalAmount2 );
   
   strcpy(szGTotalAmountDue, "0");
 }                                                   /* end PrintBudgetSummary */


static void PrintAccountNumber(char *pszPage,char *pszLine)
{
   EXEC SQL BEGIN DECLARE SECTION;
      CHAR255 szLocalText = "";
      NUMSTR  szLocalLine = "";
      NUMSTR  szLocalPage = "";
   EXEC SQL END DECLARE SECTION;

   strcpy(szLocalLine, pszLine);
   strcpy(szLocalPage, pszPage);

   DebugMsg(ucracct_cust_code, ucracct_prem_code, billno, pageno, lineno, session_id, __LINE__);

   if (strcmp(pszLine, FIELD_1_ACCOUNT_NUM) == 0) {
        BPPrintField(session_id, billno, szLocalPage, szLocalLine,
                     "Account No. -", "", "");
        add(szLocalLine, szLocalLine, "1");
   }

   EXEC SQL
      SELECT LPAD(to_char(TO_NUMBER(:ucracct_cust_code)),9,'0') ||'-'||
             LPAD(:ucracct_prem_code,7,'0')
        INTO :szLocalText:Ind_01
        FROM SYS.DUAL;
   POSTORA;

   BPPrintField(session_id, billno, szLocalPage, szLocalLine,
                szLocalText, "", "");
}                                        /* end PrintAccountNumber */


static void PrintPreviousBalance(char *pszPage,char *pszLineNum)
{
   EXEC SQL BEGIN DECLARE SECTION;
      CHAR255 szLocalText = "";
      NUMSTR  szLocalLine = "";
      NUMSTR  szLocalPage = "";
   EXEC SQL END DECLARE SECTION;

   strcpy(szLocalLine, pszLineNum);
   strcpy(szLocalPage, pszPage);

   DebugMsg(ucracct_cust_code, ucracct_prem_code, billno, pageno, lineno, session_id, __LINE__);
   EXEC SQL
      SELECT LPAD(DECODE(:szLocalLine, '147', '$','')||
                REPLACE(TO_CHAR(NVL(TO_NUMBER(:szGPastDueTotal),0),
                     '99,999,999.00MI'), '-', 'CR'),14)
        INTO :szLocalText:Ind_01
        FROM SYS.DUAL;
   POSTORA;

      if (atof(szGPastDueTotal) < 0)
         strcpy(szLocalText, " ");
   BPPrintField(session_id, billno, szLocalPage, szLocalLine,
                szLocalText, "", "");
}                                                 /* end PrintPreviousBalance */

/* ************************************************************************** */
/* insert line 17 into ubrbill collector table                                */
/* ************************************************************************** */

static void PrintCurrentAmountDue(char *pszPage)
{
   EXEC SQL BEGIN DECLARE SECTION;
      CHAR255 szLocalText = "";
      NUMSTR  szLocalPage = "";
      NUMSTR  szLocalAmount="0";

   EXEC SQL END DECLARE SECTION;
   strcpy(szLocalPage,pszPage);

   DebugMsg(ucracct_cust_code, ucracct_prem_code, billno, pageno, lineno, session_id, __LINE__);
   if (compare( szGPastDueTotal,"0",GT))
      subtract(szLocalAmount,szGTotalAmountDue,szGPastDueTotal);
   else
      strcpy(szLocalAmount,szGTotalAmountDue);

   if (compare( szLocalAmount, "0", GT)) {

      EXEC SQL
         SELECT decode(:active_draft,1,
   	             NULL,
   	             REPLACE(NVL(LPAD(TO_CHAR(TO_NUMBER(:szLocalAmount)
                    ,'$99,999,999.00MI'),14),0), '-', 'CR'))
           INTO :szLocalText:Ind_01
           FROM SYS.DUAL;
      POSTORA;
   }

   BPPrintField(session_id, billno, szLocalPage, FIELD_1_CURRENT_AMT_DUE,
                szLocalText, "", "");

   strcpy(szGUpdateAmt,szLocalText);

}                                                /* end PrintCurrentAmountDue */

/******************************************************************************/

static void PrintServiceAddress(void)
{

   BPPrintField(session_id, billno, szGChgAdjPageNo, FIELD_1_SERVICE_ADDRESS,
                "Service Address -", "", "");
   GetAddress();

   BPPrintField(session_id, billno, szGChgAdjPageNo, FIELD_1_SERVICE_ADDRESS_2,
                szAddress, "", "");
   
}                                                  /* end PrintServiceAddress */
/* ******************************************************** */
static void GetAddress(void)
{
   EXEC SQL BEGIN DECLARE SECTION;
      CHAR255 szLocalText = "";

   EXEC SQL END DECLARE SECTION;

   DebugMsg(ucracct_cust_code, ucracct_prem_code, billno, pageno, lineno, session_id, __LINE__);

   EXEC SQL
      SELECT RPAD(SUBSTR (
                DECODE(ucbprem_street_number, '','',ucbprem_street_number  || ' ') ||
                DECODE(ucbprem_pdir_code_pre, '','',ucbprem_pdir_code_pre  || ' ') ||
                DECODE(ucbprem_street_name,   '','',ucbprem_street_name    || ' ') ||
                DECODE(ucbprem_ssfx_code,     '','',ucbprem_ssfx_code      || ' ') ||
                DECODE(ucbprem_pdir_code_post,'','',ucbprem_pdir_code_post || ' ') ||
                DECODE(ucbprem_utyp_code,     '','',ucbprem_utyp_code      || ' ') ||
                ucbprem_unit,1,20),20),
                decode(ucbprem_street_number, '', '', ucbprem_street_number || ' ')
         		 || decode(ucbprem_pdir_code_pre, '', '',
         			ucbprem_pdir_code_pre || ' ')
         		 || ucbprem_street_name
         		 || decode(ucbprem_ssfx_code, '', '', ' ' || ucbprem_ssfx_code)
         		 || decode(ucbprem_pdir_code_post, '', '',
         			' ' || ucbprem_pdir_code_post),
               	ucbprem_street_number,
               	ucbprem_pdir_code_pre,
               	ucbprem_street_name,
               	ucbprem_ssfx_code,
               	ucbprem_pdir_code_post,
               	ucbprem_utyp_code,
               	ucbprem_unit,
               	ucbprem_city,
               	ucbprem_zipc_code,
               	ucbprem_delivery_point,
               	ucbprem_car_rt,
               	ucbprem_stat_code_addr,
               	ucbprem_natn_code,
                  stvnatn_nation
              INTO :szLocalText:Ind_01,
              ucbprem_street_address  :Ind_02,
              ucbprem_street_number   :Ind_03,
              ucbprem_pdir_code_pre   :Ind_04,
              ucbprem_street_name     :Ind_05,
              ucbprem_ssfx_code       :Ind_06,
              ucbprem_pdir_code_post  :Ind_07,
              ucbprem_utyp_code       :Ind_08,
              ucbprem_unit            :Ind_09,
              ucbprem_city            :Ind_10,
              ucbprem_zipc_code       :Ind_11,
              ucbprem_delivery_point  :Ind_12,
              ucbprem_car_rt          :Ind_13,
              ucbprem_stat_code       :Ind_14,
              ucbprem_natn_code       :Ind_15,
              ucbprem_nation          :Ind_16

              FROM ucbprem,
                   stvnatn
             WHERE ucbprem_code    = :ucracct_prem_code
              and	 stvnatn_code(+) = ucbprem_natn_code;

   POSTORA;
   strcpy(szAddress,szLocalText);
}                                                  /* end GetAddress */

/* ************************************************************************** */
/* print detail lines (meter readings, consumption, etc)                      */
/* ************************************************************************** */
static void PrintChgAdjDetail(char *pszChgAdjText,
                              char *pszChgAdjAmount,
                              char *pszChgAdjTotal)
{
  CHAR255 szLocalText = "";
  CHAR20  TempAmount  = "";
  int i;

  /* Citizens - keep track of no of details lines */
  check_detail_count();
  }                                                    /* end PrintChgAdjDetail */

/* ************************************************************************** */
/* print detail lines adjustments                                             */
/* ************************************************************************** */

static void PrintDetailLineAdjustments(void)
{
   EXEC SQL BEGIN DECLARE SECTION;
      CHAR255 szLocalText   = "";
      NUMSTR  szLocalAmount = "";
      short   BudInd        = IsBudgeted;
   EXEC SQL END   DECLARE SECTION;

   DebugMsg(ucracct_cust_code, ucracct_prem_code, billno, 
            szGChgAdjPageNo, szGChgAdjLineNo, session_id, __LINE__);
   EXEC SQL
      SELECT DECODE(utradjm_desc,
                NULL, 'Miscellaneous Adjustment           ',
                utradjm_desc),
               :uabadje_balance
          INTO :szLocalText   :Ind_01,
             :szLocalAmount :Ind_02
        FROM utradjm
       WHERE utradjm_code = :uabadje_adjm_code;
   POSTORA;

   if (NonOucAdj!=1) {
     PrintChgAdjDetail( szLocalText, szLocalAmount, "" );
   }

}                                        /* end PrintDetailLineAdjustments */

/* ************************************************************************** */
/* print roundup total for a year                                             */
/* ************************************************************************** */

static void PrintRoundUpYear(void)
{
   EXEC SQL BEGIN DECLARE SECTION;
      CHAR255 szLocalText   = "";
   EXEC SQL END   DECLARE SECTION;


}                                                     /* end PrintRoundUpYear */

/* ************************************************************************** */
/* print deposit installment line                                             */
/* ************************************************************************** */



static int select_ubrrchs(void) /* Mid-period rate changes */
{
   EXEC SQL BEGIN DECLARE SECTION;
      NUMSTR szLocalDOS         = "";
      NUMSTR szLocalConsumption = "";
   EXEC SQL END   DECLARE SECTION;

 EXEC SQL
   SELECT  ubrrchs_dos,
           ubrrchs_consumption
     INTO :szLocalDOS         :Ind_01,
          :szLocalConsumption :Ind_02
     FROM  ubrrchs
    WHERE  ubrrchs_cust_code   = TO_NUMBER(:ucracct_cust_code)
      AND  ubrrchs_prem_code   = :ucracct_prem_code
      AND  ubrrchs_charge_date = TO_DATE(:uabopen_charge_date, 'DD-MON-YYYY')
      AND  ubrrchs_serv_num    = TO_NUMBER(:uabopen_serv_num)
      AND  ubrrchs_ar_trans    = TO_NUMBER(:uabopen_ar_trans);
 POSTORA;

 if(sqlca.sqlcode == 0) {
    strcpy( stCurrShis.szDOS,         szLocalDOS );
    strcpy( stCurrShis.szConsumption, szLocalConsumption );
    return(TRUE);
 }
 else
    return(FALSE);
}

/******************************************************************************/

static void PrintRateChangeMsg(void) 
{
   DebugMsg(ucracct_cust_code, ucracct_prem_code, billno,
             szGChgAdjPageNo, szGChgAdjLineNo, session_id, __LINE__);
   PrintChgAdjDetail( RATE_CHANGE_LEGEND_FORMAT, "", "" );
}           


static void PrintRecalcMsg(void)
{
   DebugMsg(ucracct_cust_code, ucracct_prem_code, billno,
             szGChgAdjPageNo, szGChgAdjLineNo, session_id, __LINE__);
   PrintChgAdjDetail( RECALC_OF_EST_LEGEND_FORMAT, "", "" );
}

/******************************************************************************/

static void DebugMsg( NUMSTR  nsCustCode,
                      char   *pszPremCode,
                      NUMSTR  nsBillNo,
                      NUMSTR  nsPageNo,
                      NUMSTR  nsLineNo,
                      int     iSessionID,
                      long    lLine)
{
   EXEC SQL BEGIN DECLARE SECTION;
      CHAR23 szLocalDateTime = "";
   EXEC SQL END   DECLARE SECTION;

#ifdef DISPLAY_DEBUG
   EXEC SQL
      SELECT TO_CHAR( SYSDATE, 'DD-MON-YYYY HH24:MI:SS' )
        INTO :szLocalDateTime :Ind_01
        FROM SYS.DUAL;
   POSTORA;

   printf("time: %s cust: %d  prem: %s  bill#: %d  pg#: %d  ln#: %5.5d  sess: %d  .pcln#: %ld\n",
          szLocalDateTime,
          nsCustCode,
          pszPremCode,
          atoi(nsBillNo),
          atoi(nsPageNo),
          atoi(nsLineNo),
          iSessionID,
          lLine);
#endif
}

/* ************************************************************************** */
/* increment page no if printing multi-page bill                              */
/* New function for citizens bill print                                       */
/* ************************************************************************** */
static void increment_page_no(void)
{
   no_of_detail_lines = 1;
   no_of_agency_lines = 1;
   strcpy(multi_page_ind,"Y");

   add(szGChgAdjPageNo,szGChgAdjPageNo,"1");

   set_detail_page_limits();

   strcpy( szGConsumptionLineNum, FIELD_1_CONSUMPTION_HISTORY );
   strcpy( szGBudgetGridLineNum, "" );

   LastPage=atoi(szGChgAdjPageNo);
}

/******************************************************************************
 *                                                                            *
 *   Function : PrintSteps                                                    *
 *                                                                            *
 *   Purpose  : Checks if detail charges exist and their sum is equal to      *
 *              uabopen_billed_chg.  If so it calls PrintStepDetail else      *
 *              it calls function passed to it to print summary charge line.  *
 *                                                                            *
 *   Params   : DetailLine  - Function to call to print summary charge line if*
 *                            the sum of the detail charges does not equal    *
 *                            uabopen_billed_chg or the detail charges have   *
 *                            been purged.                                    *
 *                                                                            *
 *              pszPrevDate - Previous reading date to print with the         *
 *                            detail charge lines.                            *
 *                                                                            *
 *              pszPresDate - Present reading date to print with the          *
 *                            detail charge lines.                            *
 *                                                                            *
 *              lPrevRead   - Previous reading to print with detail charge    *
 *                            lines.                                          *
 *                                                                            *
 *              lPresRead   - Present reading to print with detail charge     *
 *                            lines.                                          *
 *                                                                            *
 *              lDOS        - Days of service to print with detail charge     *
 *                            lines.                                          *
 *                                                                            *
 *   Returns  : No Value                                                      *
 *                                                                            *
 *  
 *****************************************************************************/
static void PrintSteps(void (*DetailLine)( char *, char *, char *),
		       char * pszPrevDate,
		       char * pszPresDate,
		       long lPrevRead,
		       long lPresRead,
		       long lDOS,
             char *pszDetailLineText,
             char *pszDetailLineAmount)
{
  EXEC SQL BEGIN DECLARE SECTION;
    static double dSumDetailCharges = 0.0;
    static short  sSumDetailCharges_Ni;
    static NUMSTR old_step_no="";
  EXEC SQL END   DECLARE SECTION;

  char szLocalText[81] = "";


  DebugMsg(ucracct_cust_code, ucracct_prem_code, billno, szGChgAdjPageNo, szGChgAdjLineNo, session_id, __LINE__);

  EXEC SQL
    SELECT round(sum(uardbil_step_bill_amt),2)
      INTO :dSumDetailCharges  :sSumDetailCharges_Ni
      FROM uardbil
     WHERE uardbil_ar_trans = :uabopen_ar_trans;
   POSTORA;


   if ((szUtrsratBillDetailInd[0] == 'Y') &&
      (ROWS_FOUND) &&
      (sGPrintingOutsideAgencies == FALSE )) 
        {
    PrintStepDetail(pszPrevDate,pszPresDate,lPrevRead,lPresRead,lDOS);
  }
  else
  {


    sprintf(szLineAmount,"%lf",dSumOUCSubordCharges);
    sprintf(szVarianceAmount,"%lf",dSumOUCSubordVariance);


    add(pszDetailLineAmount,pszDetailLineAmount,szLineAmount);
    add(uabopen_billed_chg,uabopen_billed_chg,szLineAmount);
    add(uabopen_budget_variance,uabopen_budget_variance,szVarianceAmount);
    

   
    /* Docu logic to insert bill details */
                /*RAM 02-apr-1998 */
                if(*(stCurrShis.szActionDate))
                {
                strcpy(GPresentDate,stCurrShis.szActionDate);
                strcpy(GDos,stCurrShis.szDOS);
                }
                /*RAM 02-apr-1998 */


          if (!((*uabopen_srat_code_source) && (*uabopen_scat_code_source)) 
              && utrsrat_tax_ind[0] =='R')
                 
           {
            if ((First_Primary) || (strcmp(ServiceNo,break_serv_num) != 0))
             {
                GDocSeqNo=GDocSeqNo+1;
                IncludeWeather(); /*Weather */
                Init_ServHead();
                /*extract_servhead(); ram 05/feb/1998 */
                Extract_BillDetail();
                strcpy(ServiceNo,break_serv_num);
                First_Primary=FALSE;
             }
                dGPrimaryAmt = atof(pszDetailLineAmount);
                dGPrimaryStep = 0;
                dGConsumption = 0;
                GDocSeqNo = GDocSeqNo+1;
                  /***************************************/
                  /* extract_PrimaryRate(); RAM 30/jan/98 */
                  Init_PrimaryRate();
                  Extract_BillDetail();

                  /***************************************/
           }
           if (utrsrat_tax_ind[0] == 'T') {
             dGTaxStep  = 0;
             dGConsumption = 0;
             GDocSeqNo = GDocSeqNo+1;
             strcpy(GTaxText,szDetailLineText); 
             sprintf(GTax,"%.2f",atof(pszDetailLineAmount));
             /***************************************/
             /*extract_Tax(); ram 30/jan/98         */
             Init_Tax();
             Extract_BillDetail();
             /***************************************/
          }

          if (utrsrat_tax_ind[0] == 'P') {
             dGPenaltyStep  = 0;
             dGConsumption = 0;
             GDocSeqNo = GDocSeqNo+1;
             sprintf(GPenText,szDetailLineText);
             sprintf(GPenalty,"%.2f",atof(pszDetailLineAmount));
             strcpy(GPenText,"Penalty");
             /***************************************/
             /*extract_Penalty(); ram 30/jan/98     */
               Init_Penalty();
               Extract_BillDetail();
             /***************************************/
          }
         
          if (((*uabopen_srat_code_source) && (*uabopen_scat_code_source)) &&
             (utrsrat_tax_ind[0] == 'R'))
          {
             dGSubordAmt = atof(pszDetailLineAmount);
             dGSubordStep = 0;
             dGConsumption = 0;
             GDocSeqNo = GDocSeqNo+1;
             
             /***************************************/
             /*extract_SubordRate(); ram 30/jan/98  */
             Init_SubordRate();
             Extract_BillDetail();
             /***************************************/
          }
          if (
              (strcmp(ucrserv_styp_code,prev_styp_code)!=0) )
             DetailLine(pszDetailLineText, pszDetailLineAmount, "");
          else
             add(pszDetailLineAmount,pszDetailLineAmount,uabopen_billed_chg);
          strcpy(old_step_no,szStepNo);
          *szStepNo = '1';
          strcpy(szStepNo,old_step_no);
         


  }
  
}

/******************************************************************************
 *                                                                            *
 *   Function : PrintStepDetail                                               *
 *                                                                            *
 *   Purpose  : If the sum of step charges = uabopen_billed_chg then this     *
 *              function is called to print the detail charges.               *
 *                                                                            *
 *   Params   : pszPrevDate - Previous reading date to print with the         *
 *                            detail charge lines.                            *
 *                                                                            *
 *              pszPresDate - Present reading date to print with the          *
 *                            detail charge lines.                            *
 *                                                                            *
 *              lPrevRead   - Previous reading to print with detail charge    *
 *                            lines.                                          *
 *                                                                            *
 *              lPresRead   - Present reading to print with detail charge     *
 *                            lines.                                          *
 *                                                                            *
 *              lDOS        - Days of service to print with detail charge     *
 *                            lines.                                          *
 *****************************************************************************/
static void PrintStepDetail(char * pszPrevDate,
			    char * pszPresDate,
			    long lPrevRead,
			    long lPresRead,
			    long lDOS)
{
  short  bLastFetch      = FALSE;
  int    iRowsFetched    = 0;
  int    iRowsLeft       = 0;
  int    i               = 0;
  int    j               = 0;
  short  bFirstLine      = 0;
  char   szBpDesc[81]    = "";
  char   szReadDates[81] = "";
  NUMSTR szLocalAmount   = "";
  NUMSTR szLocalTotal    = "";

  EXEC SQL BEGIN DECLARE SECTION;
    static CHAR2  szUardbilBaseTypeInd[10];
    static CHAR5  szUardbilCnszCode[10];
    static NUMSTR nszUardbilFromStep[10];
    static NUMSTR nszUardbilToStep[10];
    static double dUardbilStepCharge[10];
    static double dUardbilConsump[10];
    static double dUardbilStepBillAmt[10];
    static int    iUardbilBpSeqNum[10];
    static double dTotalStepAmt[10];
    double dSumOUCSubordRemain     = 0;
    double dUabopenBilledChg       = 0;
    double dBaseCharge             = 0;
    double dSubordStepFactor       = 0;
    double dStepSubordCharge       = 0;
    NUMSTR szStepSubordCharge      = "";
    static short  sUardbilBaseTypeInd_Ni[10];
    static short  sUardbilCnszCode_Ni[10];
    static short  sUardbilFromStep_Ni[10];
    static short  sUardbilToStep_Ni[10];
    static short  sUardbilStepCharge_Ni[10];
    static short  sUardbilConsump_Ni[10];
    static short  sUardbilStepBillAmt_Ni[10];
    static short  sUardbilBpSeqNum_Ni[10];
    static short  sTotalStepAmt_Ni[10];
    short  sBaseCharge_Ni          = 0;
  EXEC SQL END   DECLARE SECTION;

  for (j=0;j<10;j++) {
     strcpy(szUardbilBaseTypeInd[j],"");
     strcpy(szUardbilCnszCode[j],"");
     strcpy(nszUardbilFromStep[j],"");
     strcpy(nszUardbilToStep[j],"");
     dUardbilStepCharge[j]= 0;
     dUardbilConsump[j]= 0;
     dUardbilStepBillAmt[j]= 0;
     iUardbilBpSeqNum[j] = 0;
     dTotalStepAmt[j] = 0;

  }

  DebugMsg(ucracct_cust_code, ucracct_prem_code, billno,
               szGChgAdjPageNo, szGChgAdjLineNo, session_id, __LINE__);

  EXEC SQL DECLARE UardbilCursor CURSOR FOR
    SELECT uardbil_base_type_ind,
	   uardbil_cnsz_code,
	   uardbil_from_step,
	   uardbil_to_step,
	   uardbil_step_charge,
	   uardbil_consump,
	   uardbil_step_bill_amt,
	   uardbil_bp_seq_num,
	   (uardbil_consump * uardbil_step_charge)
    FROM uardbil
    WHERE uardbil_ar_trans =  :uabopen_ar_trans
   ORDER BY uardbil_base_type_ind desc, uardbil_bp_seq_num;


   EXEC SQL DECLARE UardbilBaseCursor CURSOR FOR
    SELECT NVL( uardbil_step_bill_amt, 0 )
      FROM uardbil
     WHERE uardbil_ar_trans = :uabopen_ar_trans
       AND uardbil_base_type_ind IN ( '1', '2' );

     sprintf(szVarianceAmount,"%lf",dSumOUCSubordVariance);
     add(uabopen_budget_variance,uabopen_budget_variance,szVarianceAmount);



     dSumOUCSubordRemain = dSumOUCSubordCharges;


     EXEC SQL OPEN UardbilBaseCursor;
     POSTORA;

     EXEC SQL FETCH UardbilBaseCursor
      INTO :dBaseCharge :sBaseCharge_Ni;
     POSTORA;

     EXEC SQL CLOSE UardbilBaseCursor;
     POSTORA;

  EXEC SQL OPEN UardbilCursor;
  POSTORA;
  for(bFirstLine = TRUE;;)
  {
    if (iRowsLeft == 0)
    {
      if (bLastFetch) break;
      else
      {
         EXEC SQL FETCH UardbilCursor INTO
           :szUardbilBaseTypeInd  :sUardbilBaseTypeInd_Ni,
           :szUardbilCnszCode     :sUardbilCnszCode_Ni,
           :nszUardbilFromStep    :sUardbilFromStep_Ni,
           :nszUardbilToStep      :sUardbilToStep_Ni,
           :dUardbilStepCharge    :sUardbilStepCharge_Ni,
           :dUardbilConsump       :sUardbilConsump_Ni,
           :dUardbilStepBillAmt   :sUardbilStepBillAmt_Ni,
           :iUardbilBpSeqNum      :sUardbilBpSeqNum_Ni,
           :dTotalStepAmt        :sTotalStepAmt_Ni;
         POSTORA;
         if (NO_ROWS_FOUND)
           bLastFetch = TRUE;
         iRowsLeft = sqlca.sqlerrd[2] - iRowsFetched;
         if (iRowsLeft == 0) break;
         iRowsFetched = sqlca.sqlerrd[2];
         i = 0;
         iRowsLeft--;
      }
    }
    else
    {
      i++;
      iRowsLeft--;
    }

    strncpy(szReadDates,pszPrevDate,5);
    szReadDates[5] = '\0';
    strcat(szReadDates,"-");
    strncat(szReadDates,pszPresDate,5);
    szReadDates[13] = '\0';

    if (szUardbilBaseTypeInd[i][0] != 'S') {
      if ( ( *(stCurrShis.szMultiplier) ) &&
           ( compare( stCurrShis.szMultiplier, "0", NE ) ) &&
           ( compare( stCurrShis.szMultiplier, "1", NE ) ) ) {
         sprintf( szBpDesc, MULTIPLIER_FORMAT, stCurrShis.szMultiplier );
         PrintChgAdjDetail( szBpDesc, "", "" );
         szBpDesc[0] = '\0';
      }
    }

    if (szUardbilBaseTypeInd[i][0] == '1')
       strcpy(szBpDesc,"Customer Charge");
    else if (szUardbilBaseTypeInd[i][0] == '2')
      sprintf( szBpDesc, "Customer Charge - %s\" service",
               szUardbilCnszCode[i] );
    else if (szUardbilBaseTypeInd[i][0] == 'M')
      strcpy(szBpDesc,"Minimum Charge");
    else if (szUardbilBaseTypeInd[i][0] == 'C')
      strcpy(szBpDesc,"Contract Charge");
    else if (szUardbilBaseTypeInd[i][0] == 'E')
      strcpy(szBpDesc,"Effluent Charge");
    else {                                              /* Normal step charge */
      
       sprintf(szBpDesc, STEP_DETAIL_CHG_TEXT_FORMAT, dUardbilConsump[i],
       utrsrat_uoms_code, dUardbilStepCharge[i]);
    }

    /* print detail step */

    if (bFirstLine)
       sprintf(szDetailLineText,"%5.5s%ld Days  %-25.25s",
           "",
           lDOS,
           szBpDesc);
    else
       sprintf(szDetailLineText,"%5.5s          %-25.25s",
           "",
           szBpDesc);
    
    if(*(stCurrShis.szActionDate))
    {
    strcpy(GPresentDate,stCurrShis.szActionDate);
    strcpy(GDos,stCurrShis.szDOS);
    }


   if (!((*uabopen_srat_code_source) && (*uabopen_scat_code_source)) 
       && utrsrat_tax_ind[0] =='R')
          
    {
      if ((First_Primary) || (strcmp(ServiceNo,break_serv_num) != 0)){
         GDocSeqNo=GDocSeqNo+1;
         IncludeWeather(); /*Weather */
         Init_ServHead();
         /*extract_servhead(); */
         Extract_BillDetail();
         strcpy(ServiceNo,break_serv_num);
         First_Primary=FALSE;
      }
      if((dTotalStepAmt[i]!=0 ) || (utrsrat_rtyp_ind[0] =='U')
          ||(szUardbilBaseTypeInd[i][0] == 'C'))
      {
      
         if((uabopen_rate_change_ind[0] =='Y') ||
            (((szUardbilBaseTypeInd[i][0] == '1') ||  
             (szUardbilBaseTypeInd[i][0] == '2'))     
          && (utrsrat_rtyp_ind[0] =='U')))            

         {
            dGPrimaryAmt = dUardbilStepBillAmt[i];
         }
         else
         {
          /***BUG 11771 ***/
         if(dTotalStepAmt[i] ==0)
          dGPrimaryAmt = dUardbilStepBillAmt[i];
         else
         dGPrimaryAmt = dTotalStepAmt[i];
         /***BUG 11771 ***/
         }

          /***********RAM 29/01/98 ***********/
         dGPrimaryStep = dUardbilStepCharge[i];
         dGConsumption = dUardbilConsump[i];
         GDocSeqNo = GDocSeqNo+1;
         
         /*****************************************/
         /*extract_PrimaryRate(); ram 30/jan/1999 */
         Init_PrimaryRate();
         Extract_BillDetail();
         /*****************************************/
         sprintf(szLocalAmount, "%lf", dTotalStepAmt[i]);
      }

    }
        if (((szUardbilBaseTypeInd[i][0] == '1') ||
             (szUardbilBaseTypeInd[i][0] == '2'))
          && (utrsrat_rtyp_ind[0] !='U'))
           {
             
             sprintf(szLocalAmount, "%lf", dUardbilStepBillAmt[i]);
             /* Douc Code for Base Charge */
             dGBaseCharge= dUardbilStepBillAmt[i];
             GDocSeqNo = GDocSeqNo+1;
            /* extract_BaseCharge();ram 30/jan/98 */
               Init_BaseCharge();    /***To Initialise Variable ***/
               Extract_BillDetail(); /***To Insert A Bill Detail Rec ***/
            }

      if (utrsrat_tax_ind[0] == 'T') {
      dGTaxAmt   = dTotalStepAmt[i];
      dGTaxStep  = dUardbilStepCharge[i];
      dGConsumption = dUardbilConsump[i];
      sprintf(szLocalAmount, "%lf", dTotalStepAmt[i]);
      GDocSeqNo = GDocSeqNo+1;
      strcpy(GTaxText,szDetailLineText); 
      sprintf(GTax,"%.2f",atof(szLocalAmount));
      /***************************************/
      /*extract_Tax(); ram 30/jan/98         */
      Init_Tax();
      Extract_BillDetail();
      /***************************************/
   }

   if (utrsrat_tax_ind[0] == 'P') {
      dGPenaltyAmt   = dTotalStepAmt[i];
      dGPenaltyStep  = dUardbilStepCharge[i];
      dGConsumption = dUardbilConsump[i];
      sprintf(szLocalAmount, "%lf", dTotalStepAmt[i]);
      GDocSeqNo = GDocSeqNo+1;
      sprintf(GPenText,szDetailLineText);
      sprintf(GPenalty,"%.2f",atof(szLocalAmount));
      strcpy(GPenText,"Penalty");
      /***************************************/
      /*extract_Penalty(); ram 30/jan/98     */
      Init_Penalty();
      Extract_BillDetail();
      /***************************************/
   }
  
   if (((*uabopen_srat_code_source) && (*uabopen_scat_code_source)) &&
      (utrsrat_tax_ind[0] == 'R'))
   {
      if(dTotalStepAmt[i]!=0)
      {
      dGSubordAmt = dTotalStepAmt[i];
      dGSubordStep = dUardbilStepCharge[i];
      dGConsumption = dUardbilConsump[i];
      GDocSeqNo = GDocSeqNo+1;
      
      /***************************************/
      /*extract_SubordRate(); ram 30/jan/98  */
      Init_SubordRate();
      Extract_BillDetail();
      /***************************************/
      sprintf(szLocalAmount, "%lf", dTotalStepAmt[i]);
      }
   }

    
    if (szUardbilBaseTypeInd[i][0] == 'M')
      sprintf(szLocalAmount, "%lf", dUardbilStepBillAmt[i]);

    PrintChgAdjDetail(szDetailLineText, szLocalAmount, szLocalTotal);
    add(szStepNo,szStepNo,"1");

    if (bFirstLine)
       bFirstLine = FALSE;
  }


  strcpy(szStepNo,"");
  EXEC SQL CLOSE UardbilCursor;
  POSTORA;
}

/******************************************************************************/

static void GetSubordinateCharges(void)
{
   dSumOUCSubordCharges=0;
   dSumOUCSubordVariance=0;
   dSubStepCharge=0;
   EXEC SQL DECLARE OUCSubordChargeCursor CURSOR FOR
    SELECT SUM(NVL(uabopen_billed_chg,0)),
           SUM(nvl(uabopen_budget_variance,0))
      FROM uabopen
     WHERE uabopen_cust_code = TO_NUMBER(:ucracct_cust_code)
       AND uabopen_prem_code = :ucracct_prem_code
       AND uabopen_srat_code_source = :uabopen_srat_code
       AND uabopen_scat_code_source = :uabopen_scat_code
       AND uabopen_serv_num         = :uabopen_serv_num
       AND uabopen_charge_date      =
           TO_DATE( :uabopen_charge_date, 'DD-MON-YYYY' );

       EXEC SQL OPEN OUCSubordChargeCursor;
       POSTORA;

       EXEC SQL FETCH OUCSubordChargeCursor
        INTO :dSumOUCSubordCharges  :sSumOUCSubordCharges_Ni,
             :dSumOUCSubordVariance :sSumOUCSubordVariance_Ni;
       POSTORA;

       EXEC SQL CLOSE OUCSubordChargeCursor;
       POSTORA;


       EXEC SQL DECLARE OUCSubordRateCursor CURSOR FOR
        select utrrstp_charge_amt
          from utrrstp,
               uabopen
         WHERE uabopen_cust_code = TO_NUMBER(:ucracct_cust_code)
       AND uabopen_prem_code = :ucracct_prem_code
       AND uabopen_srat_code_source = :uabopen_srat_code
       AND uabopen_scat_code_source = :uabopen_scat_code
       AND uabopen_serv_num         = :uabopen_serv_num
       AND uabopen_charge_date      =
           TO_DATE( :uabopen_charge_date, 'DD-MON-YYYY' )
       and uabopen_srat_code = utrrstp_srat_code
       and uabopen_scat_code = utrrstp_scat_code;
       POSTORA;

       EXEC SQL OPEN OUCSubordRateCursor;
       POSTORA;

       EXEC SQL FETCH OUCSubordRateCursor
                 into :dSubStepCharge :dSubStepCharge_Ni;

       POSTORA;
       EXEC SQL CLOSE OUCSubordRateCursor;
       POSTORA;



}


static void insert_service_total(void)
{
   EXEC SQL BEGIN DECLARE SECTION;
      CHAR81 szLocalText           = "";
   EXEC SQL END   DECLARE SECTION;

      if (serv_misc) {
          return;
       }

       else
       {
       
       sprintf(text, "Current %s Charges", prev_asvc_desc);
       strcpy(szGTotalAmountDue,break_total);

       PrintChgAdjDetail(text, "", szGTotalAmountDue);
	    tonum(break_total,null);
	    tonum(subtotal,null);
	    print_subtot=1;     /* Only print one subtotal per service */
       PrintChgAdjDetail( "", "", "" );
       }
   /* } */
}

/*****************************************************************************/
/* Print subtotal                                                            */
/*****************************************************************************/

static void PrintBillHeaderSection( char *pszPageNo )
{
   PrintAccountNumber(pszPageNo,FIELD_1_ACCOUNT_NUM);
   PrintServiceAddress();
}                                               /* end PrintBillHeaderSection */


static void PrintBillChgTotalSection( char *pszPageNo, short sPrintDataFlag )
{
   NUMSTR szLastAgencyPageNo = "";


   sprintf( szLastAgencyPageNo, "%d", sGLastAgencyPageNo );

   /*  Print the outside agency logo and separator line information  */

   if ( compare( pszPageNo, szLastAgencyPageNo, GT ) ) {
       {
      BPPrintField(session_id, billno, pszPageNo,
                   FIELD_1_OBAG_SECT_1_SEPARATOR, "", "", "");
      BPPrintField(session_id, billno, pszPageNo,
                   FIELD_1_OBAG_SECT_1_LOGO, "", "", "");
      BPPrintField(session_id, billno, pszPageNo,
                   FIELD_1_OBAG_SECT_2_SEPARATOR, "", "", "");
      BPPrintField(session_id, billno, pszPageNo,
                   FIELD_1_OBAG_SECT_2_LOGO, "", "", "");
        }
   }

   /* First line of Budget Summary Grid */
         if ( strcmp( pszPageNo, szGBudgetGridPageNum ) == 0 )
      BPPrintField(session_id, billno, pszPageNo, FIELD_1_BUDGET_GRID,
                   szGBudgetGridLineNum, "", "");
   else
      BPPrintField(session_id, billno, pszPageNo, FIELD_1_BUDGET_GRID,
                   "", "", "");

   if (sPrintDataFlag) {
      /* due date */

      

     if ((ucbmbil_sub_pymt_ind[0] != 'N')) 
      BPPrintField(session_id, billno, pszPageNo, FIELD_1_DUE_DATE,
                    account_due_date_mmddyy, "", "");
    else  
      BPPrintField(session_id, billno, pszPageNo, FIELD_1_DUE_DATE,
                    "", "", ""); 

      /* Total current charges */

      sprintf(GCharges,"%.2f",atof(szGCurrChgsAndAdjs));
      BPPrintField(session_id, billno, pszPageNo, FIELD_1_TOTAL_CURRENT_CHARGES,
                   szGCurrChgsAndAdjs, CHG_ADJ_AMOUNT_FORMAT, "");

      GDocSeqNo = GDocSeqNo+1;
      
      /*extract_TL(); ram 30/jan/98          */
      Init_TotalLine();
      Extract_BillDetail();

      if (compare( szGPastDueTotal, "0", NE)) {
         if (compare( szGPastDueTotal, "0", GT))
         {
            BPPrintField(session_id, billno, pszPageNo, FIELD_1_NOW_PAST_DUE,
                          "** NOW PAST DUE **", "", "");
         }
         else
            BPPrintField(session_id, billno, pszPageNo, FIELD_1_NOW_PAST_DUE, "", "", "");
         PrintPreviousBalance(pszPageNo,FIELD_1_PAST_DUE);
      } else {
         BPPrintField(session_id, billno, pszPageNo, FIELD_1_NOW_PAST_DUE, "", "", "");
         BPPrintField(session_id, billno, pszPageNo, FIELD_1_PAST_DUE, "", "", "");
      }
       /* Total Amount Due */
           BPPrintField(session_id, billno, pszPageNo, FIELD_1_TOTAL_AMOUNT_DUE, szGTotalAmountDue, CHG_ADJ_AMOUNT_FORMAT, "");
   }
   else {
      /* due date */
      BPPrintField(session_id, billno, pszPageNo, FIELD_1_DUE_DATE, "", "", "");

      /* Total current charges */
      BPPrintField(session_id, billno, pszPageNo, FIELD_1_TOTAL_CURRENT_CHARGES, "", "", "");

      /* previous balance */
      BPPrintField(session_id, billno, pszPageNo, FIELD_1_NOW_PAST_DUE, "", "", "");
      BPPrintField(session_id, billno, pszPageNo, FIELD_1_PAST_DUE, "", "", "");
      BPPrintField(session_id, billno, pszPageNo, FIELD_1_TOTAL_AMOUNT_DUE, "", "", "");
   }


}                                             /* end PrintBillChgTotalSection */

/******************************************************************************/

static void PrintBillStubSection( char *pszPageNo,short sPrintDataFlag )
{
   NUMSTR szLocalLineNum="";



   if (sPrintDataFlag) {

      if (Test2) {

         if (compare( szGCurrChgsAndAdjs, "0", LT)) {

            if (( !*reprint_date_var ) &&
               compare( szGPastDueTotal, szGTotalAmountDue, NE))
               add( szGPastDueTotal, szGPastDueTotal, szGCurrChgsAndAdjs );
            else if (( *reprint_date_var ) &&
                    compare( szGPastDueTotal, ubbbhst_ending_bal, NE))
               add( szGPastDueTotal, szGPastDueTotal, szGCurrChgsAndAdjs );


            Test1 = FALSE;
         }
      }

      if (compare( szGPastDueTotal, "0", GT)) {
         strcpy( szLocalLineNum, FIELD_1_DUE_NOW_MSG );
         BPPrintField(session_id, billno, pszPageNo, szLocalLineNum,
                      DUE_NOW_MSG_TEXT_FORMAT, "", "");
         PrintPreviousBalance(pszPageNo,FIELD_1_STUB_PAST_DUE);
      } else {
         strcpy( szLocalLineNum, FIELD_1_DUE_NOW_MSG );
         BPPrintField(session_id, billno, pszPageNo, szLocalLineNum, "", "", "");
         strcpy( szLocalLineNum, FIELD_1_STUB_PAST_DUE );
         BPPrintField(session_id, billno, pszPageNo, szLocalLineNum, "", "", "");
      }

      PrintCurrentAmountDue(pszPageNo);

      /* due date */
      if ((ucbmbil_sub_pymt_ind[0] != 'N')) 
      {
      BPPrintField(session_id, billno, pszPageNo, FIELD_1_STUB_DUE_DATE,
                    account_due_date_mmddyy, "", "");
      }
      else 
      {
      BPPrintField(session_id, billno, pszPageNo, FIELD_1_STUB_DUE_DATE,
                    "", "", "");
      }  

      /* Account number */
   }
   else {
      strcpy( szLocalLineNum, FIELD_1_DUE_NOW_MSG );
      BPPrintField(session_id, billno, pszPageNo, szLocalLineNum, "", "", "");
      BPPrintField(session_id, billno, pszPageNo, FIELD_1_STUB_PAST_DUE, "", "", "");
      BPPrintField(session_id, billno, pszPageNo, FIELD_1_CURRENT_AMT_DUE, "", "", "");
      BPPrintField(session_id, billno, pszPageNo, FIELD_1_STUB_DUE_DATE, "", "", "");
   }
   PrintAccountNumber(pszPageNo,FIELD_1_STUB_ACCOUNT_NUMBER);

   /* Bill print date */
   BPPrintField(session_id, billno, pszPageNo, FIELD_1_BILL_PRINT_DATE,
                printed_date_mmddyy, "", "");

   BPPrintScanLine(ucracct_cust_code, ucracct_prem_code,
                  amount_due, account_due_date,
                  session_id, billno, pszPageNo,
                  FIELD_1_SCANLINE);
}                                                 /* end PrintBillStubSection */

/******************************************************************************/

static void InsertSpecialMessages(char *pszPageNum)
{
   BPPrintField(session_id, billno, pszPageNum, FIELD_1_SPECIAL_MESSAGES_1,"","", "");
   BPPrintField(session_id, billno, pszPageNum, FIELD_1_SPECIAL_MESSAGES_2, "", "", "");
   BPPrintField(session_id, billno, pszPageNum, FIELD_1_WATERMARK_TEXT,"", "", "");
}

/******************************************************************************/

static void check_detail_count(void)
{

   if (no_of_detail_lines > sGLastDetailLine)
   {
      if (sGPrintingOutsideAgencies == FALSE) {

         while (compare(szGConsumptionLineNum, LAST_CONSUMPTION_LINE, LE)) {
             BPPrintField(session_id, billno, szGChgAdjPageNo,
                          szGConsumptionLineNum, "", "", "");
             add(szGConsumptionLineNum, szGConsumptionLineNum, "1");
         }

      }
      else
      {

        if ( (NumberofSections == 2 ) &&
             (sGPrintSecondLogo == TRUE)) {
           BPPrintField(session_id, billno, szGChgAdjPageNo,
                        FIELD_1_OBAG_SECT_2_SEPARATOR,
                        "", "", "");
           BPPrintField(session_id, billno, szGChgAdjPageNo,
                        FIELD_1_OBAG_SECT_2_LOGO,
                        "", "", "");
        }


        lGAdditionalSections++;
      }
      increment_page_no();

      if (sGPrintingOutsideAgencies == FALSE) {
         PrintBillHeaderSection(szGChgAdjPageNo);
      }
   }
       no_of_detail_lines++;

      if ( sGPrintingOutsideAgencies == TRUE )
         no_of_agency_lines++;

}                                                  /* end check_detail_count */

/*****************************************************************************/

static int ActiveBankDraft (void)
{

/* Returns TRUE if an bank draft start date is active */
   active_draft = 0;

   EXEC SQL EXECUTE
      BEGIN
	      IF :deferred_due_date IS NULL THEN
	         IF TO_DATE(:due_date, 'DD-MON-YYYY') >=
               TO_DATE(:ucracct_draft_start_date,'DD-MON-YYYY') THEN
		         :active_draft := 1;
	         end if;
	      ELSE
	         IF TO_DATE(:deferred_due_date, 'DD-MON-YYYY') >=
		         TO_DATE(:ucracct_draft_start_date,'DD-MON-YYYY') THEN
		         :active_draft := 1;
	         END IF;
	      END IF;
      END;
   END-EXEC;

   return(active_draft);
}

/***************************************************************/
static void print_line_53_55(void)
{
  /* insert system bill message */

  
  if ( *bill_message_code && compare(system_bmsg_option,"A",NES) ) 
  {
    strcpy(bmsg_code,bill_message_code);
    Extract_BillMessages(); 
    
  }

  /* insert customer-specific message */

  if ( *ucbcust_bmsg_code ) 
   {
    strcpy(bmsg_code,ucbcust_bmsg_code);
    Extract_BillMessages(); 
   }

  /* insert account-specific message */

  if ( *ucracct_bmsg_code && compare(system_bmsg_option,"S",NES) )
    {
     strcpy(bmsg_code,ucracct_bmsg_code);
     Extract_BillMessages(); 
    }

  /*---------------UCRACCT_STATUS_MESSAGES ------------*/
       if(strcmp(ucracct_status_ind,"F")==0)
	   {
	       temp_status_ind =1;
               strcpy(temp_docu_message,"FINAL BILL");
	       Extract_BillMessages();
	       temp_status_ind =0;
	   }

       if(strcmp(ucracct_status_ind,"I")==0)
	 {
          temp_status_ind =1;
       	  strcpy(temp_docu_message,"INACTIVE ACCOUNT ");
          Extract_BillMessages();
          temp_status_ind =0;
	 }                     
}                                        /* end print_line_53_55 */
/******************************************************************/                                   
/* end of ubpbpfm.c source file */
