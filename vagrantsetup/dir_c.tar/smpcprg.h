/*TMCI18N BEGIN HEADER*/
#if !defined( _TMBSMPCPRG_H_EXISTS )
/* No Initialisation Required */                                               
#include "tmcilib.h"
static struct TMBundle _TMBSMPCPRG_H = {"smpcprg.h",NULL,NULL,NULL,NULL};
#define _TMBSMPCPRG_H_EXISTS
#endif
/*TMCI18N END HEADER*/

/* AUDIT_TRAIL_MSGKEY_UPDATE
-- PROJECT : MSGKEY
-- MODULE  : SMPCPRG
-- SOURCE  : enUS
-- TARGET  : I18N
-- DATE    : Fri Mar 20 13:22:56 2015
-- MSGSIGN : #843bd56f03ef8340
END AUDIT_TRAIL_MSGKEY_UPDATE */

/* AUDIT_TRAIL_TM63
-- TranMan 6.3 
-- PROJECT : PVV_TEST
-- MODULE  : SMPCPRG
-- SOURCE  : enUS
-- TARGET  : I18N
-- DATE    : Mon Nov 12 04:17:57 2007
END AUDIT_TRAIL_TM63 */
/*****************************************************************************/
/* SMPCPRG.H Copyright 2015 Ellucian Company L.P. and its affiliates.        */
/*****************************************************************************/

/*****************************************************************************/
/*                                                                           */
/*       CONFIDENTIAL BUSINESS INFORMATION                                   */
/*                                                                           */
/*      **********************************                                   */
/*                                                                           */
/* THIS PROGRAM IS PROPRIETARY INFORMATION OF                                */
/* SYSTEMS AND COMPUTER TECHNOLOGY CORPORATION                               */
/* AND IS NOT TO BE COPIED, REPRODUCED, LENT OR                              */
/* DISPOSED OF, NOR USED FOR ANY PURPOSE OTHER                               */
/* THAN THAT FOR WHICH IT IS SPECIFICALLY PROVIDED                           */
/* WITHOUT THE WRITTEN PERMISSION OF SAID COMPANY                            */
/*                                                                           */
/*****************************************************************************/
/* SMPCPRG.H                                                                 */
/* Program SMPCPRG.PC Header File.                                           */
/*                                                                           */
/* AUDIT TRAIL: 4.3                                  INIT    DATE            */
/* DRA 09FEB2000                                                             */
/* The purge process was created to provide the client with the ability      */
/* to purge students' records from the CAPP tables of a degree audit.        */
/* AUDIT TRAIL: 4.3.3.1                                                      */
/* AUDIT TRAIL: 5.1.0.1                              EFD   14-DEC-2000       */
/* AUDIT TRAIL: 6.0                                  LM    08-AUG-2002       */
/* 1. Defect 80056                                                           */
/* Full table scan against SPRCOLR in macro ANDSTUDLIKE and ORSTUDLIKE.      */          
/* Technical : Create macro INDSTUDLIKE (index on STUDLIKE) appended this    */
/* to the dynamically generate sql statement.                                */
/* 2. Defect 72825                                                           */
/* Process does not delete from compliance temporary tables (SMT%).          */
/* Technical : Added Seven new Define statements in header, one for          */
/* each temporary table. Updated function del_master to add a total of       */
/* fourteen new calls to del_fromTable() for each temporary table.           */
/*                                                                           */
/* AUDIT TRAIL : 8.0 (I18N)                                                  */
/*                                                                           */
/* AUDIT TRAIL: 8.8                                                          */
/* 1. CR-000125282                                                           */
/*    JDC 03/20/2015                                                         */
/*    Ran re-key to ensure G$_NLS calls were properly coded                  */
/* AUDIT TRAIL END                                                           */
/*****************************************************************************/

#ifndef _SMPCPRG_C_
#define STORE_CLASS extern
#else
#define STORE_CLASS /* */
#endif   

/*Value for array size.                                                      */
#define MAXSIZE 255   

/*Values for Boolean operations.                                             */
#define NO      _TMC("N") 
#define YES     _TMC("Y")
#define TRUE    1  
#define FALSE   0  
#define NOTHING _TMC("")
 
/*Values for file manipulation operations.                                   */
#define APPEND _TMC("a")
#define WRITE  _TMC("w")

/*Values for user entered parameters used by program.                        */
#define PARM1   _TMC("01")
#define PARM2   _TMC("02")
#define PARM3   _TMC("03")
#define PARM4   _TMC("04")
#define PARM5   _TMC("05")
#define PARM6   _TMC("06")
#define PARM7   _TMC("07")
#define PARM8   _TMC("08")
#define PARM9   _TMC("09")
#define PARM10  _TMC("10")
#define PARM11  _TMC("11") 
#define PARM12  _TMC("12")

/*Special string literals for various purposes.                              */
#define ID     TM_NLS_HGet( &_TMBSMPCPRG_H, "0000","ID") 
#define T1 TM_NLS_HGet( &_TMBSMPCPRG_H, "0001","Purge Selection [All but most Recent or User-entered criteria]: ")
#define T2 TM_NLS_HGet( &_TMBSMPCPRG_H, "0002","                                        Request Date for Purge: ")
#define T3 TM_NLS_HGet( &_TMBSMPCPRG_H, "0003","                                             ID(s) for Purging: ")
#define S3 _TMC("                                                                ")
#define T4 TM_NLS_HGet( &_TMBSMPCPRG_H, "0004","                                        Program(s) for Purging: ")
#define T5 TM_NLS_HGet( &_TMBSMPCPRG_H, "0005","                                           User(s) for Purging: ")
#define T6 TM_NLS_HGet( &_TMBSMPCPRG_H, "0006","                             Purge Processed or Not Processed?: ")
#define T7 TM_NLS_HGet( &_TMBSMPCPRG_H, "0007","                                      Purge Detail or Request?: ")
#define T8 TM_NLS_HGet( &_TMBSMPCPRG_H, "0008","                                Purge Hardcopy Requests? [Y/N]: ")
#define T9 TM_NLS_HGet( &_TMBSMPCPRG_H, "0009","                                         Hardcopy Request Date: ")
#define T10 TM_NLS_HGet( &_TMBSMPCPRG_H, "0010","                                      Run Mode [Audit/Update]: ")
#define T11 TM_NLS_HGet( &_TMBSMPCPRG_H, "0011","                                          Print Detail? [Y/N]: ")
#define T12 TM_NLS_HGet( &_TMBSMPCPRG_H, "0012","Processing Totals .......")
#define T13 TM_NLS_HGet( &_TMBSMPCPRG_H, "0013","                                   Compliance Requests Purged: ")
#define T14 TM_NLS_HGet( &_TMBSMPCPRG_H, "0014","                         Associated Hard Copy Requests Purged: ")
#define T15 TM_NLS_HGet( &_TMBSMPCPRG_H, "0015","                               Other Hard Copy Request Purged: ")
#define T16 TM_NLS_HGet( &_TMBSMPCPRG_H, "0016","                             Date Ranges for Purge Start Date: ")
#define T17 TM_NLS_HGet( &_TMBSMPCPRG_H, "0017","                                                     End Date: ")  
#define T18 TM_NLS_HGet( &_TMBSMPCPRG_H, "0018","Processing of Hard-copy output records section") 

#define ACT    TM_NLS_HGet( &_TMBSMPCPRG_H, "0019","ACTION")  
#define REQ    TM_NLS_HGet( &_TMBSMPCPRG_H, "0020","REQ#")  
#define ACT1   TM_NLS_HGet( &_TMBSMPCPRG_H, "0021","Compliance Request Audited.")
#define ACT2   TM_NLS_HGet( &_TMBSMPCPRG_H, "0022","Compliance Request Purged.")
#define ACT3   TM_NLS_HGet( &_TMBSMPCPRG_H, "0023","Print Request Audited.")
#define ACT4   TM_NLS_HGet( &_TMBSMPCPRG_H, "0024","Print Request Purged.") 
#define NAME   TM_NLS_HGet( &_TMBSMPCPRG_H, "0025","NAME")
#define PROG   TM_NLS_HGet( &_TMBSMPCPRG_H, "0026","PROGRAM/") 
#define PTYPE  TM_NLS_HGet( &_TMBSMPCPRG_H, "0027","PRINT TYPE") 
#define TITLE  TM_NLS_HGet( &_TMBSMPCPRG_H, "0028","Compliance Purge Control Report")
#define AUDIT  TM_NLS_HGet( &_TMBSMPCPRG_H, "0029","AUDIT    MODE") 
#define SELECT TM_NLS_HGet( &_TMBSMPCPRG_H, "0030"," Enter SELECTION: ")
#define UPDATE TM_NLS_HGet( &_TMBSMPCPRG_H, "0031","UPDATE   MODE")

/*UMA- following macros are used by gen_clauses_for_sel which dynamically*/
/*generates the where clause conditions of the driving query             */
#define ORSTUDLIKE _TMC(" OR SMRRQCM_PIDM IN \
                      ( SELECT SPRIDEN_PIDM \
                        FROM   SPRIDEN,SPRCOLR \
                        WHERE  SPRIDEN_ID = SPRCOLR_VALUE_ATYP \
                        AND    SPRIDEN_ID LIKE ")
#define ANDSTUDLIKE _TMC(" AND ( SMRRQCM_PIDM IN \
                      ( SELECT SPRIDEN_PIDM \
                        FROM   SPRIDEN,SPRCOLR \
                        WHERE  SPRIDEN_ID = SPRCOLR_VALUE_ATYP \
                        AND    SPRIDEN_ID LIKE ")
/* Defect 80056 */
#define INDSTUDLIKE _TMC(" AND SPRCOLR_SESSIONID = ")
#define ORUSERLIKE  _TMC(" OR  SMRRQCM_USER LIKE ")
#define ANDUSERLIKE _TMC(" AND ( SMRRQCM_USER LIKE ")
#define ORPROGLIKE  _TMC(" OR  SMRRQCM_PROGRAM LIKE ")
#define ANDPROGLIKE _TMC(" AND ( SMRRQCM_PROGRAM LIKE ")

/*Special macros used in processing.                                         */
#define ARYCPY(arr1, arr2)  tmmemcpy(arr1, arr2, sizeof(arr1))

/*These macro get data from the user.                                        */
#define GET01  input(purge_sel,SELECT,2,ALPHA)   
#define GET02  input(request_date1,SELECT,12,ALPHA)
#define GET03  input(stu_id,SELECT,10,ALPHA)
#define GET04  input(prog_name,SELECT,13,ALPHA)  
#define GET05  input(user_id,SELECT,31,ALPHA)   
#define GET06  input(processed,SELECT,2,ALPHA)
#define GET07  input(purg_det_req,SELECT,2,ALPHA)
#define GET08  input(purg_hard,SELECT,2,ALPHA)      
#define GET09  input(hard_date,SELECT,12,ALPHA)      
#define GET10  input(runmode,SELECT,2,ALPHA)      
#define GET11  input(print_det,SELECT,2,ALPHA) 
#define GET12  input(answer,SELECT,2,ALPHA)
#define GET13  input(request_date2,SELECT,12,ALPHA)

/*The string literals to be cancatenated to the dynamic sql.                */
#define AN     _TMC(" AND ")
#define DEL    _TMC("DELETE FROM ")
#define SEL    _TMC("SELECT ")
#define FRM    _TMC("FROM ")
#define PIDM   _TMC("_PIDM")
#define WHER   _TMC(" WHERE ")
#define BETWEN _TMC(" BETWEEN ")
#define REQ_NO _TMC("_REQUEST_NO") 

/*The string literals of the tables to be deleted from.                      */
#define SMBPOGN _TMC("SMBPOGN")
#define SMRPOGD _TMC("SMRPOGD")
#define SMRPOLV _TMC("SMRPOLV")
#define SMRPOSA _TMC("SMRPOSA")
#define SMRPOAT _TMC("SMRPOAT")
#define SMRPONC _TMC("SMRPONC")
#define SMRPOAN _TMC("SMRPOAN")
#define SMRDOAN _TMC("SMRDOAN")
#define SMRDOCN _TMC("SMRDOCN")
#define SMRDORJ _TMC("SMRDORJ")
#define SMRGOAT _TMC("SMRGOAT")
#define SMBGOGN _TMC("SMBGOGN")
#define SMRGOGD _TMC("SMRGOGD")
#define SMRGOLV _TMC("SMRGOLV")
#define SMRGOSA _TMC("SMRGOSA")
#define SMBGRRQ _TMC("SMBGRRQ")
#define SMRGRRQ _TMC("SMRGRRQ")
#define SMRAOST _TMC("SMRAOST")
#define SMBAOGN _TMC("SMBAOGN")
#define SMRAOGD _TMC("SMRAOGD")
#define SMRAOLV _TMC("SMRAOLV")
#define SMRAOSA _TMC("SMRAOSA")
#define SMRDOST _TMC("SMRDOST")
#define SMRDORQ _TMC("SMRDORQ")
#define SMRDOLV _TMC("SMRDOLV")
#define SMRDOEX _TMC("SMRDOEX") 
#define SMRDOUS _TMC("SMRDOUS")
#define SMBDRRQ _TMC("SMBDRRQ")
#define SMRDRRQ _TMC("SMRDRRQ")
#define SMRDRLV _TMC("SMRDRLV")
#define SMRDREX _TMC("SMRDREX")
#define SMRPRRQ _TMC("SMRPRRQ") 
#define SMRPCRS _TMC("SMRPCRS")
#define SMRRQCM _TMC("SMRRQCM")
/* 72825 */
#define SMTASEL _TMC("SMTASEL")
#define SMTCRSE _TMC("SMTCRSE")
#define SMTCUSE _TMC("SMTCUSE")
#define SMTRUSE _TMC("SMTRUSE")
#define SMTSPAT _TMC("SMTSPAT")
#define SMTSPLT _TMC("SMTSPLT")
#define SMTSTRG _TMC("SMTSTRG")

/*Dynamic SQL string literals for most recent records.                       */
#define ORDER1    _TMC(" ORDER BY SMRRQCM_REQUEST_NO")
#define SMRQCM    _TMC(" SMRRQCM ")
#define PROCESD   _TMC(" SMRRQCM_COMPLY_DATE IS NOT NULL ")
#define UNPROCD   _TMC(" SMRRQCM_COMPLY_DATE IS NULL ")
#define REQDATE   _TMC(" TO_DATE(TO_CHAR(TRUNC(SMRRQCM_REQUEST_DATE),\
                    'DD-MON-YYYY'),'DD-MON-YYYY')\
                    <= TO_DATE(:request_date1, 'DD-MON-YYYY') ")
#define REQDATE1  _TMC(" TO_DATE(TO_CHAR(TRUNC(SMRRQCM_REQUEST_DATE),\
                   'DD-MON-YYYY'),'DD-MON-YYYY')BETWEEN\
                    TO_DATE(:request_date1, 'DD-MON-YYYY')\
                    AND TO_DATE(:request_date2, 'DD-MON-YYYY') ")  
#define SMRQCMPID _TMC(" SMRRQCM_PIDM        = TO_NUMBER(:pidm) ")
#define SMRQCMREC _TMC(" SMRRQCM_REQUEST_NO  < TO_NUMBER(:recent_request) ")
#define SMRQCMREQ _TMC(" RTRIM(TO_CHAR(SMRRQCM_REQUEST_NO)) ")
#define SMRQCMPRG _TMC(" RPAD(SMRRQCM_PROGRAM, 12, ' ') = :prog_name ")

/*Dynamic SQL string literals for user defined  records.                     */
#define ORDER2   _TMC("ORDER BY RPAD(DECODE(SPRIDEN_MI,")
#define ORDER3   _TMC("'',SPRIDEN_LAST_NAME||', '||SPRIDEN_FIRST_NAME,")
#define ORDER4   _TMC("SPRIDEN_LAST_NAME||', '||SPRIDEN_FIRST_NAME||' '|| ")
#define ORDER5   _TMC("SUBSTR(SPRIDEN_MI,1,1)), 40, ' '), SMRRQCM_PROGRAM, ")
#define ORDER6   _TMC("SMRRQCM_REQUEST_NO ")  
#define ORDER7   _TMC("ORDER BY SMRRQCM_USER,SMRRQCM_PIDM,SMRRQCM_REQUEST_NO ")  
#define SPRIDE   _TMC(" SPRIDEN, ")
#define SPRIPID  _TMC(" SPRIDEN_PIDM = SMRRQCM_PIDM ")
#define SPRICHG  _TMC(" SPRIDEN_CHANGE_IND IS NULL ")
#define SMRQPIDM _TMC("TO_CHAR(SMRRQCM_PIDM), ")
#define SMRQREQN _TMC("RTRIM(TO_CHAR(SMRRQCM_REQUEST_NO)), ")
#define SMRQDATE _TMC("TRUNC(SMRRQCM_REQUEST_DATE), ")
#define SMRQPROG _TMC("RPAD(SMRRQCM_PROGRAM, 12, ' '), ")
#define SPRIDEID _TMC("RPAD(SPRIDEN_ID, 9, ' '), ")
#define SMRQUSER _TMC("SMRRQCM_USER,")
#define SPRINAME _TMC("RPAD(DECODE(SPRIDEN_MI,'',SPRIDEN_LAST_NAME||', ' \
                 ||SPRIDEN_FIRST_NAME, SPRIDEN_LAST_NAME||', ' \
                 ||SPRIDEN_FIRST_NAME||' '|| SUBSTR(SPRIDEN_MI,1,1)),40,' ') ")

EXEC SQL BEGIN DECLARE SECTION;

     STORE_CLASS TMCHAR  something[2];       /*Used N/Y for multiple parms.      */
     STORE_CLASS TMCHAR  parm_number[3];     /*Holds the parameter number.       */
     STORE_CLASS TMCHAR  parm_value[3];      /*Holds the parameter value.        */
     STORE_CLASS TMCHAR prev_stu_id[10];     /*Holds the previous student's ID.  */
     STORE_CLASS TMCHAR no_of_patterns[10];
     STORE_CLASS TMCHAR hard_date[12];       /*Holds the hard copy date.         */
     STORE_CLASS TMCHAR prev_prog_name[13];  /*Holds the previous student's name.*/
     STORE_CLASS TMCHAR prog_name[13];
     STORE_CLASS TMCHAR rptname[31];
     STORE_CLASS TMCHAR sessionid[31];
     STORE_CLASS TMCHAR single_parm[31];     /*Used to collect a single parms.   */
     STORE_CLASS TMCHAR job[31];             /*Holds the job currently being ran */
     STORE_CLASS TMCHAR inst_name[31];
     STORE_CLASS BANNUMSTR(one_up_no);
     STORE_CLASS BANNUMSTR(pidm); 
     STORE_CLASS BANNUMSTR(cur_req);         /*Holds the current required.       */
                         
EXEC SQL END DECLARE SECTION;


/* 50408 */
STORE_CLASS TMCHAR select_statement1[10000]; /* The actual record statement       */
STORE_CLASS TMCHAR select_statement2[10000]; /* The actual record statement       */
STORE_CLASS TMCHAR select_statement3[10000]; /* The actual record statement       */
STORE_CLASS TMCHAR select_delete[5000];     /* The actual delete statement        */
STORE_CLASS TMCHAR  filename[500]; 
STORE_CLASS FNSTRUC  outfile;          /*The file struct's definition.       */
STORE_CLASS UFILE     *output_file;
STORE_CLASS TMCHAR     *thisfile;        /*A pointer to the actual file name   */
STORE_CLASS TMCHAR     *ofile_name=NULL;
STORE_CLASS TMCHAR select_clause[5000] ;   /* The actual record statement        */
/*****************************************************************************/
/*****************************************************************************/
/*****************************************************************************/
/*****************************************************************************/
/*                            VARIABLE SECTION                               */
/*The variables below are used by Oracle to pad data taken from tables.      */
STORE_CLASS int   req_total;     /*Holds required purged totals.             */
STORE_CLASS int   hc_total;      /*Holds associated hard copy totals.        */
STORE_CLASS int   oc_total;      /*Holds other hard copy totals.             */
STORE_CLASS TMCHAR  *data[MAXSIZE]; /*Data array for holding constant values.  */
STORE_CLASS short IND1;          /*Used to pad variables from tables.        */
STORE_CLASS short page_no;       /*Used to hold page count.                  */
STORE_CLASS short line_count;    /*Used to hold line count.                  */
STORE_CLASS short new_header;    /*Used to hold T or F* if new header.       */
STORE_CLASS short stu_id_changed;/*Used to hold T or F* if  ID changed.      */
STORE_CLASS int   debug;     
/*****************************************************************************/
/*****************************************************************************/
/*****************************************************************************/
/*****************************************************************************/
/*                            CURSOR SECTION                                 */
/*The cursors below are used in various processes to manipulate data in the  */
/*tables.                                                                    */

/*MAJOR Cursors used for deletion of data in the tables, based on user input.*/

/*Used to get the student's data.                                            */
 EXEC SQL DECLARE get_stu_rec CURSOR FOR   
      SELECT DISTINCT(TO_CHAR(SPRIDEN_PIDM)),
             RPAD(SPRIDEN_ID, 9, ' '), 
             RPAD(DECODE(SPRIDEN_MI,
                    '',SPRIDEN_LAST_NAME||', '||SPRIDEN_FIRST_NAME,
                    SPRIDEN_LAST_NAME||', '||SPRIDEN_FIRST_NAME||' '||
                    SUBSTR(SPRIDEN_MI,1,1)),40,' ')
     FROM  SPRIDEN, SMRRQCM
     WHERE SPRIDEN_PIDM = SMRRQCM_PIDM
     AND   SPRIDEN_CHANGE_IND IS NULL
     ORDER BY RPAD(DECODE(SPRIDEN_MI,
                     '',SPRIDEN_LAST_NAME||', '||SPRIDEN_FIRST_NAME,
                     SPRIDEN_LAST_NAME||', '||SPRIDEN_FIRST_NAME||' '||
                     SUBSTR(SPRIDEN_MI,1,1)), 40, ' '); 

/*Cursor to collect the program for the division of the select of most       */
/*recent record for a student.                                               */
 EXEC SQL DECLARE get_programs CURSOR FOR
      SELECT DISTINCT RPAD(SMRRQCM_PROGRAM, 12, ' ')
      FROM   SMRRQCM
      WHERE  SMRRQCM_PIDM = TO_NUMBER(:pidm)
      ORDER BY RPAD(SMRRQCM_PROGRAM, 12, ' ');

/*Cursor to collect the parameter value for this job's run.                  */
 EXEC SQL DECLARE parm_cursor CURSOR FOR
      SELECT GJBPRUN_VALUE
      FROM   GJBPRUN
      WHERE  GJBPRUN_NUMBER = :parm_number
      AND    GJBPRUN_JOB = UPPER(:job)
      AND    GJBPRUN_ONE_UP_NO = TO_NUMBER(:one_up_no);
 
/*Get the most recent record and hold on to it.                              */
 EXEC SQL DECLARE get_most_recent_record CURSOR FOR
      SELECT RTRIM(RPAD(TO_CHAR(MAX(SMRRQCM_REQUEST_NO)),10, ' '))
      FROM   SMRRQCM
      WHERE  SMRRQCM_PIDM                   = TO_NUMBER(:pidm)
      AND    RPAD(SMRRQCM_PROGRAM, 12, ' ') = :prog_name;

/*Get the print record to be deleted.                                        */
 EXEC SQL DECLARE get_print_rec CURSOR FOR
      SELECT RPAD(SMRPRRQ_CPRT_CODE, 12, ' '), 
             RTRIM(TO_CHAR(SMRPRRQ_REQUEST_NO)), 
             SMRPRRQ_PIDM, RPAD(SPRIDEN_ID, 9, ' '),
             RPAD(DECODE(SPRIDEN_MI,
                  '',SPRIDEN_LAST_NAME||', '||SPRIDEN_FIRST_NAME,
                  SPRIDEN_LAST_NAME||', '||SPRIDEN_FIRST_NAME||' '||
                  SUBSTR(SPRIDEN_MI,1,1)),40,' ') 
      FROM   SMRPRRQ, SPRIDEN
      WHERE  SMRPRRQ_PIDM = SPRIDEN_PIDM 
      AND    SPRIDEN_CHANGE_IND IS NULL
      AND    TO_DATE(TO_CHAR(TRUNC(SMRPRRQ_REQUEST_DATE),'DD-MON-YYYY'), 
                     'DD-MON-YYYY') <= TO_DATE(:hard_date,'DD-MON-YYYY')
             ORDER BY RPAD(DECODE(SPRIDEN_MI,
             '',SPRIDEN_LAST_NAME||', '||SPRIDEN_FIRST_NAME,
             SPRIDEN_LAST_NAME||', '||SPRIDEN_FIRST_NAME||' '||
             SUBSTR(SPRIDEN_MI,1,1)), 40, ' '), SMRPRRQ_CPRT_CODE,
             SMRPRRQ_REQUEST_NO;


/*Get the atype names to be deleted from sprcolr.                           */
 EXEC SQL DECLARE atype_value CURSOR FOR 
      SELECT SPRCOLR_VALUE_ATYP
      FROM   SPRCOLR
      WHERE  SPRCOLR_JOB         = :job
      AND    SPRCOLR_SESSIONID   = :sessionid
      AND    SPRCOLR_PARM_NUMBER = :parm_value;


/*Get the Print code to be deleted from smrprrq.                           */
 EXEC SQL DECLARE print_del CURSOR FOR
      SELECT RPAD(SMRPRRQ_CPRT_CODE, 12, ' ')  
      FROM   SMRPRRQ
      WHERE  SMRPRRQ_PIDM        = TO_NUMBER(:pidm)
      AND    SMRPRRQ_REQUEST_NO  = TO_NUMBER(:cur_req);

 EXEC SQL DECLARE count_del CURSOR FOR
      SELECT COUNT(*)
      FROM   SMRPRRQ
      WHERE  SMRPRRQ_PIDM        = TO_NUMBER(:pidm)
      AND    SMRPRRQ_REQUEST_NO  = TO_NUMBER(:cur_req);
/****BOTTOM*/  



