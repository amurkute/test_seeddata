/* AUDIT TRAIL: 8.0                                                         */
/* TAM 10/08/2007                                                           */
/* 1. Internationalization unicode conversion                               */
/* AUDIT TRAIL END                                                          */
#include "tmcilib.h"
#include "unicode/umsg.h"

U_CAPI int32_t
tmu_vformatMessage(const char    *locale,
				   const TMCHAR  *pattern,
				   int32_t        patternLength,
				   TMCHAR        *result,
				   int32_t        resultLength,
				   va_list        ap,
				   UErrorCode    *status);


U_CAPI int32_t
tmumsg_vformat( UMessageFormat *fmt,
                TMCHAR         *result,
                int32_t        resultLength,
                va_list        ap,
                UErrorCode     *status);
