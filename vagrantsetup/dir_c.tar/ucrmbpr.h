/* ************************************************************************** */
/* select macro to select accounts when only more than one cycle range        */
/* is input                                                                   */
/* ************************************************************************** */
/* Audit Trail 								      */
/* Release 2.03 -C
/*----------------------------------------------------------------------------*/
/* ##   INIT   DATE     	DESCRIPTION				      */
/* --   ----   -----     -----------------------------------------------------*/
/* 1.   JCHODAV 08/01/96 Modified the selects in the SelectAccount() to       */
/*			 include the new parameter ACCOUNT.		      */
/* 2.   ''		 Modifed the where clauses in all the selects which is*/
/* 			 using printed date to use uabopen_printed_date       */
/* 3.			 The mainselect for fetching open items is changed    */
/*                       to include begin and end printed dates given by the  */
/*			 user.						      */
/* 4.   GF     02/02/98  Removed bugs from <SCR1650> 			      */
/* AUDIT TRAIL:8.0 */
/* AUDIT TRAIL END */
/* -------------------------------------------------------------------------- */

static short SelectAccounts(char *pszCycle, long *plCustCode,
                            char *pszPremCode);
/* **************************************************** */
static int body(PLLIST pLLCycleTotals);
static void OtherFunc(long lRowsFetched,PLLIST pLLCycleTotals);
static int getbill(PLLIST pLLCycleTotals);
static void OtherF(long lRowsFetched);
static int FetchOpenItems(long lCustCodeParm, char *pszPremCode,long lBHSTParm);
static int SelectBills(long lCustCodeParm, char *pszPremCode,
                       long *plBHST);
static int GetPresentReading(void);
static int GetPreviousReading(void);
static int GetPreviousDateFlat(void);
static int GetPresentDateFlat(void);
static int GetDOS(void);
static int get_adjs_unprinted(int mode);
static int GetConsumptionHist(void);
static int GetConnectSize(void);
static int GetAdjustments(long lCustCodeParm, char *pszPremCode,
                           long lBHSTParm);
static int SelectBillHistTotals(long lBHSTParm);
static int TotalPrevBalUnBilled(void);
static int TotalPaymentsUnBilled(void);
/* static void GetRateInfo(PBREG pBReg);  */
static void GetExceptionUBRACEX(char *pszException, long lLen);
static int CheckDraftStatus(void);
static void GetDiscount(double *pdDiscount, short sNi,
                        char *pszUtrsratDiscountRate);
static void CalculateDiscount(double *pdDiscount, char *pszRate);

#ifndef UCRMBPR_H
#define UCRMBPR_H

#define    SINGLE_PARM               1
#define    MAX_PARMS                20
#define    MULTIPLE_SELECT_VALUE   100

/*-- Column Defines  ---------------------------------------------------------*/
/**************  CUST/PREM LINE  */
#define L1_COL1               0
#define L1_COL2               9
#define L1_COL3              50 
#define L1_COL4              60
#define L1_COL5              105

/**************  OPEN ITEM LINE  */
#define L2_COL1               0     /* service # */
#define L2_COL2               5     
#define L2_COL3              10
#define L2_COL4              15
#define L2_COL5              20
#define L2_COL6              32
#define L2_COL7              37
#define L2_COL8              47
#define L2_COL9              53
#define L2_COL10             63
#define L2_COL11             69
#define L2_COL12             80
#define L2_COL13             93
#define L2_COL14            105 
#define L2_COL15            114
#define L2_COL16            124

/**************     BILL TOTALS  */
#define L3_COL1              0
#define L3_COL2              10
#define L3_COL3              22
#define L3_COL4              32
#define L3_COL5              44
#define L3_COL6              57
#define L3_COL7              69
#define L3_COL8              79
#define L3_COL9              91
#define L3_COL10             100
#define L3_COL11             112
#define L3_COL12             122
#define L3_COL13             134
#define L3_COL14             144

/**************  CYCLE TOTALS  */
#define L4_COL1              0
#define L4_COL2              10
#define L4_COL3              19
#define L4_COL4              25
#define L4_COL5              42
#define L4_COL6              52
#define L4_COL7              64
#define L4_COL8              91
#define L4_COL9             105
#define L4_COL10            121

/**************  OPEN ITEM DETAIL */
#define L5_COL1              15
#define L5_COL2              27
#define L5_COL3              39
#define L5_COL4              50
#define L5_COL5              78
#define L5_COL6              80
#define L5_COL7              92

typedef enum 
   {PG_DEFAULT, PG_DETAIL, PG_CYCLE_TOTAL, PG_GRAND_TOTAL} PAGETYPE;           
/*----------------------------------------------------------------------------*/

#define EXEC_NAME            "UCRMBPR"  /* the name of this program */
#define PAGE_WIDTH           131
#define DEFAULT_REPORT_TITLE "Billing Register"
/******************************************************************************/
/* parameter name strings                                                     */
/******************************************************************************/
#define   STR_LINES_PER_PAGE      "   Lines per page"
#define   STR_RECORD_COUNT        "     Record Count"
#define   STR_PRINTED_DATE        "     Printed date"
#define   STR_CYCLE_RANGE         "      Cycle range"
#define   STR_EXCEPTIONS_ONLY     "  Exceptions only"
#define   STR_OUT_OF_CYCLE_IND    "     Out of cycle"
#define   STR_NO_ACTIVITY_BILLS   "No Activity Bills"
#define   STR_BEGIN_PRINTED_DATE  " Start Print Date"
#define   STR_END_PRINTED_DATE    "   End Print Date"
#define   STR_ACCOUNT             "          Account"
#define   STR_BILLED_UNBILLED     "  Billed/Unbilled"
/***************************************************************************/
typedef struct BREGKEY
   {
   char   szSTYP      [5];
   char   szSCATCode  [5];
   char   szSRATCode  [5];
   } BREGKEY, *PBREGKEY;

typedef struct BREG
   {
   BREGKEY   BRegKey;
   char      szCYCLCode      [ 6];
   char      szRegExcInd     [ 2];
   char      szRateDesc      [31];
   char      szRevenueInd    [ 2];
   char      szTaxableInd    [ 2];

   short     sChargedThisCycle;
   double    dBilledConsump;
   double    dBilledCharge;
   double    dBudgetChg;
   double    dBudgetVariance;
   double    dGrnBudgetChg;
   double    dGrnBudgetVariance;
   double    dDiscounts;
   double    dGrnBilledConsump;
   double    dGrnBilledCharge;
   double    dGrnDiscounts;
   } BREG, *PBREG;


#endif
