/* AUDIT TRAIL: 8.0 */
/* AUDIT TRAIL END */
/******************************************************************************/
/* LOCAL FUNCTION PROTOTYPES                                                  */
/******************************************************************************/

static void  extract_billhead           ( void );
static void  extract_detail_ind_chg     ( void );
static void  extract_detail_ind_tax     ( void );
static void  extract_detail_grp_chg     ( void );
static void  extract_detail_grp_tax     ( void );
static void  extract_histinfo           ( void );
static void  extract_utiladdr           ( void );
static void  extract_budginfo           ( void );
static void  extract_servhead           (void  );
static void  extract_serviceaddr        (void  );
static void  extract_BaseCharge         (void  );
static void  extract_PrimaryRate        (void  );
static void  extract_SubordRate         (void  );
static void  extract_Tax                (void  );
static void  extract_Adj                (void  );
static void  extract_TL                 (void  );
static void  extract_Misc               (void  );
static void  extract_Penalty            (void  );
static void  extract_Loan               (void  );
static void  extract_Deposit            (void  );
static int   BillSelmacro               (int mode);
static int   ServiceSelmacro            (int mode);
static int   ConsSelmacro               ();
static void  BillHead                   (void);
static void  ServiceHead                (void);
static void  ConsHead                   (void);
static void  recfoot                    (void);
static void  Init_ServHead              (void);
static void  Extract_BillDetail         (void);
static void  Init_BaseCharge            (void);
static void  Init_PrimaryRate           (void);
static void  Init_SubordRate            (void);
static void  Init_Tax                   (void);
static void  Init_TotalLine             (void);
static void  Init_Misc                  (void);
static void  Init_Penalty               (void);
static void  Init_Loan                  (void);
static void  Init_Deposit               (void);
static void  Init_Adjustment            (void);
static void Extract_BillMessages        (void);


/******************************************************************************/
/* Function prototypes for the DOCUCORP modification to enable extract of     */
/* weather data.  These prototypes were copied from the base version of       */
/* ubpbpfm.c                                                                  */
/******************************************************************************/
static int  CalcDegreeDays(char *pszPresentDate, char *pszHeat, char *pszCool,
                           int dTimePeriod);
static int  IncludeWeather(void);      /* included for weather data reporting */
static int  SelectWeather(void);           /* uobsysc print weather indicator */
