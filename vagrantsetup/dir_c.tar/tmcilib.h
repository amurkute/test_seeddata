/****************************************************************************/
/*                                                                          */
/* Copyright 2007-2014 Ellucian Company L.P. and its affiliates.            */
/*                                                                          */
/****************************************************************************/
/* AUDIT TRAIL: 8.0                                                         */
/* TAM 10/08/2007                                                           */
/* 1. Internationalization unicode conversion                               */
/* AUDIT TRAIL: 8.1                                                         */
/* PJD 06/02/2008                                                           */
/* 1. Fixed missing comment tag on line 276 to address defect 1-3NZDFP      */
/* AUDIT TRAIL: 8.2.0.1                                                     */
/* LVH 09/09/2009                                                           */
/* 1. Added #define tmstrerror(n) _TMV(strerror(n)) to address              */
/*    defect 1-4TV8NQ                                                       */
/* AUDIT TRAIL: 8.6.3.2                                                     */
/* 1. Enhancement CR-000110134                                              */
/*    HVT / LVH 03/20/2014                                                  */
/*    Clean up for ICU 52.1                                                 */
/* AUDIT TRAIL END                                                          */
/*
TranMan Internationalization (I18N) Library include file for C.
Provides I18N functions for C,C++ and Pro*C programs converted with TranMan.
*/

#ifndef _TMCILIB_H
#ifdef ORA_PROC
#define _W64
#endif
#include "unicode/utypes.h"
#include "unicode/ures.h"
#include "unicode/ustdio.h"
#include "unicode/ustring.h"
#include "tmmapping.h"


/* define for a char that cannot become UChar */
#define TMCHAR8 char


#if defined (TMCILIB_EXPORTS)
#define TM_API  U_EXPORT
#elif defined TMCILIB_STATIC
#define TM_API
#else
#define TM_API  U_IMPORT
#endif


/* get default values using the following envs*/
#define RUN_LOCALE	 "RUN_LOCALE"
#define RUN_CODEPAGE "RUN_CODEPAGE"



#ifdef __cplusplus
#define TMC_STRUCT
extern  "C" {
#else
#define TMC_STRUCT struct
#endif

#define TMNUMSYMBOLSIZE 10
typedef TMCHAR TMNumSymbol[TMNUMSYMBOLSIZE]; /* group separator, decimal separator, currency */

/*
TranMan includes a TMBundle struct in the I18N Header of files.
This structure is used in locale aware message formatting and printing, file io and parsing.
*/
/* use const char* below
struct
TMBundle {
	char* bundleName;
	char* locale;
	char* codepage;
	UResourceBundle* uResB;
	void* strmap;			//* will point to a map with strings (void* for c compatibility) * /
	TMNumSymbol numDecSep;
	TMNumSymbol numGrpSep;
	TMNumSymbol currencySymbol;
};
*/

struct
TMBundle {
	const char* bundleName;
	const char* locale;
	const char* codepage;
	UResourceBundle* uResB;
	void* strmap;			/* will point to a map with strings (void* for c compatibility) */
	TMNumSymbol numDecSep;
	TMNumSymbol numGrpSep;
	TMNumSymbol currencySymbol;
};

/*
use tmBundleCNum for tmprintf's with plain C number formatting
*/

extern TM_API TMC_STRUCT TMBundle tmBundleCNum;

/*
standard io stream replacements
*/
extern TM_API UFILE* tmstdout;
extern TM_API UFILE* tmstdin;
extern TM_API UFILE* tmstderr;

/*
Function to retrieve a translated resource.
If the resource cannot be loaded the default string defstr is returned.
*/
TM_API TMCHAR*
TM_B_NLS_Get(TMC_STRUCT TMBundle *tmResB, char* numkey, char* defstr);

/*
Macro wrapper for TM_B_NLS_Get hiding the standard &tmBundle argument.
It is inserted by TranMan for translatable strings.
*/
#define TM_NLS_Get(key,defstr) TM_B_NLS_Get (&tmBundle,key,defstr)

/*
In Header files TranMan inserts TM_NLS_HGet. The TMBundle argument
name is unique for the header file as tmBundle is already a variable in the
C file.
*/
#define TM_NLS_HGet TM_B_NLS_Get

/*
Can store and retrieve TMCHAR* texts with following 2 routines.
Insert stores a copy of val which lives until the program terminates.
Use Get to retrieve the copy stored with Insert.
*/
TM_API const TMCHAR* namedResourceInsert(char* context, char* key, TMCHAR* val);
TM_API const TMCHAR* namedResourceGet(char* context, char* key);



/**** stdio replacement functions ***/
#define tmfflush(f) u_fflush(f)

TM_API UFILE*
tmfopen(struct TMBundle *tmResB, const TMCHAR *filename,const TMCHAR *perm);

TM_API int
tmprintf(struct TMBundle *tmResB, const TMCHAR *pattern, ...);

TM_API int
tmvprintf(struct TMBundle *tmResB, const TMCHAR *pattern,va_list argptr );

TM_API int
tmfprintf(struct TMBundle *tmResB, UFILE *ustream, const TMCHAR *pattern, ...);

TM_API int
tmvfprintf(struct TMBundle *tmResB, UFILE *ustream, const TMCHAR *pattern, va_list argptr);

TM_API int
tmsprintf(struct TMBundle *tmResB, TMCHAR *buffer, const TMCHAR *pattern, ...);

TM_API int
tmvsprintf(struct TMBundle *tmResB, TMCHAR *buffer, const TMCHAR *pattern, va_list argptr);

TM_API void
tmfclose(UFILE*);

TM_API void
tmfcloseall();

TM_API int
tmferror(UFILE*);

TM_API TMCHAR* tmfgets(TMCHAR* ,int ,UFILE*);


#define tmgets(s)       tmfgets(s,10000,tmstdin); /* TM equivalent for gets */
#define tmgetc(f)		u_fgetc(f)
#define tmfgetc(f)		u_fgetc(f)
#define tmputc(uc,f)	u_fputc(uc,f)
#define tmfputc(uc,f)	u_fputc(uc,f)
#define tmgetchar()		u_fgetc(tmstdin)
#define tmputchar(uc)	u_fputc(uc,tmstdout)
/* #define tmfputs(us,f)	u_fputs(us,f) // u_fputs puts newline at end. This is not ANSI. */
#define tmfputs(us,f)	u_file_write(us, u_strlen(us), f)
#define tmputs(us)		u_fputs(us,tmstdout)
#define tmfseek(f,offset,origin) fseek(u_fgetfile(f),offset,origin)
#define tmfsetpos(f,pos) fsetpos(u_fgetfile(f),pos)
#define tmfgetpos(f,pos) fgetpos(u_fgetfile(f),pos)
#define tmftell(f) ftell(u_fgetfile(f))


/**** end stdio replacement functions ***/

/*** string functions ***/

TM_API TMCHAR* tmstrrchr(const TMCHAR*, TMCHAR);
TM_API int tmatoi(const TMCHAR*);
TM_API long tmatol(const TMCHAR*);
TM_API double tmatof(struct TMBundle*, const TMCHAR*);
TM_API char*  tmtochar8(TMCHAR*);
TM_API void tmperror(TMCHAR*);
#define tmstrerror(n) _TMV(strerror(n))
TM_API TMCHAR* tmstrtok(TMCHAR *src, const TMCHAR *delim);
TM_API TMCHAR* tmfromchar8(TMCHAR* dst, const TMCHAR8 *src, const int len);
TM_API long tmstrtol(const TMCHAR*, TMCHAR**, int base);


/*
Another Function to get a Unicode string from an 8 bit string
dst can be NULL to get a pointer to internal storage.
The internal storage will be overwritten on the next call
with dst=NULL
*/
TM_API TMCHAR* tmcpyfromchar8(TMCHAR *dst, const TMCHAR8 *src);

/*** end string functions ***/


/* main function and arguments */
TM_API UChar**
args2UChar_open(int argc, const char** argv, char* codepage);
TM_API void
args2UChar_close(int argc, UChar** argv);

/*
  Define a main macro to replace the command line arguments
  with their UChar* values. The NULL in args2UChar_open means take the system cp.
  Change to UTF8 or other codepage if required.
  Keep a pointer to the original char** argv in main_char_argv
*/

static char **main_char_argv;
#ifdef TM_ON_STARTUP
void TM_ON_STARTUP();
#define main(a,b) \
	tmmain(a,b);\
	int main(int argc, char **argv){ \
		int rval;\
		TMCHAR **argvu=args2UChar_open(argc, (const char**) argv, NULL);\
		main_char_argv= (char**) argv;\
		TM_ON_STARTUP();\
		rval=tmmain(argc, (UChar**) argvu);\
		args2UChar_close(argc,argvu);\
		return rval;\
	}\
	tmmain(a,b)
#else /* #ifdef TM_ON_STARTUP */
#define main(a,b) \
	tmmain(a,b);\
	int main(int argc, char **argv){ \
		int rval;\
		TMCHAR **argvu=args2UChar_open(argc, (const char**) argv, NULL);\
		main_char_argv= (char**) argv;\
		rval=tmmain(argc, (UChar**) argvu);\
		args2UChar_close(argc,argvu);\
		return rval;\
	}\
	int tmmain(a,b)
#endif /* #ifdef TM_ON_STARTUP */

/* Pro*C specials */
#define UTEXTFIX(a) sizeof(a[0])==2?2*(tmstrlen((TMCHAR*)a)+1):0
#define TMVARCHAR uvarchar
#ifdef ORA_PROC
	/*
	The Oracle precompiler uses utext for UCS2 encoded string.
	Though this is not exactly UTF16 it is OK in most practical cases.
	*/
	#undef TMCHAR
	#define TMCHAR utext

#else
	/* #include "oratypes.h" */
	#define utext TMCHAR
#endif /*ORA_PROC*/

/* alternative for #include <sqlucs2.h> */
typedef uint16_t ub2;
typedef uint32_t ub4;

struct uvarchar  {ub2 len;  utext arr[1];};
typedef struct uvarchar uvarchar;
struct ulong_varchar  {ub4 len;  utext arr[1];};
typedef struct ulong_varchar ulong_varchar;


/* Character conversion macro's
Macro _TMC to convert text literals to TMCHAR*
Macro _TMV to convert char* variables to TMCHAR*
Function TM2UChar to get a UChar* 'copy' of a char* text.
  'copy' will live until the program terminates.
*/


TM_API TMCHAR* TM2UChar(char *str8);
#define _TMV(x) TM2UChar(x)
#if U_SIZEOF_WCHAR_T != 2
#define _TMC(x) TM2UChar(x)
#else
/* L"Text" is initialised UChar compatible by compiler */
#define _TMC(x) L ## x
#endif


/* stdlib replacements for getenv/setenv */
#define tmgetenv(a) TM2UChar(getenv( tmtochar8(a)))
#define tmsetenv(a) setenv(tmtochar8(a))

/* system replacement */
TM_API int tmsystem(TMCHAR*);


/* Miscellaneous TranMan functions and defines */

/*	Provide a "Constructor" for c library modules with without main()
	to initialize global variables with translations.
*/
struct TMInitGlob {
	int ok;
	#ifdef __cplusplus
	public:
		inline TMInitGlob(void (*p)(void)){
			(*p)();
			ok=true;
		};
	#endif
};

/* Macro's to avoid code to blow up with initialisation */
#define TMCHARPTR_GLOB_DCL(name,msg) name;\
void _tmInitCharPtr_##name(void){\
	name=msg;\
}
#define TMCHARRAY_GLOB_DCL(name,size,msg) name[size]={0};\
void _tmInitArrayOfChar_##name(void){\
	tmstrncpy(name,msg,(size-1));\
	name[(size-1)]=0;\
}


#if defined(ORA_PROC)
    /* Assume  NUMSTR && CHARNN are just TMCHAR */
    #define TMCHARRYT_GLOB_DCL(name,size,msg) name[size]={0}
#else
  #define TMCHARRYT_GLOB_DCL(name,size,msg) name={0};\
  void _tmInitArrayOfChar_##name(void){\
	tmstrncpy(name,msg,(size-1));\
	name[(size-1)]=0;\
  }
#endif

#define TMCHARPTRARRAY_GLOB(name) \
void _tmInitArrayOfCharPtr_##name(void)

/* Call the Initialisation Routine*/
#define TMCHARPTR_GLOB_INIT(name) _tmInitCharPtr_##name()
#define TMCHARRAY_GLOB_INIT(name) _tmInitArrayOfChar_##name()
#define TMCHARRYT_GLOB_INIT(name) _tmInitArrayOfChar_##name()
#define TMCHARPTRARRAY_GLOB_INIT(name) _tmInitArrayOfCharPtr_##name()


/* Initialise an array inside functions
TODO check if tmstrncpy stops at 0 char.
If not some copying can be avoided
*/
#define TMCHARRAY_LOCAL_INIT(name,size,msg)\
	tmstrncpy(name,msg,(size-1));\
	name[(size-1)]=0

/* Banner Numbers */
/*
#define INIT_NUMSTR_NULL( varn) TMCHAR varn[27]={0}
*/

#define BANNUMSTR(a) TMCHAR a[27]
#define BANNUMSTRARR(vname, length) TMCHAR vname[length][27]

typedef TMCHAR DATSTR[32];
#define BANDATSTR(a) TMCHAR a[32]

/* memset */
/*Not really beautiful what we do next,
  but next define fixes many issues of the form:
  memset( astring, 'x', sizeof(astring));
  Compiler should warn when memset arg0 not a TMCHAR[] type.
  Manual fix is required then.
*/
#define tmcharsizeof(a) (sizeof(a)/sizeof(TMCHAR))

/* Added below line for 1-34NC4I */
#define tmmemset_s u_memset

#define tmmemset(dst, val, siz) \
  if (siz == sizeof(dst)) \
    u_memset(dst,val, tmcharsizeof(dst)); \
  else \
    u_memset(dst,val, siz)


#define tmmemsetb memset

/* Add global variables for Oracle Date Formats */
/* Assume they can be derived from environment settings*/
extern TM_API TMCHAR *ORA_NLS_DATE_FORMAT;
extern TM_API TMCHAR *ORA_NLS_TIME_FORMAT;
extern TM_API TMCHAR *ORA_NLS_DATE_TIME_FORMAT;

/* Spell out a double */
extern TM_API TMCHAR* spellOutNumber(struct TMBundle *tmResB, double num_in, TMCHAR *txt_out);

/* Spell out a US formatted Number text */
extern TM_API TMCHAR* spellOutNumStr(struct TMBundle *tmResB, TMCHAR *numstr_in, TMCHAR *txt_out);

#ifdef __cplusplus
}
#endif

/* macro's to use the stdlib functions rather than the Unicode variants */
#define tmstrcpy8 strcpy


#define _TMCILIB_H
#endif  /*_TMCILIB_H*/
/*
Make sure tmBundle is not defined after include of this header
*/
#ifdef tmBundle
#undef tmBundle
#endif
