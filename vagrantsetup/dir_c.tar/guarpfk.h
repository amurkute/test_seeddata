/*TMCI18N BEGIN HEADER*/
#if !defined( _TMBGUARPFK_H_EXISTS )
/*#define TM_ON_STARTUP tmInitGlobS_guarpfk */
#include "tmcilib.h"
static struct TMBundle _TMBGUARPFK_H = {"guarpfk.h",NULL,NULL,NULL,NULL};
#define _TMBGUARPFK_H_EXISTS
#endif
/*TMCI18N END HEADER*/

/* AUDIT_TRAIL_TM63
-- TranMan 6.3 
-- PROJECT : PVV_TEST
-- MODULE  : GUARPFK
-- SOURCE  : enUS
-- TARGET  : I18N
-- DATE    : Thu Dec 20 05:26:57 2007
END AUDIT_TRAIL_TM63 */
/* Object: guarpfk.h
   Author: John Morgan
 Mod Date: 5/17/95
  Release: 2.1.5
*/

/***************************************************/
/*                                                 */
/*       CONFIDENTIAL BUSINESS INFORMATION         */
/*                                                 */
/*      **********************************         */
/*                                                 */
/*  THIS PROGRAM IS PROPRIETARY INFORMATION OF     */
/* SYSTEMS AND COMPUTER TECHNOLOGY CORPORATION     */
/* AND IS NOT TO BE COPIED, REPRODUCED, LENT OR    */
/* DISPOSED OF, NOR USED FOR ANY PURPOSE OTHER     */
/* THAN THAT FOR WHICH IT IS SPECIFICALLY PROVIDED */
/* WITHOUT THE WRITTEN PERMISSION OF SAID COMPANY  */
/*                                                 */
/***************************************************/

/* AUDIT TRAIL: 2.1.5                              INIT      DATE           */
/*                                                                          */
/* 1. New BANNER object - started life as          JWM     08/17/95         */
/*    tabrpf.h, a part of the SCTCCONV project.                             */
/*                                                                          */
/* AUDIT TRAIL : 8.0 (I18N) *//* AUDIT TRAIL END                                                          */

/* This header file is included twice by guaprpf.c, the first time to create
   an enumeration list of codes for RPF keywords, and the second time to
   create an array, called rpfkey, of pointers to string literals
   representing each of the keywords.  This method greatly simplifies
   modifying the keyword list.
*/

 


#ifndef _GUARPFK_H_
#define DTAB(c,s) c,

enum {
#else
#define DTAB(c,s) s,



static char *rpfkey[]={
#endif

/* format: DTAB(code,string)

   where
      code - mnemonic for the keyword
      string - upper-case RPF keyword
*/
/*
DTAB(RPF_APN,TM_NLS_HGet( &_TMBGUARPFK_H, "0000","APN"))     
DTAB(RPF_B,_TMC("B"))
DTAB(RPF_CEN,TM_NLS_HGet( &_TMBGUARPFK_H, "0001","CEN"))
DTAB(RPF_CL,TM_NLS_HGet( &_TMBGUARPFK_H, "0002","CL"))
DTAB(RPF_CONCAT,TM_NLS_HGet( &_TMBGUARPFK_H, "0003","CONCAT"))
DTAB(RPF_CS,TM_NLS_HGet( &_TMBGUARPFK_H, "0004","CS"))
DTAB(RPF_CUL,TM_NLS_HGet( &_TMBGUARPFK_H, "0005","CUL"))
DTAB(RPF_DT,TM_NLS_HGet( &_TMBGUARPFK_H, "0006","DT"))
DTAB(RPF_F,_TMC("F"))         
DTAB(RPF_FR,TM_NLS_HGet( &_TMBGUARPFK_H, "0007","FR"))
DTAB(RPF_HS,TM_NLS_HGet( &_TMBGUARPFK_H, "0008","HS"))       
DTAB(RPF_I,_TMC("I"))
DTAB(RPF_L,_TMC("L"))
DTAB(RPF_N,_TMC("N"))
DTAB(RPF_NC,TM_NLS_HGet( &_TMBGUARPFK_H, "0009","NC"))
DTAB(RPF_NP,TM_NLS_HGet( &_TMBGUARPFK_H, "0010","NP"))
DTAB(RPF_P,_TMC("P"))
DTAB(RPF_PAGE,TM_NLS_HGet( &_TMBGUARPFK_H, "0011","PAGE"))
DTAB(RPF_PAUSE,TM_NLS_HGet( &_TMBGUARPFK_H, "0012","PAUSE")) 
DTAB(RPF_R,_TMC("R"))
DTAB(RPF_RR,TM_NLS_HGet( &_TMBGUARPFK_H, "0013","RR"))
DTAB(RPF_S,_TMC("S"))
DTAB(RPF_SP,TM_NLS_HGet( &_TMBGUARPFK_H, "0014","SP"))       
DTAB(RPF_SPN,TM_NLS_HGet( &_TMBGUARPFK_H, "0015","SPN"))
DTAB(RPF_T,_TMC("T"))
DTAB(RPF_TE,TM_NLS_HGet( &_TMBGUARPFK_H, "0016","TE"))
DTAB(RPF_TTL,TM_NLS_HGet( &_TMBGUARPFK_H, "0017","TTL"))
DTAB(RPF_TTLU,TM_NLS_HGet( &_TMBGUARPFK_H, "0018","TTLU"))   
DTAB(RPF_UL,TM_NLS_HGet( &_TMBGUARPFK_H, "0019","UL"))
DTAB(RPF_VS,TM_NLS_HGet( &_TMBGUARPFK_H, "0020","VS"))       
*/

DTAB(RPF_APN,"APN")     /* n/a */
DTAB(RPF_B,"B")
DTAB(RPF_CEN,"CEN")
DTAB(RPF_CL,"CL")
DTAB(RPF_CONCAT,"CONCAT")
DTAB(RPF_CS,"CS")
DTAB(RPF_CUL,"CUL")
DTAB(RPF_DT,"DT")
DTAB(RPF_F,"F")         /* n/a */
DTAB(RPF_FR,"FR")
DTAB(RPF_HS,"HS")       /* n/a */
DTAB(RPF_I,"I")
DTAB(RPF_L,"L")
DTAB(RPF_N,"N")
DTAB(RPF_NC,"NC")
DTAB(RPF_NP,"NP")
DTAB(RPF_P,"P")
DTAB(RPF_PAGE,"PAGE")
DTAB(RPF_PAUSE,"PAUSE") /* n/a */
DTAB(RPF_R,"R")
DTAB(RPF_RR,"RR")
DTAB(RPF_S,"S")
DTAB(RPF_SP,"SP")       /* n/a */
DTAB(RPF_SPN,"SPN")
DTAB(RPF_T,"T")
DTAB(RPF_TE,"TE")
DTAB(RPF_TTL,"TTL")
DTAB(RPF_TTLU,"TTLU")   /* n/a */
DTAB(RPF_UL,"UL")
DTAB(RPF_VS,"VS")       /* n/a */

#undef DTAB

#ifndef _GUARPFK_H_
END_RPF_TAB};
#define _GUARPFK_H_
#else
NULL};
#endif

/*TMCI18N BEGIN GLOBAL STRING INITIALIZATION*/
/*#ifndef ORA_PROC
void tmInitGlobS_guarpfk(void){
	TMCHARRYT_GLOB_INIT(v_data1);

	#ifdef _DEBUG
	puts("*** Initialisation tmInitGlobS_fgrfitd OK ***\n");
	#endif
}
#endif*/
 /* not defined ORA_PROC*/
/*TMCI18N END GLOBAL STRING INITIALIZATION*/
