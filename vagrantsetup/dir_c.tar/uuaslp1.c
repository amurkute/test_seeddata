/* audit trail: 2.0                                  INIT   DATE */
/* 1. Create copylib for sleep/wake processes        SRS  06/23/93 */
/* AUDIT TRAIL: 2.1.5 Supplemental                            CFIX  12/06/95  */
/* 1. Program modified by cfix.c to remedy mostly Pro*C related problems:     */
/*    split SQL concatenations joined, colons added to FETCH targets,         */
/*    file extensions added to SQL INCLUDEs, 'static' modifier removed from   */
/*    indicator variables, new logic to hadle CLOSE_CURSOR was added to SQL   */
/*    function wrappers, and object owner references were removed as part of  */
/*    BANNER2.1.  (Not all changes necessarily apply.)                        */
/* AUDIT TRAIL: 2.1.5.1                                                       */
/*                                                                            */
/* AUDIT TRAIL:8.0
/* audit trail end */
#ifndef NO_SLEEP_SW

exec oracle ifndef NO_SLEEPING_SW;
  static int     done_sleeping=1;
  static CHAR2   abnormalexit="Y";
  static int     runsw;
  static int     nextsw;
  static int     session_id;
  static int     fileext=0;
  static char    cext[20]="";
  static char    newfile[30]="";
  static char    *outputfile;
  static CHAR255 printcom="";
  static short   SwInd_01;
  static short   SwInd_02;
exec oracle endif;

#endif
