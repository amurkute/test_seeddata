/* AUDIT TRAIL:8.0 */
/* AUDIT TRAIL END */
#ifndef UOQBILP_H
#define UOQBILP_H
/****************************************************************************/
/* ## INIT    DATE   AUDIT TRAIL                                            */
/* -- ----  -------- ------------------------------------------------------ */
/*                   RELEASE:2.0.3-C   OUC/583                              */
/*  1 EBR   11/24/96 Routines to be shared between ubpbilp and ubpmbpr for  */
/*                   Orlando Utilities Commission.                          */
/*                                                                          */
/****************************************************************************/
/****************************************************************************

 UOQBILP - Common Bill Print Routines (for regular and master bill print)

 Printing Functions:

    BPPrintBarcodeZip             - Formats and prints USPS barcode digits,
                                    including check digit, to the UBRBILL table.

    BPPrintMessages               - Prints standard bill messages to the UBRBILL
                                    table using a bill message hierarchy.

    BPPrintDepositOnHand          - Prints deposit on hand information to the
                                    UBRBILL table.

    BPPrintScanLine               - Formats a 39-digit scan line, including
                                    check digits, and prints to the UBRBILL
                                    table.

    BPPrintSpecialMessages        - Prints "special" bill messages (past due,
                                    etc.) to the UBRBILL table, including a
                                    special message watermark (e.g. DO NOT PAY).

    BPPrintField                  - Prints a text or numeric field (with
                                    formatting) to the UBRBILL table.

 Non-printing functions:

   Reading Functions:

     BPSelectDOS                  - Selects days of service for metered services
                                    from the service history table (URRSHIS)
                                    using the charge calc number passed in.

     BPSelectFlatServiceData      - Selects days of service for non-metered
                                    services from the service history table
                                    (URRSHIS) using the charge calc number
                                    passed in.

     BPSelectPreviousDateFlat     -

     BPSelectPresentDateFlat      -

     BPSelectRecalcIndForUnmetered -

     BPSelectPreviousReading      -

     BPSelectPresentReading       -

     BPSelectChangeOutReadingPrev -

     BPSelectChangeOutReading     -

     BPSelectPreviousReadingNewMeter -

     BPInitShisStruc              - Initializes the SHIS_STRUC structure passed.

   Round-up (charity) Functions:

     BPIsActiveRoundUpAcct        - Returns true if round up is active based on
                                    effective date passed in.

     BPInsertRoundUp              - Inserts a round up charge into the UABOPEN
                                    table.

   Payment Arrangement Functions:

     BPUpdateInsertPmntArrng      - Updates/Inserts a row into the UARPYAR table
                                    based on the total current charges amount.

*******************************************************************************/

/* Datatype definitions */

typedef struct SHIS_STRUC {
   CHAR10  szReading;
   NUMSTR  szReading2;
   NUMSTR  szDOS;
   NUMSTR  szConsumption;
   CHAR21  szInvnCode;
   NUMSTR  szMultiplier;
   CHAR2   szHighLowExcp;
   CHAR12  szActionDate;
   NUMSTR  szChrgCalcNum;
   CHAR2   szRtypCode;
   NUMSTR  szCadjNum;
} SHIS_STRUC;


/* Function prototypes */

extern void BPPrintBarcodeZip(char *pszZip_1_5,
                              char *pszZip_7_10,
                              char *pszDeliveryPoint,
                              char *pszBarcodeLineText);

extern void BPPrintMessages(char *pszUcbcustBmsgCode,
                            char *pszUcracctBmsgCode,
                            char *pszBillProcessBmsgCode[],
                            char *pszBillPrintBmsgCode,
                            long  lSessionID,
                            char *pszCustCode,
                            char *pszPremCode,
                            char *pszAddrSelectionDate,
                            char *pszBillNum,
                            char *pszPageNum,
                            char *pszLineNum);


extern void BPPrintDepositOnHand(char *pszCustCode,
                                 char *pszPremCode,
                                 char *pszEffectiveDate,
                                 long  lSessionID,
                                 char *pszBillNum,
                                 char *pszPageNum,
                                 char *pszLineNum);

extern void BPPrintScanLine(char *pszCustCode,
                            char *pszPremCode,
                            char *pszAmountDue,
                            char *pszDueDate,
                            long  lSessionID,
                            char *pszBillNum,
                            char *pszPageNum,
                            char *pszLineNum);

extern void BPPrintSpecialMessages(char *pszAcctStatus,
                                   char *pszDraftStatus,
                                   char *pszPastDueBalance,
                                   char *pszTotalAmountDue,
                                   char *pszUobsysc_min_draft_amt,
                                   char *pszUcracct_draft_max,
                                   char *pszRtndChkInd,
                                   char *pszAccountDueDate,
                                   long  lSessionID,
                                   char *pszBillNum,
                                   char *pszPageNum,
                                   char *pszLineNum);

extern void BPPrintField(long  lSessionID,
                         char *pszBillNum,
                         char *pszPageNum,
                         char *pszLineNum,
                         char *pszText,
                         char *pszFormat,
                         char *pszTrimInd);

extern int BPSelectDOS( char *pszChrgCalcNum, char *pszDOS );

extern int BPSelectFlatServiceData( char *pszChrgCalcNum,
                                    char *pszDOS,
                                    char *pszConsumption,
                                    char *pszActionDate,
                                    char *pszRtypCode );

extern int BPSelectPreviousDateFlat( char *pszCustCode,
                                     char *pszPremCode,
                                     char *pszServNum,
                                     char *pszStypCode,
                                     char *pszScatCode,
                                     char *pszChargeDate,
                                     char *pszChrgCalcNum,
                                     char *pszReprintDate,
                                     char *pszActionDate );

extern int BPSelectPresentDateFlat( char *pszChrgCalcNum,
                                    char *pszActionDate );

extern int BPSelectRecalcIndForUnmetered( char *pszCustCode,
                                          char *pszPremCode,
                                          char *pszServNum,
                                          char *pszStypCode,
                                          char *pszScatCode,
                                          char *pszChargeDate,
                                          char *pszChrgCalcNum,
                                          char *pszHighLowExcp );

extern int BPSelectPreviousReading(char       *pszCustCode,
                                   char       *pszPremCode,
                                   char       *pszServNum,
                                   char       *pszStypCode,
                                   char       *pszScatCode,
                                   char       *pszChargeDate,
                                   char       *pszChargeCalcNum,
                                   char       *pszReprintDate,
                                   SHIS_STRUC *pstUrrshis );

extern int BPSelectPresentReading( char       *pszChrgCalcNum,
                                   SHIS_STRUC *pstUrrshis );

extern int BPSelectChangeOutReadingPrev( char       *pszCustCode,
                                         char       *pszPremCode,
                                         char       *pszServNum,
                                         char       *pszStypCode,
                                         char       *pszScatCode,
                                         char       *pszInvnCode,
                                         char       *pszChangeOutDate,
                                         SHIS_STRUC *pstUrrshis );

extern int BPSelectChangeOutReading( char *pszChrgCalcNum,
                                     char *pszInvnCode,
                                     char *pszChangeOutInd,
                                     SHIS_STRUC *pstUrrshis );

extern int BPSelectPreviousReadingNewMeter( char       *pszCustCode,
                                            char       *pszPremCode,
                                            char       *pszServNum,
                                            char       *pszStypCode,
                                            char       *pszScatCode,
                                            char       *pszInvnCode,
                                            char       *pszChargeDate,
                                            char       *pszReprintDate,
                                            SHIS_STRUC *pstUrrshis );

extern void BPInitShisStruc( SHIS_STRUC *pstUrrhis );

extern int BPIsActiveRoundUpAcct( char *pszAcctStatus,
                                  char *pszParmRoundUpStartDate,
                                  char *pszParmRoundUpEndDate,
                                  char *pszParmPrintedDate,
                                  char *pszParmRoundUpMbilInd,
                                  char *pszParmMbilSubPymtInd,
                                  char *pszParmRoundUpMbilStartDate,
                                  char *pszParmRoundUpMbilEndDate,
                                  char *pszParmRoundUpSubordInd );

extern void BPInsertRoundup(char *CustCode,
                            char *PremCode,
                            char *PrintedDate,
                            char *UobsyscSratCodeRdup,
                            char *UobsyscSratCodeMbilRdup,
                            char *AmountDueBalance,
                            char *pszUcracctRdupAmt,
                            char *pszMbilSubPymtInd,
                            char *pszOrigin,
                            char *pszMbilRdupInd );

extern void BPUpdateInsertPmntArrng( char *pszCustCode,
                                     char *pszPremCode,
                                     char *pszUcracctArrngNum,
                                     char *pszAccountDueDate,
                                     char *pszAmount,
                                     char *pszSubPymtInd,
                                     char *pszOrigin );

#endif
