/******************************************************************************/
/* URPHUFM.H  Copyright (c) SCT Corporation 1996.  All rights reserved.       */
/******************************************************************************/

/***************************************************/
/*                                                 */
/*    CONFIDENTIAL BUSINESS INFORMATION            */
/*                                                 */
/*   **********************************            */
/*                                                 */
/*  THIS PROGRAM IS PROPRIETARY INFORMATION OF     */
/* SYSTEMS AND COMPUTER TECHNOLOGY CORPORATION     */
/* AND IS NOT TO BE COPIED, REPRODUCED, LENT OR    */
/* DISPOSED OF, NOR USED FOR ANY PURPOSE OTHER     */
/* THAN THAT FOR WHICH IT IS SPECIFICALLY PROVIDED */
/* WITHOUT THE WRITTEN PERMISSION OF SAID COMPANY  */
/*                                                 */
/***************************************************/

/*----------------------------------------------------------------------------*/
/* URPHUFM.H                                                                  */
/* Handheld Upload Device Format Module                                       */
/*                                                                            */
/* This is the device specific set of subroutines to be included in the       */
/* program URPHUPL.PC.                                                        */
/*                                                                            */
/* AUDIT TRAIL                                                 INIT    DATE   */
/* ----------------------------------------------------------- ----  -------- */
/* Release: 2.0.3.3.1                                                         */
/* 1. Initial Version                                          EMC   11/08/96 */
/* ************************************************************************** */
/* AUDIT TRAIL:8.0 */
/* AUDIT TRAIL END */
#ifndef DEVICEHDR
#define DEVICEHDR /* Default device format module header */

typedef struct {
    char service_location[41];
    char i_o_building_ind[2];
    char remote_phone[11];
    char radio_freq[11];
    char key_id[11];
    char seal_num[9];
    char clor_code[3];
    char route[6];
    char reading_seq[6];
    char over_under_ind[2];
    char lf_percent[4];
} UCRSERV;

typedef struct {
    char serial_num[21];
    char manf_code[3];
    char model[21];
    char whse_code[7];
    char amst_code[10];
    char phas[2];
    char form[5];
    char scls_code[3];
    char wires[2];
    char volts[5];
    char amps[5];
    char rrat[10];
    char sint[5];
    char smax[8];
    char measure_meth_ind[2];
    char ctpt_ind[2];
    char maxflow[7];
    char laylng[8];
    char psi[7];
    char transponder_id[16];
} UIBMINV;

typedef struct {
    char num_dials[3];
    char decpos[2];
    char cum_peak_ind[2];
    char uoms_code[5];
    char stus_code[2];
    char multiplier[10];
    char num_dead_dials[3];
    char cnsz_code[5];
    char primary_reg_ind[2];
} UIRDIAL;

typedef struct {
    char prem_code[8];
    char cust_code[10];
    char invn_code[21];
    char serv_num[5];
     int error;              /* Device format error indicator */
    char comments[133];      /* Vendor defined comments */
    char user_id_remind[31]; /* User to remind */
    char suspense_date[12];  /* Date on which to remind user DD-MON-YYYY */
   LLIST *pLLNoteLines;
} MISC;

typedef struct {
    char scat_seq_num[3];
    char reading[12];
    char mtrd_code[5];
    char trbl_code_1[5];
    char trbl_code_2[5];
    char trbl_code_3[5];
    char reas_code[5];       /* This is posted to URRSHIS_REAS_CODE */
    char action_date[12];    /* Date of field reading DD-MON-YYYY */
    char hh24[3];            /* Hour of day 0-23 */
    char mi[3];              /* Minute 0-59 */
    char ss[3];              /* Second 0-59 */
} REG;

typedef struct {
    long line_num;
    char text[76];
} HHNOTE;

extern UCRSERV Ucrserv, *pUcrserv;
extern UIBMINV Uibminv, *pUibminv;
extern UIRDIAL Uirdial, *pUirdial;
extern MISC Misc, *pMisc;
extern REG Reg, *pReg;
extern HHNOTE HHnote, *pHHnote;
extern int OpenVendorUplFile(char *pszUplFileName);
extern int ReadVendorRecord(char *pszUplFileName);                  
extern int ReadVendorRegisterRecord(char *pszUplFileName);                  
extern int VendorUpdate(void);
extern int CloseVendorUplFile(char *pszUplFileName);

#endif
