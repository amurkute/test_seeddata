/******************************************************************************/
/* UBPMBFM.C  Copyright (c) SCT Corporation 1994.  All rights reserved.       */
/******************************************************************************/

/***************************************************/
/*                                                 */
/*       CONFIDENTIAL BUSINESS INFORMATION         */
/*                                                 */
/*      **********************************         */
/*                                                 */
/*  THIS PROGRAM IS PROPRIETARY INFORMATION OF     */
/* SYSTEMS AND COMPUTER TECHNOLOGY CORPORATION     */
/* AND IS NOT TO BE COPIED, REPRODUCED, LENT OR    */
/* DISPOSED OF, NOR USED FOR ANY PURPOSE OTHER     */
/* THAN THAT FOR WHICH IT IS SPECIFICALLY PROVIDED */
/* WITHOUT THE WRITTEN PERMISSION OF SAID COMPANY  */
/*                                                 */
/***************************************************/

#if 0
/* --------------------------------------------------------------------
   RMM This has been commented out because ubrfmat.c is included in
   ubpmbpr.pc using SQL INCLUDE instead of linking in the object module
   at compile time. 
   07/14/94 HLS Added master bill number to bill print
   AUDIT  2.0.3.2
   1. Changed PAGE_SIZE TO PAGE_SZE. BUG#7662.     JEE 22-OCT-1996
   -------------------------------------------------------------------- */
/* AUDIT TRAIL: 8.0 */
/* AUDIT TRAIL END */
#include "guarpfe.h"

#define PAGE_SZE        66
#define AR_SIZE          1000

typedef struct _NodeType
     {
     char      szStypCode [5];
     char      szUOMCode  [5];
     short     sCount;
     double    dMeteredCons;
     double    dBilledCons;
     double    dBilledAmount;
     struct _NodeType *pNext;
     } NODETYPE, *PNODETYPE;

/*------------------------    GLOBALS    ---------------------------------*/
extern short int ff_flag;
extern short int eject_flag;
extern short int uc_flag;
extern short int rpf_flag;
extern short int reverse_flag;
/*extern short int trace_flag =1; RAM */
extern short int sqltrace_flag;

extern FILE *    fpFile;
extern int       iGPageNum;
extern short     sGTotalLines;
extern short     sGLineCount;
extern short     sGRecordCount;
extern short     sGLineNum;
extern short     sGRestart;
extern char      szShortDate    [12];
extern char      szGSysDate     [19];      /* Report date                  */
extern char      szGSysTime     [9];       /* Report time                  */
extern char      szGRptUser     [31];      /* Report user                  */
extern char      szGInstitution [41];      /* Utility's Name               */
extern char      szGTitle       [51];      /* Report Title                 */

extern char    ucbmbil_prem_code        [1000][8];
extern char    ucracct_prem_code        [1000][8];
extern char    ucrserv_styp_code        [1000][5];

extern long    ucbmbil_mbil_num         [1000];
extern long    ucbmbil_cust_code        [1000];
extern long    ucracct_cust_code        [1000];
extern double  uabopen_chrg_calc_num    [1000];
extern double  uabopen_balance          [1000];
#endif


/******************************************************************************
*                                                                             *
*   PrintDetailMasterName()						      *
*                                                                             *
*   Description.....: Print to the output file the master bill number ans     *
*		      master customer address 				      *
*                                                                             *
*   Parameters:                                                               *
*                                                                             *
*        Type             Name                     Description                *
*       ------------   --------------    --------------------------------     *
*        char *        pszMasterName      Master customer name                *
*                                                                             *
*   Return Values:                                                            *
*                                                                             *
*        Type       Value     #define              Description                *
*       --------    -----   ----------------   --------------------------     *
*        void                                                                 *
*                                                                             *
******************************************************************************/
void PrintDetailMasterName( char *pszMasterName, int iInd)
{
  /*---------------------------------------------*/
  /* Output the Master Bill number and name line */
  /*---------------------------------------------*/
  fprintf(fpFile, "\n\n Master Bill Number: %9d     Master Customer: %9d %-50s",
		ucbmbil_mbil_num[iInd],
		ucbmbil_cust_code[iInd],
		pszMasterName);
  sGLineNum	+= 3;
  sGTotalLines  += 3;
  sGRecordCount++;
}	/* End PrintDetailMasterName */




/******************************************************************************
*                                                                             *
*   PrintDetailAcctHeader()                                                   *
*                                                                             *
*   Description.....: Print to the output file the detail report subordinate  *
*                     section header.                                         *
*                                                                             *
*   Parameters:                                                               *
*                                                                             *
*        Type             Name                     Description                *
*       ------------   --------------    --------------------------------     *
*        char *        pszSortString      Sort details.  cust/prem, prem/cust *
*                                         service address or user-defined     *
*                                         sub group.                          *
*                                                                             *
*   Return Values:                                                            *
*                                                                             *
*        Type       Value     #define              Description                *
*       --------    -----   ----------------   --------------------------     *
*        void                                                                 *
*                                                                             *
******************************************************************************/
void PrintDetailAcctHeader( char *pszSortString) 
{
   /*--------------------------------------*/ 
   /* Print the subordinate section header */
   /*--------------------------------------*/ 
   
   fprintf(fpFile, "\n\nSort Code: %-20s",pszSortString);
   fprintf(fpFile, "\nSort Code Summary of Service Charges:");
   fprintf(fpFile,"\n   Customer  Premises   Electric%6sLights%7sWater%7sSewer",
		" ", " ", " ");
   fprintf(fpFile, "%7sGarbage%7sGas%7sCable%7sOther%7sTotal Bdg",
		 " ", " ", " ", " ", " ");

   sGLineNum += 3;
   sGTotalLines +=3;
}



/******************************************************************************
*                                                                             *
*   PrintDetailAcctTotal()                                                   *
*                                                                             *
*   Description.....: Print to the output file the master bill number ans     *
*                     master customer address                                 *
*                                                                             *
*   Parameters:                                                               *
*                                                                             *
*        Type             Name                     Description                *
*       ------------   --------------    --------------------------------     *
*        char *        pszType            'Sub' or 'Group'                    *
*	 PCHARGENODE   totals             Structure containing the total      *
*					  charges of sub-group or total group *
*                                                                             *
*   Return Values:                                                            *
*                                                                             *
*        Type       Value     #define              Description                *
*       --------    -----   ----------------   --------------------------     *
*        void                                                                 *
*                                                                             *
******************************************************************************/
void PrintDetailAcctTotal( char *pszType, PCHARGENODE totals)
{
  /*-----------------------------------------------------------*/
  /* Print the totals of the current sub group or master group */
  /*-----------------------------------------------------------*/
  /**************RAM*****************************************/
  sprintf(totals->EL_Charge,"%.2f",atof(totals->EL_Charge));
  sprintf(totals->SL_Charge,"%.2f",atof(totals->SL_Charge));
  sprintf(totals->WT_Charge,"%.2f",atof(totals->WT_Charge));
  sprintf(totals->SW_Charge,"%.2f",atof(totals->SW_Charge));
  sprintf(totals->GB_Charge,"%.2f",atof(totals->GB_Charge));
  sprintf(totals->GS_Charge,"%.2f",atof(totals->GS_Charge));
  sprintf(totals->TV_Charge,"%.2f",atof(totals->TV_Charge));
  sprintf(totals->OT_Charge,"%.2f",atof(totals->OT_Charge));
  sprintf(totals->Total_Charge,"%.2f",atof(totals->Total_Charge));
  /**************RAM*****************************************/

  strcpy(SumNewCharges,totals->Total_Charge);  /*RAM */

fprintf(fpFile, "\n %5s Total:       %11s %11s %11s %11s %11s %11s %11s %11s %11s", 
			pszType,
			totals->EL_Charge,
			totals->SL_Charge,
			totals->WT_Charge,
			totals->SW_Charge,
			totals->GB_Charge,
			totals->GS_Charge,
			totals->TV_Charge,
			totals->OT_Charge,
			totals->Total_Charge);
  sGLineNum++;
  sGTotalLines++;

  sprintf(docu_dtgrpchg_charge_1,"%12.2f",atof(totals->EL_Charge));
  sprintf(docu_dtgrpchg_charge_2,"%12.2f",atof(totals->SL_Charge));
  sprintf(docu_dtgrpchg_charge_3,"%12.2f",atof(totals->WT_Charge));
  sprintf(docu_dtgrpchg_charge_4,"%12.2f",atof(totals->SW_Charge));
  sprintf(docu_dtgrpchg_charge_5,"%12.2f",atof(totals->GB_Charge));
  sprintf(docu_dtgrpchg_charge_6,"%12.2f",atof(totals->GS_Charge));
  sprintf(docu_dtgrpchg_charge_7,"%12.2f",atof(totals->TV_Charge));
  sprintf(docu_dtgrpchg_charge_8,"%12.2f",atof(totals->OT_Charge));
  sprintf(docu_dtgrpchg_total_charge,"%14.2",atof(totals->Total_Charge));
  dtgrpchg_count++;
  extract_detail_grp_chg();
  initialize_detail_grp_chg();
  
} /* end PrintDetailAcctTotal */



/******************************************************************************
*                                                                             *
*   PrintDetailAcctData()                                                   *
*                                                                             *
*   Description.....: Print to the output file the current subordinates       *
*		      details.						      *
*                                                                             *
*   Parameters:                                                               *
*                                                                             *
*        Type             Name                     Description                *
*       ------------   --------------    --------------------------------     *
*        PCHARGENODE    sub_struct        Structure for the current           *
*					  subordinates charges                *
*                                                                             *
*   Return Values:                                                            *
*                                                                             *
*        Type       Value     #define              Description                *
*       --------    -----   ----------------   --------------------------     *
*        void                                                                 *
*                                                                             *
******************************************************************************/
void PrintDetailAcctData(PCHARGENODE sub_struct,long piCustCode,
							char *pszPremCode)
{
  /*---------------------------------------------------*/
  /* Print out the details for the current subordinate */
  /*---------------------------------------------------*/
  
   /*****RAM ***********************************/
   sprintf(sub_struct->EL_Charge,"%.2f",atof(sub_struct->EL_Charge));
   sprintf(sub_struct->SL_Charge,"%.2f",atof(sub_struct->SL_Charge));
   sprintf(sub_struct->WT_Charge,"%.2f",atof(sub_struct->WT_Charge));
   sprintf(sub_struct->SW_Charge,"%.2f",atof(sub_struct->SW_Charge));
   sprintf(sub_struct->GB_Charge,"%.2f",atof(sub_struct->GB_Charge));
   sprintf(sub_struct->GS_Charge,"%.2f",atof(sub_struct->GS_Charge));
   sprintf(sub_struct->TV_Charge,"%.2f",atof(sub_struct->TV_Charge));
   sprintf(sub_struct->OT_Charge,"%.2f",atof(sub_struct->OT_Charge));
   sprintf(sub_struct->Total_Charge,"%.2f",atof(sub_struct->Total_Charge));

fprintf(fpFile, "\n %10d %7s %11s %11s %11s %11s %11s %11s %11s %11s %11s",
		piCustCode,
		pszPremCode,
 		sub_struct->EL_Charge,
                sub_struct->SL_Charge,                        
	        sub_struct->WT_Charge,                        
		sub_struct->SW_Charge,                        
		sub_struct->GB_Charge,                        
		sub_struct->GS_Charge,                        
		sub_struct->TV_Charge,                        
		sub_struct->OT_Charge,                        
		sub_struct->Total_Charge); 
  sGLineNum++;                                                                
  sGTotalLines++; 


  /*--------------------DOCU----------------------------*/
  sprintf(docu_dtindchg_cust_code,"%d",piCustCode);
  strcpy(docu_dtindchg_prem_code,pszPremCode);
  sprintf(docu_dtindchg_charge_1,"%10.2f",atof(sub_struct->EL_Charge));    
  sprintf(docu_dtindchg_charge_2,"%10.2f",atof(sub_struct->SL_Charge));    
  sprintf(docu_dtindchg_charge_3,"%10.2f",atof(sub_struct->WT_Charge));    
  sprintf(docu_dtindchg_charge_4,"%10.2f",atof(sub_struct->SW_Charge));    
  sprintf(docu_dtindchg_charge_5,"%10.2f",atof(sub_struct->GB_Charge));    
  sprintf(docu_dtindchg_charge_6,"%10.2f",atof(sub_struct->GS_Charge));    
  sprintf(docu_dtindchg_charge_7,"%10.2f",atof(sub_struct->TV_Charge));    
  sprintf(docu_dtindchg_charge_8,"%10.2f",atof(sub_struct->OT_Charge));    
  sprintf( docu_dtindchg_total_charge ,"%12.2f",atof(sub_struct->Total_Charge));

  dtindchg_count++;
  extract_detail_ind_chg();
  initialize_detail_ind_chg();
  
} /* end PrintDetailAcctData */



/******************************************************************************
*                                                                             *
*   PrintDetailTaxHeader()                                                   *
*                                                                             *
*   Description.....: Print to the output file the tax section header.        *
*                                                                             *
*   Parameters:                                                               *
*                                                                             *
*        Type             Name                     Description                *
*       ------------   --------------    --------------------------------     *
*                                                                             *
*   Return Values:                                                            *
*                                                                             *
*        Type       Value     #define              Description                *
*       --------    -----   ----------------   --------------------------     *
*        void                                                                 *
*                                                                             *
******************************************************************************/
void PrintDetailTaxHeader() 
{
  /*-------------------------------*/
  /* Print the tax section header. */
  /*-------------------------------*/
  fprintf(fpFile, "\n\nGroup Summary of Taxes by Service:");
/*fprintf(fpFile,"\n%5sTax Type%5sElectric%5sLights%7sWater%7sSewer%5sGarbage",
       RAM */ 
  fprintf(fpFile,"\n%18sTax Type%5sElectric%5sLights%7sWater%7sSewer%5sGarbage",
		" ", " ", " ", " ", " ", " "); 
  fprintf(fpFile,"%9sGas%7sCable%6sOther%6sTotal",
		" ", " ", " ", " ");

  sGLineNum+=2;                                                                
  sGTotalLines+=2; 

} /* end PrintDetailTaxHeader */



/******************************************************************************
*                                                                             *
*   PrintDetailTaxDetail()                                                    *
*                                                                             *
*   Description.....: Print to the output file the details of the current tax *
*                     item.                                                   *
*                                                                             *
*   Parameters:                                                               *
*                                                                             *
*        Type             Name                     Description                *
*       ------------   --------------    --------------------------------     *
*        PCHARGENODE       tItem             Current tax item structure       *
*                                                                             *
*   Return Values:                                                            *
*                                                                             *
*        Type       Value     #define              Description                *
*       --------    -----   ----------------   --------------------------     *
*        void                                                                 *
*                                                                             *
******************************************************************************/
void PrintDetailTaxDetail(PCHARGENODE tItem) 
{
  /*---------------------------------------*/ 
  /* Print out the curret tax item details */
  /*---------------------------------------*/ 
  /***************RAM**********************************/
    sprintf(tItem->EL_Charge,"%.2f",atof(tItem->EL_Charge));
    sprintf(tItem->SL_Charge,"%.2f",atof(tItem->SL_Charge));
    sprintf(tItem->WT_Charge,"%.2f",atof(tItem->WT_Charge));
    sprintf(tItem->SW_Charge,"%.2f",atof(tItem->SW_Charge));
    sprintf(tItem->GB_Charge,"%.2f",atof(tItem->GB_Charge));
    sprintf(tItem->GS_Charge,"%.2f",atof(tItem->GS_Charge));
    sprintf(tItem->TV_Charge,"%.2f",atof(tItem->TV_Charge));
    sprintf(tItem->OT_Charge,"%.2f",atof(tItem->OT_Charge));
    sprintf(tItem->Total_Charge,"%.2f",atof(tItem->Total_Charge));
  /***************RAM**********************************/

/*fprintf(fpFile, "%26s: %11s %11s %11s %11s %11s %11s %11s %11s %15s", RAM */
  fprintf(fpFile, "\n%23s: %11s %11s %11s %11s %11s %11s %11s %11s %11s",
	 	tItem->tax_desc, 
	 	tItem->EL_Charge,                
	 	tItem->SL_Charge,                                    
		tItem->WT_Charge,                                    
		tItem->SW_Charge,                                    
		tItem->GB_Charge,                                    
		tItem->GS_Charge,                                    
		tItem->TV_Charge,                                    
		tItem->OT_Charge,                                    
		tItem->Total_Charge);
  sGLineNum++;                                                                
  sGTotalLines++; 


  strcpy(docu_dtindtax_type,tItem->tax_desc);
  sprintf(docu_dtindtax_charge_1,"%10.2f",atof(tItem->EL_Charge));
  sprintf(docu_dtindtax_charge_2,"%10.2f",atof(tItem->SL_Charge));
  sprintf(docu_dtindtax_charge_3,"%10.2f",atof(tItem->WT_Charge));
  sprintf(docu_dtindtax_charge_4,"%10.2f",atof(tItem->SW_Charge));
  sprintf(docu_dtindtax_charge_5,"%10.2f",atof(tItem->GB_Charge));
  sprintf(docu_dtindtax_charge_6,"%10.2f",atof(tItem->GS_Charge));
  sprintf(docu_dtindtax_charge_7,"%10.2f",atof(tItem->TV_Charge));
  sprintf(docu_dtindtax_charge_8,"%10.2f",atof(tItem->OT_Charge));
  sprintf(docu_dtindtax_total_taxes,"%12.2f",atof(tItem->Total_Charge));
  dtindtax_count++; 
  extract_detail_ind_tax();
  initialize_detail_ind_tax();

} /* end PrintDetailTaxDetail */



/******************************************************************************
*                                                                             *
*   PrintDetailTaxTotals()                                                   *
*                                                                             *
*   Description.....: Print to the output file the group tax totals           *
*                                                                             *
*   Parameters:                                                               *
*                                                                             *
*        Type             Name                     Description                *
*       ------------   --------------    --------------------------------     *
*        PCHARGENODE    tot_Item          Structure containing the group tax  *
*					  totals                              *
*                                                                             *
*   Return Values:                                                            *
*                                                                             *
*        Type       Value     #define              Description                *
*       --------    -----   ----------------   --------------------------     *
*        void                                                                 *
*                                                                             *
******************************************************************************/
void PrintDetailTaxTotals( PCHARGENODE tot_Item)
{
  /*----------------------------------*/
  /* Print the accumulated tax totals */
  /*----------------------------------*/

  sprintf(tot_Item->EL_Charge,"%.2f",atof(tot_Item->EL_Charge));
  sprintf(tot_Item->SL_Charge,"%.2f",atof(tot_Item->SL_Charge));
  sprintf(tot_Item->WT_Charge,"%.2f",atof(tot_Item->WT_Charge));
  sprintf(tot_Item->SW_Charge,"%.2f",atof(tot_Item->SW_Charge));
  sprintf(tot_Item->GB_Charge,"%.2f",atof(tot_Item->GB_Charge));
  sprintf(tot_Item->GS_Charge,"%.2f",atof(tot_Item->GS_Charge));
  sprintf(tot_Item->TV_Charge,"%.2f",atof(tot_Item->TV_Charge));
  sprintf(tot_Item->OT_Charge,"%.2f",atof(tot_Item->OT_Charge));
  sprintf(tot_Item->Total_Charge,"%.2f",atof(tot_Item->Total_Charge));
  


/*fprintf(fpFile, "\n%27s%12s %12s %12s %12s %12s %12s %12s %12s %12s", RAM */
  fprintf(fpFile, "\n%25s%11s %11s %11s %11s %11s %11s %11s %11s %11s",
		" ",
		tot_Item->EL_Charge,                         
		tot_Item->SL_Charge,
		tot_Item->WT_Charge,
      tot_Item->SW_Charge, 
      tot_Item->GB_Charge,
      tot_Item->GS_Charge,
      tot_Item->TV_Charge,
      tot_Item->OT_Charge,
      tot_Item->Total_Charge);



  sprintf(docu_dtgrptax_charge_1,"%12.2f",atof(tot_Item->EL_Charge));
  sprintf(docu_dtgrptax_charge_2,"%12.2f",atof(tot_Item->SL_Charge));
  sprintf(docu_dtgrptax_charge_3,"%12.2f",atof(tot_Item->WT_Charge));
  sprintf(docu_dtgrptax_charge_4,"%12.2f",atof(tot_Item->SW_Charge));
  sprintf(docu_dtgrptax_charge_5,"%12.2f",atof(tot_Item->GB_Charge));
  sprintf(docu_dtgrptax_charge_6,"%12.2f",atof(tot_Item->GS_Charge));
  sprintf(docu_dtgrptax_charge_7,"%12.2f",atof(tot_Item->TV_Charge));
  sprintf(docu_dtgrptax_charge_8,"%12.2f",atof(tot_Item->OT_Charge));
  sprintf( docu_dtindtax_total_taxes,"%14.2f",atof(tot_Item->Total_Charge));
  
  dtgrptax_count++;
  extract_detail_grp_tax();
  initialize_detail_grp_tax();
  sGLineNum++;                                                                
  sGTotalLines++; 

} /* end PrintDetailTaxTotals */



/******************************************************************************
*                                                                             *
*   PrintDetailConsHeader()                                                   *
*                                                                             *
*   Description.....: Print to the output file the header for the consumption *
*                     section of the detail report.                           *
*                                                                             *
*   Parameters:                                                               *
*                                                                             *
*        Type             Name                     Description                *
*       ------------   --------------    --------------------------------     *
*        char *		pszAsvcCode	  Actual Service Code                            *
*                                                                             *
*   Return Values:                                                            *
*                                                                             *
*        Type       Value     #define              Description                *
*       --------    -----   ----------------   --------------------------     *
*        void                                                                 *
*                                                                             *
******************************************************************************/
void PrintDetailConsHeader(char *pszAsvcCode) 
{
  char service[12];

  /*-----------------------------------*/
  /* determine the name of the service */
  /*-----------------------------------*/
  if(!strcmp(pszAsvcCode, "EL"))
  {
	strcpy(service, "Electric");
  }
  else if(!strcmp(pszAsvcCode, "WT"))
  {
	strcpy(service, "Water");
  }
  else if(!strcmp(pszAsvcCode, "GS"))
  {
	strcpy(service, "Gas");
  }

  /*------------------------------------------*/  
  /* Print out the consumption section header */
  /*------------------------------------------*/  
  fprintf(fpFile, "\n\nMetered %s Billed Consumption:", service);

  sGLineNum++;                                                                
  sGTotalLines++; 

  sprintf(docu_consumption_desc,"Metered %sBilled Consumpiton",service);
  
  
} /* end PrintDetailConsHeader */



/******************************************************************************
*                                                                             *
*   PrintDetailConsData()                                                     *
*                                                                             *
*   Description.....: Print to the output file the current unit of measure    *
*                     total.					              *
*                                                                             *
*   Parameters:                                                               *
*                                                                             *
*        Type             Name                     Description                *
*       ------------   --------------    --------------------------------     *
*        PCONSNODE      cItem             Structure containing total          *
*                                         consumption for a unit of measure   *
*                                                                             *
*   Return Values:                                                            *
*                                                                             *
*        Type       Value     #define              Description                *
*       --------    -----   ----------------   --------------------------     *
*        void                                                                 *
*                                                                             *
******************************************************************************/
void PrintDetailConsData(PCONSNODE cItem) 
{
  /*---------------------------------*/
  /* Print the unit of measure total */
  /*---------------------------------*/
  fprintf(fpFile, "\n%41s:  %27ld", cItem->UOMS_Code, cItem->Consumption);

  sGLineNum++;                                                                
  sGTotalLines++; 


  strcpy(docu_consumption_serv_catg_code,cItem->UOMS_Code); 
  sprintf(docu_consumption_consump,"%ld",cItem->Consumption);        
    conshist_count++;
    extract_consumption_hist();
    initialize_consumption_hist();




} /* End PrintDetailConsData */

/******************************************************************************
*                                                                             *
*   PrintDetailConsTotals()                                                   *
*                                                                             *
*   Description.....: Print to the output file the totals of the current      *
*		      metered service     				      *
*                                                                             *
*   Parameters:                                                               *
*                                                                             *
*        Type             Name                     Description                *
*       ------------   --------------    --------------------------------     *
*        char *		LocalTotal	  Total of metered service cons       *
*                                                                             *
*   Return Values:                                                            *
*                                                                             *
*        Type       Value     #define              Description                *
*       --------    -----   ----------------   --------------------------     *
*        void                                                                 *
*                                                                             *
******************************************************************************/
void PrintDetailConsTotals(long LocalTotal)
{
  /*---------------------------------*/
  /* Print the unit of measure total */
  /*---------------------------------*/
  fprintf(fpFile, "\n%38sTOTAL:  %25ld", " ", LocalTotal);
  
  sGLineNum++;                                                                
  sGTotalLines++; 


} /* End PrintDetailConsTotals */


/******************************************************************************
*                                                                             *
*   PrintSumMasterAddress()                                                   *
*                                                                             *
*   Description.....: Print to the output file the master customer address    *
*		      for the summary report.				      *
*                                                                             *
*   Parameters:                                                               *
*                                                                             *
*        Type             Name                     Description                *
*       ------------   --------------    --------------------------------     *
*        char *        pszMasterName      Master customer name                *
*        char *        pszMasterAddress1  Master address part 1               *
*        char *        pszMasterAddress2  Master address part 2               *
*        char *        pszMasterAddress3  Master address part 3               *
*        char *        pszMasterAddress4  Master address part 4               *
*        char *        pszMasterAddress5  Master address part 5               *
*                                                                             *
*   Return Values:                                                            *
*                                                                             *
*        Type       Value     #define              Description                *
*       --------    -----   ----------------   --------------------------     *
*        void                                                                 *
*                                                                             *
******************************************************************************/
void PrintSumMasterAddress(	char *pszDueString,
				char *pszMasterName,
                        	char *pszMasterAddress1,
                        	char *pszMasterAddress2,
                        	char *pszMasterAddress3,
                        	char *pszMasterAddress4,
                        	char *pszMasterAddress5,
				int  iInd)
{    
     /*-------------------------------------------------------------*/
     /* Print the Summary Report information regarding the due date */
     /*-------------------------------------------------------------*/
     fprintf(fpFile, "\n\n%5sMaster Bill Summary for Master Billing Group: %9d",
                  " ", ucbmbil_mbil_num[iInd]);
     fprintf(fpFile, "\n%5s%s", " ", pszDueString);

     /*----------------------------------------------------------------------*/
     /* Output the master customer line                                      */
     /*----------------------------------------------------------------------*/
     fprintf(fpFile, "%9d",                   ucbmbil_cust_code[iInd]);
     fprintf(fpFile, "%7s  ",                 ucbmbil_prem_code[iInd]);
     fprintf(fpFile, "%-60s\n",               pszMasterName);
     fprintf(fpFile, "%17s%-32s\n",      " ", pszMasterAddress1);
     if ((int)strlen(pszMasterAddress2) > 0)
          {
          fprintf(fpFile, "%18s%-32s\n", " ", pszMasterAddress2);
          sGLineNum    += 1;
          sGTotalLines += 1;
          }
     if ((int)strlen(pszMasterAddress3) > 0)
          {
          fprintf(fpFile, "%18s%-32s\n", " ", pszMasterAddress3);
          sGLineNum    += 1;
          sGTotalLines += 1;
          }
     if ((int)strlen(pszMasterAddress4) > 0)
          {
          fprintf(fpFile, "%18s%-32s\n", " ", pszMasterAddress4);
          sGLineNum    += 1;
          sGTotalLines += 1;
          }
     fprintf(fpFile, "%18s%-42s\n",      " ", pszMasterAddress5);

     sGLineNum    += 7;
     sGTotalLines += 7;
     sGRecordCount++;


     sprintf(docu_mastradr_master_bill_number,"%9d",ucbmbil_mbil_num[iInd]);  
    sprintf(docu_mastradr_cust_code,"%d",ucbmbil_cust_code[iInd]);           
    strcpy(docu_mastradr_prem_code,ucbmbil_prem_code[iInd]);           
    strcpy(docu_mastradr_addr_name,pszMasterName);           
    strcpy(docu_mastradr_addr_line1,pszMasterAddress1);          
    strcpy(docu_mastradr_addr_line2,pszMasterAddress2);          
    strcpy(docu_mastradr_addr_line3,pszMasterAddress3);          
    strcpy(docu_mastradr_addr_line4,pszMasterAddress4);
    strcpy(docu_mastradr_addr_line5,pszMasterAddress5);          
    strcpy(docu_mastradr_city," ");                
    strcpy(docu_mastradr_state," ");               
    strcpy(docu_mastradr_zipcode," ");             
    strcpy(docu_mastradr_nation," ");             
     
     mastradr_count++;
     extract_masteraddr_info();
     initialize_masteraddr_info();

}                                             /* end PrintSumMasterAddress */



/******************************************************************************
*                                                                             *
*   PrintSumAcctHeader()                                                     *
*                                                                             *
*   Description.....: Print to the output file the header for the subordinate *
*                     section of the summary report.                          *
*                                                                             *
*   Parameters:                                                               *
*                                                                             *
*        Type             Name                     Description                *
*       ------------   --------------    --------------------------------     *
*                                                                             *
*   Return Values:                                                            *
*                                                                             *
*        Type       Value     #define              Description                *
*       --------    -----   ----------------   --------------------------     *
*        void                                                                 *
*                                                                             *
******************************************************************************/
void PrintSumAcctHeader()
{
  /*----------------------------------------------*/
  /* Print the header for the subordinate section */
  /* of the summary report. 			  */
  /*----------------------------------------------*/
  fprintf(fpFile, "\n\n Summary of Amount Due for Each Group Member:");
/*  fprintf(fpFile, "\n   Customer   Name%23sPremises  Service Address%18s",
	 " ", " "); */
  fprintf(fpFile, "\n   Customer   Name%35sPremises  Service Address%27s",
        " ", " ");
  fprintf(fpFile, "Bill Date%10sBal Due", " ");

  sGLineNum+=2;                                                                
  sGTotalLines+=2; 

}  /* end PrintSumAcctHeader */


/******************************************************************************
*                                                                             *
*   PrintSumAcctData()                                                     *
*                                                                             *
*   Description.....: Print to the output file the current summary subordinate*
*                     details.                                                *
*                                                                             *
*   Parameters:                                                               *
*                                                                             *
*        Type             Name                     Description                *
*       ------------   --------------    --------------------------------     *
*        PSUBNODE      sItem              Structure containing current        *
*                                         subordinate information             *
*                                                                             *
*   Return Values:                                                            *
*                                                                             *
*        Type       Value     #define              Description                *
*       --------    -----   ----------------   --------------------------     *
*        void                                                                 *
*                                                                             *
******************************************************************************/
void PrintSumAcctData(PSUBNODE sItem)
{
 EXEC SQL BEGIN DECLARE SECTION;
 double temp_bal_due =0;
 NUMSTR char_bal_due ="";
 NUMSTR temp_cust_code = "";
 CHAR8  temp_prem_code = "";
EXEC SQL END DECLARE SECTION;
  /*-------------------------------------------*/
  /* Print out the current subordinate details */
  /*-------------------------------------------*/
	strcpy(temp_cust_code,sItem->Cust_Code);
	strcpy(temp_prem_code,sItem->Prem_Code);
	if(!*sleep_wake_ind)
	{
	temp_bal_due=CalcBalDue(atoi(sItem->Cust_Code),sItem->Prem_Code);
	temp_bal_due=temp_bal_due -AcctUnapplPymtBal(atoi(sItem->Cust_Code),
                                              sItem->Prem_Code);
        }
	else
	{
	   EXEC SQL SELECT sum(uabopen_balance)
		    INTO  :temp_bal_due 
		    FROM   uabopen
		    WHERE  uabopen_cust_code=:temp_cust_code
		    AND    uabopen_prem_code=:temp_prem_code
		    AND    uabopen_mbil_bhst_tran_num <= :uabopen_mbil_bhst_tran_num;
		    POSTORA;

         }

	total_bal_due =total_bal_due + temp_bal_due;

	sprintf(char_bal_due,"%.2f",temp_bal_due);

 	 sprintf(sItem->Bal_Due,"%.2f",atof(sItem->Bal_Due)); /*RAM */

  	if(strlen(sItem->Cust_Name) >40)
 	 sItem->Cust_Name[40]='\0';

 	 if(strlen(sItem->Cust_Add) >40)
 	 sItem->Cust_Add[40]='\0';

  fprintf(fpFile, "\n  %-9s  %-40s  %-7s  %-42s %-8s    %13s",
		sItem->Cust_Code,
		sItem->Cust_Name,
		sItem->Prem_Code,
		sItem->Cust_Add,
		sItem->Bill_Date,
/*		sItem->Bal_Due); */
                char_bal_due);

  sGLineNum++;                                                                
  sGTotalLines++; 


  strcpy(docu_smindchg_cust_code,sItem->Cust_Code);    
  strcpy(docu_smindchg_cust_name,sItem->Cust_Name);   
  strcpy(docu_smindchg_prem_code,sItem->Prem_Code);   
  strcpy(docu_smindchg_service_addr,sItem->Cust_Add); 
  strcpy(docu_smindchg_bill_date,sItem->Bill_Date);    
  strcpy(docu_smindchg_bal_due,char_bal_due);      

   smindchg_count++;
   extract_summary_ind_chg();
   initialize_summary_ind_chg();
   

}  /* END PrintSumAcctData */

/***************************************************************************
*  Calculate BalDue For Each Account                                       *
*  CalcBalDue()                                                            *
****************************************************************************/
static double CalcBalDue(int lCustCode, char *pszPremCode)
{
EXEC SQL BEGIN DECLARE SECTION;
double temp_uabopen=0;
short  temp_ind1;
EXEC SQL END DECLARE SECTION;
 EXEC SQL SELECT       SUM(uabopen_balance)
          INTO   :temp_uabopen :temp_ind1
          FROM   UABOPEN
          WHERE  uabopen_cust_code = :lCustCode
          AND    uabopen_prem_code = :pszPremCode
          AND    NVL(uabopen_bhst_tran_num,0) <> 0;
POSTORA;
return temp_uabopen;
}

/*****************************************************************************
*                                                                             *
*   PrintSumAcctTotals()                                                     *
*                                                                             *
*   Description.....: Print to the output file the group Balance amount due   *
*                                                                             *
*   Parameters:                                                               *
*                                                                             *
*        Type             Name                     Description                *
*       ------------   --------------    --------------------------------     *
*        char *         LocalTotal        Total figure			      *
*                                                                             *
*   Return Values:                                                            *
*                                                                             *
*        Type       Value     #define              Description                *
*       --------    -----   ----------------   --------------------------     *
*        void                                                                 *
*                                                                             *
******************************************************************************/
void PrintSumAcctTotals(char *LocalTotal)
{
  /*------------------------*/
  /* Print total amount due */
  /*------------------------*/
  sprintf(LocalTotal,"%.2f",atof(LocalTotal)); /*RAM */
  sprintf(LocalTotal,"%.2f",total_bal_due); /*RAM */
  fprintf(fpFile, "\n%105sTotal    %18s", " ", LocalTotal);

  sGLineNum++;                                                                
  sGTotalLines++; 
  total_bal_due =0;

 strcpy(docu_smgrpchg_total,LocalTotal);
 smgrpchg_count++;
 extract_summary_grp_chg();
 initialize_summary_grp_chg();
 
}  /* end PrintSumAcctTotals */


/******************************************************************************
*                                                                             *
*   PrintSumBudgHeader()                                                     *
*                                                                             *
*   Description.....: Print to the output file the Budget header              *
*                                                                             *
*   Parameters:                                                               *
*                                                                             *
*        Type             Name                     Description                *
*       ------------   --------------    --------------------------------     *
*                                                                             *
*   Return Values:                                                            *
*                                                                             *
*        Type       Value     #define              Description                *
*       --------    -----   ----------------   --------------------------     *
*        void                                                                 *
*                                                                             *
******************************************************************************/
void PrintSumBudgHeader()
{
  /*--------------------------------------------------------*/
  /* Print the summary budget header for the budget section */
  /*--------------------------------------------------------*/
  fprintf(fpFile, "\n\n%47sBudget Summary By Actual Service Type", " ");
fprintf(fpFile, "\n%19s Current Actual    Current Budget  Current Variance"," ");
  fprintf(fpFile, "%9sYTD Actual%8sYTD Budget%6sYTD Variance",
	" ", " ", " ");

  sGLineNum+=3;                                                                
  sGTotalLines+=3; 


}  /* end PrintSumBudgHeader */


/******************************************************************************
*                                                                             *
*   PrintSumBudgData()                                                     *
*                                                                             *
*   Description.....: Print to the output file the budget totals by service   *
*                                                                             *
*   Parameters:                                                               *
*                                                                             *
*        Type             Name                     Description                *
*       ------------   --------------    --------------------------------     *
*        PBUDGNODE      bItem             Structure containing totals         *
*                                         for budget items for a service      *
*                                                                             *
*   Return Values:                                                            *
*                                                                             *
*        Type       Value     #define              Description                *
*       --------    -----   ----------------   --------------------------     *
*        void                                                                 *
*                                                                             *
******************************************************************************/
void PrintSumBudgData(PBUDGNODE bItem)
{
  /*----------------------------------------*/
  /* Print the budget details for a service */
  /*----------------------------------------*/
   sprintf(bItem->Cur_Actual,"%.2f",atof(bItem->Cur_Actual));         /*RAM */
   sprintf(bItem->Cur_Budget,"%.2f",atof(bItem->Cur_Budget));         /*RAM */
   sprintf(bItem->YTD_Actual,"%.2f",atof(bItem->YTD_Actual));         /*RAM */
   sprintf(bItem->Cur_Variance,"%.2f",atof(bItem->Cur_Variance));     /*RAM */
   sprintf(bItem->YTD_Budget,"%.2f",atof(bItem->YTD_Budget));         /*RAM */
   sprintf(bItem->YTD_Variance,"%.2f",atof(bItem->YTD_Variance));     /*RAM */

  fprintf(fpFile, "\n%s %12s %17s %17s %17s %17s %17s %17s",
		bItem->Actual_Service,
		" ",
		bItem->Cur_Actual,
		bItem->Cur_Budget,
		bItem->Cur_Variance,
		bItem->YTD_Actual,
		bItem->YTD_Budget,
		bItem->YTD_Variance);

  sGLineNum++;                                                                
  sGTotalLines++; 

  strcpy(docu_budginfo_actual_Service_type,bItem->Actual_Service); 
  strcpy(docu_budginfo_actual_charge,bItem->Cur_Actual);       
  strcpy(docu_budginfo_budget_charge, bItem->Cur_Budget);       
  strcpy(docu_budginfo_variance,bItem->Cur_Variance);            
  strcpy(docu_budginfo_ytd_actual,bItem->YTD_Actual);          
  strcpy(docu_budginfo_ytd_budget,bItem->YTD_Budget);          
  strcpy(docu_budginfo_ytd_variance,bItem->YTD_Variance);        


 budginfo_count++;
 extract_budget_info();
 initialize_budget_info();

}  /* end PrintSumBudgData */

/******************************************************************************
*                                                                             *
*   PrintSumBudgTotals()                                                     *
*                                                                             *
*   Description.....: Print to the output file the total of all the budget    *
*                     details.                                                *
*                                                                             *
*   Parameters:                                                               *
*                                                                             *
*        Type             Name                     Description                *
*       ------------   --------------    --------------------------------     *
*        PBUDGNODE	bTotal		  Structure containing the budget     *
*					  totals			      *
*                                                                             *
*   Return Values:                                                            *
*                                                                             *
*        Type       Value     #define              Description                *
*       --------    -----   ----------------   --------------------------     *
*        void                                                                 *
*                                                                             *
******************************************************************************/
void PrintSumBudgTotals(PBUDGNODE bTotal)
{
  /*-------------------------------*/
  /*  Print the budget totals line */
  /*-------------------------------*/
  sprintf(bTotal->Cur_Actual,"%.2f",atof(bTotal->Cur_Actual));
  sprintf(bTotal->Cur_Budget,"%.2f",atof(bTotal->Cur_Budget));
  sprintf(bTotal->Cur_Variance,"%.2f",atof(bTotal->Cur_Variance));
  sprintf(bTotal->YTD_Actual,"%.2f",atof(bTotal->YTD_Actual));
  sprintf(bTotal->YTD_Budget,"%.2f",atof(bTotal->YTD_Budget));
  sprintf(bTotal->YTD_Variance,"%.2f",atof(bTotal->YTD_Variance));
 
  fprintf(fpFile, "\n%15s %17s %17s %17s %17s %17s %17s",
                " ",
                bTotal->Cur_Actual,
                bTotal->Cur_Budget,
                bTotal->Cur_Variance,
                bTotal->YTD_Actual,
                bTotal->YTD_Budget,
                bTotal->YTD_Variance);

  sGLineNum++;                                                                
  sGTotalLines++; 


  strcpy(docu_smbudget_actual_charge,bTotal->Cur_Actual);  
  strcpy(docu_smbudget_budget_charge,bTotal->Cur_Budget);  
  strcpy(docu_smbudget_variance,     bTotal->Cur_Variance); 
  strcpy(docu_smbudget_ytd_actual,   bTotal->YTD_Actual);  
  strcpy(docu_smbudget_ytd_budget,   bTotal->YTD_Budget);  
  strcpy(docu_smbudget_ytd_variance, bTotal->YTD_Variance); 

  smbudget_count++;
  extract_budget_summary_info();
  initialize_budget_summary_info();
 
  extract_bill_end();


}  /* end PrintSumBudgTotals */


/******************************************************************************
*                                                                             *
*   PrintSumTaxHeader()                                                     *
*                                                                             *
*   Description.....: Print to the output file the header of the tax section  *
*                                                                             *
*   Parameters:                                                               *
*                                                                             *
*        Type             Name                     Description                *
*       ------------   --------------    --------------------------------     *
*                                                                             *
*   Return Values:                                                            *
*                                                                             *
*        Type       Value     #define              Description                *
*       --------    -----   ----------------   --------------------------     *
*        void                                                                 *
*                                                                             *
******************************************************************************/
void PrintSumTaxHeader()
{
  /*---------------------------*/
  /* Print the tax header line */
  /*---------------------------*/
  fprintf(fpFile, "\n\nTax Description%29sTaxDue"," ");

  sGLineNum++;                                                                
  sGTotalLines++; 

} /* end PrintSumTaxHeader */


/******************************************************************************
*                                                                             *
*   PrintSumTaxData()                                                     *
*                                                                             *
*   Description.....: Print to the output file the current tax detail totals  *
*                                                                             *
*   Parameters:                                                               *
*                                                                             *
*        Type             Name                     Description                *
*       ------------   --------------    --------------------------------     *
*        PCHARGENODE    tItem             Structure containing the current    *
*                                         tax item.                           *
*                                                                             *
*   Return Values:                                                            *
*                                                                             *
*        Type       Value     #define              Description                *
*       --------    -----   ----------------   --------------------------     *
*        void                                                                 *
*                                                                             *
******************************************************************************/
void PrintSumTaxData(PCHARGENODE tItem)
{
  /*----------------------------*/
  /* Print the current tax item */
  /*----------------------------*/
   sprintf(tItem->Total_Charge,"%.2f",atof(tItem->Total_Charge)); 
   fprintf(fpFile, "\n%35s  %15s", tItem->tax_desc, tItem->Total_Charge);
  
  sGLineNum++;                                                                
  sGTotalLines++; 

   strcpy(docu_smtaxtot_tax_desc ,tItem->tax_desc);
   strcpy(docu_smtaxtot_tax_total,tItem->Total_Charge);
   smtaxtot_count++;
   extract_sum_tax_totals();
   initialize_sum_tax_totals();

                          
}  /* end PrintSumTaxData */

/******************************************************************************
*                                                                             *
*   PrintExcpHeader()                                                  *
*                                                                             *
*   Description.....: Print to the output file the current unit of measure    *
*                     total.                                                  *
*                                                                             *
*   Parameters:                                                               *
*                                                                             *
*        Type             Name                     Description                *
*       ------------   --------------    --------------------------------     *
*	 char *		pszReportString	  whether this is a "Detail Report"   *
*					  or a "Summary".		      *
*                                                                             *
*   Return Values:                                                            *
*                                                                             *
*        Type       Value     #define              Description                *
*       --------    -----   ----------------   --------------------------     *
*        void                                                                 *
*                                                                             *
******************************************************************************/
void PrintExcpHeader(char *pszReportString)
{
  /*-------------------------------------------*/
  /* Print the header of the exception section */
  /*-------------------------------------------*/
  fprintf(fpFile,"\n\n The following accounts could not be included on this %s",
		pszReportString);
  fprintf(fpFile,"\n Customer     Name%25sPremises  Service Address%50sReason",
		" "," ");

  sGLineNum+=2;                                                                
  sGTotalLines+=2; 

		

} /* end PrintExcpHeader */


/******************************************************************************
*                                                                             *
*   PrintExcpData()                                                           *
*                                                                             *
*   Description.....: Print to the output file the current unit of measure    *
*                     total.                                                  *
*                                                                             *
*   Parameters:                                                               *
*                                                                             *
*        Type             Name                     Description                *
*       ------------   --------------    --------------------------------     *
*        PSUBNODE       excp_item         Structure containing the details    *
*                                         of the current exception            *
*   Return Values:                                                            *
*                                                                             *
*        Type       Value     #define              Description                *
*       --------    -----   ----------------   --------------------------     *
*        void                                                                 *
*                                                                             *
******************************************************************************/
void PrintExcpData(PSUBNODE excp_item)
{
  /*-----------------------------------------*/
  /* Print the subordinate exception details */
  /*-----------------------------------------*/
  fprintf(fpFile,"\n %9s  %27s  %7s   %50s%27s",
		excp_item->Cust_Code,
		excp_item->Cust_Name,
		excp_item->Prem_Code,
		excp_item->Cust_Add,
      excp_item->Reason);
 


  strcpy(docu_excp_cust_code,excp_item->Cust_Code);       
  strcpy(docu_excp_cust_name,excp_item->Cust_Name);       
  strcpy(docu_excp_prem_code,excp_item->Prem_Code);       
  strcpy(docu_excp_serv_addr,excp_item->Cust_Add);       
  strcpy(docu_excp_exception_desc,excp_item->Reason); 

  excpinfo_count++;
  extract_exception_info();
  initialize_exception_info();


  sGLineNum++;                                                                
  sGTotalLines++; 




} /* End PrintExcpData */





/******************************************************************************
*                                                                             *
*   PrintSumBillHistHeader()                                                  *
*                                                                             *
*   Description.....: Print to the output file the Bill History header section*
*                     total.                                                  *
*                                                                             *
*   Parameters:                                                               *
*                                                                             *
*        Type             Name                     Description                *
*       ------------   --------------    --------------------------------     *
*                                                                             *
*   Return Values:                                                            *
*                                                                             *
*        Type       Value     #define              Description                *
*       --------    -----   ----------------   --------------------------     *
*        void                                                                 *
*                                                                             *
******************************************************************************/
void PrintSumBillHistHeader()
{
  /*---------------------------*/
  /* Print Bill History Header */
  /*---------------------------*/
  fprintf(fpFile, "\n\nGroup Totals:              Previous Balance%8sAdjustments%11s",
	" ", " ");
  fprintf(fpFile, "Payments%8sNew Charges%10sTotal Due",
		 " ", " ");

  sGLineNum++;                                                                
  sGTotalLines++; 


} /* end PrintSumBillHeader */


/******************************************************************************
*                                                                             *
*   PrintSumBillHistData()                                                     *
*                                                                             *
*   Description.....: Print to the output file the current groups bill hist   *
*                     data.                                                   *
*                                                                             *
*   Parameters:                                                               *
*                                                                             *
*        Type             Name                     Description                *
*       ------------   --------------    --------------------------------     *
*        PBILL_HIST     bill_hist         Bill History Structure              *
*                                                                             *
*   Return Values:                                                            *
*                                                                             *
*        Type       Value     #define              Description                *
*       --------    -----   ----------------   --------------------------     *
*        void                                                                 *
*                                                                             *
******************************************************************************/
void PrintSumBillHistData(PBILL_HIST bill_hist)
{
  /*------------------------------------------*/ 
  /* Print the group bill history information */
  /*------------------------------------------*/ 
   /***************RAM*******************************/
   sprintf(bill_hist->ending_bal,"%.2f",atof(bill_hist->ending_bal));
   sprintf(bill_hist->adjustments,"%.2f",atof(bill_hist->adjustments));
   sprintf(bill_hist->payments,"%.2f",atof(bill_hist->payments));
   sprintf(bill_hist->new_charges,"%.2f",atof(bill_hist->new_charges));
   sprintf(bill_hist->total_due,"%.2f",atof(bill_hist->total_due));
   /***************RAM*******************************/

  fprintf(fpFile, "\n%24s%17s  %17s  %17s  %17s  %17s", 
		" ", bill_hist->ending_bal,
		bill_hist->adjustments,
		bill_hist->payments,
		bill_hist->new_charges,  
                /*SumNewCharges, */
		bill_hist->total_due);

  sGLineNum++;                                                                
  sGTotalLines++; 
  strcpy(SumNewCharges,"0"); /*RAM */
	

  strcpy(docu_payments_prev_bal,bill_hist->ending_bal);        
  strcpy(docu_payments_adj, bill_hist->adjustments);  
  strcpy(docu_payments_payments,bill_hist->payments);   
  strcpy(docu_payments_new_charges,bill_hist->new_charges); 
  strcpy(docu_payments_total_amt_due,bill_hist->total_due);   
  strcpy(docu_payments_due_now_mssg," ");    
  strcpy(docu_payments_bank_draft_mssg," ");
  payments_count++;
  extract_payments();
  initialize_payments();





} /* end PrintSumBillHistData */


/******************************************************************************
*                                                                             *
*   PrintSumPaymentMessage()                                                  *
*                                                                             *
*   Description.....: Print to the output file a message concerning the       *
*                     payment of the bill.                                    *
*                                                                             *
*   Parameters:                                                               *
*                                                                             *
*        Type             Name                     Description                *
*       ------------   --------------    --------------------------------     *
*        char *         szPaymentString   Payment Message String              *
*                                                                             *
*   Return Values:                                                            *
*                                                                             *
*        Type       Value     #define              Description                *
*       --------    -----   ----------------   --------------------------     *
*        void                                                                 *
*                                                                             *
******************************************************************************/
void PrintSumPaymentMessage(char *szPaymentString)
{
  /*----------------------------------*/ 
  /* Print the payment message string */
  /*----------------------------------*/ 
  fprintf(fpFile, "\n%20s%s", " ", szPaymentString);

  sGLineNum++;                                                                
  sGTotalLines++; 


} /* end PrintSumPaymentMessage */



/******************************************************************************
*                                                                             *
*   NewPage()                                                                 *
*                                                                             *
*   Description.....: Prints a new page 				      *
*                                                                             *
*   Parameters:                                                               *
*                                                                             *
*        Type             Name                     Description                *
*       ------------   --------------    --------------------------------     *
*        int		section		  Number determining which header     *
*						would be required.            *
*	 char *		parm		  Parameter for header (optional)     *
*	 int 		report		  If this is a detail or summary      *
*					  report at the point of calling the  *
*					  form.			              *	
*                                                                             *
*   Return Values:                                                            *
*                                                                             *
*        Type       Value     #define              Description                *
*       --------    -----   ----------------   --------------------------     *
*        void                                                                 *
*                                                                             *
******************************************************************************/
static void NewPage(int section, char *parm)
{
	   PrintFormFeed(sGLineNum);

	   /*---------------------------------------------*/
	   /* If this is a summary report, make sure that */
	   /* the title changes to reflect this.          */ 
	   /*---------------------------------------------*/
	   if(section > DETAILEXCEPT)
	   {
		strcpy(szGTitle, "Master Bill Summary Report");
	   }

           /*-------------------------------------*/
           /* Write a new header for the new page */
           /*-------------------------------------*/
           Header(szGLongPrintDate,
                  szGSysTime,
                  szGInstitution,
                  szGTitle,
                  iGPageNum++);

           /*-------------------------------------------------------*/
           /* Print a new header according to the current section   */
           /*-------------------------------------------------------*/
           switch(section)
   	   {
		case 1: PrintDetailAcctHeader(parm);
			break;
		case 2: PrintDetailTaxHeader();
			break;
		case 3: PrintDetailConsHeader(parm);
			break;
		case 4:
		case 6: PrintExcpHeader(parm);
			break;
		case 7: PrintSumAcctHeader();
			break;
		case 8: PrintSumBillHistHeader();
			break;
		case 9: PrintSumTaxHeader();
			break;
		case 10: PrintSumBudgHeader();
			 break;
		case 5 :
		case 11: break;
 	    }
           sGLineNum     = 10;
           sGTotalLines += 10;
}



/******************************************************************************
*                                                                             *
*   PrintMasterAddress()                                                      *
*                                                                             *
*   Description.....: Print to the output file the master customer address    *
*                                                                             *
*   Parameters:                                                               *
*                                                                             *
*        Type             Name                     Description                *
*       ------------   --------------    --------------------------------     *
*        char *        pszDueDate         Due date of the bill                *
*        char *        pszMasterName      Master customer name                *
*        char *        pszMasterAddress1  Master address part 1               *
*        char *        pszMasterAddress2  Master address part 2               *
*        char *        pszMasterAddress3  Master address part 3               *
*        char *        pszMasterAddress4  Master address part 4               *
*        char *        pszMasterAddress5  Master address part 5               *
*        short         iInd               Array index                         *
*                                                                             *
*   Return Values:                                                            *
*                                                                             *
*        Type       Value     #define              Description                *
*       --------    -----   ----------------   --------------------------     *
*        void                                                                 *
*                                                                             *
******************************************************************************/
void PrintMasterAddress(char *pszDueDate,
                        char *pszMasterName,
                        char *pszMasterAddress1,
                        char *pszMasterAddress2,
                        char *pszMasterAddress3,
                        char *pszMasterAddress4,
                        char *pszMasterAddress5,
                        short iInd)
     {
     /*----------------------------------------------------------------------*/
     /* Print the due date                                                   */
     /*----------------------------------------------------------------------*/
     fprintf(fpFile, "%s", pszDueDate);
     
     /*----------------------------------------------------------------------*/
     /* Output the master customer line                                      */
     /*----------------------------------------------------------------------*/
     fprintf(fpFile, "\n%9d  ",               ucbmbil_mbil_num[iInd]);
     fprintf(fpFile, "%9d",                   ucbmbil_cust_code[iInd]);
     fprintf(fpFile, "%7s  ",                 ucbmbil_prem_code[iInd]);
     fprintf(fpFile, "%-32s\n",               pszMasterName);
     fprintf(fpFile, "%18s%-32s\n",      " ", pszMasterAddress1);
     if ((int)strlen(pszMasterAddress2) > 0)
          {
          fprintf(fpFile, "%18s%-32s\n", " ", pszMasterAddress2);
          sGLineNum    += 1;
          sGTotalLines += 1;
          }
     if ((int)strlen(pszMasterAddress3) > 0)
          {
          fprintf(fpFile, "%18s%-32s\n", " ", pszMasterAddress3);
          sGLineNum    += 1;
          sGTotalLines += 1;
          }
     if ((int)strlen(pszMasterAddress4) > 0)
          {
          fprintf(fpFile, "%18s%-32s\n", " ", pszMasterAddress4);
          sGLineNum    += 1;
          sGTotalLines += 1;
          }
     fprintf(fpFile, "%18s%-42s\n",      " ", pszMasterAddress5);
     
     sGLineNum    += 7;
     sGTotalLines += 7;
     sGRecordCount++;

     sprintf(docu_mastradr_master_bill_number,"%9d",ucbmbil_mbil_num[iInd]);  
     sprintf(docu_mastradr_cust_code,"%d",ucbmbil_cust_code[iInd]);           
     strcpy(docu_mastradr_prem_code,ucbmbil_prem_code[iInd]);           
     strcpy(docu_mastradr_addr_name,pszMasterName);           
     strcpy(docu_mastradr_addr_line1,pszMasterAddress1);          
     strcpy(docu_mastradr_addr_line2,pszMasterAddress2);          
     strcpy(docu_mastradr_addr_line3,pszMasterAddress3);          
     strcpy(docu_mastradr_addr_line4,pszMasterAddress4);
     strcpy(docu_mastradr_addr_line5,pszMasterAddress5);          
     strcpy(docu_mastradr_city," ");                
     strcpy(docu_mastradr_state," ");               
     strcpy(docu_mastradr_zipcode," ");             
     strcpy(docu_mastradr_nation," ");             
      
      mastradr_count++;
      extract_masteraddr_info();
      initialize_masteraddr_info();
     }                                             /* end PrintMasterAddress */

/******************************************************************************
*                                                                             *
*   PrintAcctHeader()                                                         *
*                                                                             *
*   Description.....: Print to the output file the subordinate account        *
*                     header information                                      *
*                                                                             *
*   Parameters:                                                               *
*                                                                             *
*        Type             Name                     Description                *
*       ------------   --------------    --------------------------------     *
*        void                                                                 *
*                                                                             *
*   Return Values:                                                            *
*                                                                             *
*        Type       Value     #define              Description                *
*       --------    -----   ----------------   --------------------------     *
*        void                                                                 *
*                                                                             *
******************************************************************************/
void PrintAcctHeader(void)
     {
     fprintf(fpFile, "\n\n Customer  Premises  "        );
     fprintf(fpFile, "--------Service Address--------  ");
     fprintf(fpFile, "  Bill Date       Bal Due\n"      );
     }                                                /* end PrintAcctHeader */

/******************************************************************************
*                                                                             *
*   PrintAcctData()                                                           *
*                                                                             *
*   Description.....: Print to the output file the subordinate account        *
*                     billing information                                     *
*                                                                             *
*   Parameters:                                                               *
*                                                                             *
*        Type             Name                     Description                *
*       ------------   --------------    --------------------------------     *
*        long          lCustCode          Subordinate customer code           *
*        char *        pszPremCode        Subordinate premises code           *
*        char *        pszAddress         Service address                     *
*        char *        pszBillDate        Service billing date                *
*        char *        pszBalanceDue      Balance due for service             *
*                                                                             *
*   Return Values:                                                            *
*                                                                             *
*        Type       Value     #define              Description                *
*       --------    -----   ----------------   --------------------------     *
*        void                                                                 *
*                                                                             *
******************************************************************************/
void PrintAcctData(long lCustCode,
                   char *pszPremCode,
                   char *pszAddress,
                   char *pszBillDate,
                   char *pszBalanceDue)
     {
     char      *pch  = (char *)NULL;
     char      *pch2 = (char *)NULL;

     fprintf(fpFile, "%9d   ",   lCustCode    );
     fprintf(fpFile, "%7s  ",    pszPremCode  );

     if ((int)strlen(pszAddress) > 31)
          {
          pch = &pszAddress[31];

          while (*pch != ' ' && pch != &pszAddress[0])
               pch--;

          if (pch != &pszAddress[0])
               {
               *pch = '\0';
               fprintf(fpFile, "%31.31s    ", pszAddress);
               fprintf(fpFile, "%-10s ",   pszBillDate  );
               fprintf(fpFile, "%12.12s\n",pszBalanceDue);

               pch++;
               pch2 = pch;

               while ((int)strlen(pch2) > 31)
                    {
                    pch = ((int)strlen(pch) <= 31 ? (pch + (int)strlen(pch)) :
                                                    (pch + 31));

                    while (*pch != ' ' && pch != pch2)
                         pch--;

                    *pch = '\0';
                    fprintf(fpFile, "%21s%31.31s\n", " ", pch2);

                    sGLineNum    += 1;
                    sGTotalLines += 1;   

                    pch++;
                    pch2 = pch;
                    }

               fprintf(fpFile, "%21s%31.31s\n", " ", pch2);

               sGLineNum    += 1;
               sGTotalLines += 1;   
               }
          else
               {
               fprintf(fpFile, "%31.31s    ", pszAddress);
               fprintf(fpFile, "%-10s ",   pszBillDate  );
               fprintf(fpFile, "%12.12s\n",pszBalanceDue);
               }
          }
     else
          {
          fprintf(fpFile, "%31.31s    ", pszAddress   );
          fprintf(fpFile, "%-10s ",   pszBillDate  );
          fprintf(fpFile, "%12.12s\n",pszBalanceDue);
          }
     }                                                  /* end PrintAcctData */

/******************************************************************************
*                                                                             *
*   PrintTotalDue()                                                           *
*                                                                             *
*   Description.....: Print to the output file the total amount due           *
*                                                                             *
*   Parameters:                                                               *
*                                                                             *
*        Type             Name                     Description                *
*       ------------   --------------    --------------------------------     *
*        char *         pszTotalDue       Total due string                    *
*                                                                             *
*   Return Values:                                                            *
*                                                                             *
*        Type       Value     #define              Description                *
*       --------    -----   ----------------   --------------------------     *
*        void                                                                 *
*                                                                             *
******************************************************************************/
void PrintTotalDue(char *pszTotalDue)
     {
     fprintf(fpFile, "\n%64s%15s\n\n", "Total", pszTotalDue);
     }                                                  /* end PrintTotalDue */

/******************************************************************************
*                                                                             *
*   PrintNoPaymentNeeded()                                                    *
*                                                                             *
*   Description.....: Print to the output file the total amount due along     *
*                     with a message stating that no payment is needed        *
*                     because the account is being drafted for the amount     *
*                     due.                                                    *
*                                                                             *
*   Parameters:                                                               *
*                                                                             *
*        Type             Name                     Description                *
*       ------------   --------------    --------------------------------     *
*        char *         pszTotalDue       Total due string                    *
*                                                                             *
*   Return Values:                                                            *
*                                                                             *
*        Type       Value     #define              Description                *
*       --------    -----   ----------------   --------------------------     *
*        void                                                                 *
*                                                                             *
******************************************************************************/
void PrintNoPaymentNeeded(char *pszTotalDue)
     {
     fprintf(fpFile, "%s%s\n\n%64s%15s\n%79s\n", 
             "Account will be drafted for the amount shown on/around ",
             szGDraftDate,
             "Total", pszTotalDue,
             "Do not pay -- account is being drafted for the amount owed");
     }                                           /* end PrintNoPaymentNeeded */

/******************************************************************************
*                                                                             *
*   PrintPleasePay()                                                          *
*                                                                             *
*   Description.....: Print to the output file the total amount due along     *
*                     with a message stating that a payment is required       *
*                     because the amount due is outside of the minimum or     *
*                     maximum amounts.                                        *
*                                                                             *
*   Parameters:                                                               *
*                                                                             *
*        Type             Name                     Description                *
*       ------------   --------------    --------------------------------     *
*        char *         pszTotalDue       Total due string                    *
*                                                                             *
*   Return Values:                                                            *
*                                                                             *
*        Type       Value     #define              Description                *
*       --------    -----   ----------------   --------------------------     *
*        void                                                                 *
*                                                                             *
******************************************************************************/
void PrintPleasePay(char *pszTotalDue)
     {
     fprintf(fpFile, "\n\n%64s%15s\n%79s\n", 
             "Total", pszTotalDue,
             "PLEASE PAY -- Amount is NOT being drafted");
     }                                                 /* end PrintPleasePay */

/******************************************************************************
*                                                                             *
*   PrintServiceHeader()                                                      *
*                                                                             *
*   Description.....: Print to the output file the service summary header     *
*                                                                             *
*   Parameters:                                                               *
*                                                                             *
*        Type             Name                     Description                *
*       ------------   --------------    --------------------------------     *
*        void                                                                 *
*                                                                             *
*   Return Values:                                                            *
*                                                                             *
*        Type       Value     #define              Description                *
*       --------    -----   ----------------   --------------------------     *
*        void                                                                 *
*                                                                             *
******************************************************************************/
void PrintServiceHeader(void)
     {
     fprintf(fpFile, "\n");
     fprintf(fpFile, "      Service                  Count  Metered Cons");
     fprintf(fpFile, "    Billed Cons    Billed Amt\n");
     }                                             /* end PrintServiceHeader */

/******************************************************************************
*                                                                             *
*   PrintServiceData()                                                        *
*                                                                             *
*   Description.....: Print to the output file the service summary data       *
*                                                                             *
*   Parameters:                                                               *
*                                                                             *
*        Type             Name                     Description                *
*       ------------   --------------    --------------------------------     *
*        PNODETYPE     pList              Service linked list node            *
*        char *        pszServiceDesc     Service description string          *
*        char *        pszMeteredCons     Metered consumption string          *
*        char *        pszBilledCons      Billed consumption string           *
*        char *        pszBilledAmount    Service billed amount               *
*                                                                             *
*   Return Values:                                                            *
*                                                                             *
*        Type       Value     #define              Description                *
*       --------    -----   ----------------   --------------------------     *
*        void                                                                 *
*                                                                             *
******************************************************************************/
void PrintServiceData(PNODETYPE pList,
                      char *pszServiceDesc,
                      char *pszMeteredCons,
                      char *pszBilledCons,
                      char *pszBilledAmount)
     {
     fprintf(fpFile, "%-30s %5d %9s %4s %9s %4s %12s\n",
             pszServiceDesc,
             pList->sCount,
             pszMeteredCons,
             pList->szUOMCode,
             pszBilledCons,
             pList->szUOMCode,
             pszBilledAmount);
     }                                               /* end PrintServiceData */

/******************************************************************************
*                                                                             *
*   Header()                                                                  *
*                                                                             *
*   Description.....: Generate and print to the output file the page          *
*                     header information                                      *
*                                                                             *
*   Parameters:                                                               *
*                                                                             *
*        Type             Name                     Description                *
*       ------------   --------------    --------------------------------     *
*        char *         pszDate           Date report was started             *
*        char *         pszTime           Time report was started             *
*        char *         pszInstitution    Name of utility                     *
*        char *         pszTitle          Report title                        *
*        int            iPageNum          Report page number                  *
*                                                                             *
*   Return Values:                                                            *
*                                                                             *
*        Type       Value     #define              Description                *
*       --------    -----   ----------------   --------------------------     *
*        void                                                                 *
*                                                                             *
******************************************************************************/
void Header(char  *pszDate,
            char  *pszTime,
            char  *pszInstitution,
            char  *pszTitle,
            int    iPageNum)
     {
     char      szLeftLine  [23];             /* Left format line segment     */
     char      szMidLine   [34];             /* Middle format line segment   */
     char      szRightLine [23];             /* Right format line segment    */
     short     sLength = 0;                  /* Used for string lengths      */
     short     sIndex  = 0;                  /* Index into strings           */

     /*----------------------------------------------------------------------*/
     /* If the trace flag is set print a debugging message                   */
     /*----------------------------------------------------------------------*/
     if (Trace_flag)
          printf("UBRMBPR: Header Routine Begin ... ");

     /*----------------------------------------------------------------------*/
     /* Initialize the line segments                                         */
     /*----------------------------------------------------------------------*/
     memset(szLeftLine,  ' ',  23);
     memset(szRightLine, 0x00, 23);
     memset(szMidLine,   ' ',  34);
     szLeftLine[22] = '\0';
     szMidLine[33]  = '\0';

     /*----------------------------------------------------------------------*/
     /* The left portion of the line will have the date                      */
     /*----------------------------------------------------------------------*/
     memcpy(&szLeftLine[0], pszDate, 18);

     /*----------------------------------------------------------------------*/
     /* Center the utility name within the middle line segment               */
     /*----------------------------------------------------------------------*/
     sLength = strlen(pszInstitution);
     sIndex  = 17 - (short)(sLength / 2);
     memcpy(&szMidLine[sIndex], pszInstitution, sLength);

     /*----------------------------------------------------------------------*/
     /* The right line segment will contain the updated page number          */
     /*----------------------------------------------------------------------*/
     sprintf(szRightLine, "Page %d", iPageNum);

     /*----------------------------------------------------------------------*/
     /* Print the line - left justifying the left segment, centering the     */
     /* middle segment, and right justifying the right segment               */
     /*----------------------------------------------------------------------*/
     fprintf(fpFile, "\n\n\n\n\n");
     fprintf(fpFile, "%-23s%34s%23s\n", szLeftLine, szMidLine, szRightLine);

     /*----------------------------------------------------------------------*/
     /* Reinitialize the line segments                                       */
     /*----------------------------------------------------------------------*/
     memset(szLeftLine,  0x00, 23);
     memset(szRightLine, 0x00, 23);
     memset(szMidLine,   ' ',  34);
     szMidLine[33] = '\0';

     /*----------------------------------------------------------------------*/
     /* Center the report name within the middle line segment                */
     /*----------------------------------------------------------------------*/
     sLength = strlen(pszTitle);
     sIndex  = 17 - (short)(sLength / 2);
     memcpy(&szMidLine[sIndex], pszTitle, sLength);

     /*----------------------------------------------------------------------*/
     /* Print out the line - the left and right segments are now empty       */
     /*----------------------------------------------------------------------*/
     fprintf(fpFile, "%23s%34s%23s\n", szLeftLine, szMidLine, szRightLine);

     /*----------------------------------------------------------------------*/
     /* If the trace flag is set print a debugging message                   */
     /*----------------------------------------------------------------------*/
     if (Trace_flag)
          printf("End\n");
     }                                                         /* end Header */

/******************************************************************************
*                                                                             *
*   ControlFooter()                                                           *
*                                                                             *
*   Description.....: Generate and print to the output file the report        *
*                     control information                                     *
*                                                                             *
*   Parameters:                                                               *
*                                                                             *
*        Type             Name                     Description                *
*       ------------   --------------    --------------------------------     *
*        void                                                                 *
*                                                                             *
*   Return Values:                                                            *
*                                                                             *
*        Type       Value     #define              Description                *
*       --------    -----   ----------------   --------------------------     *
*        void                                                                 *
*                                                                             *
******************************************************************************/
void ControlFooter(void)
     {
     char      szTemp[9] = "";
     short     sCursOpen = FALSE;

     /*----------------------------------------------------------------------*/
     /* If the trace flag is set print a debugging message                   */
     /*----------------------------------------------------------------------*/
     if (Trace_flag)
          printf("UBRMBPR: ControlFooter Routine Begin ...\n");

     /*----------------------------------------------------------------------*/
     /* Write a new header for the new page                                  */
     /*----------------------------------------------------------------------*/
     Header(szGSysDate,     
            szGSysTime,
            szGInstitution,
            szGTitle,
            iGPageNum++);

     /*----------------------------------------------------------------------*/
     /* Write the special control information                                */
     /*----------------------------------------------------------------------*/
     fprintf(fpFile, "%62s", "* * * REPORT CONTROL INFORMATION * * *\n\n");
     fprintf(fpFile, "Current Release: 2.0.3.4.1\n\n");
     fprintf(fpFile, "Parameter Sequence Number: %ld\n", lGOneUp);
     fprintf(fpFile, "Master Customer Codes:");

     while (ReadMasterCode(&sCursOpen, lGOneUp, szTemp))
          fprintf(fpFile, " %s", szTemp);

     fprintf(fpFile, "%s", (sGRptRestart ? " (Restart)\n" : "\n"));
     fprintf(fpFile, "Print Date: %s\n", szGPrintDate);
     fprintf(fpFile, "Due Date: %s\n", szGRptDueDate);
     fprintf(fpFile, "Restart Indicator: %s\n",
                     (sGRptRestart ? "Y" : "N"));
     fprintf(fpFile, "Address Selection Date: %s\n", szGAddrDate);
     fprintf(fpFile, "Address Type Hierarchy:");

     sCursOpen = FALSE;
     while (ReadAddrType(&sCursOpen, lGOneUp, szTemp))
          fprintf(fpFile, " %s", szTemp);

     fprintf(fpFile, "%s", (sGRptRestart ? " (Restart)\n" : "\n"));
     fprintf(fpFile, "Number of Printed Lines Per Page: %d\n", sGLineCount);
     fprintf(fpFile, "Record Count: %d\n", sGRecordCount);

     sGTotalLines += 20;

     /*----------------------------------------------------------------------*/
     /* If the trace flag is set print a debugging message                   */
     /*----------------------------------------------------------------------*/
     if (Trace_flag)
          printf("UBRMBPR: ControlFooter Routine End\n");
     }                                                  /* end ControlFooter */

/******************************************************************************
*                                                                             *
*   PrintFormFeed()                                                           *
*                                                                             *
*   Description.....: Finish out the rest of the page either with a form      *
*                     feed character or by printing blank lines               *
*                                                                             *
*   Parameters:                                                               *
*                                                                             *
*        Type             Name                     Description                *
*       ------------   --------------    --------------------------------     *
*        short          sIndex            Line count to begin printing        *
*                                                                             *
*   Return Values:                                                            *
*                                                                             *
*        Type       Value     #define              Description                *
*       --------    -----   ----------------   --------------------------     *
*        void                                                                 *
*                                                                             *
******************************************************************************/
void PrintFormFeed(short sIndex)
     {
     /*----------------------------------------------------------------------*/
     /* If the form feed flag was set use form feed instead of               */
     /* just writing blank lines                                             */
     /*----------------------------------------------------------------------*/
     if (ff_flag)
          {
          fprintf(fpFile, "\f\n");
          sGTotalLines++;
          }
     else
     while (sIndex++ < PAGE_SZE)
          {
          fprintf(fpFile, "\n");
          sGTotalLines++;
          sGLineNum++;
          }
     }                                                  /* end PrintFormFeed */
