/******************************************************************************/
/* UBPBPFM.PC - Bill Print Format Subroutines                                 */
/* Montgomery version.                                                        */
/* UBPBPFM.PC Copyright (c) SCT Corporation 1993.  All rights reserved.       */
/******************************************************************************/

/***************************************************/
/*                                                 */
/*       CONFIDENTIAL BUSINESS INFORMATION         */
/*                                                 */
/*      **********************************         */
/*                                                 */
/*  THIS PROGRAM IS PROPRIETARY INFORMATION OF     */
/* SYSTEMS AND COMPUTER TECHNOLOGY CORPORATION     */
/* AND IS NOT TO BE COPIED, REPRODUCED, LENT OR    */
/* DISPOSED OF, NOR USED FOR ANY PURPOSE OTHER     */
/* THAN THAT FOR WHICH IT IS SPECIFICALLY PROVIDED */
/* WITHOUT THE WRITTEN PERMISSION OF SAID COMPANY  */
/*                                                 */
/***************************************************/
/* UBPBPFM.PC                                                             */
/* Bill Print Format Subroutines                                          */
/*                                                                        */
/* This is the customer specific set of subroutines to be included in     */
/* program UBPBILP.PC.                                                    */
/* See that program's documentation for Tables, etc.                      */
/*                                                                        */
/* AUDIT TRAIL                                        INIT    DATE        */
/* -------------------------------------------------  ----  --------      */
/* Release: 1.1                                                           */
/* 1.  Broken out of UBPBILP.PC                       RMG   01-DEC-1993   */
/* 2.  Fixed problem with printing duplicate bills    EBR   27-APR-1994   */
/*     via UBADUPB for accts w/extended due dates.                        */
/*                                                                        */
/* AUDIT TRAIL: 8.0 */
/* AUDIT TRAIL END */
EXEC SQL BEGIN DECLARE SECTION;
  static CHAR10  hold_prev_reading="";
  static CHAR10  hold_present_reading="";
  static CHAR9   hold_prev_date="";
  static CHAR9   hold_present_date="";
  static NUMSTR  nszPreviousBalance="";
  static CHAR2   szUtvsratAsvcCode="";
  static CHAR9   prev_date_flat="";
  static CHAR9   present_date_flat="";
  static NUMSTR  meter_diff;
  static CHAR8   total_string;
  static CHAR4   m_xx;
  static NUMSTR  m_garbage_tot;
  static NUMSTR  m_other_tot;
  static NUMSTR  m_grand_tot;
  static CHAR10  garbage_digits;
  static CHAR10  other_digits;
  static CHAR10  grand_digits;
  static CHAR14  acct_digits;
  static int     sum1;
  static int     sum2;
  static int     sum3;
  static int     sum4;
EXEC SQL END DECLARE SECTION;

/* Local C variables */

  int  product;
  int  check_digit[8] = { 9, 8, 7, 6, 5, 4, 3, 2 };
  char digit_char[2];
  int  digit;
  int  bOneMeterPresent = FALSE;  /* boolean */

/* Local prototypes */

static void installation_init(void);
static void installation_body_init(void);
static void m_line_11(void);
static void m_line_14(void);
static void m_message_line(void);
static void insert_blank_line(void);
static void line_31_multi(void);
static void line_47_multi(void);
static void update_bunch_code(void);
static void insert_multiple_pages(void);
static void print_address(void);
static void print_budget_footnote(void);
static void print_budget_line(void);
static void m_print_line_06(void);
static void m_print_line_07(void);
static void m_print_line_08(void);
static void m_print_line_09(void);
static void m_print_line_11(void);
static void m_print_line_14(void);
static void m_print_line_22(void);
static void m_print_line_25(void);
static void m_print_line_27(void);
static void m_print_message_lines(void);
static void print_detail_line(void);
static void print_detail_line_2(void);
static void print_detail_line_change_out_2(void);
static void print_detail_line_adjustments(void);
static void print_line_05_30_text(void);
static void print_blank_line(void);
static void print_unprinted_bill(void);
static void print_printed_bill(void);
static void uabopen_head(void);
static void uabopen_body(void);
static void uabopen_foot(void);
static void adjustment_head(void);
static void adjustment_body(void);
static void adjustment_foot(void);
static int m_select_prev_bal(int mode);
static void print_barcode_zip(void);
static void print_draft_next_month_msg(void);
static void print_draft_msg(void);
static void m_print_line_16_dupl(void);
static void m_print_line_10_draft(void);
static void print_rdup(void);
static void m_print_line_10_no_pay(void);
static void print_please_pay_msg(void);
static void m_print_line_10_please_pay(void);

  /****************************************************************************/
  /****************************************************************************/
  /*--------------------------------------------------------------------------*/
  /* Installation Initializations                                             */
  /*--------------------------------------------------------------------------*/
  /****************************************************************************/
  /****************************************************************************/

static void installation_init(void)
{
  /*  Line number that address lines should follow on page  */
  /*  To print address at very top, set to "0".             */
  strcpy(address_after_line,"0");
}

static void installation_body_init(void)
{
  bOneMeterPresent = FALSE;
}

  /****************************************************************************/
  /****************************************************************************/
  /*--------------------------------------------------------------------------*/
  /*  print_unprinted_bill and print_printed_bill, top level control for      */
  /*  format modules.  Called from BODY in ubpbilp.pc                         */
  /*--------------------------------------------------------------------------*/
  /****************************************************************************/
  /****************************************************************************/

/* ************************************************************************** */
/* print bills that have never been printed before (printed_inds = 'N')       */
/* ************************************************************************** */

static void print_unprinted_bill(void)
{

  strcpy(m_garbage_tot,"0");
  strcpy(m_other_tot,"0");

/* select the next bhst_tran_num from the sequence */

  select_ubsbhst(FIRST_ROW);

  strcpy(amount_due,"0");
  strcpy(adjustments,"0");

/* prev balance */

  tonum(prev_bal,null);

/* Montgomery splits water/refuse and prints previous balances separately */

  m_select_prev_bal(FIRST_ROW);
  if (!*nszPreviousBalance) {
    strcpy(prev_bal,"0");
  }
  else {
    add(amount_due,amount_due,nszPreviousBalance);
    strcpy(text,"Previous Balance:");
    if (compare(szUtvsratAsvcCode,"WT",EQS))
       m_print_line_27();
    else
      strcpy(prev_bal,"0");
  }

/* adjustments            */
/*                        */

    strcpy(line_05_30_lineno,"28");

    report(select_adjs_unprinted,adjustment_body,adjustment_head,adjustment_foot);

    add(amount_due,amount_due,adjustments);

/* payments */

    tonum(payments,null);
    select_payments_unbilled(FIRST_ROW);
    if ( !*payments )
      strcpy(payments,"0");
    else
      subtract(amount_due,amount_due,payments);

    strcpy(amount,payments);
/*     strcpy(payments,ubbbhst_payments); */

/* get balance of account */
/* At this point, as we are processing each open item, we do not yet know
   what the final amount due will be.  So we go get it and store it in
   amount_due_balance.  This field differs from amount_due, which will
   eventually be the same amount but is just being computed as we go along
   at this point in the logic.                                             */

    strcpy(bill_balance,"0");
    strcpy(payments_zero_bill,"0");
    select_payments_zero_bill(FIRST_ROW);
    uabopen_bill_balance(FIRST_ROW);
    subtract(amount_due_balance,bill_balance,payments_zero_bill);
    
/*  Commented out 1/25/94, RMG - test will be done right before UBRRECP
    insert anyhow, and some updates within UABOPEN get skipped if done here.

    if ((compare(amount_due_balance,"0",EQ))
      && (print_zero_balance_bills_var[0]=='N'))
        return;
*/

/* compute round up if necessary */

    if (ucracct_rdup_ind[0]=='Y' && *uobsysc_srat_code_rdup)
      insert_roundup();

/* open item charges */

    report(uabopen_selmacro_unprinted,uabopen_body,uabopen_head,uabopen_foot);

    subtract(balance_forward,prev_bal,payments);

    if ( compare(amount_due,"0",LT) ) {
      strcpy(text,"Credit Balance ");
      strcpy(credit_bill_ind,"Y");
    }
    else {
      strcpy(text,"Total Amount Due ");    /*  Montgomery Change */
      strcpy(credit_bill_ind,null);
    }
    strcpy(amount,amount_due);
    print_line_05_30_text();
    print_blank_line();

/* if we had a budgeted service, print footnote explaining */
/* '*' beside charges                                      */

    print_budget_footnote();

    bank_drafts();
                                                         
    if (*uobsysc_srat_code_rdup)
      check_rdup_msg();

    if (ubtibil_type_ind[0] == 'D')
      m_print_line_16_dupl();

    if (ucbmbil_sub_pymt_ind[0]=='N')
      m_print_line_10_no_pay();

    m_print_line_06();
    m_print_line_07();
    m_print_line_08();
    m_print_line_09();
    m_print_line_11();    /* also prints identical line 47 */
    m_print_line_14();    /* also prints identical line 44 */
    m_print_line_22();
    m_print_line_25();

/* print the system-wide, customer-specific, and/or account specific */
/* bill message                                                      */

    strcpy(line_05_30_lineno,"27");
    m_print_message_lines();

/* if we have multi-page bills, duplicate line 47                     */
/* on all pages of the bill.  Also print the page number on all pages */

    if ( *multi_page_ind ) {
      count_pages();
      insert_multiple_pages();
    }

}                                        /* end print_unprinted_bill */

/* ************************************************************************** */
/* print bills that have been printed before (printed_inds = 'Y')             */
/* ************************************************************************** */

static void print_printed_bill(void)
{
  strcpy(m_garbage_tot,"0");
  strcpy(m_other_tot,"0");

/* get the due date from one of the open items for this */
/* billing                                              */

  select_due_date_printed(FIRST_ROW);

  strcpy(amount_due,"0");
  strcpy(adjustments,"0");
  strcpy(line_05_30_lineno,"28");

/* prev balance */

  strcpy(text,"Previous Balance:");
  strcpy(amount,ubbbhst_prev_bal);
  strcpy(prev_bal,ubbbhst_prev_bal);

/* payments */

  strcpy(text,"Less Payments:");
  strcpy(amount,ubbbhst_payments);
  strcpy(payments,ubbbhst_prev_bal);

/* open item charges */

  report(uabopen_selmacro_printed,uabopen_body,uabopen_head,uabopen_foot);

/* adjustments */

  if ( compare(ubbbhst_adjustments,"0",NE) )
    strcpy(amount,ubbbhst_adjustments);

/* amount due */

    if ( compare(ubbbhst_ending_bal,"0",LT) ) {
      strcpy(text,"Credit Balance:");
      strcpy(credit_bill_ind,"Y");
    }
    else {
      strcpy(text,"Amount Due:");
      strcpy(credit_bill_ind,null);
    }
    strcpy(amount,ubbbhst_ending_bal);
    strcpy(amount_due,ubbbhst_ending_bal);

    subtract(balance_forward,prev_bal,payments);

    if ( compare(amount_due,"0",LT) ) {
      strcpy(text,"Credit Balance ");
      strcpy(credit_bill_ind,"Y");
    }
    else {
      strcpy(text,"Total Amount Due ");    /*  Montgomery Change */
      strcpy(credit_bill_ind,null);
    }
    strcpy(amount,amount_due);
    print_line_05_30_text();
    print_blank_line();

/* if we had a budgeted service, print footnote explaining */
/* '*' beside charges                                      */

    print_budget_footnote();

    bank_drafts();

    if (*uobsysc_srat_code_rdup)
      check_rdup_msg();

    if (ubtibil_type_ind[0] == 'D')
      m_print_line_16_dupl();

    if (ucbmbil_sub_pymt_ind[0]=='N')
      m_print_line_10_no_pay();

    m_print_line_06();
    m_print_line_07();
    m_print_line_08();
    m_print_line_09();
    m_print_line_11();    /* also prints identical line 47 */
    m_print_line_14();    /* also prints identical line 44 */
    m_print_line_22();
    m_print_line_25();

/* print the system-wide, customer-specific, and/or account specific */
/* bill message                                                      */

    strcpy(line_05_30_lineno,"27");
    m_print_message_lines();

/* if we have multi-page bills, duplicate line 47                     */
/* on all pages of the bill.  Also print the page number on all pages */

    if ( *multi_page_ind ) {
      count_pages();
      insert_multiple_pages();
    }

}                                        /* end print_printed_bill */

  /****************************************************************************/
  /****************************************************************************/
  /*--------------------------------------------------------------------------*/
  /*   uabopen head and body.  Called from print_printed_bill,                */
  /*   print_unprinted_bill for each open item to print in center of page.    */
  /*--------------------------------------------------------------------------*/
  /****************************************************************************/
  /****************************************************************************/

/* ************************************************************************** */
/* uabopen head                                                               */
/* ************************************************************************** */

static void uabopen_head(void)
{
  select_serv_info(FIRST_ROW);
  test_for_budget();
  strcpy(break_serv_num,uabopen_serv_num);
  strcpy(total_budget_amount,"0");

  /*  Montgomery changes  */
  strcpy(hold_present_reading,"");
  strcpy(hold_prev_reading,"");
  strcpy(hold_prev_date,"");
  strcpy(hold_present_date,"");
  strcpy(present_date_flat,"");
  strcpy(prev_date_flat,"");
  /*  End Montgomery changes  */

  uabopen_body();
}                                        /* end uabopen_head */

/* *********************************************************************** */
/* uabopen body                                                            */
/* *********************************************************************** */

static void uabopen_body(void)
{

/* check for service break */

  if ( compare(break_serv_num,uabopen_serv_num,NE) ) {
    /* if this was a budgeted_service */
    if ( *budgeted_service_ind )
      print_budget_line();
    test_for_budget();
    select_serv_info(FIRST_ROW);
    strcpy(break_serv_num,uabopen_serv_num);
  }

/* clear detail line fields */

    strcpy(ubbchst_billed_consump,"        ");
    strcpy(present_reading,"         ");
    strcpy(prev_reading,"         ");
    strcpy(urrshis_multiplier,"         ");
    strcpy(urrshis_high_low_excp," ");

    if (*uabopen_chrg_calc_num && *non_metered_ind) {
      /* select the non-metered info if we have the primary rate */
      select_dos_flat(FIRST_ROW);
      select_present_date_flat(FIRST_ROW);
      strcpy(present_date_flat,present_date);
      select_previous_date_flat(FIRST_ROW);
      strcpy(prev_date_flat,prev_date);
    }
    else {
      if (*uabopen_chrg_calc_num) {
        /* select the metered info if we have the primary rate */
        select_previous_reading(FIRST_ROW);
        if (!bOneMeterPresent) {
          strcpy(hold_prev_date,prev_date);
          strcpy(hold_prev_reading,prev_reading);
        }
        select_present_reading(FIRST_ROW);
        if(!bOneMeterPresent) {
          strcpy(hold_present_date,present_date);
          strcpy(hold_present_reading,present_reading);
        }
        select_change_out_reading(FIRST_ROW);
        select_dos(FIRST_ROW);
        bOneMeterPresent = TRUE;
        if (change_out_ind[0]== 'Y') {
          subtract(change_out_cons,change_out_reading,prev_reading_2);
          /* print_detail_line_change_out_2();  Montgomery change */
          strcpy(change_out_ind,"N");
          select_present_reading(FIRST_ROW);
          if(!bOneMeterPresent) {
            strcpy(hold_present_date,present_date);
            strcpy(hold_present_reading,present_reading);
          }
          sel_previous_reading_new_meter(FIRST_ROW);
          /* print the open item detail */
          print_detail_line();
        }
        select_previous_reading(FIRST_ROW);
        if (!bOneMeterPresent) {
          strcpy(hold_prev_date,prev_date);
          strcpy(hold_prev_reading,prev_reading);
        }
        select_present_reading(FIRST_ROW);
        if(!bOneMeterPresent) {
          strcpy(hold_present_date,present_date);
          strcpy(hold_present_reading,present_reading);
        }
        select_dos(FIRST_ROW);
        select_cons_history(FIRST_ROW);
        /* print the open item detail */
        print_detail_line_2();
      }
      else {
        select_previous_reading(FIRST_ROW);
        if (!bOneMeterPresent) {
          strcpy(hold_prev_date,prev_date);
          strcpy(hold_prev_reading,prev_reading);
        }
        select_present_reading(FIRST_ROW);
        if(!bOneMeterPresent) {
          strcpy(hold_present_date,present_date);
          strcpy(hold_present_reading,present_reading);
        }
        select_dos(FIRST_ROW);
        select_cons_history(FIRST_ROW);
        /* print the open item detail */
        print_detail_line_2();
      }
    }

/* total the adjustments for the open item we are currently processing. */

    tonum(uabadje_budget_variance,null);
    tonum(uabadje_billed_chg,null);
    strcpy(adj_ind,null);
    select_adjs_printed(FIRST_ROW);

/* total the charges */

    if ( *budgeted_service_ind && compare(budgeted_service_ind,"C",NES) ) {
      /* we have a budgeted service, add the budget charges to the */
      /* charges total and insert the budget charge line           */
      strcpy(budget_footnote,"Y");
      if ( *uabadje_budget_variance )
        add(uabopen_budget_variance,uabopen_budget_variance,uabadje_budget_variance);
      if ( *uabadje_billed_chg )
        add(uabopen_billed_chg,uabopen_billed_chg,uabadje_billed_chg);
      subtract(budget_amount,uabopen_billed_chg,uabopen_budget_variance);
      add(charges,charges,budget_amount);
      add(total_budget_amount,total_budget_amount,budget_amount);
    }
    else
      add(charges,charges,uabopen_billed_chg);

/* ********************************************************************* */
/* update routines - do not execute if in reprint mode                   */
/* ********************************************************************* */

    if ( *reprint_date_var ||
      (*sleep_wake_ind && ubtibil_calc_update_ind[0] != 'Y') )
        return;

/* If the account has a payment arrangement, check the open item        */
/* and determine if it needs to be updated into uarpyar.  It needs to   */
/* be updated/inserted when:                                            */
/*  1) A debit open item is found with no due date (31-dec-2099) and    */
/*     has not been printed on a bill                                   */
/*  2) A debit adjustment is found that has not been printed on a bill. */

    if ( *ucracct_pmnt_arr ) {
      /* we have a payment arrangement, total the debit adjs for this */
      /* open item                                                    */
      strcpy(adj_ind,null);
      select_adjs_pay_arrng(FIRST_ROW);
      if ( *adj_ind )
        add(debit_adjs,debit_adjs,uabadje_balance);
      /* check to see if the open item has a due date and a debit amount */
      if ( compare(uabopen_due_date,"31-DEC-2099",EQS) &&
        compare(uabopen_billed_chg,"0",GT) ) {
          /* we have a positive charge, update/insert a row to uarpyar */
          strcpy(amount,uabopen_billed_chg);
          update_insert_pmnt_arrng();
      }
    }

/* update the printed indicator, printed date, and due date in uabopen */

    update_uabopen();

/* ********************************************************************* */
/* end update routines                                                   */
/* ********************************************************************* */

}                                        /* end uabopen_body */

/* ************************************************************************** */
/* uabopen foot                                                               */
/* ************************************************************************** */

static void uabopen_foot(void)
{
  /* if this was a budgeted_service */
  if ( *budgeted_service_ind )
    print_budget_line();
  add(amount_due,amount_due,charges);
  strcpy(text,"Total New Charges ");
  strcpy(amount,charges);
  /* print_line_05_30_text();  Montgomery change */
  /* print_blank_line();  Montgomery change */
}                                        /* end uabopen_foot */

  /****************************************************************************/
  /****************************************************************************/
  /*--------------------------------------------------------------------------*/
  /*   adjustment head, body, and foot.  Called from print_unprinted_bill.    */
  /*--------------------------------------------------------------------------*/
  /****************************************************************************/
  /****************************************************************************/

/* ************************************************************************** */
/*   a d j u s t m e n t   h e a d                                            */
/* ************************************************************************** */

static void adjustment_head(void)
{
  adjustment_body();
}

/* ************************************************************************** */
/*   a d j u s t m e n t   b o d y                                            */
/* ************************************************************************** */

static void adjustment_body(void)
{
  print_detail_line_adjustments();
  add(adjustments,adjustments,uabadje_balance);
  /* ********************************************************************** */
  /* update the printed indicator and printed date in uabadje               */
  /* if in sleep-wake mode and update-ind is off, skip updates              */
  /* ********************************************************************** */
  if (*sleep_wake_ind && ubtibil_calc_update_ind[0] != 'Y')
    return;
  update_uabadje();
}

/* ************************************************************************** */
/*   a d j u s t m e n t   f o o t                                            */
/* ************************************************************************** */

static void adjustment_foot(void)
{
  add(adjustments,adjustments,uabadje_balance);
  strcpy(amount,adjustments);
  strcpy(text,"Total Adjustments");
  print_line_05_30_text();
  print_blank_line();
}

  /****************************************************************************/
  /****************************************************************************/
  /*--------------------------------------------------------------------------*/
  /*           Report line creation                                           */
  /*--------------------------------------------------------------------------*/
  /****************************************************************************/
  /****************************************************************************/

/* ******************************************************************* */
/* print a blank text line                                             */
/* ******************************************************************* */

static void insert_blank_line(void)
{
  EXEC SQL
   INSERT INTO uimsmgr.ubrbill
        (
        ubrbill_bill_num,
        ubrbill_page_num,
        ubrbill_line_num,
        ubrbill_sess_id,
        ubrbill_text
        )
   VALUES
        (
        TO_NUMBER(:billno),
        TO_NUMBER(:line_05_30_pageno),
        TO_NUMBER(:line_05_30_lineno),
        :session_id,
        '          '
        );
  POSTORA;
}                                        /* end insert_blank_line */

/* ******************************************************************* */
/* if multi-page print continued on next page message for line 05-30   */
/* overflow                                                            */
/* ******************************************************************* */

static void line_31_multi(void)
{
  if (compare(line_05_30_pageno,"1",EQ))
    strcpy(line_05_30_lineno,"41");
  else
    strcpy(line_05_30_lineno,"44");
  EXEC SQL
   INSERT INTO uimsmgr.ubrbill
        (
        ubrbill_bill_num,
        ubrbill_page_num,
        ubrbill_line_num,
        ubrbill_sess_id,
        ubrbill_text
        )
   VALUES
        (
        TO_NUMBER(:billno),
        TO_NUMBER(:line_05_30_pageno),
        TO_NUMBER(:line_05_30_lineno),
        :session_id,
'                                                         Continued on Next Page'
        );
  POSTORA;
}                                        /* end line_31_multi */

/* ******************************************************************* */
/* insert the system-wide, customer-specific, or account-specific      */
/* bill messages for Montgomery                                        */
/* ******************************************************************* */

static void m_message_line(void)
{
  strcpy(valid_ind,"N");
  exec sql select 'Y', ubrbill_text
    into :valid_ind, :ubrbill_text
    from uimsmgr.ubrbill
    where ubrbill_bill_num = TO_NUMBER(:billno)
      and ubrbill_page_num = TO_NUMBER(:pageno)
      and ubrbill_line_num = TO_NUMBER(:line_05_30_lineno)
      and ubrbill_sess_id  = :session_id;
  POSTORA;
  if ( NO_ROWS_FOUND )
    { valid_ind[0]='\0'; }
  else
    { valid_ind[1]='\0'; }
  if (compare(valid_ind,"Y",EQS))
  {
    EXEC SQL
       UPDATE uimsmgr.ubrbill
         SET ubrbill_text =
           (select substr(:ubrbill_text,1,40) ||
                      substr(utvbmsg_message_text,1,40)
              FROM uimsmgr.utvbmsg
              WHERE utvbmsg_code = :bmsg_code)
         where ubrbill_bill_num = TO_NUMBER(:billno)
           and ubrbill_page_num = TO_NUMBER(:pageno)
           and ubrbill_line_num = TO_NUMBER(:line_05_30_lineno)
           and ubrbill_sess_id  = :session_id;
    POSTORA;                   
  }
  else
  {
    EXEC SQL
       INSERT INTO uimsmgr.ubrbill
          (
           ubrbill_bill_num,
           ubrbill_page_num,
           ubrbill_line_num,
           ubrbill_sess_id,
           ubrbill_text
          )                                            
       SELECT
           TO_NUMBER(:billno),
           TO_NUMBER(:pageno),
           TO_NUMBER(:line_05_30_lineno),
           :session_id,
           '                                        ' ||
           substr(utvbmsg_message_text,1,40)
       FROM uimsmgr.utvbmsg
       WHERE utvbmsg_code = :bmsg_code;
    POSTORA;
  }
}                                        /* end m_message_line */

/* ******************************************************************* */
/* if multi-page print page number on the bill                         */
/* overflow                                                            */
/* ******************************************************************* */

static void line_47_multi(void)
{
  if (compare(pageno,"1",EQ))
    strcpy(lineno,"42");
  else
    strcpy(lineno,"45");
  EXEC SQL
   INSERT INTO uimsmgr.ubrbill
        (
        ubrbill_bill_num,
        ubrbill_page_num,
        ubrbill_line_num,
        ubrbill_sess_id,
        ubrbill_text
        )
   VALUES
        (
        TO_NUMBER(:billno),
        TO_NUMBER(:pageno),
        TO_NUMBER(:lineno),
        :session_id,
        '                                                                    '
        ||
        'Page ' ||
        to_char(TO_NUMBER(:pageno)) ||
        ' of '  ||
        to_char(TO_NUMBER(:page_count))
        );
  POSTORA;
}                                        /* end line_47_multi */

/* ************************************************************************** */
/* override the bunch code in the bill print collector table because          */
/* the user choice to bunch finals, credits, and/or inactives or              */
/* we have a multi-page bill                                                  */
/* Montgomery: just return                                                    */
/* ************************************************************************** */

static void update_bunch_code(void)
{
  return;
}                                        /* end update_bunch_code */

/* ************************************************************************** */
/* if we have a multiple page bill, duplicate the below lines on all          */
/* pages of the bill                                                          */
/* ************************************************************************** */

static void insert_multiple_pages(void)
{
  line_47_multi();
  while(1) {
    add(pageno,pageno,"1");
    if ( compare(pageno,page_count,GT) )
      return;
    line_47_multi();
  }
}                                        /* end insert_multiple_pages */

/* ************************************************************************** */
/* print the address lines                                                    */
/* ************************************************************************** */

static void print_address(void)
{

  print_barcode_zip();

/* clear the address lines */

  strcpy(address_line1_text,null);
  strcpy(address_line2_text,null);
  strcpy(address_line3_text,null);
  strcpy(address_line4_text,null);
  strcpy(address_line5_text,null);
  strcpy(address_line6_text,null);

/* load the address fields */

  /*  Montgomery change below, to print whole page in OCR-A font. */
  
  if (first_time_scan == 1) {
    get_scan_escapes();
    first_time_scan = 0;
  }

  EXEC SQL
   SELECT
            /* :scanon_esc_parsed || font fix */
            '          ' ||
            rpad(substr(:ubrrecp_print_name,1,40),40)
     into :address_line1_text:Ind_01
     FROM  sys.dual;
  POSTORA;
  if ( NO_ROWS_FOUND ) {
    *address_line1_text='\0';
  }

  if ( *ubrrecp_street_line1 ) {
    EXEC SQL
     SELECT       '          '                            ||
                  rpad(:ubrrecp_street_line1,15) ||
                  ' ' ||
                  rpad(:ubrrecp_street_line2,15) ||
                  ' ' ||
                  rpad(:ubrrecp_street_line3,15)
     into :address_line2_text:Ind_01
     FROM sys.dual;
    POSTORA;
    if ( NO_ROWS_FOUND ) {
      *address_line2_text='\0';
    }
  }

  if ( *ubrrecp_street_name ) {
    EXEC SQL
     SELECT       '          '                            ||
                  rpad(substr(:ubrrecp_street_address,1,40),40)
     into :address_line3_text:Ind_01
     FROM sys.dual;
    POSTORA;
    if ( NO_ROWS_FOUND ) {
      *address_line3_text='\0';
    }
  }

  if ( *ubrrecp_street_line2 ) {
    EXEC SQL
     SELECT '          ' ||
              rpad(:ubrrecp_street_line2,40)
     into :address_line4_text:Ind_01
     FROM sys.dual;
    POSTORA;
    if ( NO_ROWS_FOUND ) {
      *address_line4_text='\0';
    }
  }

  if ( *ubrrecp_street_line3 ) {
    EXEC SQL
     SELECT '          '||
            rpad(:ubrrecp_street_line3,40)
     into :address_line5_text:Ind_01
     FROM sys.dual;
    POSTORA;
    if ( NO_ROWS_FOUND ) {
      *address_line5_text='\0';
    }
  }

  EXEC SQL
   SELECT '          ' ||rpad(
                :ubrrecp_city           ||
                ' '                     ||
                :ubrrecp_stat_code      ||
                ' '                     ||
                :ubrrecp_zip_1_5        ||
                decode(:ubrrecp_zip_7_10,
                        null,'',
                        '-' || :ubrrecp_zip_7_10),41)
   into :address_line6_text:Ind_01
   FROM sys.dual;
  POSTORA;
  if ( NO_ROWS_FOUND ) {
    *address_line6_text='\0';
  }

/* print the address lines                       */
/*                                               */
/* customer name and cycle code - address line 1 */

    newline();
    setmode(M_COLLIT);
    prtstr(address_line1_text);
    setmode(M_NORMAL);
    newline();
    add(prev_line_num,prev_line_num,"1");

/* attention line - address line 2 */

    if ( *address_line2_text ) {
      setmode(M_COLLIT);
      prtstr(address_line2_text);
      setmode(M_NORMAL);
      newline();
      add(prev_line_num,prev_line_num,"1");
    }

/* street number, street name, etc - address line 3 */

    if ( *address_line3_text ) {
      setmode(M_COLLIT);
      prtstr(address_line3_text);
      setmode(M_NORMAL);
      newline();
      add(prev_line_num,prev_line_num,"1");
    }

/* city, state and zip line - address line 6 */

    if ( *address_line6_text ) {
      setmode(M_COLLIT);
      prtstr(address_line6_text);
      setmode(M_NORMAL);
      add(prev_line_num,prev_line_num,"1");
    }

}                                        /* end print_address */

/* ************************************************************************** */
/* print the barcode zip line                                                 */
/* ************************************************************************** */

static void print_barcode_zip(void)
{

  /* set ocr barcode and print */

  int j,
      process_code=0;   /* 0=do not print,
                           1=print 5-digit zip,
                           2=print 9-digit zip with default '99' delivery point,
                           3=print 9-digit zip with delivery point  */

  if (first_time_barcode == 1) {
    barcode_return = get_barcode_escapes();
    first_time_barcode = 0;
  }

  if (barcode_return > 0)
    return;

  for (j=0; j<5; j++) {
    if (!isdigit(ubrrecp_zip_1_5[j]))
      return;
  }
  process_code = 1;
  for (j=0; j<4; j++) {
    if (!isdigit(ubrrecp_zip_7_10[j]))
      break;
  }
  if (j==4) {
    process_code = 2;
    for (j=0; j<2; j++) {
      if (!isdigit(ubrrecp_delivery_point[j]))
        break;
    }
    if (j==2)
      process_code = 3;
  }

  if (process_code == 1) {
    EXEC SQL
      SELECT
        '          ' ||
        :baron_esc_parsed ||
        :ubrrecp_zip_1_5 ||
        :baroff_esc_parsed
      into :barcode_line_text
      from SYS.DUAL;
    POSTORA;
    if (NO_ROWS_FOUND)
      *barcode_line_text = '\0';
  }
  else {
    if (process_code == 2)
      strcpy(ubrrecp_delivery_point,"99");
    EXEC SQL
      SELECT
        '          ' ||
        :baron_esc_parsed ||
        :ubrrecp_zip_1_5 ||
        :ubrrecp_zip_7_10 ||
        :ubrrecp_delivery_point ||
        :baroff_esc_parsed
      into :barcode_line_text
      from SYS.DUAL;
    POSTORA;
    if (NO_ROWS_FOUND)
      *barcode_line_text = '\0';
  }

  newline();
  setmode(M_COLLIT);
  prtstr(barcode_line_text);
  setmode(M_NORMAL);
  newline();
  add(prev_line_num,prev_line_num,"1");

}                                        /* end print_barcode_zip */

/* ************************************************************************* */
/* if we had a budgeted service, print the footnote at the bottom            */
/* of the open item detail section                                           */
/* ************************************************************************* */

static void print_budget_footnote(void)
{
  if ( *budget_footnote ) {
    add(line_05_30_lineno,line_05_30_lineno,"1");
    strcpy(text,
      "'*'=Actual Charges For Budgeted Service Not Included in Amount Due");
    tonum(amount,null);
    print_line_05_30_text();
  }
}                                        /* end print_budget_footnote */

/* ************************************************************************** */
/* print budget line                                                          */
/* ************************************************************************** */

static void print_budget_line(void)
{
  select_budget_totals(FIRST_ROW);
  subtract(ytd_budget_charges,ytd_actual_charges,ytd_budget_variance);
  EXEC SQL
   SELECT 'YTD Actual: '                                        ||
          rpad(to_char(TO_NUMBER(:ytd_actual_charges),'9999999.99'),11)    ||
        '  YTD Budget: '                                        ||
          rpad(to_char(TO_NUMBER(:ytd_budget_charges),'9999999.99'),11)    ||
        decode(:budgeted_service_ind,
                'Y', '     Budget Amount:',
                'C', ' Settlement Amount:',
                     '                   ')
     into :text:Ind_01
     FROM sys.dual;
  POSTORA;
  if ( NO_ROWS_FOUND ) {
    *text='\0';
  }
  if ( compare(budgeted_service_ind,"Y",NES) ) {
    strcpy(amount,ytd_budget_variance);
    add(charges,charges,ytd_budget_variance);
    if (!*sleep_wake_ind ||
      (*sleep_wake_ind && ubtibil_calc_update_ind[0] == 'Y'))
        update_uarbudg();
  }
  else
    strcpy(amount,total_budget_amount);
  print_line_05_30_text();
  strcpy(total_budget_amount,"0");
}                                        /* end print_budget_line */

/* ************************************************************************** */
/* insert Montgomery line 06 into ubrbill collector table                     */
/* ************************************************************************** */

static void m_print_line_06(void)
{

/* load the bill into the ubrbill-bill collector */
/*                                               */
/* billing date                                  */

  strcpy(lineno,"6");
  EXEC SQL
   INSERT INTO uimsmgr.ubrbill
        (
        ubrbill_bill_num,
        ubrbill_page_num,
        ubrbill_line_num,
        ubrbill_sess_id,
        ubrbill_text
        )
   VALUES
        (
        TO_NUMBER(:billno),
        TO_NUMBER(:pageno),
        TO_NUMBER(:lineno),
        :session_id,
        '                                                   ' ||
        to_char(to_date(:printed_date,'DD-MON-YYYY'),'MON DD YYYY')
        );
  POSTORA;
}                                        /* end m_print_line_06 */

/* ************************************************************************** */
/* insert Montgomery line 07 into ubrbill collector table                     */
/* ************************************************************************** */

static void m_print_line_07(void)
{

/* load the bill into the ubrbill-bill collector */
/*                                               */
/* account number                                */

  strcpy(lineno,"7");
  EXEC SQL
   INSERT INTO uimsmgr.ubrbill
        (
        ubrbill_bill_num,
        ubrbill_page_num,
        ubrbill_line_num,
        ubrbill_sess_id,
        ubrbill_text
        )
   VALUES
        (
        TO_NUMBER(:billno),
        TO_NUMBER(:pageno),
        TO_NUMBER(:lineno),
        :session_id,
        '                                                  ' ||
        lpad(to_char(TO_NUMBER(:ucracct_cust_code)),9)              ||
        '-'                                     ||
        rpad(:ucracct_prem_code,7)
        );
  POSTORA;
}                                        /* end m_print_line_07 */

/* ************************************************************************** */
/* insert Montgomery line 08 into ubrbill collector table                     */
/* ************************************************************************** */

static void m_print_line_08(void)
{

/* load the bill into the ubrbill-bill collector */
/*                                               */
/* service dates                                 */

  strcpy(lineno,"8");
  if(bOneMeterPresent) {
     EXEC SQL
     INSERT INTO uimsmgr.ubrbill
        (
        ubrbill_bill_num,
        ubrbill_page_num,
        ubrbill_line_num,
        ubrbill_sess_id,
        ubrbill_text
        )
     VALUES
        (
        TO_NUMBER(:billno),
        TO_NUMBER(:pageno),
        TO_NUMBER(:lineno),
        :session_id,
        '                                                 ' ||
        to_char(to_date(:hold_prev_date,'MM/DD/YY'),'MM-DD-YY') ||
        '  ' ||
        to_char(to_date(:hold_present_date,'MM/DD/YY'),'MM-DD-YY')
        );
  }
  else {
     EXEC SQL
     INSERT INTO uimsmgr.ubrbill
        (
        ubrbill_bill_num,
        ubrbill_page_num,
        ubrbill_line_num,
        ubrbill_sess_id,
        ubrbill_text
        )
     VALUES
        (
        TO_NUMBER(:billno),
        TO_NUMBER(:pageno),
        TO_NUMBER(:lineno),
        :session_id,
        '                                                 ' ||
        to_char(to_date(:prev_date_flat,'MM/DD/YY'),'MM-DD-YY') ||
        '  ' ||
        to_char(to_date(:present_date_flat,'MM/DD/YY'),'MM-DD-YY')
        );
  }
  POSTORA;
}                                        /* end m_print_line_08 */

/* ************************************************************************** */
/* insert Montgomery line 09 into ubrbill collector table                     */
/* ************************************************************************** */

static void m_print_line_09(void)
{

/* load the bill into the ubrbill-bill collector */
/*                                               */
/* due date                                      */

  strcpy(lineno,"9");
  EXEC SQL
   INSERT INTO uimsmgr.ubrbill
        (
        ubrbill_bill_num,
        ubrbill_page_num,
        ubrbill_line_num,
        ubrbill_sess_id,
        ubrbill_text
        )
   VALUES
        (
        TO_NUMBER(:billno),
        TO_NUMBER(:pageno),
        TO_NUMBER(:lineno),
        :session_id,
        '                                                  ' ||
        decode(:ucbmbil_sub_pymt_ind,
               'N','           ',
               to_char(to_date(decode(:reprint_date_var,
                                      null, decode(:deferred_due_date,
                                                   null,:due_date,
                                                   :deferred_due_date),
                                      :uabopen_due_date),
                               'DD-MON-YYYY'),
                       'MON DD YYYY'))
        );
  POSTORA;
}                                        /* end m_print_line_09 */

/* ************************************************************************** */
/* insert Montgomery lines 11, 47 into ubrbill collector table                */
/* ************************************************************************** */

static void m_print_line_11(void)
{

/* load the bill into the ubrbill-bill collector */
/*                                               */
/* premises location                             */

  strcpy(lineno,"11");
  m_line_11();
  strcpy(lineno,"47");
  m_line_11();
}                                        /* end m_print_line_11 */

/* ************************************************************************** */
/* Montgomery premises location line                                         */
/* ************************************************************************** */

static void m_line_11(void)
{
  EXEC SQL
   INSERT INTO uimsmgr.ubrbill
        (
        ubrbill_bill_num,
        ubrbill_page_num,
        ubrbill_line_num,
        ubrbill_sess_id,
        ubrbill_text
        )
   SELECT
        TO_NUMBER(:billno),
        TO_NUMBER(:pageno),
        TO_NUMBER(:lineno),
        :session_id,
        '                              ' ||
        rpad(substr (
            decode (ucbprem_street_number,'','',ucbprem_street_number||' ')||
            decode (ucbprem_pdir_code_pre,'','',ucbprem_pdir_code_pre||' ')||
            decode (ucbprem_street_name,'','',ucbprem_street_name||' ')||
            decode (ucbprem_ssfx_code,'','',ucbprem_ssfx_code||' ')||
                  ucbprem_pdir_code_post,1,38),38)
    FROM uimsmgr.ucbprem
    WHERE ucbprem_code = :ucracct_prem_code;
  POSTORA;
}                                        /*  end m_line_11 */

/* ************************************************************************** */
/* insert Montgomery lines 14, 44 into ubrbill collector table                */
/* ************************************************************************** */

static void m_print_line_14(void)
{

/* load the bill into the ubrbill-bill collector */
/*                                               */
/* scan line                                     */

  strcpy(m_xx,"XX ");
  strcpy(lineno,"14");
  add(m_grand_tot,m_garbage_tot,m_other_tot);
  multiply(m_garbage_tot,m_garbage_tot,"100");
  multiply(m_other_tot,m_other_tot,"100");
  multiply(m_grand_tot,m_grand_tot,"100");
  m_line_14();
  strcpy(m_xx,"   ");
  strcpy(lineno,"44");
  m_line_14();
}                                        /* end m_print_line_14 */

/* ************************************************************************** */
/* Montgomery scan line                                                       */
/* ************************************************************************** */

static void m_line_14(void)
{

  /* Calculate checksums */
  EXEC SQL
    SELECT
      to_char(TO_NUMBER(:m_garbage_tot),'00000000'),
      to_char(TO_NUMBER(:m_other_tot),'00000000'),
      to_char(TO_NUMBER(:m_grand_tot),'00000000')
    INTO :garbage_digits,
         :other_digits,
         :grand_digits
    FROM sys.dual;
  POSTORA;
  /*  For some reason the above SQL insists on putting the result into a
      9-byte field (10 with trailing null), with the first byte a space.
      I use subscript 'i+1' below to take care of this.                   */
  sum1 = 0;
  for (i=0; i<8; i++) {
    digit_char[0] = garbage_digits[i+1];
    digit_char[1] = '\0';
    digit = atoi(digit_char);
    product = digit * check_digit[i];
    sum1 += product;
  }
  sum2 = 0;
  for (i=0; i<8; i++) {
    digit_char[0] = other_digits[i+1];
    digit_char[1] = '\0';
    digit = atoi(digit_char);
    product = digit * check_digit[i];
    sum2 += product;
  }
  sum3 = 0;
  for (i=0; i<8; i++) {
    digit_char[0] = grand_digits[i+1];
    digit_char[1] = '\0';
    digit = atoi(digit_char);
    product = digit * check_digit[i];
    sum3 += product;
  }
  EXEC SQL
    SELECT lpad(TO_CHAR(TO_NUMBER(:ucracct_cust_code)),7,'0000000') ||
           lpad(TO_CHAR(TO_NUMBER(:ucracct_prem_code)),6,'000000')
      INTO :acct_digits
      FROM sys.dual;
  POSTORA;

  sum4 = 0;
  digit_char[0] = acct_digits[12];
  digit_char[1] = '\0';
  sum4 += 2 * (atoi(digit_char));
  digit_char[0] = acct_digits[11];
  digit_char[1] = '\0';
  sum4 += 3 * (atoi(digit_char));
  digit_char[0] = acct_digits[10];
  digit_char[1] = '\0';
  sum4 += 4 * (atoi(digit_char));
  digit_char[0] = acct_digits[9];
  digit_char[1] = '\0';
  sum4 += 5 * (atoi(digit_char));
  digit_char[0] = acct_digits[8];
  digit_char[1] = '\0';
  sum4 += 6 * (atoi(digit_char));
  digit_char[0] = acct_digits[7];
  digit_char[1] = '\0';
  sum4 += 7 * (atoi(digit_char));
  digit_char[0] = acct_digits[6];
  digit_char[1] = '\0';
  sum4 += 8 * (atoi(digit_char));
  digit_char[0] = acct_digits[5];
  digit_char[1] = '\0';
  sum4 += 9 * (atoi(digit_char));
  digit_char[0] = acct_digits[4];
  digit_char[1] = '\0';
  sum4 += 2 * (atoi(digit_char));
  digit_char[0] = acct_digits[3];
  digit_char[1] = '\0';
  sum4 += 3 * (atoi(digit_char));
  digit_char[0] = acct_digits[2];
  digit_char[1] = '\0';
  sum4 += 4 * (atoi(digit_char));
  digit_char[0] = acct_digits[1];
  digit_char[1] = '\0';
  sum4 += 5 * (atoi(digit_char));
  digit_char[0] = acct_digits[0];
  digit_char[1] = '\0';
  sum4 += 6 * (atoi(digit_char));

  EXEC SQL
   INSERT INTO uimsmgr.ubrbill
        (
        ubrbill_bill_num,
        ubrbill_page_num,
        ubrbill_line_num,
        ubrbill_sess_id,
        ubrbill_text
        )
   VALUES
        (
        TO_NUMBER(:billno),
        TO_NUMBER(:pageno),
        TO_NUMBER(:lineno),
        :session_id,
        :m_xx ||
        '      ' ||
        decode(:ucracct_status_ind,
                  'F','3',
                  '1') ||
        '       ' ||
        substr(to_char(:sum1,'000'),4,1) ||
        substr(to_char(:sum2,'000'),4,1) ||
        substr(to_char(:sum3,'000'),4,1) ||
        substr(to_char(:sum4,'000'),4,1) ||
        '  ' ||
        lpad(to_char(TO_NUMBER(:m_garbage_tot),'00000000'),9) ||
        lpad(to_char(TO_NUMBER(:m_other_tot),'00000000'),9)   ||
        lpad(to_char(TO_NUMBER(:m_grand_tot),'00000000'),9)   ||
                                                        ' '   ||
        lpad(to_char(TO_NUMBER(:ucracct_cust_code)),7,'0000000')       ||
        lpad(to_char(TO_NUMBER(:ucracct_prem_code)),6,0)
        );
  POSTORA;
}                                        /*  end m_line_14 */

/* ************************************************************************** */
/* insert Montgomery line 22 into ubrbill collector table                     */
/* ************************************************************************** */

static void m_print_line_22(void)
{

/* load the bill into the ubrbill-bill collector */
/*                                               */
/* account, cy, serv period, delq date           */

  strcpy(lineno,"22");
     EXEC SQL
     INSERT INTO uimsmgr.ubrbill
        (
        ubrbill_bill_num,
        ubrbill_page_num,
        ubrbill_line_num,
        ubrbill_sess_id,
        ubrbill_text
        )
      VALUES
        (
        TO_NUMBER(:billno),
        TO_NUMBER(:pageno),
        TO_NUMBER(:lineno),
        :session_id,
        lpad(to_char(TO_NUMBER(:ucracct_cust_code)),9)              ||
        '-'                                     ||
        rpad(:ucracct_prem_code,7)  ||
        '  '  ||
        substr(:ucracct_cycl_code,1,2) ||
        ' ' ||
        to_char(to_date(:hold_prev_date,'MM/DD/YY'),'MMDDYY') ||
        ' ' ||
        to_char(to_date(:hold_present_date,'MM/DD/YY'),'MMDDYY') ||
        ' ' ||
        decode(:ucbmbil_sub_pymt_ind,
               'N','           ',
               to_char(to_date(decode(:reprint_date_var,
                                      null, decode(:deferred_due_date,
                                                   null,:due_date,
                                                   :deferred_due_date),
                                      :uabopen_due_date),
                              'DD-MON-YYYY'),
                      'MON-DD-YYYY'))
        );
  POSTORA;
}                                        /* end m_print_line_22 */

/* ************************************************************************** */
/* insert Montgomery line 25 into ubrbill collector table                     */
/* ************************************************************************** */

static void m_print_line_25(void)
{

/* load the bill into the ubrbill-bill collector */
/*                                               */
/* current and prev reading                      */

  strcpy(lineno,"25");
  if(bOneMeterPresent) {
     subtract(meter_diff,hold_present_reading,hold_prev_reading);
     if(compare(meter_diff,"8",LT))
        strcpy(total_string,"MINIMUM");
     else
        tochar(total_string,meter_diff,"9999999");
     EXEC SQL
      INSERT INTO uimsmgr.ubrbill
           (ubrbill_bill_num,
            ubrbill_page_num,
            ubrbill_line_num,
            ubrbill_sess_id,
            ubrbill_text
           )
      VALUES
        (
        TO_NUMBER(:billno),
        TO_NUMBER(:pageno),
        TO_NUMBER(:lineno),
        :session_id,
        '   ' ||
        lpad(:hold_present_reading,5)   ||
        ' '                        ||
        lpad(:hold_prev_reading,5)      ||
        '                                 ' ||
        :total_string
        );
        POSTORA;
  }
}                                        /* end m_print_line_25 */

/* ************************************************************************** */
/* insert line 27 into ubrbill collector table                                */
/* ************************************************************************** */
/* previous balance                                                           */

static void m_print_line_27(void)
{

  strcpy(lineno,"27");
  EXEC SQL
   INSERT INTO uimsmgr.ubrbill
        (
        ubrbill_bill_num,
        ubrbill_page_num,
        ubrbill_line_num,
        ubrbill_sess_id,
        ubrbill_text
        )
    VALUES
        (
          TO_NUMBER(:billno),
          TO_NUMBER(:pageno),
          TO_NUMBER(:lineno),
          :session_id,
          nvl(lpad(to_char(TO_NUMBER(:nszPreviousBalance),
                                     '99,999,999.99'),72),0)
         );
  POSTORA;      

}                                        /* end m_print_line_27 */

/* ************************************************************************** */
/* insert line 05 duplicate bill msg into ubrbill collector table             */
/* ************************************************************************** */

static void m_print_line_16_dupl(void)
{

/* duplicate bill message */

  strcpy(lineno,"16");
                                                           
  EXEC SQL
   INSERT INTO uimsmgr.ubrbill
        (
        ubrbill_bill_num,
        ubrbill_page_num,
        ubrbill_line_num,
        ubrbill_sess_id,
        ubrbill_text
        )
    VALUES
        (
         TO_NUMBER(:billno),
         TO_NUMBER(:pageno),
         TO_NUMBER(:lineno),
         :session_id,
         'DUPLICATE BILL'
         );
  POSTORA;        
}                                        /* end m_print_line_16_dupl */
 
/* ************************************************************************** */
/* insert line 10 draft msg into ubrbill collector table                     */
/* ************************************************************************** */

static void m_print_line_10_draft(void)
{

/* bank draft message */
/* This uses line 10, also used by m_print_line_10_no_pay; bank drafting and
   master bills are mutually exclusive, so a conflict should not occur.  */

  strcpy(lineno,"10");

  EXEC SQL
   INSERT INTO uimsmgr.ubrbill
        (
        ubrbill_bill_num,
        ubrbill_page_num,
        ubrbill_line_num,
        ubrbill_sess_id,
        ubrbill_text
        )
    VALUES
        (
          TO_NUMBER(:billno),
          TO_NUMBER(:pageno),
          TO_NUMBER(:lineno),
          :session_id,
          'DO NOT PAY - account is being drafted for the amount owed.'
          );
  POSTORA;         
}                                        /* end m_print_line_10_draft */

/* ************************************************************************** */
/* insert line 10 please pay msg into ubrbill collector table                 */
/* ************************************************************************** */

static void print_please_pay_msg(void)
{
  m_print_line_10_please_pay();
}

static void m_print_line_10_please_pay(void)
{

/* bank draft message */
/* This uses line 10, also used by m_print_line_10_no_pay; bank drafting and
   master bills are mutually exclusive, so a conflict should not occur.  */

  strcpy(lineno,"10");

  EXEC SQL
   INSERT INTO uimsmgr.ubrbill
        (
        ubrbill_bill_num,
        ubrbill_page_num,
        ubrbill_line_num,
        ubrbill_sess_id,
        ubrbill_text
        )
    VALUES
        (     
          TO_NUMBER(:billno),
          TO_NUMBER(:pageno),
          TO_NUMBER(:lineno),
          :session_id,
          'PLEASE PAY - amount is NOT being drafted.'
          );
  POSTORA;         
}                                        /* end m_print_line_10_please_pay */

/* ************************************************************************** */
/* insert line 10 no pay msg into ubrbill collector table                     */
/* ************************************************************************** */

static void m_print_line_10_no_pay(void)
{

/* no payment - master bills message */
/* This uses line 10, also used by m_print_line_10_draft; bank drafting and
   master bills are mutually exclusive, so a conflict should not occur.  */

  strcpy(lineno,"10");

  EXEC SQL
   INSERT INTO uimsmgr.ubrbill
        (
        ubrbill_bill_num,
        ubrbill_page_num,
        ubrbill_line_num,
        ubrbill_sess_id,
        ubrbill_text
        )
    VALUES
        (
          TO_NUMBER(:billno),
          TO_NUMBER(:pageno),
          TO_NUMBER(:lineno),
          :session_id,
          'Do not pay - summary only.'
          );
  POSTORA;         
}                                        /* end m_print_line_10_no_pay */

/* ************************************************************************** */
/* print detail lines (meter readings, consumption, etc)                      */
/* ************************************************************************** */

static void print_detail_line(void)
{
  if (compare(line_05_30_lineno,"39",LT) ||
    (compare(line_05_30_pageno,"1",GT) && compare(line_05_30_lineno,"42",LT)))
      ;
  else {
    line_31_multi();
    strcpy(multi_page_ind,"Y");
    strcpy(line_05_30_lineno,"30");
    add(line_05_30_pageno,line_05_30_pageno,"1");
  }
  EXEC SQL
   INSERT INTO uimsmgr.ubrbill
        (
        ubrbill_bill_num,
        ubrbill_page_num,
        ubrbill_line_num,
        ubrbill_sess_id,
        ubrbill_text
        )
    VALUES
        (
          TO_NUMBER(:billno),
          TO_NUMBER(:line_05_30_pageno),
          TO_NUMBER(:line_05_30_lineno),
          :session_id,
          '    Meter Change Out:     '  ||
          decode(TO_NUMBER(:uabopen_chrg_calc_num),
                 null,'                                      ',
                 lpad(to_char(TO_NUMBER(:uabopen_billed_chg),'999,999.99'),
                      13))
        );
  POSTORA;
  /* re-retrieve line text for C usage */
  EXEC SQL SELECT ubrbill_text INTO :ubrbill_text
      FROM uimsmgr.ubrbill
      WHERE ubrbill_bill_num = TO_NUMBER(:billno)
        AND ubrbill_page_num = TO_NUMBER(:line_05_30_pageno)
        AND ubrbill_line_num = TO_NUMBER(:line_05_30_lineno)
        and ubrbill_sess_id  = :session_id;
  POSTORA;
  add(line_05_30_lineno,line_05_30_lineno,"1");
}                                        /* end print_detail_line */

/* ************************************************************************** */
/* print detail lines (meter readings, consumption, etc)                      */
/* ************************************************************************** */

static void print_detail_line_2(void)
{
  if (compare(line_05_30_lineno,"39",LT) ||
    (compare(line_05_30_pageno,"1",GT) && compare(line_05_30_lineno,"42",LT)))
      ;
  else {
    line_31_multi();
    strcpy(multi_page_ind,"Y");
    strcpy(line_05_30_lineno,"30");
    add(line_05_30_pageno,line_05_30_pageno,"1");
  }
  EXEC SQL
   INSERT INTO uimsmgr.ubrbill
        (
        ubrbill_bill_num,
        ubrbill_page_num,
        ubrbill_line_num,
        ubrbill_sess_id,
        ubrbill_text
        )
    SELECT
          TO_NUMBER(:billno),
          TO_NUMBER(:line_05_30_pageno),
          TO_NUMBER(:line_05_30_lineno),
          :session_id,
          '    ' ||
          rpad(utrsrat_bill_print_desc,22) ||
          lpad(to_char(TO_NUMBER(:uabopen_billed_chg),'999,999.99'),13)
     FROM uimsmgr.utrsrat
    WHERE utrsrat_srat_code = :uabopen_srat_code
      AND utrsrat_scat_code = :uabopen_scat_code;
  POSTORA;
  /* re-retrieve line text for C usage */
  EXEC SQL SELECT ubrbill_text INTO :ubrbill_text
      FROM uimsmgr.ubrbill
      WHERE ubrbill_bill_num = TO_NUMBER(:billno)
        AND ubrbill_page_num = TO_NUMBER(:line_05_30_pageno)
        AND ubrbill_line_num = TO_NUMBER(:line_05_30_lineno)
        and ubrbill_sess_id  = :session_id;
  POSTORA;
  add(line_05_30_lineno,line_05_30_lineno,"1");
  if (strstr(str2uc(ubrbill_text),"GARBAGE") == NULL)
    { add(m_other_tot,m_other_tot,uabopen_billed_chg); }
  else
    { add(m_garbage_tot,m_garbage_tot,uabopen_billed_chg); }
}                                        /* end print_detail_line */

/* ************************************************************************** */
/* print detail lines (meter readings, consumption, etc) for change out       */
/* Not used for Montgomery                                                    */
/* ************************************************************************** */

static void print_detail_line_change_out_2(void)
{
  if (compare(line_05_30_lineno,"39",LT) ||
    (compare(line_05_30_pageno,"1",GT) && compare(line_05_30_lineno,"42",LT)))
      ;
  else {
    strcpy(multi_page_ind,"Y");
    strcpy(line_05_30_lineno,"30");
    add(line_05_30_pageno,line_05_30_pageno,"1");
  }
  EXEC SQL
   INSERT INTO uimsmgr.ubrbill
        (
        ubrbill_bill_num,
        ubrbill_page_num,
        ubrbill_line_num,
        ubrbill_sess_id,
        ubrbill_text
        )
    VALUES
        (
          TO_NUMBER(:billno),
          TO_NUMBER(:line_05_30_pageno),
          TO_NUMBER(:line_05_30_lineno),
          :session_id,
          /*  How to handle (if necessary?)  */
          decode(:non_metered_ind,
                 'Y','        ',
                 :hold_prev_date)            ||
          ' '                                   ||
          decode(:non_metered_ind,
                 'Y','        ',
                 :change_out_date)              ||
          '  '                                  ||
          lpad(to_char(TO_NUMBER(:change_out_dos)),3)               ||
          ' '                                   ||
          lpad(nvl(:uabopen_srat_code,'    '),4)||
          ' '                                   ||
          decode(TO_NUMBER(:uabopen_chrg_calc_num),
                   null,'                                      ',
                   decode(:non_metered_ind,
                            null,lpad(:prev_reading,11),'           ') ||
                  ' '                                   ||
                   decode(:non_metered_ind,
                            null,lpad(to_char(TO_NUMBER(:change_out_reading)),
                                      14),
                                '              ') ||
                  ' '                                   ||
                   decode(:non_metered_ind,
                            null,lpad(to_char(TO_NUMBER(:change_out_cons)),11),
                          '           ')) ||
                  ' '                                   ||
                  lpad(nvl(:urrshis_high_low_excp,'  '),2)
        );
  POSTORA;
  add(line_05_30_lineno,line_05_30_lineno,"1");
}                                       /* end print_detail_line_change_out_2 */

/* ************************************************************************** */
/* print detail lines adjustments                                             */
/* ************************************************************************** */

static void print_detail_line_adjustments(void)
{
  if (compare(line_05_30_lineno,"39",LT) ||
    (compare(line_05_30_pageno,"1",GT) && compare(line_05_30_lineno,"42",LT)))
      ;
  else {
    line_31_multi();
    strcpy(multi_page_ind,"Y");
    strcpy(line_05_30_lineno,"30");
    add(line_05_30_pageno,line_05_30_pageno,"1");
  }
  EXEC SQL
   INSERT INTO uimsmgr.ubrbill
        (
        ubrbill_bill_num,
        ubrbill_page_num,
        ubrbill_line_num,
        ubrbill_sess_id,
        ubrbill_text
        )
   SELECT TO_NUMBER(:billno),
          TO_NUMBER(:line_05_30_pageno),
          TO_NUMBER(:line_05_30_lineno),
          :session_id,
          '   ' ||
          decode(utradjm_desc,null,'                      ',
                 rpad(utradjm_desc,22)) ||
          lpad(to_char(TO_NUMBER(:uabadje_balance),'999,999.99'),13)
     FROM uimsmgr.utradjm
    WHERE utradjm_code = :uabadje_adjm_code;
  POSTORA;
  /* re-retrieve line text for C usage */
  EXEC SQL SELECT ubrbill_text INTO :ubrbill_text
      FROM uimsmgr.ubrbill
      WHERE ubrbill_bill_num = TO_NUMBER(:billno)
        AND ubrbill_page_num = TO_NUMBER(:line_05_30_pageno)
        AND ubrbill_line_num = TO_NUMBER(:line_05_30_lineno)
        and ubrbill_sess_id  = :session_id;
  POSTORA;
  add(line_05_30_lineno,line_05_30_lineno,"1");
  if (strstr(str2uc(ubrbill_text),"GARBAGE") == NULL)
    { add(m_other_tot,m_other_tot,uabadje_balance); }
  else
    { add(m_garbage_tot,m_garbage_tot,uabadje_balance); }
}                                        /* end print_detail_line_adjustments */

/* ************************************************************************** */
/* print lines 05 thru 30 - text and dollar amount                            */
/* ************************************************************************** */

static void print_line_05_30_text(void)
{
  if (compare(line_05_30_lineno,"39",LT) ||
    (compare(line_05_30_pageno,"1",GT) && compare(line_05_30_lineno,"42",LT)))
      ;
  else {
    line_31_multi();
    strcpy(multi_page_ind,"Y");
    strcpy(line_05_30_lineno,"30");
    add(line_05_30_pageno,line_05_30_pageno,"1");
  }
  EXEC SQL
   INSERT INTO uimsmgr.ubrbill
        (
        ubrbill_bill_num,
        ubrbill_page_num,
        ubrbill_line_num,
        ubrbill_sess_id,
        ubrbill_text
        )
   VALUES
        (
        TO_NUMBER(:billno),
        TO_NUMBER(:line_05_30_pageno),
        TO_NUMBER(:line_05_30_lineno),
        :session_id,
        '    ' ||
        lpad(:text,22)  ||
        lpad(to_char(TO_NUMBER(:amount),'999,999.99'),13)
        );
  POSTORA;
  /* re-retrieve line text for C usage */
  EXEC SQL SELECT ubrbill_text INTO :ubrbill_text
      FROM uimsmgr.ubrbill
      WHERE ubrbill_bill_num = TO_NUMBER(:billno)
        AND ubrbill_page_num = TO_NUMBER(:line_05_30_pageno)
        AND ubrbill_line_num = TO_NUMBER(:line_05_30_lineno)
        and ubrbill_sess_id  = :session_id;
  POSTORA;
  add(line_05_30_lineno,line_05_30_lineno,"1");
}                                        /* end print_line_05_30_text */

/* ************************************************************************** */
/* print bank draft messages                                                  */
/* ************************************************************************** */

static void print_draft_next_month_msg(void)
{
  if (compare(line_05_30_lineno,"39",LT) ||
    (compare(line_05_30_pageno,"1",GT) && compare(line_05_30_lineno,"42",LT)))
      ;
  else {
    line_31_multi();
    strcpy(multi_page_ind,"Y");
    strcpy(line_05_30_lineno,"30");
    add(line_05_30_pageno,line_05_30_pageno,"1");
  }
  EXEC SQL
   INSERT INTO uimsmgr.ubrbill
        (
        ubrbill_bill_num,
        ubrbill_page_num,
        ubrbill_line_num,
        ubrbill_sess_id,
        ubrbill_text
        )
    VALUES
        (
         TO_NUMBER(:billno),
         TO_NUMBER(:line_05_30_pageno),
         TO_NUMBER(:line_05_30_lineno),
         :session_id,
         'Automatic account drafting will begin next month'
        );
  POSTORA;
  add(line_05_30_lineno,line_05_30_lineno,"1");
}                                        /* end print_draft_next_month_msg */

static void print_draft_msg(void)
{

  m_print_line_10_draft();

  if (compare(line_05_30_lineno,"39",LT) ||
    (compare(line_05_30_pageno,"1",GT) && compare(line_05_30_lineno,"42",LT)))
      ;
  else {
    line_31_multi();
    strcpy(multi_page_ind,"Y");
    strcpy(line_05_30_lineno,"30");
    add(line_05_30_pageno,line_05_30_pageno,"1");
  }
  EXEC SQL
   INSERT INTO uimsmgr.ubrbill
        (
        ubrbill_bill_num,
        ubrbill_page_num,
        ubrbill_line_num,
        ubrbill_sess_id,
        ubrbill_text
        )
    VALUES
        (
         TO_NUMBER(:billno),
         TO_NUMBER(:line_05_30_pageno),
         TO_NUMBER(:line_05_30_lineno),
         :session_id,
         'Amount will be drafted on / around ' ||
         DECODE(:reprint_date_var,
                NULL, DECODE(:deferred_due_date,
                             NULL,TO_CHAR(TO_DATE(:due_date,'DD-MON-YYYY')
                                          - to_number(:uobsysc_days_draft),
                                          'DD-MON-YYYY'),
                             TO_CHAR(TO_DATE(:deferred_due_date,'DD-MON-YYYY')
                                     - to_number(:uobsysc_days_draft),
                                     'DD-MON-YYYY')),
                TO_CHAR(TO_DATE(:uabopen_due_date,'DD-MON-YYYY')
                        - to_number(:uobsysc_days_draft),
                        'DD-MON-YYYY'))
        );
  POSTORA;
  add(line_05_30_lineno,line_05_30_lineno,"1");
}                                        /* end print_draft_msg */

/* ************************************************************************** */
/* print roundup total for a year                                             */
/* ************************************************************************** */

static void print_rdup(void)
{
  if (compare(line_05_30_lineno,"39",LT) ||
    (compare(line_05_30_pageno,"1",GT) && compare(line_05_30_lineno,"42",LT)))
      ;
  else {
    line_31_multi();
    strcpy(multi_page_ind,"Y");
    strcpy(line_05_30_lineno,"30");
    add(line_05_30_pageno,line_05_30_pageno,"1");
  }
  EXEC SQL
   INSERT INTO uimsmgr.ubrbill
        (
        ubrbill_bill_num,
        ubrbill_page_num,
        ubrbill_line_num,
        ubrbill_sess_id,
        ubrbill_text
        )
    VALUES
        (
         TO_NUMBER(:billno),
         TO_NUMBER(:line_05_30_pageno),
         TO_NUMBER(:line_05_30_lineno),
         :session_id,
         'Total Round Up Contributions for ' ||
         :year_vbg ||
         ' year: ' ||
         TO_CHAR(TO_NUMBER(:total_roundup),'999,999.99') ||
         '   Total Paid: ' ||
         TO_CHAR(TO_NUMBER(:total_roundup_paid),'999,999.99')
        );
  POSTORA;
  add(line_05_30_lineno,line_05_30_lineno,"1");
}                                        /* end print_rdup */

/* ************************************************************************** */
/* print a blank line                                                         */
/* ************************************************************************** */

static void print_blank_line(void)
{
  if (compare(line_05_30_lineno,"39",LT) ||
    (compare(line_05_30_pageno,"1",GT) && compare(line_05_30_lineno,"42",LT)))
      ;
  else {
    line_31_multi();
    strcpy(multi_page_ind,"Y");
    strcpy(line_05_30_lineno,"30");
    add(line_05_30_pageno,line_05_30_pageno,"1");
  }
  insert_blank_line();
  add(line_05_30_lineno,line_05_30_lineno,"1");
}

/* ************************************************************************** */
/* insert Montgomery messages into ubrbill collector table                    */
/* ************************************************************************** */

static void m_print_message_lines(void)
{

  if ( *bill_message_code && compare(system_bmsg_option,"A",NES) ) {
    /* insert system bill message */
    strcpy(bmsg_code,bill_message_code);
    m_message_line();
    add(line_05_30_lineno,line_05_30_lineno,"1");
  }

  if ( *ucbcust_bmsg_code ) {
    /* insert customer-specific message */
    strcpy(bmsg_code,ucbcust_bmsg_code);
    m_message_line();
    add(line_05_30_lineno,line_05_30_lineno,"1");
  }

  if ( *ucracct_bmsg_code && compare(system_bmsg_option,"S",NES) ) {
    /* insert account-specific message */
    strcpy(bmsg_code,ucracct_bmsg_code);
    m_message_line();
    add(line_05_30_lineno,line_05_30_lineno,"1");
  }

}                                        /* end m_print_message_lines */

/*  ****************************************************************** */
/*  *   select ending balance from the last posted ubbbhst row.  This  */
/*  *   will become the previous bill on the new row                   */
/*  * Montgomery, Ala displays previous balances by service type and   */
/*  * adds them to the total amount due                                */
/*  ****************************************************************** */

static int m_select_prev_bal(int mode)
{

 EXEC SQL
   SELECT  utvsrat_asvc_code,
      nvl(SUM(NVL(uabopen_balance,0)),0)
     INTO :szUtvsratAsvcCode,
          :nszPreviousBalance
     FROM  uimsmgr.uabopen, uimsmgr.utvsrat
    WHERE  uabopen_cust_code = TO_NUMBER(:ucracct_cust_code)
      AND  uabopen_prem_code = :ucracct_prem_code
      AND  uabopen_balance  <> 0
      AND  uabopen_printed_ind = 'Y'
    GROUP BY  utvsrat_asvc_code;

 if (sqlca.sqlcode == 0)
    return(TRUE);
 else {
    *szUtvsratAsvcCode = '\0';
    *nszPreviousBalance  = '\0';
    return(FALSE);
 }

/*
  commenting out all of the base previous balance process

  EXEC SQL DECLARE cursor_096 CURSOR FOR
   SELECT nvl(ubbbhst_ending_bal,0)
     FROM uimsmgr.ubbbhst
    WHERE ubbbhst_cust_code = TO_NUMBER(:ucracct_cust_code)
      AND ubbbhst_prem_code = :ucracct_prem_code
      and ubbbhst_tran_num  = (SELECT max(ubbbhst_tran_num)
                                 FROM uimsmgr.ubbbhst
                                WHERE ubbbhst_cust_code = TO_NUMBER(
                                      :ucracct_cust_code)
                                  AND ubbbhst_prem_code = :ucracct_prem_code);

  if ( !mode ) {
      EXEC SQL OPEN cursor_096;
      POSTORA;
  }

  EXEC SQL FETCH cursor_096 INTO
       :prev_bal:Ind_01;
  POSTORA;

  if ( NO_ROWS_FOUND ) {
      *prev_bal='\0';
      return FALSE;
  }
  return TRUE;

  */

}                                        /* end m_select_prev_bal */
