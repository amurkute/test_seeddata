/*	
	Object: guanlsl.h
	Author: Harry van Thor
	Mod Date: 14-Sep-2004
	Release: General SCB6.2
*/

/***************************************************/
/*                                                 */
/*       CONFIDENTIAL BUSINESS INFORMATION         */
/*                                                 */
/*      **********************************         */
/*                                                 */
/*  THIS PROGRAM IS PROPRIETARY INFORMATION OF     */
/* SYSTEMS AND COMPUTER TECHNOLOGY CORPORATION     */
/* AND IS NOT TO BE COPIED, REPRODUCED, LENT OR    */
/* DISPOSED OF, NOR USED FOR ANY PURPOSE OTHER     */
/* THAN THAT FOR WHICH IT IS SPECIFICALLY PROVIDED */
/* WITHOUT THE WRITTEN PERMISSION OF SAID COMPANY  */
/*                                                 */
/***************************************************/

/*
Common Routines to i18n Banner Pro*C 
(only routines that depend on Oracle and/or Banner should go in here)
*/

/*
Audit Trail SCB6.0
1. Add function g_date_nls_abv_day (HvT)
Audit Trail SCB6.2 31-Aug-2004
1. Add function tmsqlglm to interface with Oracle 8 bit function sqlglm (HvT)
2. Add function nls Day functions  (HvT)
3. Add function nlsGregDate
*/
/* AUDIT TRAIL: 8.0                                                         */
/* TAM 10/08/2007                                                           */
/* 1. Internationalization unicode conversion                               */
/* AUDIT TRAIL END                                                          */

#ifndef _GUANLSL_H

/* Function to translate single letter Week day abbreviations */
TMCHAR* g_date_nls_abv_day(TMCHAR* banday);

/* Fix interfacing with Oracle's sqlglm function */
#ifdef _TMUNICODE
#define sqlglm(mbuf, bufsize ,mlen) tmsqlglm(mbuf, bufsize ,mlen)
#endif

#define nlsDay(day) nlsDay##day()

TMCHAR* nlsDay(MON);
TMCHAR* nlsDay(TUE);
TMCHAR* nlsDay(WED);
TMCHAR* nlsDay(THU);
TMCHAR* nlsDay(FRI);
TMCHAR* nlsDay(SAT);
TMCHAR* nlsDay(SUN);

TMCHAR* nlsGregDate(TMCHAR8* dtxt, TMCHAR8* dfmt);

#define _GUANLSL_H
#endif
