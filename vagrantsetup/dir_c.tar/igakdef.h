/***************************************************/
/*                                                 */
/*       CONFIDENTIAL BUSINESS INFORMATION         */
/*                                                 */
/*      **********************************         */
/*                                                 */
/*  THIS PROGRAM IS PROPRIETARY INFORMATION OF     */
/* SYSTEMS AND COMPUTER TECHNOLOGY CORPORATION     */
/* AND IS NOT TO BE COPIED, REPRODUCED, LENT OR    */
/* DISPOSED OF, NOR USED FOR ANY PURPOSE OTHER     */
/* THAN THAT FOR WHICH IT IS SPECIFICALLY PROVIDED */
/* WITHOUT THE WRITTEN PERMISSION OF SAID COMPANY  */
/*                                                 */
/***************************************************/

/* AUDIT TRAIL: 2.0                                INIT      DATE           */
/*                                                                          */
/*                                                                          */
/* AUDIT TRAIL : 8.0 (I18N) *//* AUDIT TRAIL END                                                          */


#ifndef _IGAKDEF_H_


#define BUFFSIZE "200000"
#define RECORD_SEP "|"
#define FIELD_SEP  "^"   
#define CLASS_SEP  "~"


#define _IGAKDEF_H_
#endif
