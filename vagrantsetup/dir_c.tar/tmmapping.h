/* AUDIT TRAIL: 8.0                                                         */
/* TAM 10/08/2007                                                           */
/* 1. Internationalization unicode conversion                               */
/* TAM 10/24/2007                                                           */
/* 1. Added tmfeof per HvT                                                  */
/* AUDIT TRAIL END                                                          */
#ifdef _TMUNICODE
#  define TMCHAR UChar
#else
#  define TMCHAR char
#endif

#ifdef _TMUNICODE
#  define tmmemchr u_memchr 
#else
#  define tmmemchr memchr
#endif

#ifdef _TMUNICODE
#  define tmmemcmp u_memcmp 
#else
#  define tmmemcmp memcmp
#endif

#ifdef _TMUNICODE
#  define tmmemcpy u_memcpy 
#else
#  define tmmemcpy memcpy
#endif

#ifdef _TMUNICODE
#  define tmmemmove u_memmove 
#else
#  define tmmemmove memmove
#endif

#ifdef _TMUNICODE
#  define tmstrcat u_strcat
#else
#  define tmstrcat strcat
#endif

#ifdef _TMUNICODE
#  define tmstrchr u_strchr      
#else
#  define tmstrchr strchr
#endif

#ifdef _TMUNICODE
#  define tmstrcmp u_strcmp  
#else
#  define tmstrcmp strcmp
#endif

#ifdef _TMUNICODE
#  define tmstrcpy u_strcpy
#else
#  define tmstrcpy strcpy
#endif

#ifdef _TMUNICODE
#  define tmstrcspn u_strcspn     
#else
#  define tmstrcspn strcspn
#endif

#ifdef _TMUNICODE
#  define tmstrlen u_strlen
#else
#  define tmstrlen strlen
#endif

#ifdef _TMUNICODE
#  define tmstrncat u_strncat     
#else
#  define tmstrncat strncat
#endif

#ifdef _TMUNICODE
#  define tmstrncmp u_strncmp     
#else
#  define tmstrncmp strncmp
#endif

#ifdef _TMUNICODE
#  define tmstrncpy u_strncpy     
#else
#  define tmstrncpy strncpy
#endif

#ifdef _TMUNICODE
#  define tmstrpbrk u_strpbrk     
#else
#  define tmstrpbrk strpbrk
#endif

#ifdef _TMUNICODE
#  define tmstrspn u_strspn      
#else
#  define tmstrspn strspn
#endif

#ifdef _TMUNICODE
#  define tmstrstr u_strstr      
#else
#  define tmstrstr strstr
#endif

#ifdef _TMUNICODE
#  define tmfeof u_feof
#else
#  define tmfeof feof
#endif
