/* AUDIT TRAIL: 8.0 */
/* AUDIT TRAIL END */
/******************************************************************************/
/* LOCAL FUNCTION PROTOTYPES                                                  */
/******************************************************************************/

static void  extract_billhead           ( void );
static void extract_detail_ind_chg      ( void );  
static void extract_detail_ind_tax      ( void );  
static void extract_detail_grp_chg      ( void );  
static void extract_detail_grp_tax      ( void ); 
static void extract_consumption_hist    ( void );
static void extract_exception_info      ( void );
static void extract_masteraddr_info     ( void );
static void extract_summary_ind_chg     ( void );
static void extract_summary_grp_chg     ( void );
static void extract_payments            ( void );
static void extract_budget_info         ( void );
static void extract_budget_summary_info ( void );
static void extract_bill_end            ( void );
static void extract_sum_tax_totals      ( void );

static void initialize_billhead            ( void );
static void initialize_detail_ind_chg      ( void );  
static void initialize_detail_ind_tax      ( void );  
static void initialize_detail_grp_chg      ( void );  
static void initialize_detail_grp_tax      ( void ); 
static void initialize_consumption_hist    ( void );
static void initialize_exception_info      ( void );
static void initialize_masteraddr_info     ( void );
static void initialize_summary_ind_chg     ( void );
static void initialize_summary_grp_chg     ( void );
static void initialize_payments            ( void );
static void initialize_budget_info         ( void );
static void initialize_budget_summary_info ( void );
static void initialize_bill_end            ( void );
static void initialize_sum_tax_totals      ( void );


