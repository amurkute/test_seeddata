/******************************************************************************/
/* URPHDFM.H  Copyright (c) SCT Corporation 1996.  All rights reserved.       */
/******************************************************************************/

/***************************************************/
/*                                                 */
/*    CONFIDENTIAL BUSINESS INFORMATION            */
/*                                                 */
/*   **********************************            */
/*                                                 */
/*  THIS PROGRAM IS PROPRIETARY INFORMATION OF     */
/* SYSTEMS AND COMPUTER TECHNOLOGY CORPORATION     */
/* AND IS NOT TO BE COPIED, REPRODUCED, LENT OR    */
/* DISPOSED OF, NOR USED FOR ANY PURPOSE OTHER     */
/* THAN THAT FOR WHICH IT IS SPECIFICALLY PROVIDED */
/* WITHOUT THE WRITTEN PERMISSION OF SAID COMPANY  */
/*                                                 */
/***************************************************/

/*----------------------------------------------------------------------------*/
/* URPHDFM.H                                                                  */
/* Handheld Download Device Format Module                                     */
/*                                                                            */
/* This is the device specific set of subroutines to be included in the       */
/* program URPHDNL.PC.                                                        */
/*                                                                            */
/* AUDIT TRAIL                                                 INIT    DATE   */
/* ----------------------------------------------------------- ----  -------- */
/* Release: 2.0.3.3.1                                                         */
/* 1. Initial Version                                          EMC   11/08/96 */
/* ************************************************************************** */
/* AUDIT TRAIL:8.0 */
/* AUDIT TRAIL END */
#ifndef DEVICEHDR
#define DEVICEHDR /* Default device format module header */

typedef struct {
    char prem_code[8];
    char num[5];
    char styp_code[5];
    char date_installed[12];
    char activity_date[12];
    char user_id[31];
    char status_ind[2];
    char utyp_code[7];
    char unit[7];
    char dpot_code_nearest[5];
    char service_location[41];
    char scls_code[3];
    char reac_code[3];
    char tvac_code[3];
    char num_units[9];
    char srat_code[5];
    char disc_pct[7];
    char date_retired[12];
    char rrtr_code[3];
    char date_activated[12];
    char date_inactive[12];
    char invn_code[21];
    char i_o_building_ind[2];
    char remote_phone[11];
    char radio_freq[11];
    char rmth_code[3];
    char key_id[11];
    char cust_code[10];
    char seal_num[9];
    char charge_frequency[3];
    char charge_start_month[3];
    char clor_code[3];
    char route[6];
    char reading_seq[6];
    char deposit_amt[10];
    char over_under_ind[2];
    char lock_box_ind[2];
    char phase_ind[2];
    char prepaid_ind[2];
    char cust_code_revert[10];
    char map_location[21];
    char dist_code[5];
    char read_start_month[3];
    char read_frequency[3];
    char lf_percent[4];
} UCRSERV;

typedef struct {
    char code[21];
    char asvc_code[3];
    char stus_code[2];
    char cnfg_code[3];
    char activity_date[12];
    char user_id[31];
    char serial_num[21];
    char test_group[6];
    char orig_install_date[12];
    char next_test_date[12];
    char manf_code[3];
    char model[21];
    char test_interval[4];
    char whse_code[7];
    char warranty_type[7];
    char warranty_exp_date[12];
    char purchase_order[9];
    char purchase_price[10];
    char purchase_date[12];
    char amst_code[10];
    char retire_date[12];
    char rrtr_code[3];
    char phas[2];
    char form[5];
    char scls_code[3];
    char wires[2];
    char volts[5];
    char amps[5];
    char rrat[10];
    char sint[5];
    char smax[8];
    char measure_meth_ind[2];
    char ctpt_ind[2];
    char maxflow[7];
    char laylng[8];
    char psi[7];
    char transponder_id[16];
} UIBMINV;

typedef struct {
    char minv_code[21];
    char scat_code[5];
    char num_dials[3];
    char decpos[2];
    char cum_peak_ind[2];
    char uoms_code[5];
    char stus_code[2];
    char activity_date[12];
    char user_id[31];
    char multiplier[10];
    char num_dead_dials[3];
    char cnsz_code[5];
    char cnt_rollover[4];
    char primary_reg_ind[2];
    char scat_seq_num[3];
} UIRDIAL;

typedef struct {
    char code[3];
    char desc[36];
} UTVRINS;

typedef struct {
    char low_read_limit[12];
    char high_read_limit[12];
    char avg_consumption[12];
    char comments[33];
    char customer_name[33];
    char premises_address[33];
    char prev_read[12];
    char prev_consump[12];
    char prev_read_date[12];
    char read_date[12];
    char critical_date[12];
    char cycle_code[6];
    char must_read_ind[2];
    char months_estimated[6];
    long lRinsFetched;
  double consump_total;
  double consump_months;
  double min_cons_high_low;
  double tolerance_pct;
  double mask;
    char rmth_code_desc[36];
} MISC;

extern UCRSERV Ucrserv, *pUcrserv;
extern UIBMINV Uibminv, *pUibminv;
extern UIRDIAL Uirdial, *pUirdial;
extern UTVRINS RinsArray[1000];   /* This matches the number of rows fetched */
extern MISC Misc, *pMisc;
extern int OpenVendorDnlFile(char *pszDnlFileName);
extern int WriteVendorRecord(char *pszDnlFileName);                  
extern int CloseVendorDnlFile(char *pszDnlFileName);

#endif
