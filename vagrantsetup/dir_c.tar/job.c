/*TMCI18N BEGIN HEADER*/
#if !defined( tmBundle_EXISTS )
/* No Initialisation Required */
#include "tmcilib.h"
static struct TMBundle tmBundle = {"job.c",NULL,NULL,NULL,NULL};
#define tmBundle_EXISTS
#endif
/*TMCI18N END HEADER*/

/* AUDIT_TRAIL_MSGKEY_UPDATE
-- PROJECT : MSGKEY
-- MODULE  : JOB
-- SOURCE  : enUS
-- TARGET  : I18N
-- DATE    : Thu Jul 19 14:26:07 2012
-- MSGSIGN : #0000000000000000
END AUDIT_TRAIL_MSGKEY_UPDATE */

/* AUDIT_TRAIL_TM63
-- TranMan 6.3
-- PROJECT : HEGDE_I18N
-- MODULE  : JOB
-- SOURCE  : enUS
-- TARGET  : I18N
-- DATE    : Tue Oct 09 05:13:49 2007
END AUDIT_TRAIL_TM63 */
/****************************************************************************/
/*                                                                          */
/* Copyright 1995 - 2012 Ellucian.                                          */
/*                                                                          */
/****************************************************************************/

/*
AUDIT TRAIL: 2.0.6
 1. New for DL. Common job sub functions for all new C
    Development                                                 CK  02/21/95
 AUDIT TRAIL: 2.0.10
 1. Changes in strcmp return value for DEC Alpha machines       CK  05/08/95
 AUDIT TRAIL: 4.3
 1. Modifies stor_n_val function to validate the value in
    the 2nd, 3rd entry and so on for multiple parameters.       CL 11/23/99
 AUDIT TRAIL: 4.4
 1. Modified stor_n_val function to allow users to enter a
    NULL value from the host for required parameters having
    default values.                                             NP 01/04/2000
 2. Removed unused variable ptr in function form_row()          NP 01/04/2000
 AUDIT TRAIL: 4.9
 1. Defect 52239 (Oracle 8i bug #1292638) - Initialize array   RWM 01/10/2001
    variables before each fetch.
 AUDIT TRAIL: 4.9.0.1
 1. Defect 59383                                                NP 03/12/2001
    Renamed function init_array() to init_jobsub_array()
    to prevent conflict in some finaid processes where
    same function name is used locally.
 AUDIT TRAIL: 5.1
 1. Migrated 4.X version of object to 5.1.                      HW 04/17/2001
 AUDIT TRAIL:8.0 (I18N)
 1. Internationalization Unicode Conversion
 AUDIT TRAIL: 8.2
 1. Remove ALL localization codes.  Replaces TM_NLS_Get with   PNN 03/18/2009
    _TMC.  The localization codes have duplicates Id numbers with the parent
    processes.  This is causing the wrong localization messages been call by
    the parent processes.  This is most noticeable when running with debug
    turned on.
 AUDIT TRAIL: 8.8
 1. Defect 1-8W1X7F                                            RWM 04/14/2010
    Problem: C compile warning " 'gets' function is dangerous
    and should not be used" occurs in certain environments.
    The compile warning is pointing out a real defect which
    has existed since the process was first written. There's
    nothing to stop a user from entering more characters than
    the array in the calling program can hold. To fix this,
    the function needs an additional parameter with the length
    of the array that will hold the value that's being entered
    at the command line. Doing this would require changes to
    every process that calls this function. Since this
    functionality is no longer supported in Banner, the
    problematic 'gets' string processing is being replaced
    with single character 'fgetc' processing in a loop. This
    will eliminate the compile warnings but still allows the
    possibility of buffer overflow.
    Solution: 'tmgets' has been replaced with 'tmfgetc'.
 AUDIT TRAIL: 8.15
 1. Defect 1-11GQYVF                                            RWM 07/19/2012
    Problem: Financial Aid processes would fail with an
    "Invalid Parameter" message when the job was submitted with
    any optional parameters deleted from the job submission
    form (GJAPCTL).
    Resolution: The process will now handle the situation of
    optional parameters not being passed by job submission.
 AUDIT TRAIL END
*/

/* ----------------------------------------------------------------------
   Job submission functions.
   Author : Chid Kollengode, Banner Financial Aid
   Usage in programs.
	main(int argc, char *argv[])
	{
		a. Routine to get one_up_number
		b. Execute the function valid_one_up(char *var_having_one_up)

                    other processing continues .......
        }
		c. Write a function accept_parms() that accepts the values
		   from keyboard interactively for all the required inputs
		   for the program.
		    The usage is:
			define the function and call get_n_val with the
			following:
			get_n_val(prompt,var,prm,default,val_f);
			where
			 prompt - is the prompt string (50 char max)
			 var    - global static var in which to accept
				  the value from the keyboard
			 prm    - parm number
			 default- the default value if input is null, use
                                  string data type only.
			 val_f  - the function name that does the validation
				  (the val function should not have arguments
			           for the above, variable args can be supported
				   later on if need for it is felt)
				  (the first line in function should be
				    if (!*var) return;
				  if the parm does not have a validation
			  	  function, substitute val_f with NULL (upper
				  case NULL and not lower case null)
	accept_parms()
	{
	    get_n_val("Aid Year",aidy_code,"01","9596",NULL);
	    get_n_val("Fund Code",fund_code,"02",NULL,f_val);
			.
			.
	}
		d. Write a function retrieve_parms() that returns the values
		   for parm_numbers. The values are already in the GJBPRUN
		   table and use of
			retr_job_value(var, prm)
	 			where var is the variable to store the value
                                          retireved from database
                                      prm is the parm number
		   For parms that are multiple, get_value inserts rows to
		   the collector table (GJBCOLR). In this case, there is
		   no need to use the return string value from get_value
		   function. e.g. get_value("03") is fine when parm 3 is
		   multiple. (Using retr_job_value(fund_code,"03") when parm
		   03 is multiple will not cause any error nor will it cause
		   the program to behave differently. It is just an overhead).
	retrieve_parms()
	{
    	   retr_job_value(aidy_code, "01");
    	   retr_job_value(fund_code, "02");
	   get_value("03");
		.
		.
		.
        }

   -----------------------------------------------------------------------  */
/* ----------------------------------------------------------------------
   ROWS_TO_GET is defined as 25. If changed here the array subscripts for
   job_num,job_ind,job_value,job_mul,Ind_1,Ind_2 and Ind_3 from 25 to the
   new value changed.  The Pro*C runs before cpp of the C compiler that
   substitutes for the #defines
   -----------------------------------------------------------------------  */
#define ROWS_TO_GET 25
#define valid_one_up(j_one_up)  do_process(j_one_up, argv[0])
#define get_n_val(prompt, var, prm, default, func) \
         stor_n_val(prompt, var, prm, default, (int (*)(void))(func))
#define retr_job_value(var,prm) tmstrcpy(var, get_value(prm))

/* ----------------------------------------------------------------------
   Structure for linked list.
    prev    - the previous address in the chain
    next    - the next address in the chain
    prmnum  - the parameter number, which is the key for scanning the list
    prmstat - required or optional (if parm values are accepted interactively)
    prmmul  - single or multiple indication
    prmval  - the value for the parm if loaded into table and picked up using
	      one up number(applicable for job submission)
   -----------------------------------------------------------------------  */
typedef struct optional{
        struct optional *prev;
        struct optional *next;
	TMCHAR prmnum[3];
	TMCHAR prmstat[2];
	TMCHAR prmmul[2];
	TMCHAR prmval[30];
} OPTSTRU, *OPTPTR;

/* ----------------------------------------------------------------------
   Global Vars for anchoring the start of list and searching the list
   from the current spot pointed by srchptr.
   -----------------------------------------------------------------------  */
static OPTPTR anchor = NULL;
static OPTPTR srchptr = NULL;

/* ----------------------------------------------------------------------
   ROWS_TO_GET if changed in the define line it must be changed here also
   -----------------------------------------------------------------------  */
EXEC SQL BEGIN DECLARE SECTION;
    static TMCHAR job_name[31];
    static BANNUMSTR(job_1_no);
    static TMCHAR job_val[31];
    static TMCHAR  job_pno[3];
    static TMCHAR  job_num[25][3];     /* change 25 if ROWS_TO_GET is changed */
    static TMCHAR  job_ind[25][2];     /* change 25 if ROWS_TO_GET is changed */
    static TMCHAR job_value[25][31];   /* change 25 if ROWS_TO_GET is changed */
    static TMCHAR  job_mul[25][2];     /* change 25 if ROWS_TO_GET is changed */
    static int   btch_inp ;
    short Ind_1[25];               /* change 25 if ROWS_TO_GET is changed */
    short Ind_2[25];               /* change 25 if ROWS_TO_GET is changed */
    short Ind_3[25];               /* change 25 if ROWS_TO_GET is changed */
    short Ind1;
EXEC SQL END DECLARE SECTION;

/* ----------------------------------------------------------------------
   function prototypes
   -----------------------------------------------------------------------  */
static void do_process(TMCHAR *, TMCHAR *);
static void one_up(TMCHAR *, TMCHAR *);
static void gen_one_up(void);
static void sel_opts(void);
/* 08150000-1 */
static void add_missing_optionals(void);
static void fetch_gjbpdef(void);
static void mkdlst( int );   /* make doubly linked list */
static void apndlcnt( void);
static void srchlst(TMCHAR *, OPTPTR *);
static void frdlst(OPTPTR );
static int required(TMCHAR *);
static TMCHAR *get_value(TMCHAR *);
static void form_row(TMCHAR *);
static void stor_n_val(TMCHAR *, TMCHAR *, TMCHAR *, TMCHAR *, int (*)(void));
static void add_row(void);
static void del_job_parms(void );
static void close_up(void);
static void retrieve_parms(void);  /* these two functions are prototyped      */
static void accept_parms(void);    /* and must be written specifically as the */
                                   /* situation demands in each C program     */
/* 4900-1 */
/* static void init_array(void);  4901-1 renamed as below */
static void init_jobsub_array(void);  /* Initialize array variables           */


/* ----------------------------------------------------------------------
   This process validates the one up number, does the processing for
   building the linked list and executes accept_parms() or retrieve_parms()
   function depending on validity of the one_up_number. All this is done
   only if the one_up_no is not null. Otherwise, the accept parms routine
   is performed.
   -----------------------------------------------------------------------  */
static void do_process(TMCHAR *j_one_up, TMCHAR *pgname)
{
        FNSTRUC file;
#ifdef SCT_DEBUG
	tmprintf(&tmBundle, _TMC("Executing function do_process  \n"));
#endif
		tmstrcpy(file.fname,pgname);
		parsfn(&file);
		tmstrcpy(pgname,file.name);
		one_up(j_one_up, pgname);
/* 08150000-1 */
    add_missing_optionals();
		sel_opts();
		fetch_gjbpdef();
		if ( btch_inp)
			retrieve_parms();
		else
			accept_parms();
	 	frdlst(anchor);
		close_up();
}

/* ----------------------------------------------------------------------
   This function sets btch_inp variable to '0' if no valid one up number
   is given or incorrect one up is given.  Else it sets btch_inp variable to
   '1', meaning parameter values are batch input from table.
   -----------------------------------------------------------------------  */
static void one_up(TMCHAR *j_one_up, TMCHAR *pgname)
{
#ifdef SCT_DEBUG
	tmprintf(&tmBundle, _TMC("Executing function one_up  \n"));
#endif
        str2uc(tmstrcpy(job_name,tmstrtok(pgname,_TMC("."))));  /* Convert to upper */
        if (*j_one_up) {
	   tmstrcpy(job_1_no,j_one_up);
	   EXEC SQL
		SELECT '1'
		INTO   :btch_inp:Ind1
		FROM GJBPRUN
		WHERE GJBPRUN_JOB      = :job_name
		AND   GJBPRUN_ONE_UP_NO= :job_1_no;
	   POSTORA;
	   if (!btch_inp) {
	     tmfprintf(&tmBundle, tmstderr,_TMC("*ERROR* Invalid one up number \n"));
	     exit2os(EXIT_FAILURE);
           }
        }
	else gen_one_up();
}

/* ----------------------------------------------------------------------
   Generate a one up number from the sequence table
   -----------------------------------------------------------------------  */
static void gen_one_up(void)
{
#ifdef SCT_DEBUG
  tmprintf(&tmBundle, _TMC("Executing function gen_one_up  \n"));
#endif

  btch_inp = 0;
  EXEC SQL SELECT GJBPSEQ.NEXTVAL
             INTO :job_1_no:Ind1
             FROM  DUAL;

  POSTORA;
}

/* ----------------------------------------------------------------------
   08150000-1
   This function adds any missing optional params to gjbprun. Values are NULL.
   This will prevent a fatal error occurring in the link list lookup.
   -----------------------------------------------------------------------  */
static void add_missing_optionals(void)
{
#ifdef SCT_DEBUG
  tmprintf(&tmBundle, _TMC("Executing function add_missing_optionals\n"));
#endif

  EXEC SQL
     INSERT INTO GJBPRUN
                (GJBPRUN_JOB,
                 GJBPRUN_ONE_UP_NO,
                 GJBPRUN_NUMBER,
                 GJBPRUN_ACTIVITY_DATE,
                 GJBPRUN_VALUE,
                 GJBPRUN_LABEL)
          SELECT :job_name,
                 TO_NUMBER(:job_1_no),
                 GJBPDEF_NUMBER,
                 TRUNC(SYSDATE),
                 NULL,
                 NULL
            FROM GJBPDEF
           WHERE GJBPDEF_JOB = :job_name
             AND GJBPDEF_NUMBER NOT IN (SELECT GJBPRUN_NUMBER
                                          FROM GJBPRUN
                                         WHERE GJBPRUN_JOB       = :job_name
                                           AND GJBPRUN_ONE_UP_NO = :job_1_no);

  POSTORA;
}

/* ----------------------------------------------------------------------
   This function defines the cursor for extracting the rows from table
   -----------------------------------------------------------------------  */
static void sel_opts(void)
{
#ifdef SCT_DEBUG
  tmprintf(&tmBundle, _TMC("Executing function sel_opts\n"));
#endif

  switch (btch_inp)
  {
   case 1 :
        EXEC SQL DECLARE C1 CURSOR FOR
             SELECT GJBPRUN_NUMBER,
                    GJBPRUN_VALUE,
                    NVL(GJBPDEF_SINGLE_IND,'S')
               FROM GJBPRUN,
                    GJBPDEF
              WHERE GJBPRUN_JOB       = :job_name
                AND GJBPRUN_ONE_UP_NO = :job_1_no
                AND GJBPRUN_JOB       = GJBPDEF_JOB(+)
                AND GJBPRUN_NUMBER    = GJBPDEF_NUMBER(+);

        EXEC SQL OPEN C1;
        break;
   default:
        EXEC SQL DECLARE C2 CURSOR FOR
             SELECT GJBPDEF_NUMBER,
                    GJBPDEF_OPTIONAL_IND,
                    GJBPDEF_SINGLE_IND
               FROM	GJBPDEF
              WHERE	GJBPDEF_JOB = :job_name;

        EXEC SQL OPEN C2;
  }

  POSTORA;
}

/* ----------------------------------------------------------------------
   This function fetches into an array the rows read from the cursor and
   creates a doubly linked list from the array.
   -----------------------------------------------------------------------  */
static void fetch_gjbpdef(void)
{
  register int  rows_total_fetched = 0;
  register int  rows_now_fetched = 0;
  register int  cnt;

#ifdef SCT_DEBUG
tmprintf(&tmBundle, _TMC("Executing function fetch_gjbpdef\n"));
#endif
  do
  {
    init_jobsub_array(); /* 4901-1 */ /* init_array();  4900-1 */
    if (btch_inp)
       EXEC SQL FETCH C1
                 INTO :job_num:Ind_1,
                      :job_value:Ind_2,
                      :job_mul:Ind_3;
    else
       EXEC SQL FETCH C2
                 INTO :job_num:Ind_1,
                      :job_ind:Ind_2,
                      :job_mul:Ind_3;
    POSTORA;

    rows_now_fetched = sqlca.sqlerrd[2] - rows_total_fetched;
    rows_total_fetched = sqlca.sqlerrd[2];
    if (rows_now_fetched)
       for ( cnt = 0; cnt < rows_now_fetched ; cnt++)
    mkdlst(cnt);
  } while (rows_now_fetched == ROWS_TO_GET);

  if (!btch_inp)
     apndlcnt();
  srchptr = anchor;
}

/* ----------------------------------------------------------------------
   This function adds line count as a parm to end of list when the
   process is run accepting parms from the keyboard interactvively
   -----------------------------------------------------------------------  */
static void apndlcnt( void)
{
	OPTPTR base,hold;
	base   = anchor;
#ifdef SCT_DEBUG
	tmprintf(&tmBundle, _TMC("Executing function addlcnt\n"));
#endif
/* there should always be a base, if not return.*/
	if ( base && tmstrcmp(_TMC("99"),base->prmnum) )  {
	   while( base->next && tmstrcmp(_TMC("99"),base->next->prmnum) > 0)
		   base = base->next;
	   if (!base->next ){
	                hold = GETMEM(OPTSTRU,1);
			base->next = hold;
			hold->prev = base;
			hold->next = NULL;
			base  =  hold;
	   		tmstrcpy(base->prmnum ,_TMC("99"));
	   		tmstrcpy(base->prmstat,_TMC("O"));
	   		tmstrcpy(base->prmmul,_TMC("S"));
	   }
	}
}
/* ----------------------------------------------------------------------
   This function creates the linked list
   -----------------------------------------------------------------------  */
static void mkdlst( int arr_idx)
{
	OPTPTR base,hold,tmp;
	base   = anchor;
#ifdef SCT_DEBUG
	tmprintf(&tmBundle, _TMC("Executing function mkdlst\n"));
#endif
/* if this is the first time, define a start pointer to the list */
	if ( !base ) {
		base = GETMEM(OPTSTRU,1);
		base->prev = base->next = NULL;
		anchor= base;
	}
/* if not, link the new entry to the existing list in the proper place */
	else {
	   while( base->next && tmstrcmp(job_num[arr_idx],base->prmnum) > 0)
		   base = base->next;
	   hold = GETMEM(OPTSTRU,1);
	/* if end of list, append entry, set prev and next pointers */
	   if (!base->next && tmstrcmp(job_num[arr_idx],base->prmnum) > 0){
			base->next = hold;
			hold->prev = base;
			hold->next = NULL;
			base  =  hold;
	   }
	   else {
			tmp = base->prev;
			hold->prev = tmp;
			hold->next = base;
			base->prev = hold;
			if (!tmp)
				anchor = hold;  /* new start pointer */
			else
				tmp->next = hold;
			base = hold;
	   }
	}
	if (btch_inp) {
		tmstrcpy(base->prmnum ,job_num[arr_idx]);
		tmstrcpy(base->prmval,job_value[arr_idx]);
		tmstrcpy(base->prmmul,job_mul[arr_idx]);
	}
	else {
		tmstrcpy(base->prmnum ,job_num[arr_idx]);
		tmstrcpy(base->prmstat,job_ind[arr_idx]);
		tmstrcpy(base->prmmul,job_mul[arr_idx]);
	}
}

/* ----------------------------------------------------------------------
   Does the actual search for the parmeter number and sets the contents
   of search pointer to match the current parm number.
   -----------------------------------------------------------------------  */
static void srchlst(TMCHAR *prm, OPTPTR *ptr)
{
        int cval;
#ifdef SCT_DEBUG
	tmprintf(&tmBundle, _TMC("Executing function srchlst \n"));
#endif
	if (!prm ) {
		tmfprintf(&tmBundle, tmstderr,_TMC("*ERROR* Null parameter given\n"));
		frdlst(anchor);
		exit2os(EXIT_FAILURE);
	}
	if ( !anchor) {
		tmfprintf(&tmBundle, tmstderr,_TMC("*ERROR* Parm list not available for program\n"));
		exit2os(EXIT_FAILURE);
	}
	cval =  tmstrcmp(prm,(*ptr)->prmnum);
        if (cval > 0) {
	   *ptr = (*ptr)->next;
	   while(*ptr && tmstrcmp(prm,(*ptr)->prmnum) )
	       *ptr=(*ptr)->next;
        }
        else if (cval < 0) {
	        *ptr = (*ptr)->prev;
		while(*ptr && tmstrcmp(prm,(*ptr)->prmnum) )
		    *ptr=(*ptr)->prev;
              }
	if(! *ptr){
		tmfprintf(&tmBundle, tmstderr,_TMC("*ERROR* Parameter ({0}) is invalid\n"),prm);
		frdlst(anchor);
		exit2os(EXIT_FAILURE);
	}
}

/* ----------------------------------------------------------------------
   Free up the memory used by the link list
   -----------------------------------------------------------------------  */
static void frdlst(OPTPTR ptr)
{
	OPTPTR tmp;
#ifdef SCT_DEBUG
	tmprintf(&tmBundle, _TMC("Executing function frdlst \n"));
#endif
	while(ptr ) {
		tmp = ptr->next;
		FREEMEM(ptr);
		ptr=tmp;
	}
}

/* ----------------------------------------------------------------------
   Searches the link list, sets srchptr to address if parm match is
   found and returns TRUE if parm is required, FALSE if optional
   -----------------------------------------------------------------------  */
static int required(TMCHAR *prmno)
{
#ifdef SCT_DEBUG
	tmprintf(&tmBundle, _TMC("Executing function required  \n"));
#endif
                srchlst(prmno, &srchptr);
		return ( !tmstrcmp(_TMC("R"),srchptr->prmstat));
}

/* ----------------------------------------------------------------------
   Searches the link list, sets srchptr to address if parm match is
   found and returns the value for the parm.
   -----------------------------------------------------------------------  */
static TMCHAR *get_value(TMCHAR *prmno)
{
#ifdef SCT_DEBUG
	tmprintf(&tmBundle, _TMC("Executing function get_value  \n"));
#endif
                srchlst(prmno, &srchptr);
		if (! tmstrcmp(srchptr->prmmul ,_TMC("M")) )
			form_row(prmno);
		return ( srchptr->prmval);
}

/* ----------------------------------------------------------------------
   Formats rows for collector table for parameters that are multiple
   -----------------------------------------------------------------------  */
static void form_row(TMCHAR *prm)
{
	/* OPTPTR ptr=anchor;  4400-2 */
#ifdef SCT_DEBUG
	tmprintf(&tmBundle, _TMC("Executing function form_row \n"));
#endif
  	tmstrcpy(job_pno, prm);
	EXEC SQL
		INSERT INTO GJBCOLR
			(GJBCOLR_ONE_UP_NO,
		 	 GJBCOLR_JOB,
			 GJBCOLR_NUMBER,
			 GJBCOLR_VALUE,
		 	 GJBCOLR_ACTIVITY_DATE)
	        SELECT   TO_NUMBER(:job_1_no),
			  :job_name,
			  :job_pno,
		       	  GJBPRUN_VALUE,
			  sysdate
		FROM   GJBPRUN
        	WHERE  GJBPRUN_NUMBER = :job_pno
        	AND    GJBPRUN_JOB    = :job_name
        	AND    GJBPRUN_ONE_UP_NO = TO_NUMBER(:job_1_no)
        	AND    GJBPRUN_VALUE  IS NOT NULL;
	POSTORA;

	EXEC SQL COMMIT;
  	POSTORA;
}

/* ----------------------------------------------------------------------
   Function to prompt for value and validate, if a validation function
   is given. Handles single and multiple cases and also required/optional
   cases.
   -----------------------------------------------------------------------  */
static void stor_n_val(TMCHAR *prompt, TMCHAR *invar, TMCHAR *prm, TMCHAR *defualt, int (*fp)(void))
{
  int i = 1;
  TMCHAR fmtstr[120];
/* 08080000-1 */
  TMCHAR *wptr;
  int c;

#ifdef SCT_DEBUG
	tmprintf(&tmBundle, _TMC("Executing function stor_n_val\n"));
#endif

  tmsprintf(&tmBundle,  fmtstr,_TMC("{0}{1}"),prompt,_TMC(".................................................."));

  do
  {
	  tmprintf(&tmBundle, _TMC("{0,%-55.55s}:"),fmtstr);
	  tmfflush(tmstdout);

/* 08080000-1 Start change
	  tmgets(invar);
	  tmfflush(tmstdin);
*/
#ifdef SCT_DEBUG
	tmprintf(&tmBundle, _TMC("Executing tmfgetc (1)\n"));
#endif

    c = 1;
    wptr = invar;
    while( c )
    {
      c = tmfgetc( tmstdin );
      if (c == '\n')
        break;
      else
         *wptr++ = c;
    }

    *wptr = '\0';
/* 08080000-1 End change */

    if (!*invar && defualt != NULL)     /* added for 4400-1 */
       tmstrcpy(invar,defualt);
  } while ((required(prm) && !*invar)||(*fp == NULL ? 0 : !((*fp)())));

  if (*invar)
  {
    if (! tmstrcmp(srchptr->prmmul ,_TMC("M")) )
    {
	    tmstrcpy(job_pno,prm);
	    tmstrcpy(job_val,invar);
	    add_row();
      do
      {
	      tmprintf(&tmBundle, _TMC("{0,%-50.50s} ({1,%2d}):"),fmtstr,++i);
	      tmfflush(tmstdout);

/* 08080000-1 Start change
	      tmgets(invar);
	      tmfflush(tmstdin);
*/
#ifdef SCT_DEBUG
	tmprintf(&tmBundle, _TMC("Executing tmfgetc (2)\n"));
#endif

        c = 1;
        wptr = invar;
        while( c )
        {
          c = tmfgetc( tmstdin );
          if (c == '\n')
            break;
          else
            *wptr++ = c;
        }

        *wptr = '\0';
/* 08080000-1 End change */

	      if ((*invar) && (*fp == NULL ? 1 : ((*fp)())))
        {
	        tmstrcpy(job_val,invar);
	        add_row();
	      }
        else
          i--;
        } while (*invar || (*fp == NULL ? 0 : !((*fp)())));

	EXEC SQL commit;
	POSTORA;
   }
  }
    if (!*invar && defualt != NULL)
                tmstrcpy(invar,defualt);
}

/* ----------------------------------------------------------------------
   Insert row into collector table
   -----------------------------------------------------------------------  */
static void add_row(void)
{
#ifdef SCT_DEBUG
	tmprintf(&tmBundle, _TMC("Executing function add_row  \n"));
#endif
  		EXEC SQL INSERT INTO GJBCOLR
                	(GJBCOLR_ONE_UP_NO,
                 	GJBCOLR_JOB,
                 	GJBCOLR_NUMBER,
                 	GJBCOLR_VALUE,
                 	GJBCOLR_ACTIVITY_DATE)
        	VALUES  (TO_NUMBER(:job_1_no),
			:job_name,
                 	:job_pno,
                 	:job_val,
                 	sysdate);
  		POSTORA;
}

/* ----------------------------------------------------------------------
   Deletes the rows from the parameter table for the given one_up_number.
   The value of job_name and job_1_no are already populated in an earlier
   strcpy
   -----------------------------------------------------------------------  */
static void del_job_parms( void )
{
#ifdef SCT_DEBUG
	tmprintf(&tmBundle, _TMC("Executing function del_job_parms  \n"));
#endif
	EXEC SQL
		DELETE GJBPRUN
		WHERE GJBPRUN_JOB      = :job_name
		AND   GJBPRUN_ONE_UP_NO= :job_1_no;
	POSTORA;
}

/* ----------------------------------------------------------------------
   Closing operations
   -----------------------------------------------------------------------  */
static void close_up(void)
{
#ifdef SCT_DEBUG
	tmprintf(&tmBundle, _TMC("Executing function close_up  \n"));
#endif
	if (btch_inp){
  		del_job_parms();
		EXEC SQL COMMIT;
		POSTORA;
		EXEC SQL CLOSE C1;
	}
	else
		EXEC SQL CLOSE C2;
	POSTORA;
}

/* ----------------------------------------------------------------------
   4900-1
   Initialize arrays before each fetch
   -----------------------------------------------------------------------  */

static void init_jobsub_array(void)     /* 4901-1 renamed from init_array() */
{
   int i;
#ifdef SCT_DEBUG
        tmprintf(&tmBundle, _TMC("Executing init_jobsub_array  \n"));
#endif

   for (i = 0; i < ROWS_TO_GET; i++)
   {
       tmstrcpy(job_num[i],  _TMC(""));
       tmstrcpy(job_ind[i],  _TMC(""));
       tmstrcpy(job_value[i],_TMC(""));
       tmstrcpy(job_mul[i],  _TMC(""));
   }
}
