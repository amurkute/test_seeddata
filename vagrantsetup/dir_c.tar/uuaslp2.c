/***************************************************/
/*                                                 */
/*       CONFIDENTIAL BUSINESS INFORMATION         */
/*                                                 */
/*      **********************************         */
/*                                                 */
/*  THIS PROGRAM IS PROPRIETARY INFORMATION OF     */
/* SYSTEMS AND COMPUTER TECHNOLOGY CORPORATION     */
/* AND IS NOT TO BE COPIED, REPRODUCED, LENT OR    */
/* DISPOSED OF, NOR USED FOR ANY PURPOSE OTHER     */
/* THAN THAT FOR WHICH IT IS SPECIFICALLY PROVIDED */
/* WITHOUT THE WRITTEN PERMISSION OF SAID COMPANY  */
/*                                                 */
/***************************************************/
/*                                                                            */
/*                                                                            */
/* AUDIT TRAIL                                               INIT    DATE     */
/* --------------------------------------------------------  ---- ----------- */
/*                                                                            */
/* Release: 2.0.3.3                                                           */
/* 1. Bug #7909 - Changed "EXEC SQL COMMIT WORK RELEASE"     JBJ  09-SEP-1996 */
/*    to "EXEC SQL COMMIT WORK".  RELEASE statement was                       */
/*    causing UBPBILP and UCRSOPR to abort when trying to                     */
/*    update the process audit table, USBSUBM because it                      */
/*    logs off the database. SR#30902                                         */
/*                                                                            */
/*                                                                 */
/* audit trail: 2.0                                  INIT   DATE   */
/* 1. Create copylib for sleep/wake processes        SRS  06/23/93 */
/* AUDIT TRAIL: 2.1.5 Supplemental                            CFIX  12/04/96  */
/* 1. Program modified by cfix.c to remedy mostly Pro*C related problems:     */
/*    split SQL concatenations joined, colons added to FETCH targets,         */
/*    file extensions added to SQL INCLUDEs, 'static' modifier removed from   */
/*    indicator variables, new logic to hadle CLOSE_CURSOR was added to SQL   */
/*    function wrappers, and object owner references were removed as part of  */
/*    BANNER2.1.  (Not all changes necessarily apply.)                        */
/* AUDIT TRAIL:8.0
/* audit trail end */

#ifndef NO_SLEEP_SW

/* sleep prototypes */

static void buildcom(char *st);
static void resetsleep(int exit_status);
static int initsleep();
static int sleepwake();

/* build print command and include file */

static void buildcom(char *st)
{
 int kount;
 int kount2;
 static char oldprintcom[260]="";
 char builtcom[260];

/* find the printer command string */

 if ( (int)strlen(oldprintcom) == 0 )
  {
   exec sql select gtvprnt_printer_command
            into :printcom:SwInd_01
            from gtvprnt
            where gtvprnt_code=:printer;
   POSTORA;
   strcpy(oldprintcom,printcom);
  }
 else
  {
   strcpy(printcom,oldprintcom);
  }

/* replace @ with filename */

 for (kount=0,kount2=0;kount<(int)strlen(printcom);kount++)
  {
   if (st[kount] == '@')
    {
     strcat(builtcom,outputfile);
     kount2=strlen(builtcom);
     builtcom[kount2]='\0';
    }
   else
    {
     builtcom[kount2]=printcom[kount];
     builtcom[kount2+1]='\0';
     kount2+=1;
    }
  }
  strcpy(st,builtcom);
}

/* set the continue and abnormal indicators when the process ends */

static void resetsleep(int exit_status)
{
 if ( compare(abnormalexit,"Y",EQS) )
  {
   exec sql rollback work;
   POSTORA;
  }
 exec sql update gjrswpt set gjrswpt_continue_ind='N',
          gjrswpt_next_execution=null,
          gjrswpt_activity_date=sysdate,gjrswpt_error_ind=:abnormalexit
          where gjrswpt_session_id=:session_id;
 POSTORA;
/* exec sql commit work release; Bug # 7909 */
 exec sql commit work;
 POSTORA;

}


static int initsleep()
{

/* does process already have a row; if so is it already running?
                          runsw=0, not running
                          runsw=1, running
                          runsw=3, no row exists
                          runsw=4, no printer command string found
*/

 exec sql select gtvprnt_printer_command
            into :printcom:SwInd_01
            from gtvprnt
           where gtvprnt_code=:printer;
 POSTORA;
 if ( (sqlca.sqlcode == 1403) || ((int)strlen(printcom) == 0) )
  {
   runsw=4;
   return(4);
  }

 exec sql select decode(gjrswpt_continue_ind,'Y',1,'N',0,2),
          decode(gjrswpt_next_execution,null,'0','1')
          into :runsw:SwInd_01, :nextsw:SwInd_02 from gjrswpt
          where gjrswpt_process=:rptname
          and gjrswpt_printer=:printer
          and gjrswpt_continue_ind='Y';
 POSTORA;

/* see if row does not exist */

 if (sqlca.sqlcode == 1403)
  {
   runsw=3;
  }
 else
  {
   runsw=1;
   return(1);
  }

/* if the row does not exist, insert one.  Otherwise, update the row. */

 if (runsw == 3)
  {
   exec sql select userenv('sessionid')
              into :session_id:SwInd_01
              from dual;
   POSTORA;
   exec sql insert into gjrswpt(gjrswpt_process, gjrswpt_printer,
            gjrswpt_current_interval, gjrswpt_next_interval,
            gjrswpt_interval_count, gjrswpt_last_execution,
            gjrswpt_cumulative_count, gjrswpt_continue_ind,
            gjrswpt_error_ind,gjrswpt_session_id,
            gjrswpt_next_execution, gjrswpt_activity_date)
            values(:rptname,:printer,:current_interval,
            :next_interval,0,sysdate,0,'Y','N',:session_id,
            null,sysdate );
   POSTORA;
  }
 else
  {
   exec sql update gjrswpt set
            gjrswpt_current_interval=:current_interval,
            gjrswpt_next_interval=:next_interval,
            gjrswpt_interval_count=0, gjrswpt_cumulative_count=0,
            gjrswpt_continue_ind='Y',
            gjrswpt_error_ind='N',gjrswpt_session_id=:session_id,
            gjrswpt_last_execution=sysdate,
            gjrswpt_next_execution=null,
            gjrswpt_activity_date=sysdate
            where gjrswpt_process=:rptname
            and gjrswpt_printer=:printer;
   POSTORA;
  }

 exec sql commit work;
 POSTORA;

 return(0);
}

static int sleepwake()
{

/* see if the process should sleep; if so, how long to sleep. */

 exec sql select gjrswpt_next_interval,
          decode(gjrswpt_continue_ind,'Y',1,'N',0,0)
          into :next_interval:SwInd_01, :runsw:SwInd_02
          from gjrswpt
          where gjrswpt_session_id=:session_id;
 POSTORA;

/* see if row does not exist */

 if (sqlca.sqlcode == 1403)
  {
   return(1);
  }

/* reset the interval if necessary */

 if (next_interval != current_interval && runsw == 1)
  {
   current_interval=next_interval;
   exec sql update gjrswpt set
            gjrswpt_current_interval=:current_interval,
            gjrswpt_activity_date=sysdate
            where gjrswpt_session_id=:session_id;
   POSTORA;
   exec sql commit work;
   POSTORA;
  }

/* sleep and return 0, or simply return a 1 */

 if (runsw == 1)
  {
   exec sql update gjrswpt set
            gjrswpt_next_execution=(sysdate + (:current_interval/24/60/60)),
            gjrswpt_activity_date=sysdate
            where gjrswpt_session_id=:session_id;
   POSTORA;
   exec sql commit work;
   POSTORA;
   sleep(current_interval);
   exec sql update gjrswpt set
            gjrswpt_next_execution=null,
            gjrswpt_activity_date=sysdate
            where gjrswpt_session_id=:session_id;
   POSTORA;
   exec sql commit work;
   POSTORA;
   return(0);
  }
 else
  {
   return(1);
  }

}
#endif
