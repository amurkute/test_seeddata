#ifndef UOQCIS_H
#define UOQCIS_H
/****************************************************************************/
/* ## INIT    DATE   AUDIT TRAIL                                            */
/* -- ----  -------- ------------------------------------------------------ */
/*                   RELEASE:2.0.3                                          */
/*  1 CJL   03/24/95 Added UoutputMapString, changed UGetMapping            */
/*  2  MH   03/28/95 As part of bug 4319, added start column parameter to   */
/*                   UOutputMapString                                       */
/*  3 EBR   10/30/95 Bug #5921 - Added sForceRecalcInd to                   */
/*                   GetProrationFactor().                                  */
/*                                                                          */
/* AUDIT TRAIL:8.0 */
/* AUDIT TRAIL END */
/****************************************************************************/
/****************************************************************************

 UOQCIS - Routines for manipulating data that is specific to the CIS database.

 UGetCustomerName     - accesses UCBCUST and builds the customer name string
                        for the specified customer number.

 UGetPremAddress1Line - accesses UCBPREM and builds the premises address
                        string for the specified premises code.

 UGetPremAddress      - accesses UCBPREM and builds the premises address
                        string for the specified premises code and puts the
                        parts into 3 strings containing street address, unit
                        description, city/state/zip.

 UGetMapping          - accesses the UTRMAPS table and builds the mapping
                        string.

*****************************************************************************/
#define pUOBSYSC          GetUobsysc()

#define ORA_CPY_SET(Target, Source, NullInd) OraCpySet(Target, Source, \
NullInd, sizeof(Target))

typedef enum
   {M_FPRINTF, M_PRTSTR, M_FPRNT} PRINT_MODE;

typedef struct UOBSYSC_STRUC
   {
   char      szKey                      [5  ];
   char      szCashDist                 [2  ];
   char      szSeq                      [2  ];
   char      szSkipBillInd              [2  ];
   char      szReadInactiveService      [2  ];
   char      szActivityDate             [13 ];
   char      szUserID                   [31 ];
   char      szDispBatchTotalAppv       [2  ];
   char      szRereadInd                [2  ];
   char      szAtypCodeMail             [3  ];
   char      szBmsgOption               [2  ];
   char      szPyarPenaltyInd           [2  ];
   char      szRequireMoveOutInd        [2  ];
   char      szDiscOutOfCyclInd         [2  ];
   char      szDateFormat               [2  ];
   char      szCenturyPivot             [3  ];
   char      szCashDfsv                 [3  ];
   char      szProrationInd             [2  ];
   long      lSkipBillDays                   ;
   double    dMinDraftAmt                    ;
   long      lDaysDraft                      ;
   char      szSvcoBasis                [2  ];
   char      szSotpCodeMoveIn           [5  ];
   char      szSotpCodeMoveOut          [5  ];
   char      szLastFeedDocCode          [9  ];
   char      szFeedDocInd               [2  ];
   char      szAllowReversalsInd        [2  ];
   char      szNtypCodeHhd              [7  ];
   long      lBadCheckCount                  ;
   long      lBadCheckMonths                 ;
   char      szSratCodeRdup             [5  ];
   char      szPrintDraftInd            [2  ];
   char      szBankCodeUtil             [4  ];
   char      szPycdCodeDraft            [5  ];
   char      szAutoARXferInd            [2  ];
   char      szProratePartialPymt       [2  ];
   char      szNodupMemberCodeInd       [2  ];
   char      szPrintWeatherInd          [2  ];
   char      szStreetValInd             [2  ];
   char      szRecalcInd                [2  ];
   char      szDiscountLevel            [2  ];
   char      szDiscountRate             [5  ];
   long      lDiscountDays                   ;
   char      szReadBillSchedInd         [2  ];
   char      szRecalcAdjCode            [5  ];
   char      szDiscAdjmCode             [5  ];
   char      szDiscRevAdjmCode          [5  ];
   char      szReadBillInMonthInd       [2  ];
   } UOBSYSC_STRUC;

#define  CNT_MAP_PROMPTS      15

extern int  UGetCustomerName(long lCustCode, char *pszCustName, long lLen);
extern void UGetPremAddress1Line(char *pszPremCode, char *pszAddressOut,
                                short sLen);
extern int UGetPremAddress(char *pszPremCode,
                           char *pszStreetAddr,
                           char *pszApartment,
                           char *pszCityStateZip);

extern int GetUnitDesc(char *pszUTypeCode, char *pszUnitDesc);
extern int UGetMapping(char *pszType, char *pszCode, char *pszASVC,
                       char *pszMapString, short sMaxLen, short sWidth);
extern void UOutputMapString(FILE *fpFile,
                            char *pszMapString,
                            PRINT_MODE ePrintMode,
                            short *psLineNum,
                            short *psTotalLines,
                            long iStartColumn);

extern void GetProrationFactor( long    lCustCode,
                                char   *pszPremCode,
                                long    lMasterCust,
                                long    lDueDate,
                                long    lPriority,
                                double  dBalance,
                                long    lApplicationDate,
                                double *pdFactor,
                                short   sForceRecalcInd );

extern UOBSYSC_STRUC *GetUobsysc(void);

extern void OraCpySet(void *pvTarget, void *pvSource,
                         short sNi, short sSizeTarget);


#endif
